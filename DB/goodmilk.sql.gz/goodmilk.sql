-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 15, 2015 at 08:20 AM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `goodmilk`
--

-- --------------------------------------------------------

--
-- Table structure for table `access`
--

CREATE TABLE IF NOT EXISTS `access` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `mask` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(255) NOT NULL DEFAULT '',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `access`
--


-- --------------------------------------------------------

--
-- Table structure for table `accesslog`
--

CREATE TABLE IF NOT EXISTS `accesslog` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `sid` varchar(64) NOT NULL DEFAULT '',
  `title` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `url` text,
  `hostname` varchar(128) DEFAULT NULL,
  `uid` int(10) unsigned DEFAULT '0',
  `timer` int(10) unsigned NOT NULL DEFAULT '0',
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`aid`),
  KEY `accesslog_timestamp` (`timestamp`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `accesslog`
--


-- --------------------------------------------------------

--
-- Table structure for table `actions`
--

CREATE TABLE IF NOT EXISTS `actions` (
  `aid` varchar(255) NOT NULL DEFAULT '0',
  `type` varchar(32) NOT NULL DEFAULT '',
  `callback` varchar(255) NOT NULL DEFAULT '',
  `parameters` longtext NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `actions`
--

INSERT INTO `actions` (`aid`, `type`, `callback`, `parameters`, `description`) VALUES
('comment_publish_action', 'comment', 'comment_publish_action', '', 'Publish comment'),
('comment_unpublish_action', 'comment', 'comment_unpublish_action', '', 'Unpublish comment'),
('node_publish_action', 'node', 'node_publish_action', '', 'Publish post'),
('node_unpublish_action', 'node', 'node_unpublish_action', '', 'Unpublish post'),
('node_make_sticky_action', 'node', 'node_make_sticky_action', '', 'Make post sticky'),
('node_make_unsticky_action', 'node', 'node_make_unsticky_action', '', 'Make post unsticky'),
('node_promote_action', 'node', 'node_promote_action', '', 'Promote post to front page'),
('node_unpromote_action', 'node', 'node_unpromote_action', '', 'Remove post from front page'),
('node_save_action', 'node', 'node_save_action', '', 'Save post'),
('user_block_user_action', 'user', 'user_block_user_action', '', 'Block current user'),
('user_block_ip_action', 'user', 'user_block_ip_action', '', 'Ban IP address of current user'),
('imagecache_flush_action', 'node', 'imagecache_flush_action', '', 'ImageCache: Flush ALL presets for this node''s filefield images'),
('imagecache_generate_all_action', 'node', 'imagecache_generate_all_action', '', 'ImageCache: Generate ALL presets for this node''s filefield images');

-- --------------------------------------------------------

--
-- Table structure for table `actions_aid`
--

CREATE TABLE IF NOT EXISTS `actions_aid` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `actions_aid`
--


-- --------------------------------------------------------

--
-- Table structure for table `authmap`
--

CREATE TABLE IF NOT EXISTS `authmap` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `authname` varchar(128) NOT NULL DEFAULT '',
  `module` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`aid`),
  UNIQUE KEY `authname` (`authname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `authmap`
--


-- --------------------------------------------------------

--
-- Table structure for table `batch`
--

CREATE TABLE IF NOT EXISTS `batch` (
  `bid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(64) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `batch` longtext,
  PRIMARY KEY (`bid`),
  KEY `token` (`token`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `batch`
--

INSERT INTO `batch` (`bid`, `token`, `timestamp`, `batch`) VALUES
(2, '4710f10fad82ebab35e1dae3ea370b2d', 1421132071, 'a:10:{s:4:"sets";a:1:{i:0;a:12:{s:7:"sandbox";a:0:{}s:7:"results";a:1:{i:0;s:40:"sites/all/modules/cck/translations/vi.po";}s:7:"success";b:1;s:10:"operations";a:0:{}s:5:"title";s:32:"Importing interface translations";s:12:"init_message";s:26:"Starting import<br/>&nbsp;";s:13:"error_message";s:38:"Error importing interface translations";s:4:"file";s:21:"./includes/locale.inc";s:11:"#components";a:62:{i:0;s:3:"zen";i:1;s:7:"garland";i:2;s:6:"system";i:3;s:10:"admin_menu";i:4;s:14:"better_formats";i:5;s:5:"block";i:6;s:5:"color";i:7;s:7:"comment";i:8;s:7:"contact";i:9;s:13:"contact_field";i:10;s:17:"contact_listfield";i:11;s:14:"contact_option";i:12;s:17:"contact_textfield";i:13;s:7:"content";i:14;s:12:"content_copy";i:15;s:19:"content_permissions";i:16;s:4:"date";i:17;s:8:"date_api";i:18;s:13:"date_timezone";i:19;s:5:"dblog";i:20;s:5:"devel";i:21;s:10:"fieldgroup";i:22;s:9:"filefield";i:23;s:6:"filter";i:24;s:15:"googleanalytics";i:25;s:4:"help";i:26;s:8:"imageapi";i:27;s:10:"imagecache";i:28;s:10:"imagefield";i:29;s:4:"imce";i:30;s:12:"imce_wysiwyg";i:31;s:6:"insert";i:32;s:9:"lightbox2";i:33;s:6:"locale";i:34;s:4:"menu";i:35;s:10:"nice_menus";i:36;s:4:"node";i:37;s:13:"nodereference";i:38;s:6:"number";i:39;s:13:"optionwidgets";i:40;s:4:"path";i:41;s:8:"pathauto";i:42;s:3:"php";i:43;s:6:"search";i:44;s:10:"statistics";i:45;s:6:"syslog";i:46;s:8:"taxonomy";i:47;s:4:"text";i:48;s:5:"token";i:49;s:13:"token_actions";i:50;s:11:"translation";i:51;s:6:"update";i:52;s:4:"user";i:53;s:13:"userreference";i:54;s:5:"views";i:55;s:17:"views_customfield";i:56;s:12:"views_export";i:57;s:17:"views_galleriffic";i:58;s:8:"views_ui";i:59;s:14:"viewsphpfilter";i:60;s:7:"wysiwyg";i:61;s:9:"bootstrap";}s:8:"finished";s:31:"_locale_batch_language_finished";s:16:"progress_message";s:31:"Remaining @remaining of @total.";s:5:"total";i:1;}}s:4:"form";a:25:{s:13:"language list";a:20:{s:5:"#type";s:8:"fieldset";s:6:"#title";s:19:"Predefined language";s:12:"#collapsible";b:1;s:8:"langcode";a:24:{s:5:"#type";s:6:"select";s:6:"#title";s:13:"Language name";s:14:"#default_value";s:2:"ab";s:8:"#options";a:177:{s:2:"ab";s:35:"Abkhazian (аҧсуа бызшәа)";s:2:"aa";s:4:"Afar";s:2:"af";s:9:"Afrikaans";s:2:"ak";s:4:"Akan";s:2:"sq";s:16:"Albanian (Shqip)";s:2:"am";s:22:"Amharic (አማርኛ)";s:2:"ar";s:23:"Arabic (العربية)";s:2:"hy";s:25:"Armenian (Հայերեն)";s:2:"as";s:8:"Assamese";s:2:"av";s:4:"Avar";s:2:"ae";s:7:"Avestan";s:2:"ay";s:6:"Aymara";s:2:"az";s:25:"Azerbaijani (azərbaycan)";s:2:"bm";s:20:"Bambara (Bamanankan)";s:2:"ba";s:7:"Bashkir";s:2:"eu";s:16:"Basque (Euskera)";s:2:"be";s:33:"Belarusian (Беларуская)";s:2:"bn";s:7:"Bengali";s:2:"dz";s:7:"Bhutani";s:2:"bh";s:6:"Bihari";s:2:"bi";s:7:"Bislama";s:2:"bs";s:18:"Bosnian (Bosanski)";s:2:"br";s:6:"Breton";s:2:"bg";s:30:"Bulgarian (Български)";s:2:"my";s:7:"Burmese";s:2:"km";s:9:"Cambodian";s:2:"ca";s:17:"Catalan (Català)";s:2:"ch";s:8:"Chamorro";s:2:"ce";s:7:"Chechen";s:2:"ny";s:8:"Chichewa";s:7:"zh-hans";s:34:"Chinese, Simplified (简体中文)";s:7:"zh-hant";s:35:"Chinese, Traditional (繁體中文)";s:2:"cv";s:7:"Chuvash";s:2:"kw";s:7:"Cornish";s:2:"co";s:8:"Corsican";s:2:"cr";s:4:"Cree";s:2:"hr";s:19:"Croatian (Hrvatski)";s:2:"cs";s:17:"Czech (Čeština)";s:2:"da";s:14:"Danish (Dansk)";s:2:"nl";s:18:"Dutch (Nederlands)";s:2:"eo";s:9:"Esperanto";s:2:"et";s:16:"Estonian (Eesti)";s:2:"ee";s:12:"Ewe (Ɛʋɛ)";s:2:"fo";s:8:"Faeroese";s:2:"fj";s:4:"Fiji";s:2:"fi";s:15:"Finnish (Suomi)";s:2:"fr";s:18:"French (Français)";s:2:"fy";s:15:"Frisian (Frysk)";s:2:"ff";s:16:"Fulah (Fulfulde)";s:2:"gl";s:17:"Galician (Galego)";s:2:"ka";s:8:"Georgian";s:2:"de";s:16:"German (Deutsch)";s:2:"el";s:24:"Greek (Ελληνικά)";s:2:"kl";s:11:"Greenlandic";s:2:"gn";s:7:"Guarani";s:2:"gu";s:8:"Gujarati";s:2:"ha";s:5:"Hausa";s:2:"he";s:19:"Hebrew (עברית)";s:2:"hz";s:6:"Herero";s:2:"hi";s:26:"Hindi (हिन्दी)";s:2:"ho";s:9:"Hiri Motu";s:2:"hu";s:18:"Hungarian (Magyar)";s:2:"is";s:21:"Icelandic (Íslenska)";s:2:"ig";s:4:"Igbo";s:2:"id";s:29:"Indonesian (Bahasa Indonesia)";s:2:"ia";s:11:"Interlingua";s:2:"ie";s:11:"Interlingue";s:2:"iu";s:9:"Inuktitut";s:2:"ik";s:7:"Inupiak";s:2:"ga";s:15:"Irish (Gaeilge)";s:2:"it";s:18:"Italian (Italiano)";s:2:"ja";s:20:"Japanese (日本語)";s:2:"jv";s:8:"Javanese";s:2:"kn";s:25:"Kannada (ಕನ್ನಡ)";s:2:"kr";s:6:"Kanuri";s:2:"ks";s:8:"Kashmiri";s:2:"kk";s:19:"Kazakh (Қазақ)";s:2:"ki";s:6:"Kikuyu";s:2:"rw";s:11:"Kinyarwanda";s:2:"ky";s:22:"Kirghiz (Кыргыз)";s:2:"rn";s:7:"Kirundi";s:2:"kv";s:4:"Komi";s:2:"kg";s:5:"Kongo";s:2:"ko";s:18:"Korean (한국어)";s:2:"ku";s:16:"Kurdish (Kurdî)";s:2:"kj";s:8:"Kwanyama";s:2:"lo";s:8:"Laothian";s:2:"la";s:14:"Latin (Latina)";s:2:"lv";s:19:"Latvian (Latviešu)";s:2:"ln";s:7:"Lingala";s:2:"lt";s:22:"Lithuanian (Lietuvių)";s:2:"lg";s:7:"Luganda";s:2:"lb";s:13:"Luxembourgish";s:2:"mk";s:33:"Macedonian (Македонски)";s:2:"mg";s:8:"Malagasy";s:2:"ms";s:21:"Malay (Bahasa Melayu)";s:2:"ml";s:30:"Malayalam (മലയാളം)";s:2:"dv";s:9:"Maldivian";s:2:"mt";s:15:"Maltese (Malti)";s:2:"gv";s:4:"Manx";s:2:"mi";s:5:"Maori";s:2:"mr";s:7:"Marathi";s:2:"mh";s:11:"Marshallese";s:2:"mo";s:9:"Moldavian";s:2:"mn";s:9:"Mongolian";s:2:"na";s:5:"Nauru";s:2:"nv";s:6:"Navajo";s:2:"ng";s:6:"Ndonga";s:2:"ne";s:6:"Nepali";s:2:"nd";s:13:"North Ndebele";s:2:"se";s:13:"Northern Sami";s:2:"nb";s:27:"Norwegian Bokmål (Bokmål)";s:2:"nn";s:27:"Norwegian Nynorsk (Nynorsk)";s:2:"oc";s:7:"Occitan";s:2:"cu";s:12:"Old Slavonic";s:2:"or";s:5:"Oriya";s:2:"om";s:5:"Oromo";s:2:"os";s:8:"Ossetian";s:2:"pi";s:4:"Pali";s:2:"ps";s:17:"Pashto (پښتو)";s:2:"fa";s:20:"Persian (فارسی)";s:2:"pl";s:15:"Polish (Polski)";s:5:"pt-br";s:31:"Portuguese, Brazil (Português)";s:5:"pt-pt";s:33:"Portuguese, Portugal (Português)";s:2:"pa";s:7:"Punjabi";s:2:"qu";s:7:"Quechua";s:2:"rm";s:14:"Rhaeto-Romance";s:2:"ro";s:19:"Romanian (Română)";s:2:"ru";s:24:"Russian (Русский)";s:2:"sm";s:6:"Samoan";s:2:"sg";s:5:"Sango";s:2:"sa";s:8:"Sanskrit";s:2:"sc";s:9:"Sardinian";s:2:"gd";s:12:"Scots Gaelic";s:2:"sr";s:22:"Serbian (Српски)";s:2:"sh";s:14:"Serbo-Croatian";s:2:"st";s:7:"Sesotho";s:2:"tn";s:8:"Setswana";s:2:"sn";s:5:"Shona";s:2:"sd";s:6:"Sindhi";s:2:"si";s:25:"Sinhala (සිංහල)";s:2:"ss";s:7:"Siswati";s:2:"sk";s:20:"Slovak (Slovenčina)";s:2:"sl";s:25:"Slovenian (Slovenščina)";s:2:"so";s:6:"Somali";s:2:"nr";s:13:"South Ndebele";s:2:"es";s:18:"Spanish (Español)";s:2:"su";s:8:"Sudanese";s:2:"sw";s:19:"Swahili (Kiswahili)";s:2:"sv";s:17:"Swedish (Svenska)";s:2:"tl";s:7:"Tagalog";s:2:"ty";s:8:"Tahitian";s:2:"tg";s:5:"Tajik";s:2:"ta";s:23:"Tamil (தமிழ்)";s:2:"tt";s:16:"Tatar (Tatarça)";s:2:"te";s:27:"Telugu (తెలుగు)";s:2:"th";s:28:"Thai (ภาษาไทย)";s:2:"bo";s:7:"Tibetan";s:2:"ti";s:8:"Tigrinya";s:2:"to";s:5:"Tonga";s:2:"ts";s:6:"Tsonga";s:2:"tr";s:18:"Turkish (Türkçe)";s:2:"tk";s:7:"Turkmen";s:2:"tw";s:3:"Twi";s:2:"ug";s:6:"Uighur";s:2:"uk";s:32:"Ukrainian (Українська)";s:2:"ur";s:15:"Urdu (اردو)";s:2:"uz";s:14:"Uzbek (o''zbek)";s:2:"ve";s:5:"Venda";s:2:"vi";s:27:"Vietnamese (Tiếng Việt)";s:2:"cy";s:15:"Welsh (Cymraeg)";s:2:"wo";s:5:"Wolof";s:2:"xh";s:16:"Xhosa (isiXhosa)";s:2:"yi";s:7:"Yiddish";s:2:"yo";s:17:"Yoruba (Yorùbá)";s:2:"za";s:6:"Zhuang";s:2:"zu";s:14:"Zulu (isiZulu)";}s:12:"#description";s:169:"Select the desired language and click the <em>Add language</em> button. (Use the <em>Custom language</em> options if your desired language does not appear in this list.)";s:5:"#post";a:5:{s:8:"langcode";s:2:"vi";s:2:"op";s:12:"Add language";s:13:"form_build_id";s:37:"form-aa18f9ca36599bb8bc8be74756e8e396";s:10:"form_token";s:32:"f10614472ad3294b3ffafb1619dc158a";s:7:"form_id";s:32:"locale_languages_predefined_form";}s:11:"#programmed";b:0;s:5:"#tree";b:0;s:8:"#parents";a:1:{i:0;s:8:"langcode";}s:14:"#array_parents";a:2:{i:0;s:13:"language list";i:1;s:8:"langcode";}s:7:"#weight";i:0;s:10:"#processed";b:1;s:11:"#attributes";a:0:{}s:9:"#required";b:0;s:6:"#input";b:1;s:5:"#size";i:0;s:9:"#multiple";b:0;s:8:"#process";a:1:{i:0;s:16:"form_expand_ahah";}s:5:"#name";s:8:"langcode";s:3:"#id";s:13:"edit-langcode";s:6:"#value";s:2:"vi";s:17:"#needs_validation";b:1;s:16:"#defaults_loaded";b:1;s:7:"#sorted";b:1;}s:6:"submit";a:20:{s:5:"#type";s:6:"submit";s:6:"#value";s:12:"Add language";s:5:"#post";a:5:{s:8:"langcode";s:2:"vi";s:2:"op";s:12:"Add language";s:13:"form_build_id";s:37:"form-aa18f9ca36599bb8bc8be74756e8e396";s:10:"form_token";s:32:"f10614472ad3294b3ffafb1619dc158a";s:7:"form_id";s:32:"locale_languages_predefined_form";}s:11:"#programmed";b:0;s:5:"#tree";b:0;s:8:"#parents";a:1:{i:0;s:6:"submit";}s:14:"#array_parents";a:2:{i:0;s:13:"language list";i:1;s:6:"submit";}s:7:"#weight";d:0.001000000000000000020816681711721685132943093776702880859375;s:10:"#processed";b:1;s:12:"#description";N;s:11:"#attributes";a:0:{}s:9:"#required";b:0;s:6:"#input";b:1;s:5:"#name";s:2:"op";s:12:"#button_type";s:6:"submit";s:25:"#executes_submit_callback";b:1;s:8:"#process";a:1:{i:0;s:16:"form_expand_ahah";}s:3:"#id";s:11:"edit-submit";s:16:"#defaults_loaded";b:1;s:7:"#sorted";b:1;}s:5:"#post";a:5:{s:8:"langcode";s:2:"vi";s:2:"op";s:12:"Add language";s:13:"form_build_id";s:37:"form-aa18f9ca36599bb8bc8be74756e8e396";s:10:"form_token";s:32:"f10614472ad3294b3ffafb1619dc158a";s:7:"form_id";s:32:"locale_languages_predefined_form";}s:11:"#programmed";b:0;s:5:"#tree";b:0;s:8:"#parents";a:1:{i:0;s:13:"language list";}s:14:"#array_parents";a:1:{i:0;s:13:"language list";}s:7:"#weight";i:0;s:10:"#processed";b:0;s:12:"#description";N;s:11:"#attributes";a:0:{}s:9:"#required";b:0;s:10:"#collapsed";b:0;s:6:"#value";N;s:8:"#process";a:1:{i:0;s:16:"form_expand_ahah";}s:16:"#defaults_loaded";b:1;s:7:"#sorted";b:1;}s:11:"#parameters";a:2:{i:0;s:32:"locale_languages_predefined_form";i:1;a:3:{s:7:"storage";N;s:9:"submitted";b:0;s:4:"post";a:5:{s:8:"langcode";s:2:"vi";s:2:"op";s:12:"Add language";s:13:"form_build_id";s:37:"form-aa18f9ca36599bb8bc8be74756e8e396";s:10:"form_token";s:32:"f10614472ad3294b3ffafb1619dc158a";s:7:"form_id";s:32:"locale_languages_predefined_form";}}}s:9:"#build_id";s:37:"form-4a2002901fa6fb5e5a1fe48b64ebaab5";s:5:"#type";s:4:"form";s:11:"#programmed";b:0;s:13:"form_build_id";a:18:{s:5:"#type";s:6:"hidden";s:6:"#value";s:37:"form-4a2002901fa6fb5e5a1fe48b64ebaab5";s:3:"#id";s:37:"form-4a2002901fa6fb5e5a1fe48b64ebaab5";s:5:"#name";s:13:"form_build_id";s:5:"#post";a:5:{s:8:"langcode";s:2:"vi";s:2:"op";s:12:"Add language";s:13:"form_build_id";s:37:"form-aa18f9ca36599bb8bc8be74756e8e396";s:10:"form_token";s:32:"f10614472ad3294b3ffafb1619dc158a";s:7:"form_id";s:32:"locale_languages_predefined_form";}s:11:"#programmed";b:0;s:5:"#tree";b:0;s:8:"#parents";a:1:{i:0;s:13:"form_build_id";}s:14:"#array_parents";a:1:{i:0;s:13:"form_build_id";}s:7:"#weight";d:0.001000000000000000020816681711721685132943093776702880859375;s:10:"#processed";b:1;s:12:"#description";N;s:11:"#attributes";a:0:{}s:9:"#required";b:0;s:6:"#input";b:1;s:8:"#process";a:1:{i:0;s:16:"form_expand_ahah";}s:16:"#defaults_loaded";b:1;s:7:"#sorted";b:1;}s:6:"#token";s:32:"locale_languages_predefined_form";s:10:"form_token";a:19:{s:3:"#id";s:48:"edit-locale-languages-predefined-form-form-token";s:5:"#type";s:5:"token";s:14:"#default_value";s:32:"f10614472ad3294b3ffafb1619dc158a";s:5:"#post";a:5:{s:8:"langcode";s:2:"vi";s:2:"op";s:12:"Add language";s:13:"form_build_id";s:37:"form-aa18f9ca36599bb8bc8be74756e8e396";s:10:"form_token";s:32:"f10614472ad3294b3ffafb1619dc158a";s:7:"form_id";s:32:"locale_languages_predefined_form";}s:11:"#programmed";b:0;s:5:"#tree";b:0;s:8:"#parents";a:1:{i:0;s:10:"form_token";}s:14:"#array_parents";a:1:{i:0;s:10:"form_token";}s:7:"#weight";d:0.00200000000000000004163336342344337026588618755340576171875;s:10:"#processed";b:0;s:12:"#description";N;s:11:"#attributes";a:0:{}s:9:"#required";b:0;s:6:"#input";b:1;s:5:"#name";s:10:"form_token";s:6:"#value";s:32:"f10614472ad3294b3ffafb1619dc158a";s:17:"#needs_validation";b:1;s:16:"#defaults_loaded";b:1;s:7:"#sorted";b:1;}s:7:"form_id";a:18:{s:5:"#type";s:6:"hidden";s:6:"#value";s:32:"locale_languages_predefined_form";s:3:"#id";s:37:"edit-locale-languages-predefined-form";s:5:"#post";a:5:{s:8:"langcode";s:2:"vi";s:2:"op";s:12:"Add language";s:13:"form_build_id";s:37:"form-aa18f9ca36599bb8bc8be74756e8e396";s:10:"form_token";s:32:"f10614472ad3294b3ffafb1619dc158a";s:7:"form_id";s:32:"locale_languages_predefined_form";}s:11:"#programmed";b:0;s:5:"#tree";b:0;s:8:"#parents";a:1:{i:0;s:7:"form_id";}s:14:"#array_parents";a:1:{i:0;s:7:"form_id";}s:7:"#weight";d:0.003000000000000000062450045135165055398829281330108642578125;s:10:"#processed";b:1;s:12:"#description";N;s:11:"#attributes";a:0:{}s:9:"#required";b:0;s:6:"#input";b:1;s:8:"#process";a:1:{i:0;s:16:"form_expand_ahah";}s:5:"#name";s:7:"form_id";s:16:"#defaults_loaded";b:1;s:7:"#sorted";b:1;}s:3:"#id";s:32:"locale-languages-predefined-form";s:12:"#description";N;s:11:"#attributes";a:0:{}s:9:"#required";b:0;s:5:"#tree";b:0;s:8:"#parents";a:0:{}s:7:"#method";s:4:"post";s:7:"#action";s:37:"/goodmilk/admin/settings/language/add";s:9:"#validate";a:1:{i:0;s:41:"locale_languages_predefined_form_validate";}s:7:"#submit";a:1:{i:0;s:39:"locale_languages_predefined_form_submit";}s:12:"#after_build";a:1:{i:0;s:20:"wysiwyg_process_form";}s:5:"#post";a:5:{s:8:"langcode";s:2:"vi";s:2:"op";s:12:"Add language";s:13:"form_build_id";s:37:"form-aa18f9ca36599bb8bc8be74756e8e396";s:10:"form_token";s:32:"f10614472ad3294b3ffafb1619dc158a";s:7:"form_id";s:32:"locale_languages_predefined_form";}s:10:"#processed";b:0;s:16:"#defaults_loaded";b:1;s:7:"#sorted";b:1;s:17:"#after_build_done";b:1;}s:10:"form_state";a:6:{s:7:"storage";N;s:9:"submitted";b:1;s:6:"values";a:6:{s:8:"langcode";s:2:"vi";s:2:"op";s:12:"Add language";s:6:"submit";s:12:"Add language";s:13:"form_build_id";s:37:"form-4a2002901fa6fb5e5a1fe48b64ebaab5";s:10:"form_token";s:32:"f10614472ad3294b3ffafb1619dc158a";s:7:"form_id";s:32:"locale_languages_predefined_form";}s:14:"clicked_button";a:18:{s:5:"#type";s:6:"submit";s:6:"#value";s:12:"Add language";s:5:"#post";a:5:{s:8:"langcode";s:2:"vi";s:2:"op";s:12:"Add language";s:13:"form_build_id";s:37:"form-aa18f9ca36599bb8bc8be74756e8e396";s:10:"form_token";s:32:"f10614472ad3294b3ffafb1619dc158a";s:7:"form_id";s:32:"locale_languages_predefined_form";}s:11:"#programmed";b:0;s:5:"#tree";b:0;s:8:"#parents";a:1:{i:0;s:6:"submit";}s:14:"#array_parents";a:2:{i:0;s:13:"language list";i:1;s:6:"submit";}s:7:"#weight";d:0.001000000000000000020816681711721685132943093776702880859375;s:10:"#processed";b:0;s:12:"#description";N;s:11:"#attributes";a:0:{}s:9:"#required";b:0;s:6:"#input";b:1;s:5:"#name";s:2:"op";s:12:"#button_type";s:6:"submit";s:25:"#executes_submit_callback";b:1;s:8:"#process";a:1:{i:0;s:16:"form_expand_ahah";}s:3:"#id";s:11:"edit-submit";}s:13:"process_input";b:1;s:8:"redirect";s:23:"admin/settings/language";}s:11:"progressive";b:1;s:11:"current_set";i:0;s:3:"url";s:5:"batch";s:11:"source_page";s:27:"admin/settings/language/add";s:8:"redirect";N;s:2:"id";s:1:"2";s:13:"error_message";s:84:"Please continue to <a href="/goodmilk/batch?id=2&amp;op=finished">the error page</a>";}');

-- --------------------------------------------------------

--
-- Table structure for table `better_formats_defaults`
--

CREATE TABLE IF NOT EXISTS `better_formats_defaults` (
  `rid` int(10) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `format` mediumint(8) unsigned NOT NULL,
  `type_weight` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `weight` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `better_formats_defaults`
--

INSERT INTO `better_formats_defaults` (`rid`, `type`, `format`, `type_weight`, `weight`) VALUES
(1, 'node', 0, 1, 0),
(1, 'comment', 0, 1, 0),
(1, 'block', 0, 1, 25),
(2, 'node', 0, 1, 0),
(2, 'comment', 0, 1, 0),
(2, 'block', 0, 1, 25);

-- --------------------------------------------------------

--
-- Table structure for table `blocks`
--

CREATE TABLE IF NOT EXISTS `blocks` (
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(64) NOT NULL DEFAULT '',
  `delta` varchar(32) NOT NULL DEFAULT '0',
  `theme` varchar(64) NOT NULL DEFAULT '',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `weight` tinyint(4) NOT NULL DEFAULT '0',
  `region` varchar(64) NOT NULL DEFAULT '',
  `custom` tinyint(4) NOT NULL DEFAULT '0',
  `throttle` tinyint(4) NOT NULL DEFAULT '0',
  `visibility` tinyint(4) NOT NULL DEFAULT '0',
  `pages` text NOT NULL,
  `title` varchar(64) NOT NULL DEFAULT '',
  `cache` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `tmd` (`theme`,`module`,`delta`),
  KEY `list` (`theme`,`status`,`region`,`weight`,`module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `blocks`
--

INSERT INTO `blocks` (`bid`, `module`, `delta`, `theme`, `status`, `weight`, `region`, `custom`, `throttle`, `visibility`, `pages`, `title`, `cache`) VALUES
(1, 'user', '0', 'garland', 0, -5, '', 0, 0, 0, '', '', -1),
(2, 'user', '1', 'garland', 0, 0, '', 0, 0, 0, '', '', -1),
(3, 'system', '0', 'garland', 1, -5, 'footer', 0, 0, 0, '', '', -1),
(4, 'comment', '0', 'garland', 0, -3, '', 0, 0, 0, '', '', 1),
(5, 'menu', 'primary-links', 'garland', 0, -4, '', 0, 0, 0, '', '', -1),
(6, 'menu', 'secondary-links', 'garland', 0, -2, '', 0, 0, 0, '', '', -1),
(7, 'node', '0', 'garland', 0, -1, '', 0, 0, 0, '', '', -1),
(8, 'user', '2', 'garland', 0, 0, '', 0, 0, 0, '', '', 1),
(9, 'user', '3', 'garland', 0, 1, '', 0, 0, 0, '', '', -1),
(10, 'comment', '0', 'goodmilk', 0, -3, 'header_right_top', 0, 0, 0, '', '', 1),
(11, 'menu', 'primary-links', 'goodmilk', 0, -4, 'header_right_top', 0, 0, 0, '', '', -1),
(12, 'menu', 'secondary-links', 'goodmilk', 0, -2, 'header_right_top', 0, 0, 0, '', '', -1),
(13, 'node', '0', 'goodmilk', 0, -1, 'header_right_top', 0, 0, 0, '', '', -1),
(14, 'system', '0', 'goodmilk', 1, -5, 'header_right_top', 0, 0, 0, '', '', -1),
(15, 'user', '0', 'goodmilk', 0, -5, 'header_right_top', 0, 0, 0, '', '', -1),
(16, 'user', '1', 'goodmilk', 0, 0, 'header_right_top', 0, 0, 0, '', '', -1),
(17, 'user', '2', 'goodmilk', 0, 0, 'header_right_top', 0, 0, 0, '', '', 1),
(18, 'user', '3', 'goodmilk', 0, 1, 'header_right_top', 0, 0, 0, '', '', -1),
(19, 'comment', '0', 'zen', 0, -3, 'sidebar_first', 0, 0, 0, '', '', 1),
(20, 'menu', 'primary-links', 'zen', 0, -4, 'sidebar_first', 0, 0, 0, '', '', -1),
(21, 'menu', 'secondary-links', 'zen', 0, -2, 'sidebar_first', 0, 0, 0, '', '', -1),
(22, 'node', '0', 'zen', 0, -1, 'sidebar_first', 0, 0, 0, '', '', -1),
(23, 'system', '0', 'zen', 1, -5, 'sidebar_first', 0, 0, 0, '', '', -1),
(24, 'user', '0', 'zen', 0, -5, 'sidebar_first', 0, 0, 0, '', '', -1),
(25, 'user', '1', 'zen', 0, 0, 'sidebar_first', 0, 0, 0, '', '', -1),
(26, 'user', '2', 'zen', 0, 0, 'sidebar_first', 0, 0, 0, '', '', 1),
(27, 'user', '3', 'zen', 0, 1, 'sidebar_first', 0, 0, 0, '', '', -1),
(28, 'user', '0', 'bootstrap', 0, -5, 'sidebar_first', 0, 0, 0, '', '', -1),
(29, 'menu', 'primary-links', 'bootstrap', 0, -4, 'sidebar_first', 0, 0, 0, '', '', -1),
(30, 'comment', '0', 'bootstrap', 0, -3, 'sidebar_first', 0, 0, 0, '', '', 1),
(31, 'menu', 'secondary-links', 'bootstrap', 0, -2, 'sidebar_first', 0, 0, 0, '', '', -1),
(32, 'node', '0', 'bootstrap', 0, -1, 'sidebar_first', 0, 0, 0, '', '', -1),
(33, 'user', '1', 'bootstrap', 0, 0, 'sidebar_first', 0, 0, 0, '', '', -1),
(34, 'user', '2', 'bootstrap', 0, 0, 'sidebar_first', 0, 0, 0, '', '', 1),
(35, 'user', '3', 'bootstrap', 0, 1, 'sidebar_first', 0, 0, 0, '', '', -1),
(36, 'system', '0', 'bootstrap', 1, -5, 'sidebar_first', 0, 0, 0, '', '', -1),
(37, 'locale', '0', 'bootstrap', 0, 0, '', 0, 0, 0, '', '', -1),
(38, 'menu', 'devel', 'bootstrap', 0, 0, '', 0, 0, 0, '', '', -1),
(39, 'search', '0', 'bootstrap', 0, 0, '', 0, 0, 0, '', '', -1),
(40, 'nice_menus', '1', 'bootstrap', 0, 0, '', 0, 0, 0, '', '', -1),
(41, 'nice_menus', '2', 'bootstrap', 0, 0, '', 0, 0, 0, '', '', -1),
(42, 'devel', '0', 'bootstrap', 0, 0, '', 0, 0, 0, '', '', 1),
(43, 'devel', '2', 'bootstrap', 0, 0, '', 0, 0, 0, 'devel/php', '', 1),
(44, 'locale', '0', 'zen', 0, 0, '', 0, 0, 0, '', '', -1),
(45, 'menu', 'devel', 'zen', 0, 0, '', 0, 0, 0, '', '', -1),
(46, 'search', '0', 'zen', 0, 0, '', 0, 0, 0, '', '', -1),
(47, 'nice_menus', '1', 'zen', 0, 0, '', 0, 0, 0, '', '', -1),
(48, 'nice_menus', '2', 'zen', 0, 0, '', 0, 0, 0, '', '', -1),
(49, 'devel', '0', 'zen', 0, 0, '', 0, 0, 0, '', '', 1),
(50, 'devel', '2', 'zen', 0, 0, '', 0, 0, 0, 'devel/php', '', 1),
(51, 'locale', '0', 'garland', 0, 0, '', 0, 0, 0, '', '', -1),
(52, 'menu', 'devel', 'garland', 0, 0, '', 0, 0, 0, '', '', -1),
(53, 'search', '0', 'garland', 0, 0, '', 0, 0, 0, '', '', -1),
(54, 'nice_menus', '1', 'garland', 0, 0, '', 0, 0, 0, '', '', -1),
(55, 'nice_menus', '2', 'garland', 0, 0, '', 0, 0, 0, '', '', -1),
(56, 'devel', '0', 'garland', 0, 0, '', 0, 0, 0, '', '', 1),
(57, 'devel', '2', 'garland', 0, 0, '', 0, 0, 0, 'devel/php', '', 1),
(58, 'poll', '0', 'bootstrap', 0, 0, '', 0, 0, 0, '', '', 1),
(59, 'profile', '0', 'bootstrap', 0, 0, '', 0, 0, 0, '', '', 5),
(60, 'i18npoll', '0', 'bootstrap', 0, 0, '', 0, 0, 0, '', '', 1),
(61, 'poll', '0', 'zen', 0, 0, '', 0, 0, 0, '', '', 1),
(62, 'profile', '0', 'zen', 0, 0, '', 0, 0, 0, '', '', 5),
(63, 'i18npoll', '0', 'zen', 0, 0, '', 0, 0, 0, '', '', 1),
(64, 'poll', '0', 'garland', 0, 0, '', 0, 0, 0, '', '', 1),
(65, 'profile', '0', 'garland', 0, 0, '', 0, 0, 0, '', '', 5),
(66, 'i18npoll', '0', 'garland', 0, 0, '', 0, 0, 0, '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `blocks_roles`
--

CREATE TABLE IF NOT EXISTS `blocks_roles` (
  `module` varchar(64) NOT NULL,
  `delta` varchar(32) NOT NULL,
  `rid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`module`,`delta`,`rid`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blocks_roles`
--


-- --------------------------------------------------------

--
-- Table structure for table `boxes`
--

CREATE TABLE IF NOT EXISTS `boxes` (
  `bid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext,
  `info` varchar(128) NOT NULL DEFAULT '',
  `format` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `info` (`info`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `boxes`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE IF NOT EXISTS `cache` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_block`
--

CREATE TABLE IF NOT EXISTS `cache_block` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_block`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_content`
--

CREATE TABLE IF NOT EXISTS `cache_content` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_content`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_filter`
--

CREATE TABLE IF NOT EXISTS `cache_filter` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_filter`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_form`
--

CREATE TABLE IF NOT EXISTS `cache_form` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_form`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_menu`
--

CREATE TABLE IF NOT EXISTS `cache_menu` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_menu`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_page`
--

CREATE TABLE IF NOT EXISTS `cache_page` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_page`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_update`
--

CREATE TABLE IF NOT EXISTS `cache_update` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_update`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_views`
--

CREATE TABLE IF NOT EXISTS `cache_views` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_views`
--


-- --------------------------------------------------------

--
-- Table structure for table `cache_views_data`
--

CREATE TABLE IF NOT EXISTS `cache_views_data` (
  `cid` varchar(255) NOT NULL DEFAULT '',
  `data` longblob,
  `expire` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `headers` text,
  `serialized` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`cid`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cache_views_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT '0',
  `nid` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `subject` varchar(64) NOT NULL DEFAULT '',
  `comment` longtext NOT NULL,
  `hostname` varchar(128) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `format` smallint(6) NOT NULL DEFAULT '0',
  `thread` varchar(255) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `mail` varchar(64) DEFAULT NULL,
  `homepage` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cid`),
  KEY `pid` (`pid`),
  KEY `nid` (`nid`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `cid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL DEFAULT '',
  `recipients` longtext NOT NULL,
  `reply` longtext NOT NULL,
  `weight` tinyint(4) NOT NULL DEFAULT '0',
  `selected` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  UNIQUE KEY `category` (`category`),
  KEY `list` (`weight`,`category`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`cid`, `category`, `recipients`, `reply`, `weight`, `selected`) VALUES
(1, 'contact', 'admin@goodsoft.com', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `contact_fields`
--

CREATE TABLE IF NOT EXISTS `contact_fields` (
  `field_name` varchar(255) NOT NULL DEFAULT '',
  `field_type` varchar(255) NOT NULL,
  `settings` text NOT NULL,
  `required` int(11) NOT NULL DEFAULT '0',
  `enabled` int(11) NOT NULL DEFAULT '1',
  `weight` int(11) DEFAULT NULL,
  `core` int(11) DEFAULT '0',
  `field_group` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`field_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contact_fields`
--

INSERT INTO `contact_fields` (`field_name`, `field_type`, `settings`, `required`, `enabled`, `weight`, `core`, `field_group`) VALUES
('name', 'textfield', 'a:1:{s:5:"title";s:9:"Your name";}', 1, 1, -10, 1, ''),
('mail', 'textfield', 'a:1:{s:5:"title";s:19:"Your e-mail address";}', 1, 1, -8, 1, ''),
('subject', 'textfield', 'a:1:{s:5:"title";s:7:"Subject";}', 1, 1, -6, 1, ''),
('cid', 'value', 'a:1:{s:5:"title";N;}', 0, 1, -5, 1, ''),
('message', 'textarea', 'a:1:{s:5:"title";s:7:"Message";}', 1, 1, -4, 1, ''),
('field_address', 'textfield', 'a:7:{s:5:"title";s:7:"Address";s:11:"description";s:0:"";s:6:"prefix";s:0:"";s:6:"suffix";s:0:"";s:9:"maxlength";i:255;s:12:"field_prefix";s:0:"";s:12:"field_suffix";s:0:"";}', 0, 1, -9, 0, ''),
('field_phone', 'textfield', 'a:7:{s:5:"title";s:5:"Phone";s:11:"description";s:0:"";s:6:"prefix";s:0:"";s:6:"suffix";s:0:"";s:9:"maxlength";i:255;s:12:"field_prefix";s:0:"";s:12:"field_suffix";s:0:"";}', 0, 1, -7, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `content_group`
--

CREATE TABLE IF NOT EXISTS `content_group` (
  `group_type` varchar(32) NOT NULL DEFAULT 'standard',
  `type_name` varchar(32) NOT NULL DEFAULT '',
  `group_name` varchar(32) NOT NULL DEFAULT '',
  `label` varchar(255) NOT NULL DEFAULT '',
  `settings` mediumtext NOT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`type_name`,`group_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `content_group`
--


-- --------------------------------------------------------

--
-- Table structure for table `content_group_fields`
--

CREATE TABLE IF NOT EXISTS `content_group_fields` (
  `type_name` varchar(32) NOT NULL DEFAULT '',
  `group_name` varchar(32) NOT NULL DEFAULT '',
  `field_name` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`type_name`,`group_name`,`field_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `content_group_fields`
--


-- --------------------------------------------------------

--
-- Table structure for table `content_node_field`
--

CREATE TABLE IF NOT EXISTS `content_node_field` (
  `field_name` varchar(32) NOT NULL DEFAULT '',
  `type` varchar(127) NOT NULL DEFAULT '',
  `global_settings` mediumtext NOT NULL,
  `required` tinyint(4) NOT NULL DEFAULT '0',
  `multiple` tinyint(4) NOT NULL DEFAULT '0',
  `db_storage` tinyint(4) NOT NULL DEFAULT '1',
  `module` varchar(127) NOT NULL DEFAULT '',
  `db_columns` mediumtext NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`field_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `content_node_field`
--

INSERT INTO `content_node_field` (`field_name`, `type`, `global_settings`, `required`, `multiple`, `db_storage`, `module`, `db_columns`, `active`, `locked`) VALUES
('field_contact_phone', 'text', 'a:4:{s:15:"text_processing";s:1:"0";s:10:"max_length";s:0:"";s:14:"allowed_values";s:0:"";s:18:"allowed_values_php";s:0:"";}', 0, 0, 1, 'text', 'a:1:{s:5:"value";a:5:{s:4:"type";s:4:"text";s:4:"size";s:3:"big";s:8:"not null";b:0;s:8:"sortable";b:1;s:5:"views";b:1;}}', 1, 0),
('field_contact_mobile', 'text', 'a:4:{s:15:"text_processing";s:1:"0";s:10:"max_length";s:0:"";s:14:"allowed_values";s:0:"";s:18:"allowed_values_php";s:0:"";}', 0, 0, 1, 'text', 'a:1:{s:5:"value";a:5:{s:4:"type";s:4:"text";s:4:"size";s:3:"big";s:8:"not null";b:0;s:8:"sortable";b:1;s:5:"views";b:1;}}', 1, 0),
('field_contact_address', 'text', 'a:4:{s:15:"text_processing";s:1:"0";s:10:"max_length";s:0:"";s:14:"allowed_values";s:0:"";s:18:"allowed_values_php";s:0:"";}', 0, 0, 1, 'text', 'a:1:{s:5:"value";a:5:{s:4:"type";s:4:"text";s:4:"size";s:3:"big";s:8:"not null";b:0;s:8:"sortable";b:1;s:5:"views";b:1;}}', 1, 0),
('field_contact_email', 'text', 'a:4:{s:15:"text_processing";s:1:"0";s:10:"max_length";s:0:"";s:14:"allowed_values";s:0:"";s:18:"allowed_values_php";s:0:"";}', 0, 0, 1, 'text', 'a:1:{s:5:"value";a:5:{s:4:"type";s:4:"text";s:4:"size";s:3:"big";s:8:"not null";b:0;s:8:"sortable";b:1;s:5:"views";b:1;}}', 1, 0),
('field_contact_fax', 'text', 'a:4:{s:15:"text_processing";s:1:"0";s:10:"max_length";s:0:"";s:14:"allowed_values";s:0:"";s:18:"allowed_values_php";s:0:"";}', 0, 0, 1, 'text', 'a:1:{s:5:"value";a:5:{s:4:"type";s:4:"text";s:4:"size";s:3:"big";s:8:"not null";b:0;s:8:"sortable";b:1;s:5:"views";b:1;}}', 1, 0),
('field_contact_website', 'text', 'a:4:{s:15:"text_processing";s:1:"0";s:10:"max_length";s:0:"";s:14:"allowed_values";s:0:"";s:18:"allowed_values_php";s:0:"";}', 0, 0, 1, 'text', 'a:1:{s:5:"value";a:5:{s:4:"type";s:4:"text";s:4:"size";s:3:"big";s:8:"not null";b:0;s:8:"sortable";b:1;s:5:"views";b:1;}}', 1, 0),
('field_intro_embed', 'text', 'a:4:{s:15:"text_processing";s:1:"0";s:10:"max_length";s:0:"";s:14:"allowed_values";s:0:"";s:18:"allowed_values_php";s:0:"";}', 0, 0, 1, 'text', 'a:1:{s:5:"value";a:5:{s:4:"type";s:4:"text";s:4:"size";s:3:"big";s:8:"not null";b:0;s:8:"sortable";b:1;s:5:"views";b:1;}}', 1, 0),
('field_intro_content', 'text', 'a:4:{s:15:"text_processing";s:1:"1";s:10:"max_length";s:0:"";s:14:"allowed_values";s:0:"";s:18:"allowed_values_php";s:0:"";}', 0, 0, 1, 'text', 'a:2:{s:5:"value";a:5:{s:4:"type";s:4:"text";s:4:"size";s:3:"big";s:8:"not null";b:0;s:8:"sortable";b:1;s:5:"views";b:1;}s:6:"format";a:4:{s:4:"type";s:3:"int";s:8:"unsigned";b:1;s:8:"not null";b:0;s:5:"views";b:0;}}', 1, 0),
('field_home_company_info', 'text', 'a:4:{s:15:"text_processing";s:1:"1";s:10:"max_length";s:0:"";s:14:"allowed_values";s:0:"";s:18:"allowed_values_php";s:0:"";}', 0, 0, 1, 'text', 'a:2:{s:5:"value";a:5:{s:4:"type";s:4:"text";s:4:"size";s:3:"big";s:8:"not null";b:0;s:8:"sortable";b:1;s:5:"views";b:1;}s:6:"format";a:4:{s:4:"type";s:3:"int";s:8:"unsigned";b:1;s:8:"not null";b:0;s:5:"views";b:0;}}', 1, 0),
('field_home_trophic_info', 'text', 'a:4:{s:15:"text_processing";s:1:"1";s:10:"max_length";s:0:"";s:14:"allowed_values";s:0:"";s:18:"allowed_values_php";s:0:"";}', 0, 0, 1, 'text', 'a:2:{s:5:"value";a:5:{s:4:"type";s:4:"text";s:4:"size";s:3:"big";s:8:"not null";b:0;s:8:"sortable";b:1;s:5:"views";b:1;}s:6:"format";a:4:{s:4:"type";s:3:"int";s:8:"unsigned";b:1;s:8:"not null";b:0;s:5:"views";b:0;}}', 1, 0),
('field_home_embed', 'text', 'a:4:{s:15:"text_processing";s:1:"0";s:10:"max_length";s:0:"";s:14:"allowed_values";s:0:"";s:18:"allowed_values_php";s:0:"";}', 0, 0, 1, 'text', 'a:1:{s:5:"value";a:5:{s:4:"type";s:4:"text";s:4:"size";s:3:"big";s:8:"not null";b:0;s:8:"sortable";b:1;s:5:"views";b:1;}}', 1, 0),
('field_distribution_content', 'text', 'a:4:{s:15:"text_processing";s:1:"1";s:10:"max_length";s:0:"";s:14:"allowed_values";s:0:"";s:18:"allowed_values_php";s:0:"";}', 0, 0, 1, 'text', 'a:2:{s:5:"value";a:5:{s:4:"type";s:4:"text";s:4:"size";s:3:"big";s:8:"not null";b:0;s:8:"sortable";b:1;s:5:"views";b:1;}s:6:"format";a:4:{s:4:"type";s:3:"int";s:8:"unsigned";b:1;s:8:"not null";b:0;s:5:"views";b:0;}}', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `content_node_field_instance`
--

CREATE TABLE IF NOT EXISTS `content_node_field_instance` (
  `field_name` varchar(32) NOT NULL DEFAULT '',
  `type_name` varchar(32) NOT NULL DEFAULT '',
  `weight` int(11) NOT NULL DEFAULT '0',
  `label` varchar(255) NOT NULL DEFAULT '',
  `widget_type` varchar(32) NOT NULL DEFAULT '',
  `widget_settings` mediumtext NOT NULL,
  `display_settings` mediumtext NOT NULL,
  `description` mediumtext NOT NULL,
  `widget_module` varchar(127) NOT NULL DEFAULT '',
  `widget_active` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`field_name`,`type_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `content_node_field_instance`
--

INSERT INTO `content_node_field_instance` (`field_name`, `type_name`, `weight`, `label`, `widget_type`, `widget_settings`, `display_settings`, `description`, `widget_module`, `widget_active`) VALUES
('field_contact_phone', 'contact', 0, 'Phone', 'text_textfield', 'a:4:{s:4:"rows";i:5;s:4:"size";s:2:"60";s:13:"default_value";a:1:{i:0;a:2:{s:5:"value";s:0:"";s:14:"_error_element";s:51:"default_value_widget][field_contact_phone][0][value";}}s:17:"default_value_php";N;}', 'a:7:{s:5:"label";a:2:{s:6:"format";s:5:"above";s:7:"exclude";i:0;}s:6:"teaser";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:4:"full";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:4;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:2;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:3;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:5:"token";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}}', '', 'text', 1),
('field_contact_address', 'contact', -4, 'Address', 'text_textfield', 'a:4:{s:4:"rows";i:5;s:4:"size";s:2:"60";s:13:"default_value";a:1:{i:0;a:2:{s:5:"value";s:0:"";s:14:"_error_element";s:53:"default_value_widget][field_contact_address][0][value";}}s:17:"default_value_php";N;}', 'a:7:{s:5:"label";a:2:{s:6:"format";s:5:"above";s:7:"exclude";i:0;}s:6:"teaser";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:4:"full";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:4;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:2;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:3;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:5:"token";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}}', '', 'text', 1),
('field_contact_email', 'contact', -3, 'Email', 'text_textfield', 'a:4:{s:4:"rows";i:5;s:4:"size";s:2:"60";s:13:"default_value";a:1:{i:0;a:2:{s:5:"value";s:0:"";s:14:"_error_element";s:51:"default_value_widget][field_contact_email][0][value";}}s:17:"default_value_php";N;}', 'a:7:{s:5:"label";a:2:{s:6:"format";s:5:"above";s:7:"exclude";i:0;}s:6:"teaser";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:4:"full";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:4;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:2;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:3;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:5:"token";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}}', '', 'text', 1),
('field_contact_fax', 'contact', -2, 'Fax', 'text_textfield', 'a:4:{s:4:"rows";i:5;s:4:"size";s:2:"60";s:13:"default_value";a:1:{i:0;a:2:{s:5:"value";s:0:"";s:14:"_error_element";s:49:"default_value_widget][field_contact_fax][0][value";}}s:17:"default_value_php";N;}', 'a:7:{s:5:"label";a:2:{s:6:"format";s:5:"above";s:7:"exclude";i:0;}s:6:"teaser";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:4:"full";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:4;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:2;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:3;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:5:"token";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}}', '', 'text', 1),
('field_contact_mobile', 'contact', -1, 'Mobile', 'text_textfield', 'a:4:{s:4:"rows";i:5;s:4:"size";s:2:"60";s:13:"default_value";a:1:{i:0;a:2:{s:5:"value";s:0:"";s:14:"_error_element";s:52:"default_value_widget][field_contact_mobile][0][value";}}s:17:"default_value_php";N;}', 'a:7:{s:5:"label";a:2:{s:6:"format";s:5:"above";s:7:"exclude";i:0;}s:6:"teaser";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:4:"full";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:4;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:2;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:3;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:5:"token";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}}', '', 'text', 1),
('field_contact_website', 'contact', 1, 'Website', 'text_textfield', 'a:4:{s:4:"rows";i:5;s:4:"size";s:2:"60";s:13:"default_value";a:1:{i:0;a:2:{s:5:"value";s:0:"";s:14:"_error_element";s:53:"default_value_widget][field_contact_website][0][value";}}s:17:"default_value_php";N;}', 'a:7:{s:5:"label";a:2:{s:6:"format";s:5:"above";s:7:"exclude";i:0;}s:6:"teaser";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:4:"full";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:4;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:2;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:3;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:5:"token";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}}', '', 'text', 1),
('field_intro_embed', 'intro', -4, 'Embed', 'text_textfield', 'a:4:{s:4:"rows";i:5;s:4:"size";s:2:"60";s:13:"default_value";a:1:{i:0;a:2:{s:5:"value";s:0:"";s:14:"_error_element";s:49:"default_value_widget][field_intro_embed][0][value";}}s:17:"default_value_php";N;}', 'a:7:{s:5:"label";a:2:{s:6:"format";s:5:"above";s:7:"exclude";i:0;}s:6:"teaser";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:4:"full";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:4;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:2;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:3;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:5:"token";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}}', '', 'text', 1),
('field_intro_content', 'intro', -3, 'Content', 'text_textarea', 'a:4:{s:4:"rows";s:1:"5";s:4:"size";i:60;s:13:"default_value";a:1:{i:0;a:2:{s:5:"value";s:0:"";s:14:"_error_element";s:51:"default_value_widget][field_intro_content][0][value";}}s:17:"default_value_php";N;}', 'a:7:{s:5:"label";a:2:{s:6:"format";s:5:"above";s:7:"exclude";i:0;}s:6:"teaser";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:4:"full";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:4;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:2;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:3;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:5:"token";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}}', '', 'text', 1),
('field_home_company_info', 'home', -3, 'Company info', 'text_textarea', 'a:4:{s:4:"rows";s:1:"5";s:4:"size";i:60;s:13:"default_value";a:1:{i:0;a:2:{s:5:"value";s:0:"";s:14:"_error_element";s:55:"default_value_widget][field_home_company_info][0][value";}}s:17:"default_value_php";N;}', 'a:7:{s:5:"label";a:2:{s:6:"format";s:5:"above";s:7:"exclude";i:0;}s:6:"teaser";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:4:"full";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:4;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:2;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:3;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:5:"token";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}}', '', 'text', 1),
('field_home_trophic_info', 'home', -2, 'Trophic info', 'text_textarea', 'a:4:{s:4:"rows";s:1:"5";s:4:"size";i:60;s:13:"default_value";a:1:{i:0;a:2:{s:5:"value";s:0:"";s:14:"_error_element";s:55:"default_value_widget][field_home_trophic_info][0][value";}}s:17:"default_value_php";N;}', 'a:7:{s:5:"label";a:2:{s:6:"format";s:5:"above";s:7:"exclude";i:0;}s:6:"teaser";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:4:"full";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:4;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:2;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:3;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:5:"token";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}}', '', 'text', 1),
('field_home_embed', 'home', -4, 'Embed', 'text_textfield', 'a:4:{s:4:"rows";i:5;s:4:"size";s:2:"60";s:13:"default_value";a:1:{i:0;a:2:{s:5:"value";s:0:"";s:14:"_error_element";s:48:"default_value_widget][field_home_embed][0][value";}}s:17:"default_value_php";N;}', 'a:7:{s:5:"label";a:2:{s:6:"format";s:5:"above";s:7:"exclude";i:0;}s:6:"teaser";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:4:"full";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:4;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:2;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:3;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:5:"token";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}}', '', 'text', 1),
('field_distribution_content', 'distribution', -4, 'Content', 'text_textarea', 'a:4:{s:4:"rows";s:1:"5";s:4:"size";i:60;s:13:"default_value";a:1:{i:0;a:2:{s:5:"value";s:0:"";s:14:"_error_element";s:58:"default_value_widget][field_distribution_content][0][value";}}s:17:"default_value_php";N;}', 'a:7:{s:5:"label";a:2:{s:6:"format";s:5:"above";s:7:"exclude";i:0;}s:6:"teaser";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:4:"full";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:4;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:2;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}i:3;a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}s:5:"token";a:2:{s:6:"format";s:7:"default";s:7:"exclude";i:0;}}', '', 'text', 1);

-- --------------------------------------------------------

--
-- Table structure for table `content_type_contact`
--

CREATE TABLE IF NOT EXISTS `content_type_contact` (
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `field_contact_address_value` longtext,
  `field_contact_email_value` longtext,
  `field_contact_fax_value` longtext,
  `field_contact_mobile_value` longtext,
  `field_contact_phone_value` longtext,
  `field_contact_website_value` longtext,
  PRIMARY KEY (`vid`),
  KEY `nid` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `content_type_contact`
--

INSERT INTO `content_type_contact` (`vid`, `nid`, `field_contact_address_value`, `field_contact_email_value`, `field_contact_fax_value`, `field_contact_mobile_value`, `field_contact_phone_value`, `field_contact_website_value`) VALUES
(5, 5, 'Số 413/7/6 Lê Văn Quới, KP.5 P. Bình Trị Đông A, Q. Bình Tân, TP. HCM', 'info@goodmilk.com.vn', '08. 3767 1576', '0938331299', '08. 3767 1576 - 08. 6273 3576', 'http://www.goodmilk.com.vn');

-- --------------------------------------------------------

--
-- Table structure for table `content_type_distribution`
--

CREATE TABLE IF NOT EXISTS `content_type_distribution` (
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `field_distribution_content_value` longtext,
  `field_distribution_content_format` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`vid`),
  KEY `nid` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `content_type_distribution`
--

INSERT INTO `content_type_distribution` (`vid`, `nid`, `field_distribution_content_value`, `field_distribution_content_format`) VALUES
(9, 9, '<p><img alt="" src="/goodmilk/sites/default/files/distribution.jpg" style="width: 706px; height: 449px;" /></p>', 2);

-- --------------------------------------------------------

--
-- Table structure for table `content_type_home`
--

CREATE TABLE IF NOT EXISTS `content_type_home` (
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `field_home_company_info_value` longtext,
  `field_home_company_info_format` int(10) unsigned DEFAULT NULL,
  `field_home_trophic_info_value` longtext,
  `field_home_trophic_info_format` int(10) unsigned DEFAULT NULL,
  `field_home_embed_value` longtext,
  PRIMARY KEY (`vid`),
  KEY `nid` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `content_type_home`
--

INSERT INTO `content_type_home` (`vid`, `nid`, `field_home_company_info_value`, `field_home_company_info_format`, `field_home_trophic_info_value`, `field_home_trophic_info_format`, `field_home_embed_value`) VALUES
(8, 8, '<p><img alt="" src="/goodmilk/sites/default/files/company-info.jpg" style="width: 445px; height: 326px;" /></p>', 2, '<p>Sữa bột goodmilk canxi đã được nghiên cứu và đặc chế với công thức chuẩn hoá lượng canxi thiếu hụt qua khẩu phần ăn hàng ngày và thể tr ạng chung của người Việt và tỷ lệ tối ưu giữa thành phần&nbsp; dưỡng chất hoàn chỉnh gồm Canxi, Phốt pho, Magie, Kẽm, Vitamin D là các chất thiết yếu của quá trình chuyển hóa kiến tạo cấu trúc mô xương, giúp xương phát triển bền vững mà còn:<br /><br />Phòng ngừa bệnh loãng xương và bệnh tiểu đường ở người lớn tuổi.<br /><br />Bổ sung đầy đủ lượng canxi thiếu hụt cho phụ nữ trong giai đoạn mãn kinh.<br /><br />Phòng ngừa&nbsp; các bệnh về tim mạch, và các rối loạn nội tiết do sự thay đổi các hooc môn.<br /><br />Sữa bột goodmilk&nbsp; ít béo giàu canxi , không cholesterol rất phù hợp cho người bị tiểu đường ( chỉ số đường huyết thấp), người thừa cân, bị béo ph&acute;, nhiễm mỡ trong máu, trong gan cao, người ốm chán ăn cần năng lượng, người bị cao huyết áp</p>', 2, '//www.youtube.com/embed/tseEEQC3SZE');

-- --------------------------------------------------------

--
-- Table structure for table `content_type_intro`
--

CREATE TABLE IF NOT EXISTS `content_type_intro` (
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `field_intro_embed_value` longtext,
  `field_intro_content_value` longtext,
  `field_intro_content_format` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`vid`),
  KEY `nid` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `content_type_intro`
--

INSERT INTO `content_type_intro` (`vid`, `nid`, `field_intro_embed_value`, `field_intro_content_value`, `field_intro_content_format`) VALUES
(7, 7, '//www.youtube.com/embed/tseEEQC3SZE', '<p><img alt="" src="/goodmilk/sites/default/files/intro.jpg" style="width: 991px; height: 469px;" /></p>', 2);

-- --------------------------------------------------------

--
-- Table structure for table `date_formats`
--

CREATE TABLE IF NOT EXISTS `date_formats` (
  `dfid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `format` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `type` varchar(200) NOT NULL,
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`dfid`),
  UNIQUE KEY `formats` (`format`,`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `date_formats`
--

INSERT INTO `date_formats` (`dfid`, `format`, `type`, `locked`) VALUES
(1, 'Y-m-d H:i', 'short', 1),
(2, 'm/d/Y - H:i', 'short', 1),
(3, 'd/m/Y - H:i', 'short', 1),
(4, 'Y/m/d - H:i', 'short', 1),
(5, 'd.m.Y - H:i', 'short', 1),
(6, 'm/d/Y - g:ia', 'short', 1),
(7, 'd/m/Y - g:ia', 'short', 1),
(8, 'Y/m/d - g:ia', 'short', 1),
(9, 'M j Y - H:i', 'short', 1),
(10, 'j M Y - H:i', 'short', 1),
(11, 'Y M j - H:i', 'short', 1),
(12, 'M j Y - g:ia', 'short', 1),
(13, 'j M Y - g:ia', 'short', 1),
(14, 'Y M j - g:ia', 'short', 1),
(15, 'D, Y-m-d H:i', 'medium', 1),
(16, 'D, m/d/Y - H:i', 'medium', 1),
(17, 'D, d/m/Y - H:i', 'medium', 1),
(18, 'D, Y/m/d - H:i', 'medium', 1),
(19, 'F j, Y - H:i', 'medium', 1),
(20, 'j F, Y - H:i', 'medium', 1),
(21, 'Y, F j - H:i', 'medium', 1),
(22, 'D, m/d/Y - g:ia', 'medium', 1),
(23, 'D, d/m/Y - g:ia', 'medium', 1),
(24, 'D, Y/m/d - g:ia', 'medium', 1),
(25, 'F j, Y - g:ia', 'medium', 1),
(26, 'j F Y - g:ia', 'medium', 1),
(27, 'Y, F j - g:ia', 'medium', 1),
(28, 'j. F Y - G:i', 'medium', 1),
(29, 'l, F j, Y - H:i', 'long', 1),
(30, 'l, j F, Y - H:i', 'long', 1),
(31, 'l, Y,  F j - H:i', 'long', 1),
(32, 'l, F j, Y - g:ia', 'long', 1),
(33, 'l, j F Y - g:ia', 'long', 1),
(34, 'l, Y,  F j - g:ia', 'long', 1),
(35, 'l, j. F Y - G:i', 'long', 1);

-- --------------------------------------------------------

--
-- Table structure for table `date_format_locale`
--

CREATE TABLE IF NOT EXISTS `date_format_locale` (
  `format` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `type` varchar(200) NOT NULL,
  `language` varchar(12) NOT NULL,
  PRIMARY KEY (`type`,`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `date_format_locale`
--


-- --------------------------------------------------------

--
-- Table structure for table `date_format_types`
--

CREATE TABLE IF NOT EXISTS `date_format_types` (
  `type` varchar(200) NOT NULL,
  `title` varchar(255) NOT NULL,
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `date_format_types`
--

INSERT INTO `date_format_types` (`type`, `title`, `locked`) VALUES
('long', 'Long', 1),
('medium', 'Medium', 1),
('short', 'Short', 1);

-- --------------------------------------------------------

--
-- Table structure for table `devel_queries`
--

CREATE TABLE IF NOT EXISTS `devel_queries` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `function` varchar(255) NOT NULL DEFAULT '',
  `query` text NOT NULL,
  `hash` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `qid` (`qid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `devel_queries`
--


-- --------------------------------------------------------

--
-- Table structure for table `devel_times`
--

CREATE TABLE IF NOT EXISTS `devel_times` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL DEFAULT '0',
  `time` float DEFAULT NULL,
  PRIMARY KEY (`tid`),
  KEY `qid` (`qid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `devel_times`
--


-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `fid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `filemime` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fid`),
  KEY `uid` (`uid`),
  KEY `status` (`status`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`fid`, `uid`, `filename`, `filepath`, `filemime`, `filesize`, `status`, `timestamp`) VALUES
(1, 1, 'intro.jpg', 'sites/default/files/intro.jpg', 'image/jpeg', 84968, 1, 1421144386),
(2, 1, 'company-info.jpg', 'sites/default/files/company-info.jpg', 'image/jpeg', 43359, 1, 1421304580),
(3, 1, 'distribution.jpg', 'sites/default/files/distribution.jpg', 'image/jpeg', 53496, 1, 1421309665);

-- --------------------------------------------------------

--
-- Table structure for table `filters`
--

CREATE TABLE IF NOT EXISTS `filters` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `format` int(11) NOT NULL DEFAULT '0',
  `module` varchar(64) NOT NULL DEFAULT '',
  `delta` tinyint(4) NOT NULL DEFAULT '0',
  `weight` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `fmd` (`format`,`module`,`delta`),
  KEY `list` (`format`,`weight`,`module`,`delta`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `filters`
--

INSERT INTO `filters` (`fid`, `format`, `module`, `delta`, `weight`) VALUES
(1, 1, 'filter', 2, 0),
(2, 1, 'filter', 0, 1),
(3, 1, 'filter', 1, 2),
(4, 1, 'filter', 3, 10),
(5, 2, 'filter', 2, 0),
(6, 2, 'filter', 1, 1),
(7, 2, 'filter', 3, 10),
(8, 3, 'php', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `filter_formats`
--

CREATE TABLE IF NOT EXISTS `filter_formats` (
  `format` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `roles` varchar(255) NOT NULL DEFAULT '',
  `cache` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`format`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `filter_formats`
--

INSERT INTO `filter_formats` (`format`, `name`, `roles`, `cache`) VALUES
(1, 'Filtered HTML', ',1,2,', 1),
(2, 'Full HTML', '', 1),
(3, 'PHP code', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `flood`
--

CREATE TABLE IF NOT EXISTS `flood` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `event` varchar(64) NOT NULL DEFAULT '',
  `hostname` varchar(128) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fid`),
  KEY `allow` (`event`,`hostname`,`timestamp`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `flood`
--

INSERT INTO `flood` (`fid`, `event`, `hostname`, `timestamp`) VALUES
(1, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421050597),
(2, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421050597),
(3, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421050598),
(4, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421058351),
(5, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421058351),
(6, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421058379),
(7, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421115375),
(8, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421115389),
(9, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421116737),
(10, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421122295),
(11, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421127607),
(12, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421127607),
(13, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421127867),
(14, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421131701),
(15, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421132071),
(16, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421132087),
(17, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421135320),
(18, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421135793),
(19, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421136352),
(20, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421144362),
(21, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421144387),
(22, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421144417),
(23, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421289376),
(24, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421289470),
(25, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421304383),
(26, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421304567),
(27, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421304580),
(28, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421309652),
(29, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421309665),
(30, 'bootstrap_rebuild_registry_warning', '127.0.0.1', 1421309676);

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `uid` int(11) NOT NULL DEFAULT '0',
  `nid` int(11) NOT NULL DEFAULT '0',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`,`nid`),
  KEY `nid` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`uid`, `nid`, `timestamp`) VALUES
(1, 1, 1421289470),
(1, 2, 1421304383),
(1, 3, 1421058379),
(1, 4, 1421135320),
(1, 5, 1421135793),
(1, 6, 1421136352),
(1, 7, 1421144431),
(1, 8, 1421304675),
(1, 9, 1421309676);

-- --------------------------------------------------------

--
-- Table structure for table `i18n_blocks`
--

CREATE TABLE IF NOT EXISTS `i18n_blocks` (
  `ibid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(64) NOT NULL,
  `delta` varchar(32) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `language` varchar(12) NOT NULL DEFAULT '',
  PRIMARY KEY (`ibid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `i18n_blocks`
--


-- --------------------------------------------------------

--
-- Table structure for table `i18n_strings`
--

CREATE TABLE IF NOT EXISTS `i18n_strings` (
  `lid` int(11) NOT NULL DEFAULT '0',
  `objectid` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(255) NOT NULL DEFAULT '',
  `property` varchar(255) NOT NULL DEFAULT '',
  `objectindex` int(11) NOT NULL DEFAULT '0',
  `format` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `i18n_strings`
--

INSERT INTO `i18n_strings` (`lid`, `objectid`, `type`, `property`, `objectindex`, `format`) VALUES
(131, 'contact-field_contact_address', 'field', 'widget_label', 0, 0),
(132, 'contact-field_contact_email', 'field', 'widget_label', 0, 0),
(133, 'contact-field_contact_fax', 'field', 'widget_label', 0, 0),
(134, 'contact-field_contact_mobile', 'field', 'widget_label', 0, 0),
(135, 'contact-field_contact_phone', 'field', 'widget_label', 0, 0),
(136, 'contact-field_contact_website', 'field', 'widget_label', 0, 0),
(137, 'poll', 'type', 'name', 0, 0),
(138, 'poll', 'type', 'title', 0, 0),
(139, 'poll', 'type', 'description', 0, 0),
(140, 'contact', 'type', 'name', 0, 0),
(141, 'contact', 'type', 'title', 0, 0),
(142, 'page', 'type', 'name', 0, 0),
(143, 'page', 'type', 'title', 0, 0),
(144, 'page', 'type', 'body', 0, 0),
(145, 'page', 'type', 'description', 0, 0),
(146, 'story', 'type', 'name', 0, 0),
(147, 'story', 'type', 'title', 0, 0),
(148, 'story', 'type', 'body', 0, 0),
(149, 'story', 'type', 'description', 0, 0),
(150, '225', 'item', 'title', 225, 0),
(963, 'intro', 'type', 'title', 0, 0),
(962, 'intro', 'type', 'name', 0, 0),
(153, '444', 'item', 'title', 444, 0),
(867, '557', 'item', 'title', 557, 0),
(1013, 'home', 'type', 'name', 0, 0),
(1014, 'home', 'type', 'title', 0, 0),
(1015, '610', 'item', 'title', 610, 0),
(1016, 'distribution', 'type', 'name', 0, 0),
(1017, 'distribution', 'type', 'title', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `i18n_variable`
--

CREATE TABLE IF NOT EXISTS `i18n_variable` (
  `name` varchar(128) NOT NULL DEFAULT '',
  `language` varchar(12) NOT NULL DEFAULT '',
  `value` longtext NOT NULL,
  PRIMARY KEY (`name`,`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `i18n_variable`
--


-- --------------------------------------------------------

--
-- Table structure for table `imagecache_action`
--

CREATE TABLE IF NOT EXISTS `imagecache_action` (
  `actionid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `presetid` int(10) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `module` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `data` longtext NOT NULL,
  PRIMARY KEY (`actionid`),
  KEY `presetid` (`presetid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `imagecache_action`
--


-- --------------------------------------------------------

--
-- Table structure for table `imagecache_preset`
--

CREATE TABLE IF NOT EXISTS `imagecache_preset` (
  `presetid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `presetname` varchar(255) NOT NULL,
  PRIMARY KEY (`presetid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `imagecache_preset`
--


-- --------------------------------------------------------

--
-- Table structure for table `imce_files`
--

CREATE TABLE IF NOT EXISTS `imce_files` (
  `fid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `imce_files`
--

INSERT INTO `imce_files` (`fid`) VALUES
(1),
(2),
(3);

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE IF NOT EXISTS `languages` (
  `language` varchar(12) NOT NULL DEFAULT '',
  `name` varchar(64) NOT NULL DEFAULT '',
  `native` varchar(64) NOT NULL DEFAULT '',
  `direction` int(11) NOT NULL DEFAULT '0',
  `enabled` int(11) NOT NULL DEFAULT '0',
  `plurals` int(11) NOT NULL DEFAULT '0',
  `formula` varchar(128) NOT NULL DEFAULT '',
  `domain` varchar(128) NOT NULL DEFAULT '',
  `prefix` varchar(128) NOT NULL DEFAULT '',
  `weight` int(11) NOT NULL DEFAULT '0',
  `javascript` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`language`),
  KEY `list` (`weight`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`language`, `name`, `native`, `direction`, `enabled`, `plurals`, `formula`, `domain`, `prefix`, `weight`, `javascript`) VALUES
('en', 'English', 'English', 0, 1, 0, '', '', 'en', 0, ''),
('vi', 'Vietnamese', 'Tiếng Việt', 0, 1, 2, '($n!=1)', '', 'vi', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `locales_source`
--

CREATE TABLE IF NOT EXISTS `locales_source` (
  `lid` int(11) NOT NULL AUTO_INCREMENT,
  `location` varchar(255) NOT NULL DEFAULT '',
  `textgroup` varchar(255) NOT NULL DEFAULT 'default',
  `source` blob NOT NULL,
  `version` varchar(20) NOT NULL DEFAULT 'none',
  PRIMARY KEY (`lid`),
  KEY `source` (`source`(30)),
  KEY `textgroup_location` (`textgroup`(30),`location`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1018 ;

--
-- Dumping data for table `locales_source`
--

INSERT INTO `locales_source` (`lid`, `location`, `textgroup`, `source`, `version`) VALUES
(1, 'misc/drupal.js', 'default', 0x556e737065636966696564206572726f72, 'none'),
(2, 'misc/drupal.js', 'default', 0x416e206572726f72206f636375727265642e205c6e407572695c6e4074657874, 'none'),
(3, 'misc/drupal.js', 'default', 0x416e206572726f72206f636375727265642e205c6e407572695c6e286e6f20696e666f726d6174696f6e20617661696c61626c65292e, 'none'),
(4, 'misc/drupal.js', 'default', 0x416e2048545450206572726f722040737461747573206f636375727265642e205c6e40757269, 'none'),
(5, 'sites/all/modules/lightbox2/js/lightbox.js', 'default', 0x50726576696f7573, 'none'),
(6, 'sites/all/modules/lightbox2/js/lightbox.js', 'default', 0x4e657874, 'none'),
(7, 'sites/all/modules/lightbox2/js/lightbox.js; sites/all/modules/imce/js/imce.js', 'default', 0x436c6f7365, 'none'),
(8, 'sites/all/modules/lightbox2/js/lightbox.js', 'default', 0x506175736520536c69646573686f77, 'none'),
(9, 'sites/all/modules/lightbox2/js/lightbox.js', 'default', 0x506c617920536c69646573686f77, 'none'),
(10, 'misc/tabledrag.js', 'default', 0x4472616720746f2072652d6f72646572, 'none'),
(11, 'misc/tabledrag.js', 'default', 0x4368616e676573206d61646520696e2074686973207461626c652077696c6c206e6f7420626520736176656420756e74696c2074686520666f726d206973207375626d69747465642e, 'none'),
(12, 'sites/all/modules/pathauto/pathauto.js', 'default', 0x4175746f6d6174696320616c696173, 'none'),
(13, 'sites/all/modules/pathauto/pathauto.js', 'default', 0x416c6961733a2040616c696173, 'none'),
(14, 'sites/all/modules/pathauto/pathauto.js', 'default', 0x4e6f20616c696173, 'none'),
(15, 'sites/all/modules/imce/js/imce.js', 'default', 0x46696c652062726f7773696e672069732064697361626c656420696e206469726563746f727920256469722e, 'none'),
(16, 'sites/all/modules/imce/js/imce.js', 'default', 0x55706c6f6164, 'none'),
(17, 'sites/all/modules/imce/js/imce.js', 'default', 0x596f752063616e206e6f7420706572666f726d2074686973206f7065726174696f6e2e, 'none'),
(18, 'sites/all/modules/imce/js/imce.js', 'default', 0x446f20796f752077616e7420746f2072656672657368207468652063757272656e74206469726563746f72793f, 'none'),
(19, 'sites/all/modules/imce/js/imce.js', 'default', 0x4f6e6c792066696c657320776974682074686520666f6c6c6f77696e6720657874656e73696f6e732061726520616c6c6f7765643a202566696c65732d616c6c6f7765642e, 'none'),
(20, 'sites/all/modules/imce/js/imce.js', 'default', 0x44656c6574652073656c65637465642066696c65733f, 'none'),
(21, 'sites/all/modules/imce/js/imce.js', 'default', 0x506c656173652073656c6563742061207468756d626e61696c2e, 'none'),
(22, 'sites/all/modules/imce/js/imce.js', 'default', 0x506c6561736520737065636966792064696d656e73696f6e732077697468696e2074686520616c6c6f7765642072616e676520746861742069732066726f6d2031783120746f204064696d656e73696f6e732e, 'none'),
(23, 'sites/all/modules/imce/js/imce.js', 'default', 0x756e6c696d69746564, 'none'),
(24, 'sites/all/modules/imce/js/imce.js', 'default', 0x506c656173652073656c65637420612066696c652e, 'none'),
(25, 'sites/all/modules/imce/js/imce.js', 'default', 0x4c6f67206d65737361676573, 'none'),
(26, 'sites/all/modules/imce/js/imce.js', 'default', 0x2566696c656e616d65206973206e6f7420616e20696d6167652e, 'none'),
(27, 'sites/all/modules/imce/js/imce.js', 'default', 0x596f75206d7573742073656c656374206174206c6561737420256e756d2066696c65732e, 'none'),
(28, 'sites/all/modules/imce/js/imce.js', 'default', 0x596f7520617265206e6f7420616c6c6f77656420746f206f706572617465206f6e206d6f7265207468616e20256e756d2066696c65732e, 'none'),
(29, 'sites/all/modules/imce/js/imce_extras.js', 'default', 0x4368616e67652076696577, 'none'),
(30, 'modules/block/block.js', 'default', 0x546865206368616e67657320746f20746865736520626c6f636b732077696c6c206e6f7420626520736176656420756e74696c20746865203c656d3e5361766520626c6f636b733c2f656d3e20627574746f6e20697320636c69636b65642e, 'none'),
(31, 'content.module:18', 'default', 0x416c6c6f77732061646d696e6973747261746f727320746f20646566696e65206e657720636f6e74656e742074797065732e, 'none'),
(32, 'content.module:73', 'default', 0x61646420636f6e74656e742074797065, 'none'),
(33, 'content.module:80', 'default', 0x6669656c6473, '6.22'),
(34, 'content.module:119,  content_admin.inc:25', 'default', 0x6475706c6963617465, 'none'),
(35, 'content.module:135', 'default', 0x6d616e616765206669656c6473, '6.22'),
(36, 'content.module:164', 'default', 0x72656d6f7665206669656c64, 'none'),
(37, 'content_admin.inc:42', 'default', 0x436f6e74656e74207479706573, '6.22'),
(38, 'content_admin.inc:90', 'default', 0x5468652068756d616e2d7265616461626c65206e616d65206f66207468697320636f6e74656e7420747970652e, 'none'),
(39, 'content_admin.inc:98', 'default', 0x41206272696566206465736372697074696f6e206f662074686520636f6e74656e7420747970652e, 'none'),
(40, 'content_admin.inc:106', 'default', 0x496e737472756374696f6e7320746f2070726573656e7420746f207468652075736572207768656e20616464696e67206e657720636f6e74656e74206f66207468697320747970652e, 'none'),
(41, 'content_admin.inc:110', 'default', 0x5469746c65206669656c64206c6162656c, '6.22'),
(42, 'content_admin.inc:113', 'default', 0x546865206c6162656c20666f7220746865207469746c65206669656c642e, 'none'),
(43, 'content_admin.inc:118', 'default', 0x5361766520636f6e74656e742074797065, '6.22'),
(44, 'content_admin.inc:182', 'default', 0x536176656420636f6e74656e7420747970652025747970652e, 'none'),
(45, 'content_admin.inc:198', 'default', 0x41726520796f75207375726520796f752077616e7420746f2064656c6574652074686520636f6e74656e7420747970652025747970653f, 'none'),
(46, 'content_admin.inc:198', 'default', 0x496620796f75206861766520616e7920636f6e74656e74206c65667420696e207468697320636f6e74656e7420747970652c2069742077696c6c206265207065726d616e656e746c792064656c657465642e205468697320616374696f6e2063616e6e6f7420626520756e646f6e652e, 'none'),
(47, 'content_admin.inc:218', 'default', 0x44656c6574656420636f6e74656e7420747970652025747970652e, 'none'),
(48, 'content_admin.inc:248', 'default', 0x72656d6f7665, 'none'),
(49, 'content_admin.inc:277', 'default', 0x416464206578697374696e67206669656c64, 'none'),
(50, 'content_admin.inc:286', 'default', 0x416464206669656c64, '6.22'),
(51, 'content_admin.inc:307', 'default', 0x437265617465206e6577206669656c64, 'none'),
(52, 'content_admin.inc:313', 'default', 0x5468652068756d616e2d7265616461626c65206e616d65206f662074686973206669656c642e, 'none'),
(53, 'content_admin.inc:318', 'default', 0x4669656c642074797065, '6.22'),
(54, 'content_admin.inc:326', 'default', 0x437265617465206669656c64, 'none'),
(55, 'content_admin.inc:335', 'default', 0x4e6f206669656c64206d6f64756c65732061726520656e61626c65642e20596f75206e65656420746f203c6120687265663d22256d6f64756c65735f75726c223e656e61626c65206f6e653c2f613e2c207375636820617320746578742e6d6f64756c652c206265666f726520796f752063616e20616464206e6577206669656c64732e, 'none'),
(56, 'content_admin.inc:389', 'default', 0x4164646564206669656c6420256c6162656c2e, '6.22'),
(57, 'content_admin.inc:432', 'default', 0x43726561746564206669656c6420256c6162656c2e, 'none'),
(58, 'content_admin.inc:452', 'default', 0x41726520796f75207375726520796f752077616e7420746f2072656d6f766520746865206669656c6420256669656c643f, 'none'),
(59, 'content_admin.inc:452', 'default', 0x496620796f75206861766520616e7920636f6e74656e74206c65667420696e2074686973206669656c642c2069742077696c6c206265206c6f73742e205468697320616374696f6e2063616e6e6f7420626520756e646f6e652e, 'none'),
(60, 'content_admin.inc:452', 'default', 0x52656d6f7665, '6.22'),
(61, 'content_admin.inc:468', 'default', 0x52656d6f766564206669656c6420256669656c642066726f6d2025747970652e, 'none'),
(62, 'content_admin.inc:487', 'default', 0x546865206669656c6420256669656c64206e6f206c6f6e6765722065786973747320696e20616e7920636f6e74656e7420747970652c20736f206974207761732064656c657465642e, 'none'),
(63, 'content_admin.inc:511', 'default', 0x5769646765742073657474696e6773, 'none'),
(64, 'content_admin.inc:512', 'default', 0x54686573652073657474696e6773206170706c79206f6e6c7920746f2074686520256669656c64206669656c64206173206974206170706561727320696e2074686520257479706520636f6e74656e7420747970652e, '6.22'),
(65, 'content_admin.inc:526', 'default', 0x576964676574, 'none'),
(66, 'content_admin.inc:541', 'default', 0x496e20746865206e6f64652065646974696e6720666f726d2c207468652068656176696572206669656c64732077696c6c2073696e6b20616e6420746865206c696768746572206669656c64732077696c6c20626520706f736974696f6e6564206e65617265722074686520746f702e, 'none'),
(67, 'content_admin.inc:552', 'default', 0x496e737472756374696f6e7320746f2070726573656e7420746f2074686520757365722062656c6f772074686973206669656c64206f6e207468652065646974696e6720666f726d2e, 'none'),
(68, 'content_admin.inc:558', 'default', 0x446174612073657474696e6773, 'none'),
(69, 'content_admin.inc:559', 'default', 0x54686573652073657474696e6773206170706c7920746f2074686520256669656c64206669656c6420696e20657665727920636f6e74656e74207479706520696e20776869636820697420617070656172732e, '6.22'),
(70, 'content_admin.inc:568', 'default', 0x4d756c7469706c652076616c756573, 'none'),
(71, 'content_admin.inc:579', 'default', 0x53617665206669656c642073657474696e6773, '6.22'),
(72, 'content_admin.inc:652', 'default', 0x5361766564206669656c6420256669656c642e, 'none'),
(73, 'content_admin.inc:16;87;232;310;533', 'default', 0x4c6162656c, '6.22'),
(74, 'content_admin.inc:882;971', 'default', 0x4e6f20506f737467726553514c206d617070696e6720666f756e6420666f72202574797065206461746120747970652e, 'none'),
(75, 'content_admin.inc:882;971', 'default', 0x6461746162617365, 'none'),
(76, 'date.module:15', 'default', 0x446566696e6573206120646174652f74696d65206669656c6420747970652e203c656d3e4e6f74653a20526571756972657320636f6e74656e742e6d6f64756c652e3c2f656d3e, 'none'),
(77, 'date.module:36', 'default', 0x59656172, 'none'),
(78, 'date.module:37', 'default', 0x5965617220616e64206d6f6e7468, 'none'),
(79, 'date.module:39', 'default', 0x4461746520616e642074696d65, '6.22'),
(80, 'date.module:43', 'default', 0x4772616e756c6172697479, 'none'),
(81, 'date.module:101', 'default', 0x54696d65732061726520656e746572656420616e6420646973706c617965642077697468207369746527732074696d65207a6f6e65, 'none'),
(82, 'date.module:102', 'default', 0x54696d65732061726520656e746572656420616e6420646973706c617965642077697468207573657227732074696d65207a6f6e65, 'none'),
(83, 'date.module:106', 'default', 0x54696d65207a6f6e652068616e646c696e67, 'none'),
(84, 'date.module:154', 'default', 0x256e616d65206d75737420626520656e746572656420696e2049534f203836303120666f726d6174202859595959292e, 'none'),
(85, 'date.module:159', 'default', 0x256e616d65206d75737420626520656e746572656420696e2049534f203836303120666f726d61742028595959592d4d4d292e, 'none'),
(86, 'date.module:164', 'default', 0x256e616d65206d75737420626520656e746572656420696e2049534f203836303120666f726d61742028595959592d4d4d2d4444292e, 'none'),
(87, 'date.module:169', 'default', 0x256e616d65206d75737420626520656e746572656420696e2049534f203836303120666f726d61742028595959592d4d4d2d44445468683a6d6d3a7373292e, 'none'),
(88, 'field.php:77,  text.module:44', 'default', 0x4d6178696d756d206c656e677468, '6.22'),
(89, 'field.php:80,  text.module:47', 'default', 0x546865206d6178696d756d206c656e677468206f6620746865206669656c6420696e20636861726163746572732e204c6561766520626c616e6b20666f7220616e20756e6c696d697465642073697a652e, '6.22'),
(90, 'field.php:102,  number.module:82,  text.module:80', 'default', 0x697320657175616c20746f, 'none'),
(91, 'field.php:103,  number.module:83,  text.module:81', 'default', 0x6973206e6f7420657175616c20746f, 'none'),
(92, 'field.php:104,  text.module:82', 'default', 0x6d61746368657320746865207061747465726e, 'none'),
(93, 'field.php:265,  text.module:159', 'default', 0x526f7773, '6.22'),
(94, 'field.php:273,  text.module:167', 'default', 0x22526f777322206d757374206265206120706f73697469766520696e74656765722e, 'none'),
(95, 'field.php:180;190,  number.module:119,  text.module:107', 'default', 0x496c6c6567616c2076616c756520666f7220256e616d652e, 'none'),
(96, 'nodereference.module:0', 'default', 0x6e6f64657265666572656e6365, 'none'),
(97, 'nodereference.module:15', 'default', 0x446566696e65732061206669656c64207479706520666f72207265666572656e63696e67206f6e65206e6f64652066726f6d20616e6f746865722e203c656d3e4e6f74653a20526571756972657320636f6e74656e742e6d6f64756c652e3c2f656d3e, 'none'),
(98, 'nodereference.module:26', 'default', 0x6e6f6465207265666572656e6365206175746f636f6d706c657465, 'none'),
(99, 'nodereference.module:51', 'default', 0x436f6e74656e7420747970657320746861742063616e206265207265666572656e636564, 'none'),
(100, 'nodereference.module:204', 'default', 0x4e6f20706f737420776974682074686174207469746c65206578697374732e, 'none'),
(101, 'number.module:0', 'default', 0x6e756d626572, 'none'),
(102, 'number.module:15', 'default', 0x446566696e6573206e756d65726963206669656c642074797065732e203c656d3e4e6f74653a20526571756972657320636f6e74656e742e6d6f64756c652e3c2f656d3e, 'none'),
(103, 'number.module:38', 'default', 0x4d696e696d756d, 'none'),
(104, 'number.module:43', 'default', 0x4d6178696d756d, 'none'),
(105, 'number.module:48,  text.module:51', 'default', 0x416c6c6f7765642076616c756573, '6.22'),
(106, 'number.module:52,  text.module:55', 'default', 0x54686520706f737369626c652076616c7565732074686973206669656c642063616e20636f6e7461696e2e20416e79206f746865722076616c7565732077696c6c20726573756c7420696e20616e206572726f722e20456e746572206f6e652076616c756520706572206c696e652e, 'none'),
(107, 'number.module:58', 'default', 0x224d696e696d756d22206d7573742062652061206e756d6265722e, 'none'),
(108, 'number.module:61', 'default', 0x224d6178696d756d22206d7573742062652061206e756d6265722e, 'none'),
(109, 'number.module:113', 'default', 0x5468652076616c7565206f6620256e616d65206d6179206265206e6f20736d616c6c6572207468616e20256d696e2e, 'none'),
(110, 'number.module:116', 'default', 0x5468652076616c7565206f6620256e616d65206d6179206265206e6f206c6172676572207468616e20256d61782e, 'none'),
(111, 'optionwidgets.module:0', 'default', 0x6f7074696f6e77696467657473, 'none'),
(112, 'optionwidgets.module:15', 'default', 0x446566696e65732073656c656374696f6e2c20636865636b20626f7820616e6420726164696f20627574746f6e207769646765747320666f72207465787420616e64206e756d65726963206669656c64732e203c656d3e4e6f74653a20526571756972657320636f6e74656e742e6d6f64756c652c20746578742e6d6f64756c6520616e64206e756d6265722e6d6f64756c652e3c2f656d3e, 'none'),
(113, 'text.module:0', 'default', 0x74657874, 'none'),
(114, 'text.module:15', 'default', 0x446566696e65732073696d706c652074657874206669656c642074797065732e203c656d3e4e6f74653a20526571756972657320636f6e74656e742e6d6f64756c652e3c2f656d3e, 'none'),
(115, 'text.module:35', 'default', 0x46696c746572656420746578742028757365722073656c6563747320696e70757420666f726d617429, '6.22'),
(116, 'text.module:35', 'default', 0x506c61696e2074657874, '6.22'),
(117, 'text.module:38', 'default', 0x546578742070726f63657373696e67, '6.22'),
(118, 'text.module:144', 'default', 0x54657874204669656c64, 'none'),
(119, 'userreference.module:0', 'default', 0x757365727265666572656e6365, 'none'),
(120, 'userreference.module:15', 'default', 0x446566696e65732061206669656c64207479706520666f72207265666572656e63696e67206120757365722066726f6d2061206e6f64652e203c656d3e4e6f74653a20526571756972657320636f6e74656e742e6d6f64756c652e3c2f656d3e, 'none'),
(121, 'userreference.module:176', 'default', 0x496e76616c69642075736572206e616d652e, 'none'),
(122, 'weburl.module:0', 'default', 0x77656275726c, 'none'),
(123, 'weburl.module:15', 'default', 0x446566696e65732073696d706c652077656275726c206669656c642074797065732e203c656d3e4e6f74653a20526571756972657320636f6e74656e742e6d6f64756c652e3c2f656d3e, 'none'),
(124, 'weburl.module:164;172', 'default', 0x4e6f7420612076616c6964205765622055524c2e, 'none'),
(125, 'misc/tableselect.js', 'default', 0x53656c65637420616c6c20726f777320696e2074686973207461626c65, 'none'),
(126, 'misc/tableselect.js', 'default', 0x446573656c65637420616c6c20726f777320696e2074686973207461626c65, 'none'),
(127, 'sites/all/modules/views/js/tabs.js', 'default', 0x6a517565727920554920546162733a204d69736d61746368696e6720667261676d656e74206964656e7469666965722e, 'none'),
(128, 'sites/all/modules/views/js/tabs.js', 'default', 0x6a517565727920554920546162733a204e6f7420656e6f75676820617267756d656e747320746f20616464207461622e, 'none'),
(129, 'sites/all/modules/views/js/ajax.js', 'default', 0x496e7465726e616c20736572766572206572726f722e20506c656173652073656520736572766572206f7220504850206c6f677320666f72206572726f7220696e666f726d6174696f6e2e, 'none'),
(130, 'sites/all/modules/views/js/ajax.js', 'default', 0x416e206572726f72206f636375727265642061742040706174682e5c6e5c6e4572726f72204465736372697074696f6e3a20406572726f72, 'none'),
(131, 'field:contact-field_contact_address:widget_label', 'cck', 0x41646472657373, '1'),
(132, 'field:contact-field_contact_email:widget_label', 'cck', 0x456d61696c, '1'),
(133, 'field:contact-field_contact_fax:widget_label', 'cck', 0x466178, '1'),
(134, 'field:contact-field_contact_mobile:widget_label', 'cck', 0x4d6f62696c65, '1'),
(135, 'field:contact-field_contact_phone:widget_label', 'cck', 0x50686f6e65, '1'),
(136, 'field:contact-field_contact_website:widget_label', 'cck', 0x57656273697465, '1'),
(137, 'type:poll:name', 'nodetype', 0x506f6c6c, '1'),
(138, 'type:poll:title', 'nodetype', 0x5175657374696f6e, '1'),
(139, 'type:poll:description', 'nodetype', 0x41203c656d3e706f6c6c3c2f656d3e2069732061207175657374696f6e2077697468206120736574206f6620706f737369626c6520726573706f6e7365732e2041203c656d3e706f6c6c3c2f656d3e2c206f6e636520637265617465642c206175746f6d61746963616c6c792070726f766964657320612073696d706c652072756e6e696e6720636f756e74206f6620746865206e756d626572206f6620766f74657320726563656976656420666f72206561636820726573706f6e73652e, '1'),
(140, 'type:contact:name', 'nodetype', 0x436f6e74616374, '1'),
(141, 'type:contact:title', 'nodetype', 0x5469746c65, '1'),
(142, 'type:page:name', 'nodetype', 0x50616765, '1'),
(143, 'type:page:title', 'nodetype', 0x5469746c65, '1'),
(144, 'type:page:body', 'nodetype', 0x426f6479, '1'),
(145, 'type:page:description', 'nodetype', 0x41203c656d3e706167653c2f656d3e2c2073696d696c617220696e20666f726d20746f2061203c656d3e73746f72793c2f656d3e2c20697320612073696d706c65206d6574686f6420666f72206372656174696e6720616e6420646973706c6179696e6720696e666f726d6174696f6e207468617420726172656c79206368616e6765732c207375636820617320616e202241626f7574207573222073656374696f6e206f66206120776562736974652e2042792064656661756c742c2061203c656d3e706167653c2f656d3e20656e74727920646f6573206e6f7420616c6c6f772076697369746f7220636f6d6d656e747320616e64206973206e6f74206665617475726564206f6e207468652073697465277320696e697469616c20686f6d6520706167652e, '1'),
(146, 'type:story:name', 'nodetype', 0x53746f7279, '1'),
(147, 'type:story:title', 'nodetype', 0x5469746c65, '1'),
(148, 'type:story:body', 'nodetype', 0x426f6479, '1'),
(149, 'type:story:description', 'nodetype', 0x41203c656d3e73746f72793c2f656d3e2c2073696d696c617220696e20666f726d20746f2061203c656d3e706167653c2f656d3e2c20697320696465616c20666f72206372656174696e6720616e6420646973706c6179696e6720636f6e74656e74207468617420696e666f726d73206f7220656e676167657320776562736974652076697369746f72732e2050726573732072656c65617365732c207369746520616e6e6f756e63656d656e74732c20616e6420696e666f726d616c20626c6f672d6c696b6520656e7472696573206d617920616c6c206265206372656174656420776974682061203c656d3e73746f72793c2f656d3e20656e7472792e2042792064656661756c742c2061203c656d3e73746f72793c2f656d3e20656e747279206973206175746f6d61746963616c6c79206665617475726564206f6e207468652073697465277320696e697469616c20686f6d6520706167652c20616e642070726f766964657320746865206162696c69747920746f20706f737420636f6d6d656e74732e, '1'),
(150, 'item:225:title', 'menu', 0x5472616e6720436875, '1'),
(874, '/goodmilk/admin/content/types', 'default', 0x54797065, '6.22'),
(153, 'item:444:title', 'menu', 0x4c69e1bb876e2068e1bb87, '1'),
(154, '/goodmilk/admin/settings/language', 'default', 0x707265737320217820746f20636c6f7365, '6.22'),
(155, '/goodmilk/admin/settings/language', 'default', 0x4c616e677561676573, '6.22'),
(156, '/goodmilk/admin/settings/language', 'default', 0x436f6e666967757265206c616e67756167657320666f7220636f6e74656e7420616e6420746865207573657220696e746572666163652e, '6.22'),
(157, '/goodmilk/admin/settings/language', 'default', 0x4c65667420746f207269676874, '6.22'),
(158, '/goodmilk/admin/settings/language', 'default', 0x5361766520636f6e66696775726174696f6e, '6.22'),
(159, '/goodmilk/admin/settings/language', 'default', 0x65646974, '6.22'),
(160, '/goodmilk/admin/settings/language', 'default', 0x456e61626c6564, '6.22'),
(161, '/goodmilk/admin/settings/language', 'default', 0x436f6465, '6.22'),
(162, '/goodmilk/admin/settings/language', 'default', 0x456e676c697368206e616d65, '6.22'),
(163, '/goodmilk/admin/settings/language', 'default', 0x4e6174697665206e616d65, '6.22'),
(164, '/goodmilk/admin/settings/language', 'default', 0x446972656374696f6e, '6.22'),
(165, '/goodmilk/admin/settings/language', 'default', 0x44656661756c74, '6.22'),
(166, '/goodmilk/admin/settings/language', 'default', 0x576569676874, '6.22'),
(167, '/goodmilk/admin/settings/language', 'default', 0x4f7065726174696f6e73, '6.22'),
(168, '/goodmilk/admin/settings/language', 'default', 0x506f6c6c, '6.22'),
(169, '/goodmilk/admin/settings/language', 'default', 0x41203c656d3e706f6c6c3c2f656d3e2069732061207175657374696f6e2077697468206120736574206f6620706f737369626c6520726573706f6e7365732e2041203c656d3e706f6c6c3c2f656d3e2c206f6e636520637265617465642c206175746f6d61746963616c6c792070726f766964657320612073696d706c652072756e6e696e6720636f756e74206f6620746865206e756d626572206f6620766f74657320726563656976656420666f72206561636820726573706f6e73652e, '6.22'),
(170, '/goodmilk/admin/settings/language', 'default', 0x5175657374696f6e, '6.22'),
(171, '/goodmilk/admin/settings/language', 'default', 0x4c6566742073696465626172, '6.22'),
(172, '/goodmilk/admin/settings/language', 'default', 0x52696768742073696465626172, '6.22'),
(173, '/goodmilk/admin/settings/language', 'default', 0x436f6e74656e74, '6.22'),
(174, '/goodmilk/admin/settings/language', 'default', 0x486561646572, '6.22'),
(175, '/goodmilk/admin/settings/language', 'default', 0x466f6f746572, '6.22'),
(176, '/goodmilk/admin/settings/language', 'default', 0x506f77657265642062792044727570616c2c20616e206f70656e20736f7572636520636f6e74656e74206d616e6167656d656e742073797374656d, '6.22'),
(177, '/goodmilk/admin/settings/language', 'default', 0x486f6d65, '6.22'),
(178, '/goodmilk/admin/settings/language', 'default', '', '6.22'),
(179, '/goodmilk/admin/settings/language', 'default', 0x41646d696e6973746572, '6.22'),
(180, '/goodmilk/admin/settings/language', 'default', 0x436f6d70616374206d6f6465, '6.22'),
(181, '/goodmilk/admin/settings/language', 'default', 0x436f6e74656e74206d616e6167656d656e74, '6.22'),
(182, '/goodmilk/admin/settings/language', 'default', 0x4d616e61676520796f75722073697465277320636f6e74656e742e, '6.22'),
(183, '/goodmilk/admin/settings/language', 'default', 0x48656c70, '6.22'),
(184, '/goodmilk/admin/settings/language', 'default', 0x5265706f727473, '6.22'),
(185, '/goodmilk/admin/settings/language', 'default', 0x56696577207265706f7274732066726f6d2073797374656d206c6f677320616e64206f746865722073746174757320696e666f726d6174696f6e2e, '6.22'),
(186, '/goodmilk/admin/settings/language', 'default', 0x53697465206275696c64696e67, '6.22'),
(187, '/goodmilk/admin/settings/language', 'default', 0x436f6e74726f6c20686f7720796f75722073697465206c6f6f6b7320616e64206665656c732e, '6.22'),
(188, '/goodmilk/admin/settings/language', 'default', 0x5369746520636f6e66696775726174696f6e, '6.22'),
(189, '/goodmilk/admin/settings/language', 'default', 0x41646a757374206261736963207369746520636f6e66696775726174696f6e206f7074696f6e732e, '6.22'),
(190, '/goodmilk/admin/settings/language', 'default', 0x416374696f6e73, '6.22'),
(191, '/goodmilk/admin/settings/language', 'default', 0x4d616e6167652074686520616374696f6e7320646566696e656420666f7220796f757220736974652e, '6.22'),
(192, '/goodmilk/admin/settings/language', 'default', 0x41646d696e697374726174696f6e207468656d65, '6.22'),
(193, '/goodmilk/admin/settings/language', 'default', 0x53657474696e677320666f7220686f7720796f75722061646d696e6973747261746976652070616765732073686f756c64206c6f6f6b2e, '6.22'),
(194, '/goodmilk/admin/settings/language', 'default', 0x436c65616e2055524c73, '6.22'),
(195, '/goodmilk/admin/settings/language', 'default', 0x456e61626c65206f722064697361626c6520636c65616e2055524c7320666f7220796f757220736974652e, '6.22'),
(196, '/goodmilk/admin/settings/language', 'default', 0x53657474696e677320666f7220686f772044727570616c20646973706c617973206461746520616e642074696d652c2061732077656c6c206173207468652073797374656d27732064656661756c742074696d657a6f6e652e, '6.22'),
(197, '/goodmilk/admin/settings/language', 'default', 0x4572726f72207265706f7274696e67, '6.22'),
(198, '/goodmilk/admin/settings/language', 'default', 0x436f6e74726f6c20686f772044727570616c206465616c732077697468206572726f727320696e636c7564696e67203430332f343034206572726f72732061732077656c6c20617320504850206572726f72207265706f7274696e672e, '6.22'),
(199, '/goodmilk/admin/settings/language', 'default', 0x46696c652073797374656d, '6.22'),
(200, '/goodmilk/admin/settings/language', 'default', 0x54656c6c2044727570616c20776865726520746f2073746f72652075706c6f616465642066696c657320616e6420686f772074686579206172652061636365737365642e, '6.22'),
(201, '/goodmilk/admin/settings/language', 'default', 0x496d61676520746f6f6c6b6974, '6.22'),
(202, '/goodmilk/admin/settings/language', 'default', 0x43686f6f736520776869636820696d61676520746f6f6c6b697420746f2075736520696620796f75206861766520696e7374616c6c6564206f7074696f6e616c20746f6f6c6b6974732e, '6.22'),
(203, '/goodmilk/admin/settings/language', 'default', 0x496e70757420666f726d617473, '6.22'),
(204, '/goodmilk/admin/settings/language', 'default', 0x436f6e66696775726520686f7720636f6e74656e7420696e7075742062792075736572732069732066696c74657265642c20696e636c7564696e6720616c6c6f7765642048544d4c20746167732e20416c736f20616c6c6f777320656e61626c696e67206f66206d6f64756c652d70726f76696465642066696c746572732e, '6.22'),
(205, '/goodmilk/admin/settings/language', 'default', 0x4c6f6767696e6720616e6420616c65727473, '6.22'),
(206, '/goodmilk/admin/settings/language', 'default', 0x53657474696e677320666f72206c6f6767696e6720616e6420616c65727473206d6f64756c65732e20566172696f7573206d6f64756c65732063616e20726f7574652044727570616c27732073797374656d206576656e747320746f20646966666572656e742064657374696e6174696f6e2c2073756368206173207379736c6f672c2064617461626173652c20656d61696c2c202e2e2e6574632e, '6.22'),
(207, '/goodmilk/admin/settings/language', 'default', 0x506572666f726d616e6365, '6.22'),
(208, '/goodmilk/admin/settings/language', 'default', 0x456e61626c65206f722064697361626c6520706167652063616368696e6720666f7220616e6f6e796d6f757320757365727320616e64207365742043535320616e64204a532062616e647769647468206f7074696d697a6174696f6e206f7074696f6e732e, '6.22'),
(209, '/goodmilk/admin/settings/language', 'default', 0x5369746520696e666f726d6174696f6e, '6.22'),
(210, '/goodmilk/admin/settings/language', 'default', 0x4368616e6765206261736963207369746520696e666f726d6174696f6e2c2073756368206173207468652073697465206e616d652c20736c6f67616e2c20652d6d61696c20616464726573732c206d697373696f6e2c2066726f6e74207061676520616e64206d6f72652e, '6.22'),
(211, '/goodmilk/admin/settings/language', 'default', 0x53697465206d61696e74656e616e6365, '6.22'),
(212, '/goodmilk/admin/settings/language', 'default', 0x54616b65207468652073697465206f66662d6c696e6520666f72206d61696e74656e616e6365206f72206272696e67206974206261636b206f6e6c696e652e, '6.22'),
(213, '/goodmilk/admin/settings/language', 'default', 0x41646d696e697374726174696f6e206d656e75, '6.22'),
(214, '/goodmilk/admin/settings/language', 'default', 0x41646a7573742061646d696e697374726174696f6e206d656e752073657474696e67732e, '6.22'),
(215, '/goodmilk/admin/settings/language', 'default', 0x496d616765415049, '6.22'),
(216, '/goodmilk/admin/settings/language', 'default', 0x436f6e66696775726520496d6167654150492e, '6.22'),
(217, '/goodmilk/admin/settings/language', 'default', 0x446576656c2073657474696e6773, '6.22'),
(218, '/goodmilk/admin/settings/language', 'default', 0x48656c7065722066756e6374696f6e732c2070616765732c20616e6420626c6f636b7320746f206173736973742044727570616c20646576656c6f706572732e2054686520646576656c20626c6f636b732063616e206265206d616e616765642076696120746865203c6120687265663d222f61646d696e2f6275696c642f626c6f636b223e626c6f636b2061646d696e697374726174696f6e3c2f613e20706167652e, '6.22'),
(219, '/goodmilk/admin/settings/language', 'default', 0x476f6f676c6520416e616c7974696373, '6.22'),
(220, '/goodmilk/admin/settings/language', 'default', 0x436f6e666967757265207468652073657474696e6773207573656420746f2067656e657261746520796f757220476f6f676c6520416e616c797469637320747261636b696e6720636f64652e, '6.22'),
(221, '/goodmilk/admin/settings/language', 'default', 0x494d4345, '6.22'),
(222, '/goodmilk/admin/settings/language', 'default', 0x436f6e74726f6c20686f7720796f757220696d6167652f66696c652062726f7773657220776f726b732e, '6.22'),
(223, '/goodmilk/admin/settings/language', 'default', 0x4c69676874626f7832, '6.22'),
(224, '/goodmilk/admin/settings/language', 'default', 0x416c6c6f777320746865207573657220746f20636f6e66696775726520746865206c69676874626f78322073657474696e6773, '6.22'),
(225, '/goodmilk/admin/settings/language', 'default', 0x4e696365206d656e7573, '6.22'),
(226, '/goodmilk/admin/settings/language', 'default', 0x436f6e666967757265204e696365206d656e75732e, '6.22'),
(227, '/goodmilk/admin/settings/language', 'default', 0x5365617263682073657474696e6773, '6.22'),
(228, '/goodmilk/admin/settings/language', 'default', 0x436f6e6669677572652072656c6576616e63652073657474696e677320666f722073656172636820616e64206f7468657220696e646578696e67206f7074696f6e73, '6.22'),
(229, '/goodmilk/admin/settings/language', 'default', 0x577973697779672070726f66696c6573, '6.22'),
(230, '/goodmilk/admin/settings/language', 'default', 0x436f6e66696775726520636c69656e742d7369646520656469746f72732e, '6.22'),
(231, '/goodmilk/admin/settings/language', 'default', 0x55736572206d616e6167656d656e74, '6.22'),
(232, '/goodmilk/admin/settings/language', 'default', 0x4d616e61676520796f7572207369746527732075736572732c2067726f75707320616e642061636365737320746f20736974652066656174757265732e, '6.22'),
(233, '/goodmilk/admin/settings/language', 'default', 0x4c6f67206f7574, '6.22'),
(234, '/goodmilk/admin/settings/language', 'default', 0x5253532066656564, '6.22'),
(235, '/goodmilk/admin/settings/language', 'default', 0x55736572206163636f756e74, '6.22'),
(236, '/goodmilk/admin/settings/language', 'default', 0x436f6d706f73652074697073, '6.22'),
(237, '/goodmilk/admin/settings/language', 'default', 0x43726561746520636f6e74656e74, '6.22'),
(238, '/goodmilk/admin/settings/language', 'default', 0x44656c65746520636f6d6d656e74, '6.22'),
(239, '/goodmilk/admin/settings/language', 'default', 0x4564697420636f6d6d656e74, '6.22'),
(240, '/goodmilk/admin/settings/language', 'default', 0x46696c6520646f776e6c6f6164, '6.22'),
(241, '/goodmilk/admin/settings/language', 'default', 0x55736572206175746f636f6d706c657465, '6.22'),
(242, '/goodmilk/admin/settings/language', 'default', 0x4d79206163636f756e74, '6.22'),
(243, '/goodmilk/admin/settings/language', 'default', 0x4175746f636f6d706c657465207461786f6e6f6d79, '6.22'),
(244, '/goodmilk/admin/settings/language', 'default', 0x44656c657465, '6.22'),
(245, '/goodmilk/admin/settings/language', 'default', 0x4e6f6465207265666572656e6365, '6.22'),
(246, '/goodmilk/admin/settings/language', 'default', 0x53746f726520746865204944206f6620612072656c61746564206e6f646520617320616e20696e74656765722076616c75652e, '6.22'),
(247, '/goodmilk/admin/settings/language', 'default', 0x496e7465676572, '6.22'),
(248, '/goodmilk/admin/settings/language', 'default', 0x53746f72652061206e756d62657220696e2074686520646174616261736520617320616e20696e74656765722e, '6.22'),
(249, '/goodmilk/admin/settings/language', 'default', 0x446563696d616c, '6.22'),
(250, '/goodmilk/admin/settings/language', 'default', 0x53746f72652061206e756d62657220696e2074686520646174616261736520696e206120666978656420646563696d616c20666f726d61742e, '6.22'),
(251, '/goodmilk/admin/settings/language', 'default', 0x466c6f6174, '6.22'),
(252, '/goodmilk/admin/settings/language', 'default', 0x53746f72652061206e756d62657220696e2074686520646174616261736520696e206120666c6f6174696e6720706f696e7420666f726d61742e, '6.22'),
(253, '/goodmilk/admin/settings/language', 'default', 0x54657874, '6.22'),
(254, '/goodmilk/admin/settings/language', 'default', 0x53746f7265207465787420696e207468652064617461626173652e, '6.22'),
(255, '/goodmilk/admin/settings/language', 'default', 0x55736572207265666572656e6365, '6.22'),
(256, '/goodmilk/admin/settings/language', 'default', 0x53746f726520746865204944206f6620612072656c61746564207573657220617320616e20696e74656765722076616c75652e, '6.22'),
(257, '/goodmilk/admin/settings/language', 'default', 0x53746f72652061206461746520696e2074686520646174616261736520617320616e2049534f20646174652c207265636f6d6d656e64656420666f7220686973746f726963616c206f72207061727469616c2064617465732e, '6.22'),
(258, '/goodmilk/admin/settings/language', 'default', 0x53746f72652061206461746520696e2074686520646174616261736520617320612074696d657374616d702c206465707265636174656420666f726d617420746f2073757070706f7274206c656761637920646174612e, '6.22'),
(259, '/goodmilk/admin/settings/language', 'default', 0x53746f72652061206461746520696e207468652064617461626173652061732061206461746574696d65206669656c642c207265636f6d6d656e64656420666f7220636f6d706c65746520646174657320616e642074696d65732074686174206d6179206e6565642074696d657a6f6e6520636f6e76657273696f6e2e, '6.22'),
(260, '/goodmilk/admin/settings/language', 'default', 0x46696c65, '6.22'),
(261, '/goodmilk/admin/settings/language', 'default', 0x53746f726520616e206172626974726172792066696c652e, '6.22'),
(262, '/goodmilk/admin/settings/language', 'default', 0x53656c656374206c697374, '6.22'),
(263, '/goodmilk/admin/settings/language', 'default', 0x436865636b20626f7865732f726164696f20627574746f6e73, '6.22'),
(264, '/goodmilk/admin/settings/language', 'default', 0x4175746f636f6d706c6574652074657874206669656c64, '6.22'),
(265, '/goodmilk/admin/settings/language', 'default', 0x5469746c6520286c696e6b29, '6.22'),
(266, '/goodmilk/admin/settings/language', 'default', 0x5469746c6520286e6f206c696e6b29, '6.22'),
(267, '/goodmilk/admin/settings/language', 'default', 0x46756c6c206e6f6465, '6.22'),
(268, '/goodmilk/admin/settings/language', 'default', 0x546561736572, '6.22'),
(269, '/goodmilk/admin/settings/language', 'default', 0x54657874206669656c64, '6.22'),
(270, '/goodmilk/admin/settings/language', 'default', 0x756e666f726d6174746564, '6.22'),
(271, '/goodmilk/admin/settings/language', 'default', 0x53696e676c65206f6e2f6f666620636865636b626f78, '6.22'),
(272, '/goodmilk/admin/settings/language', 'default', 0x54657874206172656120286d756c7469706c6520726f777329, '6.22'),
(273, '/goodmilk/admin/settings/language', 'default', 0x5472696d6d6564, '6.22'),
(274, '/goodmilk/admin/settings/language', 'default', 0x53656c656374204c697374, '6.22'),
(275, '/goodmilk/admin/settings/language', 'default', 0x53656c656374204c697374207769746820526570656174206f7074696f6e73, '6.22'),
(276, '/goodmilk/admin/settings/language', 'default', 0x54657874204669656c64207769746820637573746f6d20696e70757420666f726d6174, '6.22'),
(277, '/goodmilk/admin/settings/language', 'default', 0x54657874204669656c64207769746820526570656174206f7074696f6e73, '6.22'),
(278, '/goodmilk/admin/settings/language', 'default', 0x41732054696d652041676f, '6.22'),
(279, '/goodmilk/admin/settings/language', 'default', 0x4c6f6e67, '6.22'),
(280, '/goodmilk/admin/settings/language', 'default', 0x4d656469756d, '6.22'),
(281, '/goodmilk/admin/settings/language', 'default', 0x53686f7274, '6.22'),
(282, '/goodmilk/admin/settings/language', 'default', 0x46696c652055706c6f6164, '6.22'),
(283, '/goodmilk/admin/settings/language', 'default', 0x4120706c61696e2066696c652075706c6f6164207769646765742e, '6.22'),
(284, '/goodmilk/admin/settings/language', 'default', 0x47656e657269632066696c6573, '6.22'),
(285, '/goodmilk/admin/settings/language', 'default', 0x446973706c61797320616c6c206b696e6473206f662066696c6573207769746820616e2069636f6e20616e642061206c696e6b65642066696c65206465736372697074696f6e2e, '6.22'),
(286, '/goodmilk/admin/settings/language', 'default', 0x5061746820746f2066696c65, '6.22'),
(287, '/goodmilk/admin/settings/language', 'default', 0x446973706c617973207468652066696c652073797374656d207061746820746f207468652066696c652e, '6.22'),
(288, '/goodmilk/admin/settings/language', 'default', 0x55524c20746f2066696c65, '6.22'),
(289, '/goodmilk/admin/settings/language', 'default', 0x446973706c61797320612066756c6c2055524c20746f207468652066696c652e, '6.22'),
(290, '/goodmilk/admin/settings/language', 'default', 0x496d616765, '6.22'),
(291, '/goodmilk/admin/settings/language', 'default', 0x416e20656469742077696467657420666f7220696d6167652066696c65732c20696e636c7564696e6720612070726576696577206f662074686520696d6167652e, '6.22'),
(292, '/goodmilk/admin/settings/language', 'default', 0x446973706c61797320696d6167652066696c657320696e207468656972206f726967696e616c2073697a652e, '6.22'),
(293, '/goodmilk/admin/settings/language', 'default', 0x496d616765206c696e6b656420746f206e6f6465, '6.22'),
(294, '/goodmilk/admin/settings/language', 'default', 0x496d616765206c696e6b656420746f2066696c65, '6.22'),
(295, '/goodmilk/admin/settings/language', 'default', 0x4c69676874626f783220696672616d65, '6.22'),
(296, '/goodmilk/admin/settings/language', 'default', 0x4e6f6465206d6f64756c6520666f726d2e, '6.22'),
(297, '/goodmilk/admin/settings/language', 'default', 0x5265766973696f6e20696e666f726d6174696f6e, '6.22'),
(298, '/goodmilk/admin/settings/language', 'default', 0x417574686f72696e6720696e666f726d6174696f6e, '6.22'),
(299, '/goodmilk/admin/settings/language', 'default', 0x5075626c697368696e67206f7074696f6e73, '6.22'),
(300, '/goodmilk/admin/settings/language', 'default', 0x436f6d6d656e742073657474696e6773, '6.22'),
(301, '/goodmilk/admin/settings/language', 'default', 0x436f6d6d656e74206d6f64756c6520666f726d2e, '6.22'),
(302, '/goodmilk/admin/settings/language', 'default', 0x4d656e752073657474696e6773, '6.22'),
(303, '/goodmilk/admin/settings/language', 'default', 0x4d656e75206d6f64756c6520666f726d2e, '6.22'),
(304, '/goodmilk/admin/settings/language', 'default', 0x506174682073657474696e6773, '6.22'),
(305, '/goodmilk/admin/settings/language', 'default', 0x50617468206d6f64756c6520666f726d2e, '6.22'),
(306, '/goodmilk/admin/settings/language', 'default', 0x506f6c6c207469746c65, '6.22'),
(307, '/goodmilk/admin/settings/language', 'default', 0x506f6c6c206d6f64756c65207469746c652e, '6.22'),
(308, '/goodmilk/admin/settings/language', 'default', 0x506f6c6c2063686f69636573, '6.22'),
(309, '/goodmilk/admin/settings/language', 'default', 0x506f6c6c206d6f64756c652063686f696365732e, '6.22'),
(310, '/goodmilk/admin/settings/language', 'default', 0x506f6c6c2073657474696e6773, '6.22'),
(311, '/goodmilk/admin/settings/language', 'default', 0x506f6c6c206d6f64756c652073657474696e67732e, '6.22'),
(312, '/goodmilk/admin/settings/language', 'default', 0x557365727265666572656e6365206175746f636f6d706c657465, '6.22'),
(313, '/goodmilk/admin/settings/language', 'default', 0x5669657773, '6.22'),
(314, '/goodmilk/admin/settings/language', 'default', 0x416a61782063616c6c6261636b20666f722076696577206c6f6164696e672e, '6.22'),
(315, '/goodmilk/admin/settings/language', 'default', 0x436f6e74616374, '6.22'),
(316, '/goodmilk/admin/settings/language', 'default', 0x46696c652062726f77736572, '6.22'),
(317, '/goodmilk/admin/settings/language', 'default', 0x536561726368, '6.22'),
(318, '/goodmilk/admin/settings/language', 'default', 0x557365722074696d657a6f6e65, '6.22'),
(319, '/goodmilk/admin/settings/language', 'default', 0x46696c74657220585353, '6.22'),
(320, '/goodmilk/admin/settings/language', 'default', 0x52656d6f7665206669656c64, '6.22'),
(321, '/goodmilk/admin/settings/language', 'default', 0x506f6c6c73, '6.22'),
(322, '/goodmilk/admin/settings/language', 'default', 0x55736572206c697374, '6.22'),
(323, '/goodmilk/admin/settings/language', 'default', 0x5361766520737472696e67, '6.22'),
(324, '/goodmilk/admin/settings/language', 'default', 0x4e6f6465207469746c65206175746f636f6d706c657465, '6.22'),
(325, '/goodmilk/admin/settings/language', 'default', 0x4c616e6775616765206e65676f74696174696f6e, '6.22'),
(326, '/goodmilk/admin/settings/language', 'default', 0x4c697374, '6.22'),
(327, '/goodmilk/admin/settings/language', 'default', 0x4f7074696f6e73, '6.22'),
(328, '/goodmilk/admin/settings/language', 'default', 0x436f6e66696775726520657874656e646564206f7074696f6e7320666f72206d756c74696c696e6775616c20636f6e74656e7420616e64207472616e736c6174696f6e732e, '6.22'),
(329, '/goodmilk/admin/settings/language', 'default', 0x5661726961626c6573, '6.22'),
(330, '/goodmilk/admin/settings/language', 'default', 0x4d756c74696c696e6775616c207661726961626c65732e, '6.22'),
(331, '/goodmilk/admin/settings/language', 'default', 0x416464206c616e6775616765, '6.22'),
(332, '/goodmilk/admin/settings/language', 'default', 0x436f6e666967757265, '6.22'),
(333, '/goodmilk/admin/settings/language', 'default', 0x49636f6e73, '6.22'),
(334, '/goodmilk/admin/settings/language', 'default', 0x4d756c74696c696e6775616c2073797374656d, '6.22'),
(335, '/goodmilk/admin/settings/language', 'default', 0x537472696e67207472616e736c6174696f6e, '6.22'),
(336, '/goodmilk/admin/settings/language', 'default', 0x5468697320706167652070726f766964657320616e206f76657276696577206f6620796f75722073697465277320656e61626c6564206c616e6775616765732e204966206d756c7469706c65206c616e6775616765732061726520617661696c61626c6520616e6420656e61626c65642c207468652074657874206f6e20796f7572207369746520696e74657266616365206d6179206265207472616e736c617465642c2072656769737465726564207573657273206d61792073656c65637420746865697220707265666572726564206c616e6775616765206f6e20746865203c656d3e4d79206163636f756e743c2f656d3e20706167652c20616e64207369746520617574686f7273206d617920696e6469636174652061207370656369666963206c616e6775616765207768656e206372656174696e6720706f7374732e20546865207369746527732064656661756c74206c616e6775616765206973207573656420666f7220616e6f6e796d6f75732076697369746f727320616e6420666f722075736572732077686f2068617665206e6f742073656c6563746564206120707265666572726564206c616e67756167652e, '6.22'),
(337, '/goodmilk/admin/settings/language', 'default', 0x466f722065616368206c616e677561676520617661696c61626c65206f6e2074686520736974652c2075736520746865203c656d3e656469743c2f656d3e206c696e6b20746f20636f6e666967757265206c616e67756167652064657461696c732c20696e636c7564696e67206e616d652c20616e206f7074696f6e616c206c616e67756167652d73706563696669632070617468206f7220646f6d61696e2c20616e64207768657468657220746865206c616e6775616765206973206e61746976656c792070726573656e74656420656974686572206c6566742d746f2d7269676874206f722072696768742d746f2d6c6566742e205468657365206c616e67756167657320616c736f2061707065617220696e20746865203c656d3e4c616e67756167653c2f656d3e2073656c656374696f6e207768656e206372656174696e67206120706f7374206f66206120636f6e74656e7420747970652077697468206d756c74696c696e6775616c20737570706f72742e, '6.22'),
(338, '/goodmilk/admin/settings/language', 'default', 0x55736520746865203c6120687265663d22406164642d6c616e6775616765223e616464206c616e677561676520706167653c2f613e20746f20656e61626c65206164646974696f6e616c206c616e6775616765732028616e64206175746f6d61746963616c6c7920696d706f72742066696c65732066726f6d2061207472616e736c6174696f6e207061636b6167652c20696620617661696c61626c65292c20746865203c6120687265663d2240736561726368223e7472616e736c61746520696e7465726661636520706167653c2f613e20746f206c6f6361746520737472696e677320666f72206d616e75616c207472616e736c6174696f6e2c206f7220746865203c6120687265663d2240696d706f7274223e696d706f727420706167653c2f613e20746f20616464207472616e736c6174696f6e732066726f6d20696e646976696475616c203c656d3e2e706f3c2f656d3e2066696c65732e2041206e756d626572206f6620636f6e7472696275746564207472616e736c6174696f6e207061636b6167657320636f6e7461696e696e67203c656d3e2e706f3c2f656d3e2066696c65732061726520617661696c61626c65206f6e20746865203c6120687265663d22407472616e736c6174696f6e73223e44727570616c2e6f7267207472616e736c6174696f6e7320706167653c2f613e2e, '6.22'),
(339, '/goodmilk/admin/settings/language', 'default', 0x44727570616c20636f72652075706461746520737461747573, '6.22'),
(340, '/goodmilk/admin/settings/language', 'default', 0x4e6f20757064617465206461746120617661696c61626c65, '6.22'),
(341, '/goodmilk/admin/settings/language', 'default', 0x4e6f20696e666f726d6174696f6e20697320617661696c61626c652061626f757420706f74656e7469616c206e65772072656c656173657320666f722063757272656e746c7920696e7374616c6c6564206d6f64756c657320616e64207468656d65732e20546f20636865636b20666f7220757064617465732c20796f75206d6179206e65656420746f203c6120687265663d224072756e5f63726f6e223e72756e2063726f6e3c2f613e206f7220796f752063616e203c6120687265663d2240636865636b5f6d616e75616c6c79223e636865636b206d616e75616c6c793c2f613e2e20506c65617365206e6f7465207468617420636865636b696e6720666f7220617661696c61626c6520757064617465732063616e2074616b652061206c6f6e672074696d652c20736f20706c656173652062652070617469656e742e, '6.22'),
(342, '/goodmilk/admin/settings/language', 'default', 0x3c7374726f6e673e5761726e696e673c2f7374726f6e673e3a204368616e67696e67207468652064656661756c74206c616e6775616765206d6179206861766520756e77616e7465642065666665637473206f6e20737472696e67207472616e736c6174696f6e732e2052656164206d6f72652061626f7574203c6120687265663d22406931386e737472696e67732d68656c70223e537472696e67207472616e736c6174696f6e3c2f613e, '6.22'),
(343, '/goodmilk/admin/settings/language', 'default', 0x53656172636820746869732073697465, '6.22'),
(344, '/goodmilk/admin/settings/language', 'default', 0x456e74657220746865207465726d7320796f75207769736820746f2073656172636820666f722e, '6.22'),
(345, '/goodmilk/admin/settings/language', 'default', 0x217469746c653a20217265717569726564, '6.22'),
(346, '/goodmilk/admin/settings/language', 'default', 0x52756e2063726f6e, '6.22'),
(347, '/goodmilk/admin/settings/language', 'default', 0x5661726961626c6520656469746f72, '6.22'),
(348, '/goodmilk/admin/settings/language', 'default', 0x4564697420616e642064656c6574652073697465207661726961626c65732e, '6.22'),
(349, '/goodmilk/admin/settings/language', 'default', 0x4c6f67206f75742040757365726e616d65, '6.22'),
(350, '/goodmilk/admin/settings/language', 'default', 0x43757272656e7420616e6f6e796d6f7573202f2061757468656e74696361746564207573657273, '6.22'),
(351, '/goodmilk/admin/settings/language', 'default', 0x40636f756e742d616e6f6e202f2040636f756e742d61757468202169636f6e, '6.22'),
(352, '/goodmilk/admin/settings/language', 'default', 0x436f6d6d656e7473, '6.22'),
(353, '/goodmilk/admin/settings/language', 'default', 0x4c69737420616e642065646974207369746520636f6d6d656e747320616e642074686520636f6d6d656e74206d6f6465726174696f6e2071756575652e, '6.22'),
(354, '/goodmilk/admin/settings/language', 'default', 0x417070726f76616c207175657565, '6.22'),
(355, '/goodmilk/admin/settings/language', 'default', 0x5075626c697368656420636f6d6d656e7473, '6.22'),
(356, '/goodmilk/admin/settings/language', 'default', 0x566965772c20656469742c20616e642064656c65746520796f75722073697465277320636f6e74656e742e, '6.22'),
(357, '/goodmilk/admin/settings/language', 'default', 0x4d616e61676520706f73747320627920636f6e74656e7420747970652c20696e636c7564696e672064656661756c74207374617475732c2066726f6e7420706167652070726f6d6f74696f6e2c206574632e, '6.22'),
(358, '/goodmilk/admin/settings/language', 'default', 0x41646420636f6e74656e742074797065, '6.22'),
(359, '/goodmilk/admin/settings/language', 'default', 0x456469742021636f6e74656e742d74797065, '6.22'),
(360, '/goodmilk/admin/settings/language', 'default', 0x446973706c6179206669656c6473, '6.22'),
(361, '/goodmilk/admin/settings/language', 'default', 0x4261736963, '6.22'),
(362, '/goodmilk/admin/settings/language', 'default', 0x525353, '6.22'),
(363, '/goodmilk/admin/settings/language', 'default', 0x546f6b656e, '6.22'),
(364, '/goodmilk/admin/settings/language', 'default', 0x4d616e616765206669656c6473, '6.22'),
(365, '/goodmilk/admin/settings/language', 'default', 0x4578706f7274, '6.22'),
(366, '/goodmilk/admin/settings/language', 'default', 0x4669656c6473, '6.22'),
(367, '/goodmilk/admin/settings/language', 'default', 0x496d706f7274, '6.22'),
(368, '/goodmilk/admin/settings/language', 'default', 0x41646472657373, '6.22'),
(369, '/goodmilk/admin/settings/language', 'default', 0x456d61696c, '6.22'),
(370, '/goodmilk/admin/settings/language', 'default', 0x466178, '6.22'),
(371, '/goodmilk/admin/settings/language', 'default', 0x4d6f62696c65, '6.22'),
(372, '/goodmilk/admin/settings/language', 'default', 0x50686f6e65, '6.22'),
(373, '/goodmilk/admin/settings/language', 'default', 0x57656273697465, '6.22'),
(374, '/goodmilk/admin/settings/language', 'default', 0x506f73742073657474696e6773, '6.22'),
(375, '/goodmilk/admin/settings/language', 'default', 0x436f6e74726f6c20706f7374696e67206265686176696f722c207375636820617320746561736572206c656e6774682c20726571756972696e67207072657669657773206265666f726520706f7374696e672c20616e6420746865206e756d626572206f6620706f737473206f6e207468652066726f6e7420706167652e, '6.22'),
(376, '/goodmilk/admin/settings/language', 'default', 0x525353207075626c697368696e67, '6.22'),
(377, '/goodmilk/admin/settings/language', 'default', 0x436f6e66696775726520746865206e756d626572206f66206974656d7320706572206665656420616e6420776865746865722066656564732073686f756c64206265207469746c65732f746561736572732f66756c6c2d746578742e, '6.22'),
(378, '/goodmilk/admin/settings/language', 'default', 0x5461786f6e6f6d79, '6.22'),
(379, '/goodmilk/admin/settings/language', 'default', 0x4d616e6167652074616767696e672c2063617465676f72697a6174696f6e2c20616e6420636c617373696669636174696f6e206f6620796f757220636f6e74656e742e, '6.22'),
(380, '/goodmilk/admin/settings/language', 'default', 0x41646420766f636162756c617279, '6.22'),
(381, '/goodmilk/admin/settings/language', 'default', 0x41203c656d3e706167653c2f656d3e2c2073696d696c617220696e20666f726d20746f2061203c656d3e73746f72793c2f656d3e2c20697320612073696d706c65206d6574686f6420666f72206372656174696e6720616e6420646973706c6179696e6720696e666f726d6174696f6e207468617420726172656c79206368616e6765732c207375636820617320616e202241626f7574207573222073656374696f6e206f66206120776562736974652e2042792064656661756c742c2061203c656d3e706167653c2f656d3e20656e74727920646f6573206e6f7420616c6c6f772076697369746f7220636f6d6d656e747320616e64206973206e6f74206665617475726564206f6e207468652073697465277320696e697469616c20686f6d6520706167652e, '6.22');
INSERT INTO `locales_source` (`lid`, `location`, `textgroup`, `source`, `version`) VALUES
(382, '/goodmilk/admin/settings/language', 'default', 0x41203c656d3e73746f72793c2f656d3e2c2073696d696c617220696e20666f726d20746f2061203c656d3e706167653c2f656d3e2c20697320696465616c20666f72206372656174696e6720616e6420646973706c6179696e6720636f6e74656e74207468617420696e666f726d73206f7220656e676167657320776562736974652076697369746f72732e2050726573732072656c65617365732c207369746520616e6e6f756e63656d656e74732c20616e6420696e666f726d616c20626c6f672d6c696b6520656e7472696573206d617920616c6c206265206372656174656420776974682061203c656d3e73746f72793c2f656d3e20656e7472792e2042792064656661756c742c2061203c656d3e73746f72793c2f656d3e20656e747279206973206175746f6d61746963616c6c79206665617475726564206f6e207468652073697465277320696e697469616c20686f6d6520706167652c20616e642070726f766964657320746865206162696c69747920746f20706f737420636f6d6d656e74732e, '6.22'),
(383, '/goodmilk/admin/settings/language', 'default', 0x417661696c61626c652075706461746573, '6.22'),
(384, '/goodmilk/admin/settings/language', 'default', 0x476574206120737461747573207265706f72742061626f757420617661696c61626c65207570646174657320666f7220796f757220696e7374616c6c6564206d6f64756c657320616e64207468656d65732e, '6.22'),
(385, '/goodmilk/admin/settings/language', 'default', 0x53657474696e6773, '6.22'),
(386, '/goodmilk/admin/settings/language', 'default', 0x526563656e74206c6f6720656e7472696573, '6.22'),
(387, '/goodmilk/admin/settings/language', 'default', 0x56696577206576656e74732074686174206861766520726563656e746c79206265656e206c6f676765642e, '6.22'),
(388, '/goodmilk/admin/settings/language', 'default', 0x537461747573207265706f7274, '6.22'),
(389, '/goodmilk/admin/settings/language', 'default', 0x476574206120737461747573207265706f72742061626f757420796f757220736974652773206f7065726174696f6e20616e6420616e792064657465637465642070726f626c656d732e, '6.22'),
(390, '/goodmilk/admin/settings/language', 'default', 0x546f7020276163636573732064656e69656427206572726f7273, '6.22'),
(391, '/goodmilk/admin/settings/language', 'default', 0x5669657720276163636573732064656e69656427206572726f7273202834303373292e, '6.22'),
(392, '/goodmilk/admin/settings/language', 'default', 0x546f70202770616765206e6f7420666f756e6427206572726f7273, '6.22'),
(393, '/goodmilk/admin/settings/language', 'default', 0x56696577202770616765206e6f7420666f756e6427206572726f7273202834303473292e, '6.22'),
(394, '/goodmilk/admin/settings/language', 'default', 0x416363657373206c6f672073657474696e6773, '6.22'),
(395, '/goodmilk/admin/settings/language', 'default', 0x436f6e74726f6c2064657461696c732061626f7574207768617420616e6420686f7720796f75722073697465206c6f67732e, '6.22'),
(396, '/goodmilk/admin/settings/language', 'default', 0x526563656e742068697473, '6.22'),
(397, '/goodmilk/admin/settings/language', 'default', 0x566965772070616765732074686174206861766520726563656e746c79206265656e20766973697465642e, '6.22'),
(398, '/goodmilk/admin/settings/language', 'default', 0x546f70207061676573, '6.22'),
(399, '/goodmilk/admin/settings/language', 'default', 0x5669657720706167657320746861742068617665206265656e20686974206672657175656e746c792e, '6.22'),
(400, '/goodmilk/admin/settings/language', 'default', 0x546f7020726566657272657273, '6.22'),
(401, '/goodmilk/admin/settings/language', 'default', 0x5669657720746f70207265666572726572732e, '6.22'),
(402, '/goodmilk/admin/settings/language', 'default', 0x546f70207365617263682070687261736573, '6.22'),
(403, '/goodmilk/admin/settings/language', 'default', 0x56696577206d6f737420706f70756c61722073656172636820706872617365732e, '6.22'),
(404, '/goodmilk/admin/settings/language', 'default', 0x546f702076697369746f7273, '6.22'),
(405, '/goodmilk/admin/settings/language', 'default', 0x566965772076697369746f7273207468617420686974206d616e792070616765732e, '6.22'),
(406, '/goodmilk/admin/settings/language', 'default', 0x426c6f636b73, '6.22'),
(407, '/goodmilk/admin/settings/language', 'default', 0x436f6e666967757265207768617420626c6f636b20636f6e74656e74206170706561727320696e20796f75722073697465277320736964656261727320616e64206f7468657220726567696f6e732e, '6.22'),
(408, '/goodmilk/admin/settings/language', 'default', 0x41646420626c6f636b, '6.22'),
(409, '/goodmilk/admin/settings/language', 'default', 0x4761726c616e64, '6.22'),
(410, '/goodmilk/admin/settings/language', 'default', 0x5a656e, '6.22'),
(411, '/goodmilk/admin/settings/language', 'default', 0x426f6f747374726170, '6.22'),
(412, '/goodmilk/admin/settings/language', 'default', 0x4d656e7573, '6.22'),
(413, '/goodmilk/admin/settings/language', 'default', 0x436f6e74726f6c20796f757220736974652773206e617669676174696f6e206d656e752c207072696d617279206c696e6b7320616e64207365636f6e64617279206c696e6b732c2061732077656c6c2061732072656e616d6520616e642072656f7267616e697a65206d656e75206974656d732e, '6.22'),
(414, '/goodmilk/admin/settings/language', 'default', 0x416464206d656e75, '6.22'),
(415, '/goodmilk/admin/settings/language', 'default', 0x4c697374206d656e7573, '6.22'),
(416, '/goodmilk/admin/settings/language', 'default', 0x4d6f64756c6573, '6.22'),
(417, '/goodmilk/admin/settings/language', 'default', 0x456e61626c65206f722064697361626c65206164642d6f6e206d6f64756c657320666f7220796f757220736974652e, '6.22'),
(418, '/goodmilk/admin/settings/language', 'default', 0x556e696e7374616c6c, '6.22'),
(419, '/goodmilk/admin/settings/language', 'default', 0x5468656d6573, '6.22'),
(420, '/goodmilk/admin/settings/language', 'default', 0x4368616e6765207768696368207468656d6520796f757220736974652075736573206f7220616c6c6f777320757365727320746f207365742e, '6.22'),
(421, '/goodmilk/admin/settings/language', 'default', 0x476c6f62616c2073657474696e6773, '6.22'),
(422, '/goodmilk/admin/settings/language', 'default', 0x53656c656374207468652064656661756c74207468656d652e, '6.22'),
(423, '/goodmilk/admin/settings/language', 'default', 0x56696577732061726520637573746f6d697a6564206c69737473206f6620636f6e74656e74206f6e20796f75722073797374656d3b20746865792061726520686967686c7920636f6e666967757261626c6520616e64206769766520796f7520636f6e74726f6c206f76657220686f77206c69737473206f6620636f6e74656e74206172652070726573656e7465642e, '6.22'),
(424, '/goodmilk/admin/settings/language', 'default', 0x416464, '6.22'),
(425, '/goodmilk/admin/settings/language', 'default', 0x546f6f6c73, '6.22'),
(426, '/goodmilk/admin/settings/language', 'default', 0x42756c6b206578706f7274, '6.22'),
(427, '/goodmilk/admin/settings/language', 'default', 0x436f6e76657274, '6.22'),
(428, '/goodmilk/admin/settings/language', 'default', 0x436f6e766572742073746f72656420566965777320312076696577732e, '6.22'),
(429, '/goodmilk/admin/settings/language', 'default', 0x436f6e7461637420666f726d, '6.22'),
(430, '/goodmilk/admin/settings/language', 'default', 0x43726561746520612073797374656d20636f6e7461637420666f726d20616e64207365742075702063617465676f7269657320666f722074686520666f726d20746f207573652e, '6.22'),
(431, '/goodmilk/admin/settings/language', 'default', 0x4164642063617465676f7279, '6.22'),
(432, '/goodmilk/admin/settings/language', 'default', 0x4d6573736167652074656d706c617465, '6.22'),
(433, '/goodmilk/admin/settings/language', 'default', 0x5472616e736c61746520696e74657266616365, '6.22'),
(434, '/goodmilk/admin/settings/language', 'default', 0x5472616e736c61746520746865206275696c7420696e20696e7465726661636520616e64206f7074696f6e616c6c79206f7468657220746578742e, '6.22'),
(435, '/goodmilk/admin/settings/language', 'default', 0x4f76657276696577, '6.22'),
(436, '/goodmilk/admin/settings/language', 'default', 0x52656672657368, '6.22'),
(437, '/goodmilk/admin/settings/language', 'default', 0x55524c20616c6961736573, '6.22'),
(438, '/goodmilk/admin/settings/language', 'default', 0x4368616e676520796f7572207369746527732055524c20706174687320627920616c696173696e67207468656d2e, '6.22'),
(439, '/goodmilk/admin/settings/language', 'default', 0x41646420616c696173, '6.22'),
(440, '/goodmilk/admin/settings/language', 'default', 0x4175746f6d6174656420616c6961732073657474696e6773, '6.22'),
(441, '/goodmilk/admin/settings/language', 'default', 0x44656c65746520616c6961736573, '6.22'),
(442, '/goodmilk/admin/settings/language', 'default', 0x4d616e61676520616374696f6e73, '6.22'),
(443, '/goodmilk/admin/settings/language', 'default', 0x466f726d617473, '6.22'),
(444, '/goodmilk/admin/settings/language', 'default', 0x416c6c6f7720757365727320746f20636f6e666967757265206461746520666f726d617473, '6.22'),
(445, '/goodmilk/admin/settings/language', 'default', 0x41646420666f726d6174, '6.22'),
(446, '/goodmilk/admin/settings/language', 'default', 0x416c6c6f7720757365727320746f20616464206164646974696f6e616c206461746520666f726d6174732e, '6.22'),
(447, '/goodmilk/admin/settings/language', 'default', 0x437573746f6d20666f726d617473, '6.22'),
(448, '/goodmilk/admin/settings/language', 'default', 0x416c6c6f7720757365727320746f20636f6e66696775726520637573746f6d206461746520666f726d6174732e, '6.22'),
(449, '/goodmilk/admin/settings/language', 'default', 0x41646420696e70757420666f726d6174, '6.22'),
(450, '/goodmilk/admin/settings/language', 'default', 0x44656661756c7473, '6.22'),
(451, '/goodmilk/admin/settings/language', 'default', 0x4d616e61676520696e70757420666f726d617473, '6.22'),
(452, '/goodmilk/admin/settings/language', 'default', 0x4461746162617365206c6f6767696e67, '6.22'),
(453, '/goodmilk/admin/settings/language', 'default', 0x53657474696e677320666f72206c6f6767696e6720746f207468652044727570616c206461746162617365206c6f67732e205468697320697320746865206d6f737420636f6d6d6f6e206d6574686f6420666f7220736d616c6c20746f206d656469756d207369746573206f6e2073686172656420686f7374696e672e20546865206c6f677320617265207669657761626c652066726f6d207468652061646d696e2070616765732e, '6.22'),
(454, '/goodmilk/admin/settings/language', 'default', 0x5379736c6f67, '6.22'),
(455, '/goodmilk/admin/settings/language', 'default', 0x53657474696e677320666f72207379736c6f67206c6f6767696e672e205379736c6f6720697320616e206f7065726174696e672073797374656d2061646d696e697374726174697665206c6f6767696e6720746f6f6c207573656420696e2073797374656d73206d616e6167656d656e7420616e64207365637572697479206175646974696e672e204d6f73742073756974656420746f206d656469756d20616e64206c617267652073697465732c207379736c6f672070726f76696465732066696c746572696e6720746f6f6c73207468617420616c6c6f77206d6573736167657320746f20626520726f75746564206279207479706520616e642073657665726974792e, '6.22'),
(456, '/goodmilk/admin/settings/language', 'default', 0x4279206d6f64756c65, '6.22'),
(457, '/goodmilk/admin/settings/language', 'default', 0x4175746f6d6174696320696d6167652068616e646c696e67, '6.22'),
(458, '/goodmilk/admin/settings/language', 'default', 0x416c6c6f777320746865207573657220746f20636f6e66696775726520746865206c69676874626f7832206175746f6d6174696320696d6167652068616e646c696e672073657474696e6773, '6.22'),
(459, '/goodmilk/admin/settings/language', 'default', 0x47656e6572616c, '6.22'),
(460, '/goodmilk/admin/settings/language', 'default', 0x48544d4c20436f6e74656e74, '6.22'),
(461, '/goodmilk/admin/settings/language', 'default', 0x416c6c6f777320746865207573657220746f20636f6e66696775726520746865206c69676874626f78322048544d4c20636f6e74656e742066756e6374696f6e616c6974792e, '6.22'),
(462, '/goodmilk/admin/settings/language', 'default', 0x536c69646573686f77, '6.22'),
(463, '/goodmilk/admin/settings/language', 'default', 0x416c6c6f777320746865207573657220746f20636f6e66696775726520746865206c69676874626f783220736c69646573686f772066756e6374696f6e616c697479, '6.22'),
(464, '/goodmilk/admin/settings/language', 'default', 0x4163636573732072756c6573, '6.22'),
(465, '/goodmilk/admin/settings/language', 'default', 0x4c69737420616e64206372656174652072756c657320746f20646973616c6c6f7720757365726e616d65732c20652d6d61696c206164647265737365732c20616e64204950206164647265737365732e, '6.22'),
(466, '/goodmilk/admin/settings/language', 'default', 0x4164642072756c65, '6.22'),
(467, '/goodmilk/admin/settings/language', 'default', 0x436865636b2072756c6573, '6.22'),
(468, '/goodmilk/admin/settings/language', 'default', 0x5065726d697373696f6e73, '6.22'),
(469, '/goodmilk/admin/settings/language', 'default', 0x44657465726d696e652061636365737320746f2066656174757265732062792073656c656374696e67207065726d697373696f6e7320666f7220726f6c65732e, '6.22'),
(470, '/goodmilk/admin/settings/language', 'default', 0x526f6c6573, '6.22'),
(471, '/goodmilk/admin/settings/language', 'default', 0x4c6973742c20656469742c206f7220616464207573657220726f6c65732e, '6.22'),
(472, '/goodmilk/admin/settings/language', 'default', 0x557365722073657474696e6773, '6.22'),
(473, '/goodmilk/admin/settings/language', 'default', 0x436f6e6669677572652064656661756c74206265686176696f72206f662075736572732c20696e636c7564696e6720726567697374726174696f6e20726571756972656d656e74732c20652d6d61696c732c20616e6420757365722070696374757265732e, '6.22'),
(474, '/goodmilk/admin/settings/language', 'default', 0x5573657273, '6.22'),
(475, '/goodmilk/admin/settings/language', 'default', 0x4c6973742c206164642c20616e6420656469742075736572732e, '6.22'),
(476, '/goodmilk/admin/settings/language', 'default', 0x4164642075736572, '6.22'),
(477, '/goodmilk/admin/settings/language', 'default', 0x50726f66696c6573, '6.22'),
(478, '/goodmilk/admin/settings/language', 'default', 0x43726561746520637573746f6d697a61626c65206669656c647320666f7220796f75722075736572732e, '6.22'),
(479, '/goodmilk/admin/settings/language', 'default', 0x436f6e66696775726174696f6e2073617665642e, '6.22'),
(480, '/goodmilk/contact', 'default', 0x596f752063616e206c656176652061206d657373616765207573696e672074686520636f6e7461637420666f726d2062656c6f772e, '6.22'),
(481, '/goodmilk/contact', 'default', 0x596f7572206e616d65, '6.22'),
(482, '/goodmilk/contact', 'default', 0x596f757220652d6d61696c2061646472657373, '6.22'),
(483, '/goodmilk/contact', 'default', 0x5375626a656374, '6.22'),
(484, '/goodmilk/contact', 'default', 0x4d657373616765, '6.22'),
(485, '/goodmilk/contact', 'default', 0x53656e6420652d6d61696c, '6.22'),
(486, '/goodmilk/contact', 'default', 0x436f6d6d656e74, '6.22'),
(487, '/goodmilk/contact', 'default', 0x446973706c61792074686520636f6d6d656e742077697468207374616e6461726420636f6d6d656e7420766965772e, '6.22'),
(488, '/goodmilk/contact', 'default', 0x446973706c61792074686520636f6d6d656e74206173205253532e, '6.22'),
(489, '/goodmilk/contact', 'default', 0x4e6f6465, '6.22'),
(490, '/goodmilk/contact', 'default', 0x446973706c617920746865206e6f64652077697468207374616e64617264206e6f646520766965772e, '6.22'),
(491, '/goodmilk/contact', 'default', 0x4e6f64652049442066726f6d2055524c, '6.22'),
(492, '/goodmilk/contact', 'default', 0x5461786f6e6f6d79207465726d, '6.22'),
(493, '/goodmilk/contact', 'default', 0x5461786f6e6f6d79205465726d2049442066726f6d2055524c, '6.22'),
(494, '/goodmilk/contact', 'default', 0x557365722049442066726f6d2055524c, '6.22'),
(495, '/goodmilk/contact', 'default', 0x557365722049442066726f6d206c6f6767656420696e2075736572, '6.22'),
(496, '/goodmilk/contact', 'default', 0x55736572, '6.22'),
(497, '/goodmilk/contact', 'default', 0x446174652062726f77736572, '6.22'),
(498, '/goodmilk/contact', 'default', 0x44617465206261636b2f6e657874206e617669676174696f6e20746f2061747461636820746f206f7468657220646973706c6179732e20526571756972657320746865204461746520617267756d656e742e, '6.22'),
(499, '/goodmilk/contact', 'default', 0x446174652062726f77736572207374796c65, '6.22'),
(500, '/goodmilk/contact', 'default', 0x43726561746573206261636b2f6e657874206e617669676174696f6e2e, '6.22'),
(501, '/goodmilk/contact', 'default', 0x47616c6c657269666669632047616c6c657279, '6.22'),
(502, '/goodmilk/contact', 'default', 0x446973706c617920612076696577206c696b6520612047616c6c657269666669632067616c6c6572792e, '6.22'),
(503, '/goodmilk/contact', 'default', 0x47616c6c65726966666963204669656c6473, '6.22'),
(504, '/goodmilk/contact', 'default', 0x43686f6f736520746865206669656c647320746f20646973706c617920696e207468652047616c6c657269666669632067616c6c6572792e, '6.22'),
(505, '/goodmilk/contact', 'default', 0x44656661756c742073657474696e677320666f72207468697320766965772e, '6.22'),
(506, '/goodmilk/contact', 'default', 0x50616765, '6.22'),
(507, '/goodmilk/contact', 'default', 0x446973706c6179207468652076696577206173206120706167652c207769746820612055524c20616e64206d656e75206c696e6b732e, '6.22'),
(508, '/goodmilk/contact', 'default', 0x426c6f636b, '6.22'),
(509, '/goodmilk/contact', 'default', 0x446973706c6179207468652076696577206173206120626c6f636b2e, '6.22'),
(510, '/goodmilk/contact', 'default', 0x4174746163686d656e74, '6.22'),
(511, '/goodmilk/contact', 'default', 0x4174746163686d656e747320616464656420746f206f7468657220646973706c61797320746f2061636869657665206d756c7469706c6520766965777320696e207468652073616d6520766965772e, '6.22'),
(512, '/goodmilk/contact', 'default', 0x46656564, '6.22'),
(513, '/goodmilk/contact', 'default', 0x446973706c6179207468652076696577206173206120666565642c207375636820617320616e2052535320666565642e, '6.22'),
(514, '/goodmilk/contact', 'default', 0x556e666f726d6174746564, '6.22'),
(515, '/goodmilk/contact', 'default', 0x446973706c61797320726f7773206f6e6520616674657220616e6f746865722e, '6.22'),
(516, '/goodmilk/contact', 'default', 0x48544d4c204c697374, '6.22'),
(517, '/goodmilk/contact', 'default', 0x446973706c61797320726f777320617320616e2048544d4c206c6973742e, '6.22'),
(518, '/goodmilk/contact', 'default', 0x47726964, '6.22'),
(519, '/goodmilk/contact', 'default', 0x446973706c61797320726f777320696e206120677269642e, '6.22'),
(520, '/goodmilk/contact', 'default', 0x5461626c65, '6.22'),
(521, '/goodmilk/contact', 'default', 0x446973706c61797320726f777320696e2061207461626c652e, '6.22'),
(522, '/goodmilk/contact', 'default', 0x446973706c617973207468652064656661756c742073756d6d6172792061732061206c6973742e, '6.22'),
(523, '/goodmilk/contact', 'default', 0x446973706c617973207468652073756d6d61727920756e666f726d61747465642c2077697468206f7074696f6e20666f72206f6e6520616674657220616e6f74686572206f7220696e6c696e652e, '6.22'),
(524, '/goodmilk/contact', 'default', 0x5253532046656564, '6.22'),
(525, '/goodmilk/contact', 'default', 0x47656e65726174657320616e2052535320666565642066726f6d206120766965772e, '6.22'),
(526, '/goodmilk/contact', 'default', 0x446973706c61797320746865206669656c6473207769746820616e206f7074696f6e616c2074656d706c6174652e, '6.22'),
(527, '/goodmilk/contact', 'default', 0x466978656420656e747279, '6.22'),
(528, '/goodmilk/contact', 'default', 0x50485020436f6465, '6.22'),
(529, '/goodmilk/contact', 'default', 0x4e756d65726963, '6.22'),
(530, '/goodmilk/contact', 'default', 0x4e6f6e65, '6.22'),
(531, '/goodmilk/contact', 'default', 0x57696c6c20626520617661696c61626c6520746f20616c6c2075736572732e, '6.22'),
(532, '/goodmilk/contact', 'default', 0x526f6c65, '6.22'),
(533, '/goodmilk/contact', 'default', 0x4163636573732077696c6c206265206772616e74656420746f207573657273207769746820616e79206f66207468652073706563696669656420726f6c65732e, '6.22'),
(534, '/goodmilk/contact', 'default', 0x5065726d697373696f6e, '6.22'),
(535, '/goodmilk/contact', 'default', 0x4163636573732077696c6c206265206772616e74656420746f20757365727320776974682074686520737065636966696564207065726d697373696f6e20737472696e672e, '6.22'),
(536, '/goodmilk/contact', 'default', 0x4e6f2063616368696e67206f6620566965777320646174612e, '6.22'),
(537, '/goodmilk/contact', 'default', 0x54696d652d6261736564, '6.22'),
(538, '/goodmilk/contact', 'default', 0x53696d706c652074696d652d62617365642063616368696e67206f6620646174612e, '6.22'),
(539, '/goodmilk/contact', 'default', 0x54686973206669656c642069732072657175697265642e, '6.22'),
(540, '/goodmilk/contact', 'default', 0x46697273742073696465626172, '6.22'),
(541, '/goodmilk/contact', 'default', 0x5365636f6e642073696465626172, '6.22'),
(542, '/goodmilk/contact', 'default', 0x4e617669676174696f6e20626172, '6.22'),
(543, '/goodmilk/contact', 'default', 0x486967686c69676874656420636f6e74656e74, '6.22'),
(544, '/goodmilk/contact', 'default', 0x436f6e74656e7420746f70, '6.22'),
(545, '/goodmilk/contact', 'default', 0x436f6e74656e7420626f74746f6d, '6.22'),
(546, '/goodmilk/contact', 'default', 0x5061676520636c6f73757265, '6.22'),
(547, '/goodmilk/contact', 'default', 0x4c6f67696e, '6.22'),
(548, '/goodmilk/admin/settings/language/configure', 'default', 0x4e6f6e652e, '6.22'),
(549, '/goodmilk/admin/settings/language/configure', 'default', 0x5061746820707265666978206f6e6c792e, '6.22'),
(550, '/goodmilk/admin/settings/language/configure', 'default', 0x50617468207072656669782077697468206c616e67756167652066616c6c6261636b2e, '6.22'),
(551, '/goodmilk/admin/settings/language/configure', 'default', 0x446f6d61696e206e616d65206f6e6c792e, '6.22'),
(552, '/goodmilk/admin/settings/language/configure', 'default', 0x53656c65637420746865206d656368616e69736d207573656420746f2064657465726d696e6520796f7572207369746527732070726573656e746174696f6e206c616e67756167652e203c7374726f6e673e4d6f64696679696e6720746869732073657474696e67206d617920627265616b20616c6c20696e636f6d696e672055524c7320616e642073686f756c64206265207573656420776974682063617574696f6e20696e20612070726f64756374696f6e20656e7669726f6e6d656e742e3c2f7374726f6e673e, '6.22'),
(553, '/goodmilk/admin/settings/language/configure', 'default', 0x536176652073657474696e6773, '6.22'),
(554, '/goodmilk/admin/settings/language/configure', 'default', 0x4c616e6775616765206e65676f74696174696f6e2073657474696e67732064657465726d696e6520746865207369746527732070726573656e746174696f6e206c616e67756167652e20417661696c61626c65206f7074696f6e7320696e636c7564653a, '6.22'),
(555, '/goodmilk/admin/settings/language/configure', 'default', 0x3c7374726f6e673e4e6f6e652e3c2f7374726f6e673e205468652064656661756c74206c616e6775616765206973207573656420666f7220736974652070726573656e746174696f6e2c2074686f756768207573657273206d617920286f7074696f6e616c6c79292073656c656374206120707265666572726564206c616e6775616765206f6e20746865203c656d3e4d79204163636f756e743c2f656d3e20706167652e202855736572206c616e677561676520707265666572656e6365732077696c6c206265207573656420666f72207369746520652d6d61696c732c20696620617661696c61626c652e29, '6.22'),
(556, '/goodmilk/admin/settings/language/configure', 'default', 0x3c7374726f6e673e5061746820707265666978206f6e6c792e3c2f7374726f6e673e205468652070726573656e746174696f6e206c616e67756167652069732064657465726d696e6564206279206578616d696e696e6720746865207061746820666f722061206c616e677561676520636f6465206f72206f7468657220637573746f6d20737472696e672074686174206d617463686573207468652070617468207072656669782028696620616e79292073706563696669656420666f722065616368206c616e67756167652e2049662061207375697461626c6520707265666978206973206e6f74206964656e7469666965642c207468652064656661756c74206c616e677561676520697320757365642e203c656d3e4578616d706c653a20226578616d706c652e636f6d2f64652f636f6e746163742220736574732070726573656e746174696f6e206c616e677561676520746f204765726d616e206261736564206f6e2074686520757365206f6620226465222077697468696e2074686520706174682e3c2f656d3e, '6.22'),
(557, '/goodmilk/admin/settings/language/configure', 'default', 0x3c7374726f6e673e50617468207072656669782077697468206c616e67756167652066616c6c6261636b2e3c2f7374726f6e673e205468652070726573656e746174696f6e206c616e67756167652069732064657465726d696e6564206279206578616d696e696e6720746865207061746820666f722061206c616e677561676520636f6465206f72206f7468657220637573746f6d20737472696e672074686174206d617463686573207468652070617468207072656669782028696620616e79292073706563696669656420666f722065616368206c616e67756167652e2049662061207375697461626c6520707265666978206973206e6f74206964656e7469666965642c2074686520646973706c6179206c616e67756167652069732064657465726d696e65642062792074686520757365722773206c616e677561676520707265666572656e6365732066726f6d20746865203c656d3e4d79204163636f756e743c2f656d3e20706167652c206f72206279207468652062726f777365722773206c616e67756167652073657474696e67732e20496620612070726573656e746174696f6e206c616e67756167652063616e6e6f742062652064657465726d696e65642c207468652064656661756c74206c616e677561676520697320757365642e, '6.22'),
(558, '/goodmilk/admin/settings/language/configure', 'default', 0x3c7374726f6e673e446f6d61696e206e616d65206f6e6c792e3c2f7374726f6e673e205468652070726573656e746174696f6e206c616e67756167652069732064657465726d696e6564206279206578616d696e696e672074686520646f6d61696e207573656420746f206163636573732074686520736974652c20616e6420636f6d706172696e6720697420746f20746865206c616e677561676520646f6d61696e2028696620616e79292073706563696669656420666f722065616368206c616e67756167652e2049662061206d61746368206973206e6f74206964656e7469666965642c207468652064656661756c74206c616e677561676520697320757365642e203c656d3e4578616d706c653a2022687474703a2f2f64652e6578616d706c652e636f6d2f636f6e746163742220736574732070726573656e746174696f6e206c616e677561676520746f204765726d616e206261736564206f6e2074686520757365206f662022687474703a2f2f64652e6578616d706c652e636f6d2220696e2074686520646f6d61696e2e3c2f656d3e, '6.22'),
(559, '/goodmilk/admin/settings/language/configure', 'default', 0x546865207061746820707265666978206f7220646f6d61696e206e616d6520666f722061206c616e6775616765206d6179206265207365742062792065646974696e6720746865203c6120687265663d22406c616e677561676573223e617661696c61626c65206c616e6775616765733c2f613e2e20496e2074686520616273656e6365206f6620616e20617070726f707269617465206d617463682c20746865207369746520697320646973706c6179656420696e20746865203c6120687265663d22406c616e677561676573223e64656661756c74206c616e67756167653c2f613e2e, '6.22'),
(560, '/goodmilk/admin/settings/language/icons', 'default', 0x416464206c616e67756167652069636f6e73, '6.22'),
(561, '/goodmilk/admin/settings/language/icons', 'default', 0x4c696e6b20747970657320746f20616464206c616e67756167652069636f6e732e, '6.22'),
(562, '/goodmilk/admin/settings/language/icons', 'default', 0x4e6f6465206c696e6b73, '6.22'),
(563, '/goodmilk/admin/settings/language/icons', 'default', 0x4c616e677561676520737769746368657220626c6f636b, '6.22'),
(564, '/goodmilk/admin/settings/language/icons', 'default', 0x49636f6e20706c6163656d656e74, '6.22'),
(565, '/goodmilk/admin/settings/language/icons', 'default', 0x4265666f7265206c696e6b, '6.22'),
(566, '/goodmilk/admin/settings/language/icons', 'default', 0x4166746572206c696e6b, '6.22'),
(567, '/goodmilk/admin/settings/language/icons', 'default', 0x5265706c616365206c696e6b, '6.22'),
(568, '/goodmilk/admin/settings/language/icons', 'default', 0x576865726520746f20646973706c6179207468652069636f6e2c2072656c617469766520746f20746865206c696e6b207469746c652e, '6.22'),
(569, '/goodmilk/admin/settings/language/icons', 'default', 0x49636f6e732066696c652070617468, '6.22'),
(570, '/goodmilk/admin/settings/language/icons', 'default', 0x5061746820666f72206c616e67756167652069636f6e732c2072656c617469766520746f2044727570616c20696e7374616c6c6174696f6e2e20222a22206973206120706c616365686f6c64657220666f72206c616e677561676520636f64652e, '6.22'),
(571, '/goodmilk/admin/settings/language/icons', 'default', 0x496d6167652073697a65, '6.22'),
(572, '/goodmilk/admin/settings/language/icons', 'default', 0x496d6167652073697a6520666f72206c616e67756167652069636f6e732c20696e2074686520666f726d20227769647468207820686569676874222e, '6.22'),
(573, '/goodmilk/admin/settings/language/icons', 'default', 0x526573657420746f2064656661756c7473, '6.22'),
(574, '/goodmilk/admin/settings/language/i18n', 'default', 0x436f6e74656e742073656c656374696f6e, '6.22'),
(575, '/goodmilk/admin/settings/language/i18n', 'default', 0x436f6e74656e742073656c656374696f6e206d6f6465, '6.22'),
(576, '/goodmilk/admin/settings/language/i18n', 'default', 0x43757272656e74206c616e677561676520616e64206c616e6775616765206e65757472616c2e, '6.22'),
(577, '/goodmilk/admin/settings/language/i18n', 'default', 0x4d697865642063757272656e74206c616e67756167652028696620617661696c61626c6529206f722064656661756c74206c616e677561676520286966206e6f742920616e64206c616e6775616765206e65757472616c2e, '6.22'),
(578, '/goodmilk/admin/settings/language/i18n', 'default', 0x4f6e6c792064656661756c74206c616e677561676520616e64206c616e6775616765206e65757472616c2e, '6.22'),
(579, '/goodmilk/admin/settings/language/i18n', 'default', 0x4f6e6c792063757272656e74206c616e67756167652e, '6.22'),
(580, '/goodmilk/admin/settings/language/i18n', 'default', 0x416c6c20636f6e74656e742e204e6f206c616e677561676520636f6e646974696f6e73206170706c792e, '6.22'),
(581, '/goodmilk/admin/settings/language/i18n', 'default', 0x44657465726d696e657320776869636820636f6e74656e7420746f2073686f7720646570656e64696e67206f6e207468652063757272656e742070616765206c616e677561676520616e64207468652064656661756c74206c616e6775616765206f662074686520736974652e, '6.22'),
(582, '/goodmilk/admin/settings/language/i18n', 'default', 0x436f6e74656e74207472616e736c6174696f6e206c696e6b73, '6.22'),
(583, '/goodmilk/admin/settings/language/i18n', 'default', 0x4869646520636f6e74656e74207472616e736c6174696f6e206c696e6b73, '6.22'),
(584, '/goodmilk/admin/settings/language/i18n', 'default', 0x4869646520746865206c696e6b7320746f207472616e736c6174696f6e7320696e20636f6e74656e7420626f647920616e6420746561736572732e20496620796f752063686f6f73652074686973206f7074696f6e2c20737769746368696e67206c616e67756167652077696c6c206f6e6c7920626520617661696c61626c652066726f6d20746865206c616e677561676520737769746368657220626c6f636b2e, '6.22'),
(585, '/goodmilk/admin/settings/language/i18n', 'default', 0x53776974636820696e7465726661636520666f72207472616e736c6174696e67, '6.22'),
(586, '/goodmilk/admin/settings/language/i18n', 'default', 0x53776974636820696e74657266616365206c616e677561676520746f20666974206e6f6465206c616e6775616765207768656e206372656174696e67206f722065646974696e672061207472616e736c6174696f6e2e204966206e6f7420636865636b65642074686520696e74657266616365206c616e67756167652077696c6c20626520696e646570656e64656e742066726f6d206e6f6465206c616e67756167652e, '6.22'),
(587, '/goodmilk/admin/settings/language/i18n', 'default', 0x546f20736574207570206d756c74696c696e6775616c206f7074696f6e7320666f7220766f636162756c617269657320676f20746f203c6120687265663d2240636f6e6669677572655f7461786f6e6f6d79223e5461786f6e6f6d7920636f6e66696775726174696f6e20706167653c2f613e2e, '6.22'),
(588, '/goodmilk/admin/settings/language/i18n', 'default', 0x546f20656e61626c65206d756c74696c696e6775616c20737570706f727420666f7220737065636966696320636f6e74656e7420747970657320676f20746f203c6120687265663d2240636f6e6669677572655f636f6e74656e745f7479706573223e636f6e66696775726520636f6e74656e742074797065733c2f613e2e, '6.22'),
(589, '/goodmilk/admin/settings/language/i18n', 'default', 0x54686520636f6e66696775726174696f6e206f7074696f6e732068617665206265656e2073617665642e, '6.22'),
(590, '/goodmilk/admin/settings/language/i18n/variables', 'default', 0x546865726520617265206e6f206d756c74696c696e6775616c207661726961626c65732e, '6.22'),
(591, '/goodmilk/admin/settings/language/edit/vi', 'default', 0x45646974206c616e6775616765, '6.22'),
(592, '/goodmilk/admin/settings/language/edit/vi', 'default', 0x4c616e677561676520636f6465, '6.22'),
(593, '/goodmilk/admin/settings/language/edit/vi', 'default', 0x4c616e6775616765206e616d6520696e20456e676c697368, '6.22'),
(594, '/goodmilk/admin/settings/language/edit/vi', 'default', 0x4e616d65206f6620746865206c616e677561676520696e20456e676c6973682e2057696c6c20626520617661696c61626c6520666f72207472616e736c6174696f6e20696e20616c6c206c616e6775616765732e, '6.22'),
(595, '/goodmilk/admin/settings/language/edit/vi', 'default', 0x4e6174697665206c616e6775616765206e616d65, '6.22'),
(596, '/goodmilk/admin/settings/language/edit/vi', 'default', 0x4e616d65206f6620746865206c616e677561676520696e20746865206c616e6775616765206265696e672061646465642e, '6.22'),
(597, '/goodmilk/admin/settings/language/edit/vi', 'default', 0x5061746820707265666978, '6.22'),
(598, '/goodmilk/admin/settings/language/edit/vi', 'default', 0x4c616e677561676520636f6465206f72206f7468657220637573746f6d20737472696e6720666f72207061747465726e206d61746368696e672077697468696e2074686520706174682e2057697468206c616e6775616765206e65676f74696174696f6e2073657420746f203c656d3e5061746820707265666978206f6e6c793c2f656d3e206f72203c656d3e50617468207072656669782077697468206c616e67756167652066616c6c6261636b3c2f656d3e2c207468697320736974652069732070726573656e74656420696e2074686973206c616e6775616765207768656e207468652050617468207072656669782076616c7565206d61746368657320616e20656c656d656e7420696e2074686520706174682e20466f72207468652064656661756c74206c616e67756167652c20746869732076616c7565206d6179206265206c65667420626c616e6b2e203c7374726f6e673e4d6f64696679696e6720746869732076616c75652077696c6c20627265616b206578697374696e672055524c7320616e642073686f756c64206265207573656420776974682063617574696f6e20696e20612070726f64756374696f6e20656e7669726f6e6d656e742e3c2f7374726f6e673e203c656d3e4578616d706c653a2053706563696679696e67202264657574736368222061732074686520706174682070726566697820666f72204765726d616e20726573756c747320696e2055524c7320696e2074686520666f726d20227777772e6578616d706c652e636f6d2f646575747363682f6e6f6465222e3c2f656d3e, '6.22'),
(599, '/goodmilk/admin/settings/language/edit/vi', 'default', 0x4c616e677561676520646f6d61696e, '6.22'),
(600, '/goodmilk/admin/settings/language/edit/vi', 'default', 0x4c616e67756167652d73706563696669632055524c2c20776974682070726f746f636f6c2e2057697468206c616e6775616765206e65676f74696174696f6e2073657420746f203c656d3e446f6d61696e206e616d65206f6e6c793c2f656d3e2c2074686520736974652069732070726573656e74656420696e2074686973206c616e6775616765207768656e207468652055524c20616363657373696e67207468652073697465207265666572656e636573207468697320646f6d61696e2e20466f72207468652064656661756c74206c616e67756167652c20746869732076616c7565206d6179206265206c65667420626c616e6b2e203c7374726f6e673e546869732076616c7565206d75737420696e636c75646520612070726f746f636f6c2061732070617274206f662074686520737472696e672e3c2f7374726f6e673e203c656d3e4578616d706c653a2053706563696679696e672022687474703a2f2f6578616d706c652e646522206f722022687474703a2f2f64652e6578616d706c652e636f6d22206173206c616e677561676520646f6d61696e7320666f72204765726d616e20726573756c747320696e2055524c7320696e2074686520666f726d732022687474703a2f2f6578616d706c652e64652f6e6f64652220616e642022687474703a2f2f64652e6578616d706c652e636f6d2f6e6f6465222c20726573706563746976656c792e3c2f656d3e, '6.22'),
(601, '/goodmilk/admin/settings/language/edit/vi', 'default', 0x446972656374696f6e2074686174207465787420696e2074686973206c616e67756167652069732070726573656e7465642e, '6.22'),
(602, '/goodmilk/admin/settings/language/edit/vi', 'default', 0x526967687420746f206c656674, '6.22'),
(603, '/goodmilk/admin/settings/language/edit/vi', 'default', 0x53617665206c616e6775616765, '6.22'),
(604, '/goodmilk/admin/build/themes', 'default', 0x53637265656e73686f7420666f7220257468656d65207468656d65, '6.22'),
(605, '/goodmilk/admin/build/themes', 'default', 0x636f6e666967757265, '6.22'),
(606, '/goodmilk/admin/build/themes', 'default', 0x5461626c652d6261736564206d756c74692d636f6c756d6e207468656d6520776974682061206d6172696e6520616e642061736820636f6c6f7220736368656d652e, '6.22'),
(607, '/goodmilk/admin/build/themes', 'default', 0x5265616420746865203c6120687265663d22687474703a2f2f64727570616c2e6f72672f6e6f64652f363239353130223e6f6e6c696e6520646f63733c2f613e206f722074686520696e636c7564656420524541444d452e747874206f6e20686f7720746f206372656174652061205a656e207375622d7468656d652e, '6.22'),
(608, '/goodmilk/admin/build/themes', 'default', 0x4d696e696d616c697374207461626c6564207468656d652077697468206c6967687420636f6c6f72732e, '6.22'),
(609, '/goodmilk/admin/build/themes', 'default', 0x5461626c656c6573732c207265636f6c6f7261626c652c206d756c74692d636f6c756d6e2c20666c756964207769647468207468656d65202864656661756c74292e, '6.22'),
(610, '/goodmilk/admin/build/themes', 'default', 0x426f7879207461626c6564207468656d6520696e20616c6c2067726179732e, '6.22'),
(611, '/goodmilk/admin/build/themes', 'default', 0x5461626c656c6573732c207265636f6c6f7261626c652c206d756c74692d636f6c756d6e2c206669786564207769647468207468656d652e, '6.22'),
(612, '/goodmilk/admin/build/themes', 'default', 0x5461626c65642c206d756c74692d636f6c756d6e207468656d6520696e20626c756520616e64206f72616e676520746f6e65732e, '6.22'),
(613, '/goodmilk/admin/build/themes', 'default', 0x56697369204b61726420436f6d70616e792e, '6.22'),
(614, '/goodmilk/admin/build/themes', 'default', 0x5a656e207375622d7468656d6573206172652074686520756c74696d617465207374617274696e67207468656d657320666f722044727570616c20362e205265616420746865203c6120687265663d22687474703a2f2f64727570616c2e6f72672f6e6f64652f383733373738223e6f6e6c696e6520646f63733c2f613e206f722074686520696e636c7564656420524541444d452d46495253542e747874206f6e20686f7720746f206372656174652061207468656d652077697468205a656e2e, '6.22'),
(615, '/goodmilk/admin/build/themes', 'default', 0x53637265656e73686f74, '6.22'),
(616, '/goodmilk/admin/build/themes', 'default', 0x4e616d65, '6.22'),
(617, '/goodmilk/admin/build/themes', 'default', 0x56657273696f6e, '6.22'),
(618, '/goodmilk/admin/build/themes', 'default', 0x436f6e766572742076696577, '6.22'),
(619, '/goodmilk/admin/build/themes', 'default', 0x44656c6574652076696577, '6.22'),
(620, '/goodmilk/admin/build/themes', 'default', 0x53656c656374207768696368207468656d65732061726520617661696c61626c6520746f20796f757220757365727320616e642073706563696679207468652064656661756c74207468656d652e20546f20636f6e66696775726520736974652d7769646520646973706c61792073657474696e67732c20636c69636b207468652022636f6e66696775726522207461736b2061626f76652e20416c7465726e61746976656c792c20746f206f766572726964652074686573652073657474696e677320696e2061207370656369666963207468656d652c20636c69636b207468652022636f6e66696775726522206c696e6b20666f722074686174207468656d652e204e6f7465207468617420646966666572656e74207468656d6573206d6179206861766520646966666572656e7420726567696f6e7320617661696c61626c6520666f7220646973706c6179696e6720636f6e74656e743b20666f7220636f6e73697374656e637920696e2070726573656e746174696f6e2c20796f75206d6179207769736820746f20656e61626c65206f6e6c79206f6e65207468656d652e, '6.22'),
(621, '/goodmilk/admin/build/themes', 'default', 0x546f206368616e67652074686520617070656172616e6365206f6620796f757220736974652c2061206e756d626572206f66203c6120687265663d22407468656d6573223e636f6e7472696275746564207468656d65733c2f613e2061726520617661696c61626c652e, '6.22'),
(622, '/goodmilk/admin/build/themes', 'default', 0x53656520746865203c6120687265663d2240617661696c61626c655f75706461746573223e617661696c61626c6520757064617465733c2f613e207061676520666f7220696e666f726d6174696f6e206f6e20696e7374616c6c6564206d6f64756c657320616e64207468656d65732077697468206e65772076657273696f6e732072656c65617365642e, '6.22'),
(623, '/goodmilk/admin/build/themes', 'default', 0x506c65617365206e6f7465207468617420746865203c6120687265663d222161646d696e5f7468656d655f70616765223e61646d696e697374726174696f6e207468656d653c2f613e206973207374696c6c2073657420746f20746865202561646d696e5f7468656d65207468656d653b20636f6e73657175656e746c792c20746865207468656d65206f6e207468697320706167652072656d61696e7320756e6368616e6765642e20416c6c206e6f6e2d61646d696e6973747261746976652073656374696f6e73206f662074686520736974652c20686f77657665722c2077696c6c2073686f77207468652073656c6563746564202573656c65637465645f7468656d65207468656d652062792064656661756c742e, '6.22'),
(624, '/goodmilk/admin/build/themes', 'default', 0x4163636f756e742073657474696e6773, '6.22'),
(625, '/goodmilk/admin/build/themes', 'default', 0x53656172636820496e646578, '6.22'),
(626, '/goodmilk/admin/build/themes', 'default', 0x53656172636820526573756c74, '6.22'),
(627, '/goodmilk/admin/build/themes', 'default', 0x4669656c64, '6.22'),
(628, '/goodmilk/admin/build/themes', 'default', 0x6669656c64, '6.22'),
(629, '/goodmilk/admin/build/themes', 'default', 0x417267756d656e7473, '6.22'),
(630, '/goodmilk/admin/build/themes', 'default', 0x617267756d656e7473, '6.22'),
(631, '/goodmilk/admin/build/themes', 'default', 0x417267756d656e74, '6.22'),
(632, '/goodmilk/admin/build/themes', 'default', 0x536f7274206372697465726961, '6.22'),
(633, '/goodmilk/admin/build/themes', 'default', 0x736f7274206372697465726961, '6.22'),
(634, '/goodmilk/admin/build/themes', 'default', 0x536f727420637269746572696f6e, '6.22'),
(635, '/goodmilk/admin/build/themes', 'default', 0x736f727420637269746572696f6e, '6.22'),
(636, '/goodmilk/admin/build/themes', 'default', 0x46696c74657273, '6.22'),
(637, '/goodmilk/admin/build/themes', 'default', 0x66696c74657273, '6.22'),
(638, '/goodmilk/admin/build/themes', 'default', 0x46696c746572, '6.22'),
(639, '/goodmilk/admin/build/themes', 'default', 0x66696c746572, '6.22'),
(640, '/goodmilk/admin/build/themes', 'default', 0x52656c6174696f6e7368697073, '6.22'),
(641, '/goodmilk/admin/build/themes', 'default', 0x72656c6174696f6e7368697073, '6.22'),
(642, '/goodmilk/admin/build/themes', 'default', 0x52656c6174696f6e73686970, '6.22'),
(643, '/goodmilk/admin/build/themes', 'default', 0x5468697320757365722063616e20737769746368206261636b2e, '6.22'),
(644, '/goodmilk/admin/build/themes', 'default', 0x44697361626c6520646576656c6f706572206d6f64756c6573, '6.22'),
(645, '/goodmilk/admin/settings/performance', 'default', 0x546865206e6f726d616c206361636865206d6f6465206973207375697461626c6520666f72206d6f737420736974657320616e6420646f6573206e6f7420636175736520616e79207369646520656666656374732e205468652061676772657373697665206361636865206d6f6465206361757365732044727570616c20746f20736b697020746865206c6f6164696e672028626f6f742920616e6420756e6c6f6164696e6720286578697429206f6620656e61626c6564206d6f64756c6573207768656e2073657276696e6720612063616368656420706167652e205468697320726573756c747320696e20616e206164646974696f6e616c20706572666f726d616e636520626f6f7374206275742063616e20636175736520756e77616e746564207369646520656666656374732e, '6.22'),
(646, '/goodmilk/admin/settings/performance', 'default', 0x3c7374726f6e6720636c6173733d226572726f72223e54686520666f6c6c6f77696e6720656e61626c6564206d6f64756c65732061726520696e636f6d70617469626c6520776974682061676772657373697665206d6f64652063616368696e6720616e642077696c6c206e6f742066756e6374696f6e2070726f7065726c793a20256d6f64756c65733c2f7374726f6e673e, '6.22'),
(647, '/goodmilk/admin/settings/performance', 'default', 0x50616765206361636865, '6.22'),
(648, '/goodmilk/admin/settings/performance', 'default', 0x456e61626c696e672074686520706167652063616368652077696c6c206f666665722061207369676e69666963616e7420706572666f726d616e636520626f6f73742e2044727570616c2063616e2073746f726520616e642073656e6420636f6d707265737365642063616368656420706167657320726571756573746564206279203c656d3e616e6f6e796d6f75733c2f656d3e2075736572732e2042792063616368696e6720612077656220706167652c2044727570616c20646f6573206e6f74206861766520746f20636f6e73747275637420746865207061676520656163682074696d65206974206973207669657765642e, '6.22'),
(649, '/goodmilk/admin/settings/performance', 'default', 0x43616368696e67206d6f6465, '6.22'),
(650, '/goodmilk/admin/settings/performance', 'default', 0x44697361626c6564, '6.22'),
(651, '/goodmilk/admin/settings/performance', 'default', 0x4e6f726d616c20287265636f6d6d656e64656420666f722070726f64756374696f6e2073697465732c206e6f2073696465206566666563747329, '6.22'),
(652, '/goodmilk/admin/settings/performance', 'default', 0x41676772657373697665202865787065727473206f6e6c792c20706f737369626c652073696465206566666563747329, '6.22'),
(653, '/goodmilk/admin/settings/performance', 'default', 0x3020736563, '6.22'),
(654, '/goodmilk/admin/settings/performance', 'default', 0x31206d696e, '6.22'),
(655, '/goodmilk/admin/settings/performance', 'default', 0x40636f756e74206d696e, '6.22'),
(656, '/goodmilk/admin/settings/performance', 'default', 0x3120686f7572, '6.22'),
(657, '/goodmilk/admin/settings/performance', 'default', 0x40636f756e7420686f757273, '6.22'),
(658, '/goodmilk/admin/settings/performance', 'default', 0x3120646179, '6.22'),
(659, '/goodmilk/admin/settings/performance', 'default', 0x6e6f6e65, '6.22'),
(660, '/goodmilk/admin/settings/performance', 'default', 0x4d696e696d756d206361636865206c69666574696d65, '6.22'),
(661, '/goodmilk/admin/settings/performance', 'default', 0x4f6e20686967682d747261666669632073697465732c206974206d6179206265206e656365737361727920746f20656e666f7263652061206d696e696d756d206361636865206c69666574696d652e20546865206d696e696d756d206361636865206c69666574696d6520697320746865206d696e696d756d20616d6f756e74206f662074696d6520746861742077696c6c20656c61707365206265666f72652074686520636163686520697320656d707469656420616e64207265637265617465642c20616e64206973206170706c69656420746f20626f7468207061676520616e6420626c6f636b206361636865732e2041206c6172676572206d696e696d756d206361636865206c69666574696d65206f66666572732062657474657220706572666f726d616e63652c206275742075736572732077696c6c206e6f7420736565206e657720636f6e74656e7420666f722061206c6f6e67657220706572696f64206f662074696d652e, '6.22'),
(662, '/goodmilk/admin/settings/performance', 'default', 0x5061676520636f6d7072657373696f6e, '6.22'),
(663, '/goodmilk/admin/settings/performance', 'default', 0x42792064656661756c742c2044727570616c20636f6d70726573736573207468652070616765732069742063616368657320696e206f7264657220746f20736176652062616e64776964746820616e6420696d70726f766520646f776e6c6f61642074696d65732e2054686973206f7074696f6e2073686f756c642062652064697361626c6564207768656e207573696e67206120776562736572766572207468617420706572666f726d7320636f6d7072657373696f6e2e, '6.22'),
(664, '/goodmilk/admin/settings/performance', 'default', 0x426c6f636b206361636865, '6.22'),
(665, '/goodmilk/admin/settings/performance', 'default', 0x456e61626c696e672074686520626c6f636b2063616368652063616e206f66666572206120706572666f726d616e636520696e63726561736520666f7220616c6c2075736572732062792070726576656e74696e6720626c6f636b732066726f6d206265696e67207265636f6e7374727563746564206f6e20656163682070616765206c6f61642e20496620746865207061676520636163686520697320616c736f20656e61626c65642c20706572666f726d616e636520696e637265617365732066726f6d20656e61626c696e672074686520626c6f636b2063616368652077696c6c206d61696e6c792062656e656669742061757468656e746963617465642075736572732e, '6.22'),
(666, '/goodmilk/admin/settings/performance', 'default', 0x456e61626c656420287265636f6d6d656e64656429, '6.22'),
(667, '/goodmilk/admin/settings/performance', 'default', 0x4e6f7465207468617420626c6f636b2063616368696e6720697320696e616374697665207768656e206d6f64756c657320646566696e696e6720636f6e74656e7420616363657373207265737472696374696f6e732061726520656e61626c65642e, '6.22'),
(668, '/goodmilk/admin/settings/performance', 'default', 0x42616e647769647468206f7074696d697a6174696f6e73, '6.22'),
(669, '/goodmilk/admin/settings/performance', 'default', 0x3c703e44727570616c2063616e206175746f6d61746963616c6c79206f7074696d697a652065787465726e616c207265736f7572636573206c696b652043535320616e64204a6176615363726970742c2077686963682063616e2072656475636520626f7468207468652073697a6520616e64206e756d626572206f66207265717565737473206d61646520746f20796f757220776562736974652e204353532066696c65732063616e206265206167677265676174656420616e6420636f6d7072657373656420696e746f20612073696e676c652066696c652c207768696c65204a6176615363726970742066696c65732061726520616767726567617465642028627574206e6f7420636f6d70726573736564292e205468657365206f7074696f6e616c206f7074696d697a6174696f6e73206d61792072656475636520736572766572206c6f61642c2062616e64776964746820726571756972656d656e74732c20616e642070616765206c6f6164696e672074696d65732e3c2f703e3c703e5468657365206f7074696f6e73206172652064697361626c656420696620796f752068617665206e6f742073657420757020796f75722066696c6573206469726563746f72792c206f7220696620796f757220646f776e6c6f6164206d6574686f642069732073657420746f20707269766174652e3c2f703e, '6.22'),
(670, '/goodmilk/admin/settings/performance', 'default', 0x4f7074696d697a65204353532066696c6573, '6.22'),
(671, '/goodmilk/admin/settings/performance', 'default', 0x54686973206f7074696f6e2063616e20696e746572666572652077697468207468656d6520646576656c6f706d656e7420616e642073686f756c64206f6e6c7920626520656e61626c656420696e20612070726f64756374696f6e20656e7669726f6e6d656e742e, '6.22'),
(672, '/goodmilk/admin/settings/performance', 'default', 0x4f7074696d697a65204a6176615363726970742066696c6573, '6.22'),
(673, '/goodmilk/admin/settings/performance', 'default', 0x54686973206f7074696f6e2063616e20696e746572666572652077697468206d6f64756c6520646576656c6f706d656e7420616e642073686f756c64206f6e6c7920626520656e61626c656420696e20612070726f64756374696f6e20656e7669726f6e6d656e742e, '6.22'),
(674, '/goodmilk/admin/settings/performance', 'default', 0x436c656172206361636865642064617461, '6.22'),
(675, '/goodmilk/admin/settings/performance', 'default', 0x43616368696e67206461746120696d70726f76657320706572666f726d616e63652c20627574206d61792063617573652070726f626c656d73207768696c652074726f75626c6573686f6f74696e67206e6577206d6f64756c65732c207468656d65732c206f72207472616e736c6174696f6e732c206966206f7574646174656420696e666f726d6174696f6e20686173206265656e206361636865642e20546f207265667265736820616c6c206361636865642064617461206f6e20796f757220736974652c20636c69636b2074686520627574746f6e2062656c6f772e203c656d3e5761726e696e673a20686967682d747261666669632073697465732077696c6c20657870657269656e636520706572666f726d616e636520736c6f77646f776e73207768696c652063616368656420646174612069732072656275696c742e3c2f656d3e, '6.22'),
(676, '/goodmilk/admin/settings/performance', 'default', 0x53746f7265732064657461696c732061626f75742062617463686573202870726f63657373657320746861742072756e20696e206d756c7469706c652048545450207265717565737473292e, '6.22'),
(677, '/goodmilk/admin/settings/performance', 'default', 0x53746f726520636f6e74616374206669656c647320696e666f726d6174696f6e, '6.22'),
(678, '/goodmilk/admin/settings/performance', 'default', 0x546865207072696d617279206964656e74696669657220666f7220616e20696d61676563616368655f7072657365742e, '6.22'),
(679, '/goodmilk/admin/settings/performance', 'default', 0x546865207072696d617279206964656e74696669657220666f722061206e6f64652e, '6.22'),
(680, '/goodmilk/admin/settings/performance', 'default', 0x546865207072696d617279206964656e74696669657220666f7220616e20696d61676563616368655f616374696f6e2e, '6.22'),
(681, '/goodmilk/admin/settings/performance', 'default', 0x54686520776569676874206f662074686520616374696f6e20696e20746865207072657365742e, '6.22'),
(682, '/goodmilk/admin/settings/performance', 'default', 0x546865206d6f64756c65207468617420646566696e65642074686520616374696f6e2e, '6.22'),
(683, '/goodmilk/admin/settings/performance', 'default', 0x54686520756e69717565204944206f662074686520616374696f6e20746f2062652065786563757465642e, '6.22'),
(684, '/goodmilk/admin/settings/performance', 'default', 0x54686520636f6e66696775726174696f6e206461746120666f722074686520616374696f6e2e, '6.22'),
(685, '/goodmilk/admin/settings/performance', 'default', 0x5065722d757365722074696d657a6f6e65206e616d652e, '6.22'),
(686, '/goodmilk/admin/settings/performance', 'default', 0x5b656d70747920737472696e675d, '6.22');
INSERT INTO `locales_source` (`lid`, `location`, `textgroup`, `source`, `version`) VALUES
(687, '/goodmilk/admin/settings/performance', 'default', 0x526563656e7420636f6d6d656e7473, '6.22'),
(688, '/goodmilk/admin/settings/performance', 'default', 0x4c616e6775616765207377697463686572, '6.22'),
(689, '/goodmilk/admin/settings/performance', 'default', 0x53796e646963617465, '6.22'),
(690, '/goodmilk/admin/settings/performance', 'default', 0x4d6f737420726563656e7420706f6c6c, '6.22'),
(691, '/goodmilk/admin/settings/performance', 'default', 0x417574686f7220696e666f726d6174696f6e, '6.22'),
(692, '/goodmilk/admin/settings/performance', 'default', 0x53656172636820666f726d, '6.22'),
(693, '/goodmilk/admin/settings/performance', 'default', 0x506f77657265642062792044727570616c, '6.22'),
(694, '/goodmilk/admin/settings/performance', 'default', 0x55736572206c6f67696e, '6.22'),
(695, '/goodmilk/admin/settings/performance', 'default', 0x4e617669676174696f6e, '6.22'),
(696, '/goodmilk/admin/settings/performance', 'default', 0x57686f2773206e6577, '6.22'),
(697, '/goodmilk/admin/settings/performance', 'default', 0x57686f2773206f6e6c696e65, '6.22'),
(698, '/goodmilk/admin/settings/performance', 'default', 0x4d6f737420726563656e7420706f6c6c202841676772656761746564207472616e736c6174696f6e7329, '6.22'),
(699, '/goodmilk/admin/settings/performance', 'default', 0x5377697463682075736572, '6.22'),
(700, '/goodmilk/admin/settings/performance', 'default', 0x4578656375746520504850, '6.22'),
(701, '/goodmilk/admin/settings/performance', 'default', 0x43616368657320636c65617265642e, '6.22'),
(702, '/goodmilk/admin/build/translate', 'default', 0x4275696c742d696e20696e74657266616365, '6.22'),
(703, '/goodmilk/admin/build/translate', 'default', 0x43434b, '6.22'),
(704, '/goodmilk/admin/build/translate', 'default', 0x436f6e74656e742074797065, '6.22'),
(705, '/goodmilk/admin/build/translate', 'default', 0x4d656e75, '6.22'),
(706, '/goodmilk/admin/build/translate', 'default', 0x50726f66696c65, '6.22'),
(707, '/goodmilk/admin/build/translate', 'default', 0x4c616e6775616765, '6.22'),
(708, '/goodmilk/admin/build/translate', 'default', 0x456e676c69736820286275696c742d696e29, '6.22'),
(709, '/goodmilk/admin/build/translate', 'default', 0x6e2f61, '6.22'),
(710, '/goodmilk/admin/build/translate', 'default', 0x566965746e616d657365, '6.22'),
(711, '/goodmilk/admin/build/translate', 'default', 0x5468697320706167652070726f766964657320616e206f76657276696577206f6620617661696c61626c65207472616e736c617461626c6520737472696e67732e2044727570616c20646973706c617973207472616e736c617461626c6520737472696e677320696e20746578742067726f7570733b206d6f64756c6573206d617920646566696e65206164646974696f6e616c20746578742067726f75707320636f6e7461696e696e67206f74686572207472616e736c617461626c6520737472696e67732e204265636175736520746578742067726f7570732070726f766964652061206d6574686f64206f662067726f7570696e672072656c6174656420737472696e67732c207468657920617265206f6674656e207573656420746f20666f637573207472616e736c6174696f6e206566666f727473206f6e207370656369666963206172656173206f66207468652044727570616c20696e746572666163652e, '6.22'),
(712, '/goodmilk/admin/build/translate', 'default', 0x52657669657720746865203c6120687265663d22406c616e677561676573223e6c616e67756167657320706167653c2f613e20666f72206d6f726520696e666f726d6174696f6e206f6e20616464696e6720737570706f727420666f72206164646974696f6e616c206c616e6775616765732e, '6.22'),
(713, '/goodmilk/admin/build/translate/search', 'default', 0x456e676c697368, '6.22'),
(714, '/goodmilk/admin/build/translate/search', 'default', 0x537472696e6720636f6e7461696e73, '6.22'),
(715, '/goodmilk/admin/build/translate/search', 'default', 0x4c6561766520626c616e6b20746f2073686f7720616c6c20737472696e67732e205468652073656172636820697320636173652073656e7369746976652e, '6.22'),
(716, '/goodmilk/admin/build/translate/search', 'default', 0x416c6c206c616e677561676573, '6.22'),
(717, '/goodmilk/admin/build/translate/search', 'default', 0x456e676c697368202870726f76696465642062792044727570616c29, '6.22'),
(718, '/goodmilk/admin/build/translate/search', 'default', 0x53656172636820696e, '6.22'),
(719, '/goodmilk/admin/build/translate/search', 'default', 0x426f7468207472616e736c6174656420616e6420756e7472616e736c6174656420737472696e6773, '6.22'),
(720, '/goodmilk/admin/build/translate/search', 'default', 0x4f6e6c79207472616e736c6174656420737472696e6773, '6.22'),
(721, '/goodmilk/admin/build/translate/search', 'default', 0x4f6e6c7920756e7472616e736c6174656420737472696e6773, '6.22'),
(722, '/goodmilk/admin/build/translate/search', 'default', 0x4c696d69742073656172636820746f, '6.22'),
(723, '/goodmilk/admin/build/translate/search', 'default', 0x416c6c20746578742067726f757073, '6.22'),
(724, '/goodmilk/admin/build/translate/search', 'default', 0x54686973207061676520616c6c6f77732061207472616e736c61746f7220746f2073656172636820666f72207370656369666963207472616e736c6174656420616e6420756e7472616e736c6174656420737472696e67732c20616e642069732075736564207768656e206372656174696e67206f722065646974696e67207472616e736c6174696f6e732e20284e6f74653a20466f72207472616e736c6174696f6e207461736b7320696e766f6c76696e67206d616e7920737472696e67732c206974206d6179206265206d6f726520636f6e76656e69656e7420746f203c6120687265663d22406578706f7274223e6578706f72743c2f613e20737472696e677320666f72206f66662d6c696e652065646974696e6720696e2061206465736b746f702047657474657874207472616e736c6174696f6e20656469746f722e29205365617263686573206d6179206265206c696d6974656420746f20737472696e677320666f756e642077697468696e206120737065636966696320746578742067726f7570206f7220696e2061207370656369666963206c616e67756167652e, '6.22'),
(725, '/goodmilk/admin/build/translate/search', 'default', 0x546578742067726f7570, '6.22'),
(726, '/goodmilk/admin/build/translate/search', 'default', 0x537472696e67, '6.22'),
(727, '/goodmilk/admin/build/translate/search', 'default', 0x64656c657465, '6.22'),
(728, '/goodmilk/admin/build/translate/search', 'default', 0xc2ab206669727374, '6.22'),
(729, '/goodmilk/admin/build/translate/search', 'default', 0xe280b92070726576696f7573, '6.22'),
(730, '/goodmilk/admin/build/translate/search', 'default', 0x6e65787420e280ba, '6.22'),
(731, '/goodmilk/admin/build/translate/search', 'default', 0x6c61737420c2bb, '6.22'),
(732, '/goodmilk/admin/build/translate/edit/677', 'default', 0x4564697420737472696e67, '6.22'),
(733, '/goodmilk/admin/build/translate/edit/677', 'default', 0x4f726967696e616c2074657874, '6.22'),
(734, '/goodmilk/admin/build/translate/edit/677', 'default', 0x53617665207472616e736c6174696f6e73, '6.22'),
(735, '/goodmilk/admin/build/translate/edit/315', 'default', 0x54686520737472696e6720686173206265656e2073617665642e, '6.22'),
(736, '/goodmilk/user/login', 'default', 0x4c6f6720696e, '6.22'),
(737, '/goodmilk/user/login', 'default', 0x557365726e616d65, '6.22'),
(738, '/goodmilk/user/login', 'default', 0x456e74657220796f757220407320757365726e616d652e, '6.22'),
(739, '/goodmilk/user/login', 'default', 0x50617373776f7264, '6.22'),
(740, '/goodmilk/user/login', 'default', 0x456e746572207468652070617373776f72642074686174206163636f6d70616e69657320796f757220757365726e616d652e, '6.22'),
(741, '/goodmilk/user/login', 'default', 0x437265617465206e6577206163636f756e74, '6.22'),
(742, '/goodmilk/user/login', 'default', 0x52657175657374206e65772070617373776f7264, '6.22'),
(743, '/goodmilk/', 'default', 0x3c683120636c6173733d227469746c65223e57656c636f6d6520746f20796f7572206e65772044727570616c2077656273697465213c2f68313e3c703e506c6561736520666f6c6c6f7720746865736520737465707320746f2073657420757020616e64207374617274207573696e6720796f757220776562736974653a3c2f703e, '6.22'),
(744, '/goodmilk/', 'default', 0x3c7374726f6e673e436f6e66696775726520796f757220776562736974653c2f7374726f6e673e204f6e6365206c6f6767656420696e2c20766973697420746865203c6120687265663d224061646d696e223e61646d696e697374726174696f6e2073656374696f6e3c2f613e2c20776865726520796f752063616e203c6120687265663d2240636f6e666967223e637573746f6d697a6520616e6420636f6e6669677572653c2f613e20616c6c2061737065637473206f6620796f757220776562736974652e, '6.22'),
(745, '/goodmilk/', 'default', 0x3c7374726f6e673e456e61626c65206164646974696f6e616c2066756e6374696f6e616c6974793c2f7374726f6e673e204e6578742c20766973697420746865203c6120687265663d22406d6f64756c6573223e6d6f64756c65206c6973743c2f613e20616e6420656e61626c65206665617475726573207768696368207375697420796f7572207370656369666963206e656564732e20596f752063616e2066696e64206164646974696f6e616c206d6f64756c657320696e20746865203c6120687265663d2240646f776e6c6f61645f6d6f64756c6573223e44727570616c206d6f64756c657320646f776e6c6f61642073656374696f6e3c2f613e2e, '6.22'),
(746, '/goodmilk/', 'default', 0x3c7374726f6e673e437573746f6d697a6520796f757220776562736974652064657369676e3c2f7374726f6e673e20546f206368616e67652074686520226c6f6f6b20616e64206665656c22206f6620796f757220776562736974652c20766973697420746865203c6120687265663d22407468656d6573223e7468656d65732073656374696f6e3c2f613e2e20596f75206d61792063686f6f73652066726f6d206f6e65206f662074686520696e636c75646564207468656d6573206f7220646f776e6c6f6164206164646974696f6e616c207468656d65732066726f6d20746865203c6120687265663d2240646f776e6c6f61645f7468656d6573223e44727570616c207468656d657320646f776e6c6f61642073656374696f6e3c2f613e2e, '6.22'),
(747, '/goodmilk/', 'default', 0x3c7374726f6e673e537461727420706f7374696e6720636f6e74656e743c2f7374726f6e673e2046696e616c6c792c20796f752063616e203c6120687265663d2240636f6e74656e74223e63726561746520636f6e74656e743c2f613e20666f7220796f757220776562736974652e2054686973206d6573736167652077696c6c20646973617070656172206f6e636520796f7520686176652070726f6d6f746564206120706f737420746f207468652066726f6e7420706167652e, '6.22'),
(748, '/goodmilk/', 'default', 0x466f72206d6f726520696e666f726d6174696f6e2c20706c6561736520726566657220746f20746865203c6120687265663d224068656c70223e68656c702073656374696f6e3c2f613e2c206f7220746865203c6120687265663d224068616e64626f6f6b223e6f6e6c696e652044727570616c2068616e64626f6f6b733c2f613e2e20596f75206d617920616c736f20706f737420617420746865203c6120687265663d2240666f72756d223e44727570616c20666f72756d3c2f613e2c206f7220766965772074686520776964652072616e6765206f66203c6120687265663d2240737570706f7274223e6f7468657220737570706f7274206f7074696f6e733c2f613e20617661696c61626c652e, '6.22'),
(749, '/goodmilk/node/1', 'default', 0x48544d4c2066696c746572, '6.22'),
(750, '/goodmilk/node/1', 'default', 0x4c696e6520627265616b20636f6e766572746572, '6.22'),
(751, '/goodmilk/node/1', 'default', 0x55524c2066696c746572, '6.22'),
(752, '/goodmilk/node/1', 'default', 0x48544d4c20636f72726563746f72, '6.22'),
(753, '/goodmilk/node/1', 'default', 0x53756e, '6.22'),
(754, '/goodmilk/node/1', 'default', 0x56696577, '6.22'),
(755, '/goodmilk/admin/build/menu', 'default', 0x4d656e757320617265206120636f6c6c656374696f6e206f66206c696e6b7320286d656e75206974656d7329207573656420746f206e61766967617465206120776562736974652e20546865206d656e75732063757272656e746c7920617661696c61626c65206f6e20796f757220736974652061726520646973706c617965642062656c6f772e2053656c6563742061206d656e752066726f6d2074686973206c69737420746f206d616e61676520697473206d656e75206974656d732e, '6.22'),
(756, '/goodmilk/admin/build/menu', 'default', 0x546865206d656e75206d6f64756c652070726f766964657320616e20696e7465726661636520746f20636f6e74726f6c20616e6420637573746f6d697a652044727570616c277320706f77657266756c206d656e752073797374656d2e204d656e75732061726520612068696572617263686963616c20636f6c6c656374696f6e206f66206c696e6b732c206f72206d656e75206974656d732c207573656420746f206e61766967617465206120776562736974652c20616e642061726520706f736974696f6e656420616e6420646973706c61796564207573696e672044727570616c277320666c657869626c6520626c6f636b2073797374656d2e2042792064656661756c742c207468726565206d656e757320617265206372656174656420647572696e6720696e7374616c6c6174696f6e3a203c656d3e4e617669676174696f6e3c2f656d3e2c203c656d3e5072696d617279206c696e6b733c2f656d3e2c20616e64203c656d3e5365636f6e64617279206c696e6b733c2f656d3e2e20546865203c656d3e4e617669676174696f6e3c2f656d3e206d656e7520636f6e7461696e73206d6f7374206c696e6b73206e656365737361727920666f7220776f726b696e67207769746820616e64206e617669676174696e6720796f757220736974652c20616e64206973206f6674656e20646973706c6179656420696e2065697468657220746865206c656674206f7220726967687420736964656261722e204d6f73742044727570616c207468656d657320616c736f2070726f7669646520737570706f727420666f72203c656d3e5072696d617279206c696e6b733c2f656d3e20616e64203c656d3e5365636f6e64617279206c696e6b733c2f656d3e2c20627920646973706c6179696e67207468656d20696e206569746865722074686520686561646572206f7220666f6f746572206f66206561636820706167652e2042792064656661756c742c203c656d3e5072696d617279206c696e6b733c2f656d3e20616e64203c656d3e5365636f6e64617279206c696e6b733c2f656d3e20636f6e7461696e206e6f206d656e75206974656d7320627574206d617920626520636f6e6669677572656420746f20636f6e7461696e20637573746f6d206d656e75206974656d7320737065636966696320746f20796f757220736974652e, '6.22'),
(757, '/goodmilk/admin/build/menu', 'default', 0x546865203c6120687265663d22406d656e75223e6d656e757320706167653c2f613e20646973706c61797320616c6c206d656e75732063757272656e746c7920617661696c61626c65206f6e20796f757220736974652e2053656c6563742061206d656e752066726f6d2074686973206c69737420746f20616464206f7220656469742061206d656e75206974656d2c206f7220746f207265617272616e6765206974656d732077697468696e20746865206d656e752e20437265617465206e6577206d656e7573207573696e6720746865203c6120687265663d22406164642d6d656e75223e616464206d656e7520706167653c2f613e202874686520626c6f636b20636f6e7461696e696e672061206e6577206d656e75206d75737420616c736f20626520656e61626c6564206f6e20746865203c6120687265663d2240626c6f636b73223e626c6f636b732061646d696e697374726174696f6e20706167653c2f613e292e, '6.22'),
(758, '/goodmilk/admin/build/menu', 'default', 0x466f72206d6f726520696e666f726d6174696f6e2c2073656520746865206f6e6c696e652068616e64626f6f6b20656e74727920666f72203c6120687265663d22406d656e75223e4d656e75206d6f64756c653c2f613e2e, '6.22'),
(759, '/goodmilk/admin/build/menu', 'default', 0x5b3c6120687265663d22406c696e6b223e6d6f72652068656c702e2e2e3c2f613e5d, '6.22'),
(760, '/goodmilk/admin/build/menu-customize/primary-links', 'default', 0x4d656e75206974656d, '6.22'),
(761, '/goodmilk/admin/build/menu-customize/primary-links', 'default', 0x457870616e646564, '6.22'),
(762, '/goodmilk/admin/build/menu-customize/primary-links', 'default', 0x4c697374206974656d73, '6.22'),
(763, '/goodmilk/admin/build/menu-customize/primary-links', 'default', 0x416464206974656d, '6.22'),
(764, '/goodmilk/admin/build/menu-customize/primary-links', 'default', 0x45646974206d656e75, '6.22'),
(765, '/goodmilk/admin/build/menu-customize/primary-links', 'default', 0x546f207265617272616e6765206d656e75206974656d732c2067726162206120647261672d616e642d64726f702068616e646c6520756e64657220746865203c656d3e4d656e75206974656d3c2f656d3e20636f6c756d6e20616e64206472616720746865206974656d7320286f722067726f7570206f66206974656d732920746f2061206e6577206c6f636174696f6e20696e20746865206c6973742e20284772616220612068616e646c6520627920636c69636b696e6720616e6420686f6c64696e6720746865206d6f757365207768696c6520686f766572696e67206f76657220612068616e646c652069636f6e2e292052656d656d626572207468617420796f7572206368616e6765732077696c6c206e6f7420626520736176656420756e74696c20796f7520636c69636b20746865203c656d3e5361766520636f6e66696775726174696f6e3c2f656d3e20627574746f6e2061742074686520626f74746f6d206f662074686520706167652e, '6.22'),
(766, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x50617468, '6.22'),
(767, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x54686520706174682074686973206d656e75206974656d206c696e6b7320746f2e20546869732063616e20626520616e20696e7465726e616c2044727570616c2070617468207375636820617320256164642d6e6f6465206f7220616e2065787465726e616c2055524c2073756368206173202564727570616c2e20456e746572202566726f6e7420746f206c696e6b20746f207468652066726f6e7420706167652e, '6.22'),
(768, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x4d656e75206c696e6b207469746c65, '6.22'),
(769, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x546865206c696e6b207465787420636f72726573706f6e64696e6720746f2074686973206974656d20746861742073686f756c642061707065617220696e20746865206d656e752e, '6.22'),
(770, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x4465736372697074696f6e, '6.22'),
(771, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x546865206465736372697074696f6e20646973706c61796564207768656e20686f766572696e67206f7665722061206d656e75206974656d2e, '6.22'),
(772, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x4d656e75206974656d73207468617420617265206e6f7420656e61626c65642077696c6c206e6f74206265206c697374656420696e20616e79206d656e752e, '6.22'),
(773, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x49662073656c656374656420616e642074686973206d656e75206974656d20686173206368696c6472656e2c20746865206d656e752077696c6c20616c776179732061707065617220657870616e6465642e, '6.22'),
(774, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x457865637574652050485020436f6465, '6.22'),
(775, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x4578656375746520736f6d652050485020636f6465, '6.22'),
(776, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x46756e6374696f6e207265666572656e6365, '6.22'),
(777, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x566965772061206c697374206f662063757272656e746c7920646566696e656420757365722066756e6374696f6e73207769746820646f63756d656e746174696f6e206c696e6b732e, '6.22'),
(778, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x486f6f6b5f656c656d656e74732829, '6.22'),
(779, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x56696577207468652061637469766520666f726d2f72656e64657220656c656d656e747320666f72207468697320736974652e, '6.22'),
(780, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x504850696e666f2829, '6.22'),
(781, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x5669657720796f75722073657276657227732050485020636f6e66696775726174696f6e, '6.22'),
(782, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x5265696e7374616c6c206d6f64756c6573, '6.22'),
(783, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x52756e20686f6f6b5f756e696e7374616c6c282920616e64207468656e20686f6f6b5f696e7374616c6c282920666f72206120676976656e206d6f64756c652e, '6.22'),
(784, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x53657373696f6e20766965776572, '6.22'),
(785, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x4c6973742074686520636f6e74656e7473206f6620245f53455353494f4e2e, '6.22'),
(786, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x456d707479206361636865, '6.22'),
(787, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x436c656172207468652043535320636163686520616e6420616c6c206461746162617365206361636865207461626c65732077686963682073746f726520706167652c206e6f64652c207468656d6520616e64207661726961626c65206361636865732e, '6.22'),
(788, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x52656275696c64206d656e7573, '6.22'),
(789, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x52656275696c64206d656e75206261736564206f6e20686f6f6b5f6d656e75282920616e642072657665727420616e7920637573746f6d206368616e6765732e20416c6c206d656e75206974656d732072657475726e20746f2074686569722064656661756c742073657474696e67732e, '6.22'),
(790, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x5468656d65207265676973747279, '6.22'),
(791, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x566965772061206c697374206f6620617661696c61626c65207468656d652066756e6374696f6e73206163726f7373207468652077686f6c6520736974652e, '6.22'),
(792, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x52656275696c64207065726d697373696f6e73, '6.22'),
(793, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x45646974207465726d, '6.22'),
(794, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x53746f7279, '6.22'),
(795, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x626c6f636b, '6.22'),
(796, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x636f6c6f72, '6.22'),
(797, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x636f6d6d656e74, '6.22'),
(798, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x68656c70, '6.22'),
(799, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x6d656e75, '6.22'),
(800, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x6e6f6465, '6.22'),
(801, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x73797374656d, '6.22'),
(802, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x75736572, '6.22'),
(803, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x64626c6f67, '6.22'),
(804, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x7461786f6e6f6d79, '6.22'),
(805, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x757064617465, '6.22'),
(806, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x61646d696e5f6d656e75, '6.22'),
(807, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x636f6e74656e74, '6.22'),
(808, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x76696577735f7569, '6.22'),
(809, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x766965777370687066696c746572, '6.22'),
(810, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x6265747465725f666f726d617473, '6.22'),
(811, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x636f6e74616374, '6.22'),
(812, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x64617465, '6.22'),
(813, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x646576656c, '6.22'),
(814, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x676f6f676c65616e616c7974696373, '6.22'),
(815, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x6c69676874626f7832, '6.22'),
(816, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x6c6f63616c65, '6.22'),
(817, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x6e6963655f6d656e7573, '6.22'),
(818, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x70617468, '6.22'),
(819, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x706174686175746f, '6.22'),
(820, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x706870, '6.22'),
(821, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x736561726368, '6.22'),
(822, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x73746174697374696373, '6.22'),
(823, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x7379736c6f67, '6.22'),
(824, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x746f6b656e, '6.22'),
(825, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x7472616e736c6174696f6e, '6.22'),
(826, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x77797369777967, '6.22'),
(827, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x6931386e, '6.22'),
(828, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x6931386e626c6f636b73, '6.22'),
(829, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x6931386e636f6e74656e74, '6.22'),
(830, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x6931386e6d656e75, '6.22'),
(831, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x6931386e70726f66696c65, '6.22'),
(832, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x6931386e737472696e6773, '6.22'),
(833, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x6931386e73796e63, '6.22'),
(834, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x6931386e7461786f6e6f6d79, '6.22'),
(835, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x6c616e677561676569636f6e73, '6.22'),
(836, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x706f6c6c, '6.22'),
(837, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x70726f66696c65, '6.22'),
(838, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x504850, '6.22'),
(839, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x53514c, '6.22'),
(840, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x4d616e75616c2075706461746520636865636b, '6.22'),
(841, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x436f6e66696775726520626c6f636b, '6.22'),
(842, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x44656c65746520626c6f636b, '6.22'),
(843, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x4a617661536372697074204c69737420466f726d, '6.22'),
(844, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x44656c65746520616c696173, '6.22'),
(845, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x4564697420616c696173, '6.22'),
(846, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x436f6e66696775726520616e20616476616e63656420616374696f6e, '6.22'),
(847, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x52656d6f7665206f727068616e73, '6.22'),
(848, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x436c65616e2055524c20636865636b, '6.22'),
(849, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x4461746520616e642074696d65206c6f6f6b7570, '6.22'),
(850, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x44656c65746520696e70757420666f726d6174, '6.22'),
(851, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x416464206e65772070726f66696c65, '6.22'),
(852, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x436c65617220696e646578, '6.22'),
(853, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x44656c6574652072756c65, '6.22'),
(854, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x456469742072756c65, '6.22'),
(855, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x4564697420726f6c65, '6.22'),
(856, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x44656c657465206669656c64, '6.22'),
(857, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x45646974206669656c64, '6.22'),
(858, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x50726f66696c652063617465676f7279206175746f636f6d706c657465, '6.22'),
(859, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x4a6176617363726970742043686f69636520466f726d, '6.22'),
(860, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x50726f66696c65206175746f636f6d706c657465, '6.22'),
(861, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x64697361626c6564, '6.22'),
(862, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x506172656e74206974656d, '6.22'),
(863, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x546865206d6178696d756d20646570746820666f7220616e206974656d20616e6420616c6c20697473206368696c6472656e20697320666978656420617420216d617864657074682e20536f6d65206d656e75206974656d73206d6179206e6f7420626520617661696c61626c6520617320706172656e74732069662073656c656374696e67207468656d20776f756c64206578636565642074686973206c696d69742e, '6.22'),
(864, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x4f7074696f6e616c2e20496e20746865206d656e752c207468652068656176696572206974656d732077696c6c2073696e6b20616e6420746865206c696768746572206974656d732077696c6c20626520706f736974696f6e6564206e65617265722074686520746f702e, '6.22'),
(865, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x53617665, '6.22'),
(866, '/goodmilk/admin/build/menu-customize/primary-links/add', 'default', 0x53656c6563742061206c616e677561676520666f722074686973206d656e75206974656d2e2043686f6f73652022416c6c206c616e6775616765732220746f206d616b6520746865206d656e75206974656d207472616e736c617461626c6520696e746f20646966666572656e74206c616e6775616765732e, '6.22'),
(867, 'item:557:title', 'menu', 0x47696f69205468696575, '1'),
(868, '/goodmilk/admin/build/menu/item/430/delete', 'default', 0x44656c657465206d656e75206974656d, '6.22'),
(869, '/goodmilk/admin/build/menu/item/430/delete', 'default', 0x41726520796f75207375726520796f752077616e7420746f2064656c6574652074686520637573746f6d206d656e75206974656d20256974656d3f, '6.22'),
(870, '/goodmilk/admin/build/menu/item/430/delete', 'default', 0x5468697320616374696f6e2063616e6e6f7420626520756e646f6e652e, '6.22'),
(871, '/goodmilk/admin/build/menu/item/430/delete', 'default', 0x43616e63656c, '6.22'),
(872, '/goodmilk/admin/build/menu/item/430/delete', 'default', 0x436f6e6669726d, '6.22'),
(873, '/goodmilk/admin/build/menu/item/430/delete', 'default', 0x546865206d656e75206974656d20257469746c6520686173206265656e2064656c657465642e, '6.22'),
(875, '/goodmilk/admin/content/types', 'default', 0xc2bb204164642061206e657720636f6e74656e742074797065, '6.22'),
(876, '/goodmilk/admin/content/types', 'default', 0x42656c6f772069732061206c697374206f6620616c6c2074686520636f6e74656e74207479706573206f6e20796f757220736974652e20416c6c20706f7374732074686174206578697374206f6e20796f757220736974652061726520696e7374616e636573206f66206f6e65206f6620746865736520636f6e74656e742074797065732e, '6.22'),
(877, '/goodmilk/admin/content/types/add', 'default', 0x5469746c65, '6.22'),
(878, '/goodmilk/admin/content/types/add', 'default', 0x426f6479, '6.22'),
(879, '/goodmilk/admin/content/types/add', 'default', 0x4964656e74696669636174696f6e, '6.22'),
(880, '/goodmilk/admin/content/types/add', 'default', 0x5468652068756d616e2d7265616461626c65206e616d65206f66207468697320636f6e74656e7420747970652e205468697320746578742077696c6c20626520646973706c617965642061732070617274206f6620746865206c697374206f6e20746865203c656d3e63726561746520636f6e74656e743c2f656d3e20706167652e204974206973207265636f6d6d656e64656420746861742074686973206e616d6520626567696e20776974682061206361706974616c206c657474657220616e6420636f6e7461696e206f6e6c79206c6574746572732c206e756d626572732c20616e64203c7374726f6e673e7370616365733c2f7374726f6e673e2e2054686973206e616d65206d75737420626520756e697175652e, '6.22'),
(881, '/goodmilk/admin/content/types/add', 'default', 0x546865206d616368696e652d7265616461626c65206e616d65206f66207468697320636f6e74656e7420747970652e205468697320746578742077696c6c206265207573656420666f7220636f6e737472756374696e67207468652055524c206f6620746865203c656d3e63726561746520636f6e74656e743c2f656d3e207061676520666f72207468697320636f6e74656e7420747970652e2054686973206e616d65206d75737420636f6e7461696e206f6e6c79206c6f77657263617365206c6574746572732c206e756d626572732c20616e6420756e64657273636f7265732e20556e64657273636f7265732077696c6c20626520636f6e76657274656420696e746f2068797068656e73207768656e20636f6e737472756374696e67207468652055524c206f6620746865203c656d3e63726561746520636f6e74656e743c2f656d3e20706167652e2054686973206e616d65206d75737420626520756e697175652e, '6.22'),
(882, '/goodmilk/admin/content/types/add', 'default', 0x41206272696566206465736372697074696f6e206f66207468697320636f6e74656e7420747970652e205468697320746578742077696c6c20626520646973706c617965642061732070617274206f6620746865206c697374206f6e20746865203c656d3e63726561746520636f6e74656e743c2f656d3e20706167652e, '6.22'),
(883, '/goodmilk/admin/content/types/add', 'default', 0x5375626d697373696f6e20666f726d2073657474696e6773, '6.22'),
(884, '/goodmilk/admin/content/types/add', 'default', 0x426f6479206669656c64206c6162656c, '6.22'),
(885, '/goodmilk/admin/content/types/add', 'default', 0x546f206f6d69742074686520626f6479206669656c6420666f72207468697320636f6e74656e7420747970652c2072656d6f766520616e79207465787420616e64206c656176652074686973206669656c6420626c616e6b2e, '6.22'),
(886, '/goodmilk/admin/content/types/add', 'default', 0x4d696e696d756d206e756d626572206f6620776f726473, '6.22'),
(887, '/goodmilk/admin/content/types/add', 'default', 0x546865206d696e696d756d206e756d626572206f6620776f72647320666f722074686520626f6479206669656c6420746f20626520636f6e736964657265642076616c696420666f72207468697320636f6e74656e7420747970652e20546869732063616e2062652075736566756c20746f2072756c65206f7574207375626d697373696f6e73207468617420646f206e6f74206d6565742074686520736974652773207374616e64617264732c20737563682061732073686f7274207465737420706f7374732e, '6.22'),
(888, '/goodmilk/admin/content/types/add', 'default', 0x4578706c616e6174696f6e206f72207375626d697373696f6e2067756964656c696e6573, '6.22'),
(889, '/goodmilk/admin/content/types/add', 'default', 0x5468697320746578742077696c6c20626520646973706c617965642061742074686520746f70206f6620746865207375626d697373696f6e20666f726d20666f72207468697320636f6e74656e7420747970652e2049742069732075736566756c20666f722068656c70696e67206f7220696e737472756374696e6720796f75722075736572732e, '6.22'),
(890, '/goodmilk/admin/content/types/add', 'default', 0x576f726b666c6f772073657474696e6773, '6.22'),
(891, '/goodmilk/admin/content/types/add', 'default', 0x44656661756c74206f7074696f6e73, '6.22'),
(892, '/goodmilk/admin/content/types/add', 'default', 0x5075626c6973686564, '6.22'),
(893, '/goodmilk/admin/content/types/add', 'default', 0x50726f6d6f74656420746f2066726f6e742070616765, '6.22'),
(894, '/goodmilk/admin/content/types/add', 'default', 0x537469636b7920617420746f70206f66206c69737473, '6.22'),
(895, '/goodmilk/admin/content/types/add', 'default', 0x437265617465206e6577207265766973696f6e, '6.22'),
(896, '/goodmilk/admin/content/types/add', 'default', 0x5573657273207769746820746865203c656d3e61646d696e6973746572206e6f6465733c2f656d3e207065726d697373696f6e2077696c6c2062652061626c6520746f206f76657272696465207468657365206f7074696f6e732e, '6.22'),
(897, '/goodmilk/admin/content/types/add', 'default', 0x44656661756c7420636f6d6d656e742073657474696e67, '6.22'),
(898, '/goodmilk/admin/content/types/add', 'default', 0x52656164206f6e6c79, '6.22'),
(899, '/goodmilk/admin/content/types/add', 'default', 0x526561642f5772697465, '6.22'),
(900, '/goodmilk/admin/content/types/add', 'default', 0x5573657273207769746820746865203c656d3e61646d696e697374657220636f6d6d656e74733c2f656d3e207065726d697373696f6e2077696c6c2062652061626c6520746f206f7665727269646520746869732073657474696e672e, '6.22'),
(901, '/goodmilk/admin/content/types/add', 'default', 0x44656661756c7420646973706c6179206d6f6465, '6.22'),
(902, '/goodmilk/admin/content/types/add', 'default', 0x466c6174206c697374202d20636f6c6c6170736564, '6.22'),
(903, '/goodmilk/admin/content/types/add', 'default', 0x466c6174206c697374202d20657870616e646564, '6.22'),
(904, '/goodmilk/admin/content/types/add', 'default', 0x5468726561646564206c697374202d20636f6c6c6170736564, '6.22'),
(905, '/goodmilk/admin/content/types/add', 'default', 0x5468726561646564206c697374202d20657870616e646564, '6.22'),
(906, '/goodmilk/admin/content/types/add', 'default', 0x5468652064656661756c74207669657720666f7220636f6d6d656e74732e20457870616e64656420766965777320646973706c61792074686520626f6479206f662074686520636f6d6d656e742e205468726561646564207669657773206b656570207265706c69657320746f6765746865722e, '6.22'),
(907, '/goodmilk/admin/content/types/add', 'default', 0x44656661756c7420646973706c6179206f72646572, '6.22'),
(908, '/goodmilk/admin/content/types/add', 'default', 0x44617465202d206e6577657374206669727374, '6.22'),
(909, '/goodmilk/admin/content/types/add', 'default', 0x44617465202d206f6c64657374206669727374, '6.22'),
(910, '/goodmilk/admin/content/types/add', 'default', 0x5468652064656661756c7420736f7274696e6720666f72206e657720757365727320616e6420616e6f6e796d6f7573207573657273207768696c652076696577696e6720636f6d6d656e74732e205468657365207573657273206d6179206368616e67652074686569722076696577207573696e672074686520636f6d6d656e7420636f6e74726f6c2070616e656c2e20466f7220726567697374657265642075736572732c2074686973206368616e67652069732072656d656d626572656420617320612070657273697374656e74207573657220707265666572656e63652e, '6.22'),
(911, '/goodmilk/admin/content/types/add', 'default', 0x44656661756c7420636f6d6d656e7473207065722070616765, '6.22'),
(912, '/goodmilk/admin/content/types/add', 'default', 0x44656661756c74206e756d626572206f6620636f6d6d656e747320666f72206561636820706167653a206d6f726520636f6d6d656e74732061726520646973747269627574656420696e207365766572616c2070616765732e, '6.22'),
(913, '/goodmilk/admin/content/types/add', 'default', 0x436f6d6d656e7420636f6e74726f6c73, '6.22'),
(914, '/goodmilk/admin/content/types/add', 'default', 0x446973706c61792061626f76652074686520636f6d6d656e7473, '6.22'),
(915, '/goodmilk/admin/content/types/add', 'default', 0x446973706c61792062656c6f772074686520636f6d6d656e7473, '6.22'),
(916, '/goodmilk/admin/content/types/add', 'default', 0x446973706c61792061626f766520616e642062656c6f772074686520636f6d6d656e7473, '6.22'),
(917, '/goodmilk/admin/content/types/add', 'default', 0x446f206e6f7420646973706c6179, '6.22'),
(918, '/goodmilk/admin/content/types/add', 'default', 0x506f736974696f6e206f662074686520636f6d6d656e7420636f6e74726f6c7320626f782e2054686520636f6d6d656e7420636f6e74726f6c73206c6574207468652075736572206368616e6765207468652064656661756c7420646973706c6179206d6f646520616e6420646973706c6179206f72646572206f6620636f6d6d656e74732e, '6.22'),
(919, '/goodmilk/admin/content/types/add', 'default', 0x416e6f6e796d6f757320636f6d6d656e74696e67, '6.22'),
(920, '/goodmilk/admin/content/types/add', 'default', 0x416e6f6e796d6f757320706f7374657273206d6179206e6f7420656e74657220746865697220636f6e7461637420696e666f726d6174696f6e, '6.22'),
(921, '/goodmilk/admin/content/types/add', 'default', 0x416e6f6e796d6f757320706f7374657273206d6179206c6561766520746865697220636f6e7461637420696e666f726d6174696f6e, '6.22'),
(922, '/goodmilk/admin/content/types/add', 'default', 0x416e6f6e796d6f757320706f7374657273206d757374206c6561766520746865697220636f6e7461637420696e666f726d6174696f6e, '6.22'),
(923, '/goodmilk/admin/content/types/add', 'default', 0x54686973206f7074696f6e20697320656e61626c6564207768656e20616e6f6e796d6f75732075736572732068617665207065726d697373696f6e20746f20706f737420636f6d6d656e7473206f6e20746865203c6120687265663d224075726c223e7065726d697373696f6e7320706167653c2f613e2e, '6.22'),
(924, '/goodmilk/admin/content/types/add', 'default', 0x436f6d6d656e74207375626a656374206669656c64, '6.22'),
(925, '/goodmilk/admin/content/types/add', 'default', 0x43616e2075736572732070726f76696465206120756e69717565207375626a65637420666f7220746865697220636f6d6d656e74733f, '6.22'),
(926, '/goodmilk/admin/content/types/add', 'default', 0x5072657669657720636f6d6d656e74, '6.22'),
(927, '/goodmilk/admin/content/types/add', 'default', 0x4f7074696f6e616c, '6.22'),
(928, '/goodmilk/admin/content/types/add', 'default', 0x5265717569726564, '6.22'),
(929, '/goodmilk/admin/content/types/add', 'default', 0x466f726365732061207573657220746f206c6f6f6b20617420746865697220636f6d6d656e7420627920636c69636b696e67206f6e20612027507265766965772720627574746f6e206265666f726520746865792063616e2061637475616c6c79206164642074686520636f6d6d656e74, '6.22'),
(930, '/goodmilk/admin/content/types/add', 'default', 0x4c6f636174696f6e206f6620636f6d6d656e74207375626d697373696f6e20666f726d, '6.22'),
(931, '/goodmilk/admin/content/types/add', 'default', 0x446973706c6179206f6e2073657061726174652070616765, '6.22'),
(932, '/goodmilk/admin/content/types/add', 'default', 0x446973706c61792062656c6f7720706f7374206f7220636f6d6d656e7473, '6.22'),
(933, '/goodmilk/admin/content/types/add', 'default', 0x4d756c74696c696e6775616c20737570706f7274, '6.22'),
(934, '/goodmilk/admin/content/types/add', 'default', 0x456e61626c65206d756c74696c696e6775616c20737570706f727420666f72207468697320636f6e74656e7420747970652e20496620656e61626c65642c2061206c616e67756167652073656c656374696f6e206669656c642077696c6c20626520616464656420746f207468652065646974696e6720666f726d2c20616c6c6f77696e6720796f7520746f2073656c6563742066726f6d206f6e65206f6620746865203c6120687265663d22216c616e677561676573223e656e61626c6564206c616e6775616765733c2f613e2e2049662064697361626c65642c206e657720706f737473206172652073617665642077697468207468652064656661756c74206c616e67756167652e204578697374696e6720636f6e74656e742077696c6c206e6f74206265206166666563746564206279206368616e67696e672074686973206f7074696f6e2e, '6.22'),
(935, '/goodmilk/admin/content/types/add', 'default', 0x456e61626c65642c2077697468207472616e736c6174696f6e, '6.22'),
(936, '/goodmilk/admin/content/types/add', 'default', 0x456e61626c65206d756c74696c696e6775616c20737570706f727420666f72207468697320636f6e74656e7420747970652e20496620656e61626c65642c2061206c616e67756167652073656c656374696f6e206669656c642077696c6c20626520616464656420746f207468652065646974696e6720666f726d2c20616c6c6f77696e6720796f7520746f2073656c6563742066726f6d206f6e65206f6620746865203c6120687265663d22216c616e677561676573223e656e61626c6564206c616e6775616765733c2f613e2e20596f752063616e20616c736f207475726e206f6e207472616e736c6174696f6e20666f72207468697320636f6e74656e7420747970652c207768696368206c65747320796f75206861766520636f6e74656e74207472616e736c6174656420746f20616e79206f662074686520656e61626c6564206c616e6775616765732e2049662064697361626c65642c206e657720706f737473206172652073617665642077697468207468652064656661756c74206c616e67756167652e204578697374696e6720636f6e74656e742077696c6c206e6f74206265206166666563746564206279206368616e67696e672074686973206f7074696f6e2e, '6.22'),
(937, '/goodmilk/admin/content/types/add', 'default', 0x4d756c74696c616e6775616765206f7074696f6e73, '6.22'),
(938, '/goodmilk/admin/content/types/add', 'default', 0x457874656e646564206d756c74696c696e6775616c206f7074696f6e732070726f766964656420627920496e7465726e6174696f6e616c697a6174696f6e206d6f64756c652e, '6.22'),
(939, '/goodmilk/admin/content/types/add', 'default', 0x54686573652077696c6c20626520617661696c61626c65206f6e6c79207768656e20796f7520656e61626c65204d756c74696c696e6775616c20737570706f727420696e20576f726b666c6f772073657474696e67732061626f76652e, '6.22'),
(940, '/goodmilk/admin/content/types/add', 'default', 0x4f7074696f6e7320666f72206e6f6465206c616e6775616765, '6.22'),
(941, '/goodmilk/admin/content/types/add', 'default', 0x5365742063757272656e74206c616e67756167652061732064656661756c7420666f72206e657720636f6e74656e742e, '6.22'),
(942, '/goodmilk/admin/content/types/add', 'default', 0x52657175697265206c616e67756167652028446f206e6f7420616c6c6f77204c616e6775616765204e65757472616c292e, '6.22'),
(943, '/goodmilk/admin/content/types/add', 'default', 0x4c6f636b206c616e6775616765202843616e6e6f74206265206368616e676564292e, '6.22'),
(944, '/goodmilk/admin/content/types/add', 'default', 0x457874656e646564206c616e677561676520737570706f7274, '6.22'),
(945, '/goodmilk/admin/content/types/add', 'default', 0x4e6f726d616c202d20416c6c20656e61626c6564206c616e6775616765732077696c6c20626520616c6c6f7765642e, '6.22'),
(946, '/goodmilk/admin/content/types/add', 'default', 0x457874656e646564202d20416c6c20646566696e6564206c616e6775616765732077696c6c20626520616c6c6f7765642e, '6.22'),
(947, '/goodmilk/admin/content/types/add', 'default', 0x457874656e6465642c20627574206e6f7420646973706c61796564202d20416c6c20646566696e6564206c616e6775616765732077696c6c20626520616c6c6f77656420666f7220696e7075742c20627574206e6f7420646973706c6179656420696e206c696e6b732e, '6.22'),
(948, '/goodmilk/admin/content/types/add', 'default', 0x496620656e61626c65642c20616c6c20646566696e6564206c616e6775616765732077696c6c20626520616c6c6f77656420666f72207468697320636f6e74656e74207479706520696e206164646974696f6e20746f206f6e6c7920656e61626c6564206f6e65732e20546869732069732075736566756c20746f2068617665206d6f7265206c616e67756167657320666f7220636f6e74656e74207468616e20666f722074686520696e746572666163652e, '6.22'),
(949, '/goodmilk/admin/content/types/add', 'default', 0x53796e6368726f6e697a65207472616e736c6174696f6e73, '6.22'),
(950, '/goodmilk/admin/content/types/add', 'default', 0x53656c656374207768696368206669656c647320746f2073796e6368726f6e697a6520666f7220616c6c207472616e736c6174696f6e73206f66207468697320636f6e74656e7420747970652e, '6.22'),
(951, '/goodmilk/admin/content/types/add', 'default', 0x5374616e64617264206e6f6465206669656c64732e, '6.22'),
(952, '/goodmilk/admin/content/types/add', 'default', 0x417574686f72, '6.22'),
(953, '/goodmilk/admin/content/types/add', 'default', 0x537461747573, '6.22'),
(954, '/goodmilk/admin/content/types/add', 'default', 0x50726f6d6f7465, '6.22'),
(955, '/goodmilk/admin/content/types/add', 'default', 0x4d6f646572617465, '6.22'),
(956, '/goodmilk/admin/content/types/add', 'default', 0x537469636b79, '6.22'),
(957, '/goodmilk/admin/content/types/add', 'default', 0x5265766973696f6e202843726561746520616c736f206e6577207265766973696f6e20666f72207472616e736c6174696f6e7329, '6.22'),
(958, '/goodmilk/admin/content/types/add', 'default', 0x426f6f6b206f75746c696e6520287769746820746865207472616e736c6174656420706172656e7429, '6.22'),
(959, '/goodmilk/admin/content/types/add', 'default', 0x5461786f6e6f6d79207465726d73, '6.22'),
(960, '/goodmilk/admin/content/types/add', 'default', 0x546f206372656174652061206e657720636f6e74656e7420747970652c20656e746572207468652068756d616e2d7265616461626c65206e616d652c20746865206d616368696e652d7265616461626c65206e616d652c20616e6420616c6c206f746865722072656c6576616e74206669656c6473207468617420617265206f6e207468697320706167652e204f6e636520637265617465642c207573657273206f6620796f757220736974652077696c6c2062652061626c6520746f2063726561746520706f73747320746861742061726520696e7374616e636573206f66207468697320636f6e74656e7420747970652e, '6.22'),
(961, '/goodmilk/admin/content/types/add', 'default', 0x44656c65746520636f6e74656e742074797065, '6.22'),
(962, 'type:intro:name', 'nodetype', 0x496e74726f, '1'),
(963, 'type:intro:title', 'nodetype', 0x5469746c65, '1'),
(964, '/goodmilk/admin/content/types/add', 'default', 0x54686520636f6e74656e74207479706520256e616d6520686173206265656e2061646465642e, '6.22'),
(965, '/goodmilk/admin/content/types/add', 'default', 0x76696577, '6.22'),
(966, '/goodmilk/admin/content/types', 'default', 0x496e74726f, '6.22'),
(967, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x5374616e646172642067726f7570, '6.22'),
(968, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x44617465, '6.22'),
(969, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x446174657374616d70, '6.22'),
(970, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x4461746574696d65, '6.22'),
(971, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x2d2053656c6563742061206669656c642074797065202d, '6.22'),
(972, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x2d2053656c656374206120776964676574202d, '6.22'),
(973, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x4669656c64206e616d652028612d7a2c20302d392c205f29, '6.22'),
(974, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x54797065206f66206461746120746f2073746f72652e, '6.22'),
(975, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x466f726d20656c656d656e7420746f20656469742074686520646174612e, '6.22'),
(976, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x40747970653a20406669656c642028406c6162656c29, '6.22'),
(977, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x2d2053656c65637420616e206578697374696e67206669656c64202d, '6.22'),
(978, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x4669656c6420746f207368617265, '6.22'),
(979, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x47726f7570206e616d652028612d7a2c20302d392c205f29, '6.22'),
(980, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x416464206669656c647320616e642067726f75707320746f2074686520636f6e74656e7420747970652c20616e6420617272616e6765207468656d206f6e20636f6e74656e7420646973706c617920616e6420696e70757420666f726d732e, '6.22'),
(981, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x596f752063616e206164642061206669656c6420746f20612067726f7570206279206472616767696e672069742062656c6f7720616e6420746f20746865207269676874206f66207468652067726f75702e, '6.22'),
(982, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x4e6f74653a20496e7374616c6c696e6720746865203c6120687265663d22216164765f68656c70223e416476616e6365642068656c703c2f613e206d6f64756c652077696c6c206c657420796f7520616363657373206d6f726520616e64206265747465722068656c702e, '6.22'),
(983, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x4e6577206669656c64, '6.22'),
(984, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x4578697374696e67206669656c64, '6.22'),
(985, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x4e65772067726f7570, '6.22'),
(986, '/goodmilk/admin/content/node-type/intro/fields', 'default', 0x45646974, '6.22'),
(987, '/goodmilk/www.youtube.com/embed/pTbzXl4rMK0', 'default', 0x50616765206e6f7420666f756e64, '6.22'),
(988, '/goodmilk/www.youtube.com/embed/pTbzXl4rMK0', 'default', 0x54686520726571756573746564207061676520636f756c64206e6f7420626520666f756e642e, '6.22'),
(989, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x456d626564, '6.22'),
(990, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x257479706520626173696320696e666f726d6174696f6e, '6.22'),
(991, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x4669656c64206e616d65, '6.22'),
(992, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x5769646765742074797065, '6.22'),
(993, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x4368616e676520626173696320696e666f726d6174696f6e, '6.22');
INSERT INTO `locales_source` (`lid`, `location`, `textgroup`, `source`, `version`) VALUES
(994, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x25747970652073657474696e6773, '6.22'),
(995, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x53697a65206f6620746578746669656c64, '6.22'),
(996, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x48656c702074657874, '6.22'),
(997, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x496e737472756374696f6e7320746f2070726573656e7420746f2074686520757365722062656c6f772074686973206669656c64206f6e207468652065646974696e6720666f726d2e3c6272202f3e416c6c6f7765642048544d4c20746167733a204074616773, '6.22'),
(998, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x44656661756c742076616c7565, '6.22'),
(999, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x50485020636f6465, '6.22'),
(1000, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x2740636f6c756d6e27203d3e2076616c756520666f722040636f6c756d6e, '6.22'),
(1001, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x72657475726e206172726179280a202030203d3e2061727261792840636f6c756d6e73292c0a20202f2f20596f75276c6c20757375616c6c792077616e7420746f2073746f7020686572652e2050726f76696465206d6f72652076616c7565730a20202f2f20696620796f752077616e7420796f7572202764656661756c742076616c75652720746f206265206d756c74692d76616c7565643a0a202031203d3e2061727261792840636f6c756d6e73292c0a202032203d3e202e2e2e0a293b, '6.22'),
(1002, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x416476616e636564207573616765206f6e6c793a2050485020636f646520746861742072657475726e7320612064656661756c742076616c75652e2053686f756c64206e6f7420696e636c75646520266c743b3f706870203f2667743b2064656c696d69746572732e2049662074686973206669656c642069732066696c6c6564206f75742c207468652076616c75652072657475726e6564206279207468697320636f64652077696c6c206f7665727269646520616e792076616c7565207370656369666965642061626f76652e20457870656374656420666f726d61743a203c7072653e2173616d706c653c2f7072653e546f20666967757265206f75742074686520657870656374656420666f726d61742c20796f752063616e2075736520746865203c656d3e646576656c206c6f61643c2f656d3e207461622070726f7669646564206279203c6120687265663d22406c696e6b5f646576656c223e646576656c206d6f64756c653c2f613e206f6e206120257479706520636f6e74656e7420706167652e, '6.22'),
(1003, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x4d6178696d756d206e756d626572206f662076616c7565732075736572732063616e20656e74657220666f722074686973206669656c642e, '6.22'),
(1004, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x27556e6c696d69746564272077696c6c2070726f7669646520616e2027416464206d6f72652720627574746f6e20736f207468652075736572732063616e20616464206173206d616e792076616c7565732061732074686579206c696b652e, '6.22'),
(1005, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x5761726e696e6721204368616e67696e6720746869732073657474696e67206166746572206461746120686173206265656e206372656174656420636f756c6420726573756c7420696e20746865206c6f7373206f66206461746121, '6.22'),
(1006, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x4e756d626572206f662076616c756573, '6.22'),
(1007, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x556e6c696d69746564, '6.22'),
(1008, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x416c6c6f7765642076616c756573206c697374, '6.22'),
(1009, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x54686520706f737369626c652076616c7565732074686973206669656c642063616e20636f6e7461696e2e20456e746572206f6e652076616c756520706572206c696e652c20696e2074686520666f726d6174206b65797c6c6162656c2e20546865206b6579206973207468652076616c756520746861742077696c6c2062652073746f72656420696e207468652064617461626173652c20616e64206974206d757374206d6174636820746865206669656c642073746f72616765207479706520282574797065292e20546865206c6162656c206973206f7074696f6e616c2c20616e6420746865206b65792077696c6c206265207573656420617320746865206c6162656c206966206e6f206c6162656c206973207370656369666965642e3c6272202f3e416c6c6f7765642048544d4c20746167733a204074616773, '6.22'),
(1010, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x416476616e636564207573616765206f6e6c793a2050485020636f646520746861742072657475726e732061206b65796564206172726179206f6620616c6c6f7765642076616c7565732e2053686f756c64206e6f7420696e636c75646520266c743b3f706870203f2667743b2064656c696d69746572732e2049662074686973206669656c642069732066696c6c6564206f75742c207468652061727261792072657475726e6564206279207468697320636f64652077696c6c206f766572726964652074686520616c6c6f7765642076616c756573206c6973742061626f76652e, '6.22'),
(1011, '/goodmilk/admin/content/node-type/intro/fields/field_intro_embed?destinations%5B0%5D=admin%2Fcontent%2Fnode-type%2Fintro%2Ffields', 'default', 0x4372656174652061206c697374206f66206f7074696f6e732061732061206c69737420696e203c7374726f6e673e416c6c6f7765642076616c756573206c6973743c2f7374726f6e673e206f7220617320616e20617272617920696e2050485020636f64652e2054686573652076616c7565732077696c6c206265207468652073616d6520666f7220256669656c6420696e20616c6c20636f6e74656e742074797065732e, '6.22'),
(1012, 'sites/all/modules/imce/js/imce_set_app.js', 'default', 0x496e736572742066696c65, 'none'),
(1013, 'type:home:name', 'nodetype', 0x486f6d65, '1'),
(1014, 'type:home:title', 'nodetype', 0x5469746c65, '1'),
(1015, 'item:610:title', 'menu', 0x4854205068c3a26e205068e1bb9169, '1'),
(1016, 'type:distribution:name', 'nodetype', 0x446973747269627574696f6e, '1'),
(1017, 'type:distribution:title', 'nodetype', 0x5469746c65, '1');

-- --------------------------------------------------------

--
-- Table structure for table `locales_target`
--

CREATE TABLE IF NOT EXISTS `locales_target` (
  `lid` int(11) NOT NULL DEFAULT '0',
  `translation` blob NOT NULL,
  `language` varchar(12) NOT NULL DEFAULT '',
  `plid` int(11) NOT NULL DEFAULT '0',
  `plural` int(11) NOT NULL DEFAULT '0',
  `i18n_status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`language`,`lid`,`plural`),
  KEY `lid` (`lid`),
  KEY `plid` (`plid`),
  KEY `plural` (`plural`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `locales_target`
--

INSERT INTO `locales_target` (`lid`, `translation`, `language`, `plid`, `plural`, `i18n_status`) VALUES
(31, 0x43686f207068c3a970206e67c6b0e1bb9d6920c49169e1bb81752068606e6820c491e1bb8b6e68206e6768c4a9612063c3a163206b69e1bb8375206ee1bb99692064756e67206de1bb9b692e, 'vi', 0, 0, 0),
(32, 0x7468c3aa6d206b69e1bb83752064e1bbaf206c69e1bb8775, 'vi', 0, 0, 0),
(33, 0x63c3a163207472c6b0e1bb9d6e67, 'vi', 0, 0, 0),
(34, 0x74e1baa16f2062e1baa36e2073616f, 'vi', 0, 0, 0),
(35, 0x7175e1baa36e206cc3bd2063c3a163207472c6b0e1bb9d6e67, 'vi', 0, 0, 0),
(36, 0x78c3b361207472c6b0e1bb9d6e67, 'vi', 0, 0, 0),
(37, 0x43c3a163206b69e1bb8375206ee1bb99692064756e67, 'vi', 0, 0, 0),
(38, 0x54c3aa6e2063e1bba761206b69e1bb8375206ee1bb99692064756e672063c3b3207468e1bb8320c491e1bb8d6320c491c6b0e1bba3632e, 'vi', 0, 0, 0),
(39, 0x4dc3b42074e1baa3206e67e1baaf6e2063686f206b69e1bb8375206ee1bb99692064756e672e, 'vi', 0, 0, 0),
(40, 0x4ce1bb9d692068c6b0e1bb9b6e672064e1baab6e20c491c6b0e1bba363206869e1bb836e207468e1bb8b2063686f206e67c6b0e1bb9d692064c3b96e67206b68692068e1bb8d207468c3aa6d206de1bb9974206ee1bb99692064756e67206de1bb9b692076e1bb9b69206b69e1bb8375206ee1bb99692064756e67206e60792e, 'vi', 0, 0, 0),
(41, 0x5469746c65206669656c64206c6162656c, 'vi', 0, 0, 0),
(42, 0x4e68c3a36e2063686f207469c3aa7520c491e1bb812063e1bba761207472c6b0e1bb9d6e672e, 'vi', 0, 0, 0),
(43, 0x4cc6b075206b69e1bb8375206ee1bb99692064756e67, 'vi', 0, 0, 0),
(44, 0xc490c3a3206cc6b075206b69e1bb8375206ee1bb99692064756e67202574797065, 'vi', 0, 0, 0),
(45, 0x42e1baa16e207468e1baad742073e1bbb1206d75e1bb916e2078c3b361206b69e1bb8375206ee1bb99692064756e672025747970653f, 'vi', 0, 0, 0),
(46, 0x4ee1babf752062e1baa16e2063c3b3206ee1bb99692064756e67206e606f206b68c3b46e67207875e1baa574206869e1bb876e2074726f6e67206b69e1bb8375206ee1bb99692064756e67206e60792c206ec3b32073e1babd2062e1bb8b2078c3b3612e205468616f2074c3a163206e6079206b68c3b46e67207468e1bb8320c491c6b0e1bba36320686f606e206ce1baa1692e, 'vi', 0, 0, 0),
(47, 0xc490c3a32078c3b361206b69e1bb8375206ee1bb99692064756e67202574797065, 'vi', 0, 0, 0),
(48, 0x78c3b361, 'vi', 0, 0, 0),
(49, 0x5468c3aa6d207472c6b0e1bb9d6e6720c491c3a32074e1bb936e2074e1baa169, 'vi', 0, 0, 0),
(50, 0x5468c3aa6d207472c6b0e1bb9d6e67, 'vi', 0, 0, 0),
(51, 0x54e1baa16f207472c6b0e1bb9d6e67206de1bb9b69, 'vi', 0, 0, 0),
(52, 0x54c3aa6e2063c3b3207468e1bb8320c491e1bb8d632063686f207472c6b0e1bb9d6e67206e60792e, 'vi', 0, 0, 0),
(53, 0x4b69e1bb8375207472c6b0e1bb9d6e67, 'vi', 0, 0, 0),
(54, 0x54e1baa16f207472c6b0e1bb9d6e67, 'vi', 0, 0, 0),
(55, 0x4b68c3b46e672063c3b3206d6f64756c652074e1baa16f207261207472c6b0e1bb9d6e67206e606f2e2042e1baa16e2063e1baa76e203c6120687265663d22256d6f64756c65735f75726c223e6bc3ad636820686fe1baa174206de1bb99743c2f613e2c206e68c6b0206c6020746578742e6d6f64756c652c207472c6b0e1bb9b63206b68692062e1baa16e2063c3b3207468e1bb83207468c3aa6d2076606f2063c3a163207472c6b0e1bb9d6e672e, 'vi', 0, 0, 0),
(56, 0xc490c3a3207468c3aa6d207472c6b0e1bb9d6e6720256c6162656c2e, 'vi', 0, 0, 0),
(57, 0xc490c3a32074e1baa16f207472c6b0e1bb9d6e6720256c6162656c2e, 'vi', 0, 0, 0),
(58, 0x42e1baa16e207468e1baad742073e1bbb1206d75e1bb916e2078c3b361207472c6b0e1bb9d6e6720246669656c643f, 'vi', 0, 0, 0),
(59, 0x4ee1babf752062e1baa16e2063c3b3206ee1bb99692064756e67206e606f206b68c3b46e672063c3b320e1bb9f2074726f6e67207472c6b0e1bb9d6e67206e60792c206ec3b32073e1babd2062e1bb8b206de1baa57420c491692e205468616f2074c3a163206e6079206b68c3b46e67207468e1bb8320686f606e206ce1baa1692e, 'vi', 0, 0, 0),
(60, 0x58c3b361, 'vi', 0, 0, 0),
(61, 0xc490c3a32078c3b361207472c6b0e1bb9d6e6720256669656c64206b68e1bb8f69202574797065, 'vi', 0, 0, 0),
(62, 0x5472c6b0e1bb9d6e6720256669656c64206b68c3b46e672063c3b26e2074e1bb936e2074e1baa1692074726f6e67206b69e1bb8375206ee1bb99692064756e67206e606f2c2076c3ac207468e1babf206ec3b320c491c3a32062e1bb8b2078c3b3612e, 'vi', 0, 0, 0),
(63, 0x43c3a16320746869e1babf74206ce1baad7020776964676574, 'vi', 0, 0, 0),
(64, 0x4e68e1bbaf6e6720746869e1babf74206ce1baad70206368e1bb8920c3a1702064e1bba56e672063686f207472c6b0e1bb9d6e6720256669656c64206b6869206ec3b3206869e1bb836e207468e1bb8b20e1bb9f206b69e1bb8375206ee1bb99692064756e672025747970652e, 'vi', 0, 0, 0),
(65, 0x576964676574, 'vi', 0, 0, 0),
(66, 0x54726f6e6720666f726d20736fe1baa16e207468e1baa36f206e6f64652c206e68e1bbaf6e67207472c6b0e1bb9d6e67206ee1bab76e672068c6a16e2073e1babd206368c3ac6d207875e1bb916e67207660206e68e1bbaf6e67207472c6b0e1bb9d6e67206e68e1bab92068c6a16e2073e1babd206ee1bb9569206cc3aa6e207068c3ad61207472c3aa6e2e, 'vi', 0, 0, 0),
(67, 0x4ce1bb9d692068c6b0e1bb9b6e672064e1baab6e2063686f206e67c6b0e1bb9d692064c3b96e672073e1babd20c491c6b0e1bba363206869e1bb836e207468e1bb8b20e1bb9f207068c3ad612064c6b0e1bb9b69207472c6b0e1bb9d6e672074726f6e67207472616e67206269c3aa6e20736fe1baa16e2e, 'vi', 0, 0, 0),
(68, 0x43c3a16320746869e1babf74206ce1baad702064e1bbaf206c69e1bb8775, 'vi', 0, 0, 0),
(69, 0x43c3a16320746869e1babf74206ce1baad70206e607920c3a1702064e1bba56e672076606f207472c6b0e1bb9d6e6720256669656c642074726f6e67206de1bb9769206b69e1bb8375206ee1bb99692064756e67206d60206ec3b3207875e1baa574206869e1bb876e2e, 'vi', 0, 0, 0),
(70, 0x4e6869e1bb8175206769c3a1207472e1bb8b, 'vi', 0, 0, 0),
(71, 0x4cc6b0752063c3a16320746869e1babf74206ce1baad702063e1bba761207472c6b0e1bb9d6e67, 'vi', 0, 0, 0),
(72, 0xc490c3a3206cc6b075207472c6b0e1bb9d6e6720256669656c64, 'vi', 0, 0, 0),
(73, 0x4e68c3a36e, 'vi', 0, 0, 0),
(74, 0x4b68c3b46e672074c3ac6d207468e1baa57920506f737467726553514c206d617070696e672063686f206b69e1bb83752064e1bbaf206c69e1bb87752025747970652e, 'vi', 0, 0, 0),
(75, 0x63c6a12073e1bb9f2064e1bbaf206c69e1bb8775, 'vi', 0, 0, 0),
(76, 0xc490e1bb8b6e68206e6768c4a961206de1bb9974206b69e1bb8375207472c6b0e1bb9d6e67206e6760792f6769e1bb9d2e203c656d3e4368c3ba20c3bd3a2059c3aa752063e1baa77520636f6e74656e742e6d6f64756c652e3c2f656d3e, 'vi', 0, 0, 0),
(77, 0x4ec4836d, 'vi', 0, 0, 0),
(78, 0x4ec4836d207660207468c3a16e67, 'vi', 0, 0, 0),
(79, 0x4e676079207660206769e1bb9d, 'vi', 0, 0, 0),
(80, 0x4772616e756c6172697479, 'vi', 0, 0, 0),
(81, 0x5468e1bb9d69206769616e20c491c6b0e1bba3632067c3a16e2076606f207660207472c3ac6e682062607920e1bba96e672076e1bb9b69206d75e1bb9169206769e1bb9d2063e1bba761206e67c6b0e1bb9d692064c3b96e672e, 'vi', 0, 0, 0),
(82, 0x5468e1bb9d69206769616e20c491c6b0e1bba3632067c3a16e2076606f207660207472c3ac6e682062607920e1bba96e672076e1bb9b69206d75e1bb9169206769e1bb9d2063e1bba761206e67c6b0e1bb9d692064c3b96e672e, 'vi', 0, 0, 0),
(83, 0x5468616f2074c3a1632076e1bb9b692063c3a163206d75e1bb9169206769e1bb9d2e, 'vi', 0, 0, 0),
(84, 0x256e616d65207068e1baa36920c491c6b0e1bba3632067c3a16e2076e1bb9b6920c491e1bb8b6e682064e1baa16e672049534f20383630312028595959592d4d4d2d4444292e, 'vi', 0, 0, 0),
(85, 0x256e616d65207068e1baa36920c491c6b0e1bba3632067c3a16e2076e1bb9b6920c491e1bb8b6e682064e1baa16e672049534f20383630312028595959592d4d4d2d4444292e, 'vi', 0, 0, 0),
(86, 0x256e616d65207068e1baa36920c491c6b0e1bba3632067c3a16e2076e1bb9b6920c491e1bb8b6e682064e1baa16e672049534f20383630312028595959592d4d4d2d4444292e, 'vi', 0, 0, 0),
(87, 0x256e616d65207068e1baa36920c491c6b0e1bba3632067c3a16e2076e1bb9b6920c491e1bb8b6e682064e1baa16e672049534f203836303120285959592d4d4d2d4444292e, 'vi', 0, 0, 0),
(88, 0xc490e1bb99206460692074e1bb916920c49161, 'vi', 0, 0, 0),
(89, 0x53e1bb91206bc3bd2074e1bbb12074e1bb916920c491612063686f207472c6b0e1bb9d6e672e20c490e1bb83207472e1bb916e67206ee1babf75206d75e1bb916e20c491e1bb9920646069206c602076c3b42068e1baa16e2e, 'vi', 0, 0, 0),
(90, 0x62e1bab16e672076e1bb9b69, 'vi', 0, 0, 0),
(91, 0x6b68c3b46e672062e1bab16e672076e1bb9b69, 'vi', 0, 0, 0),
(92, 0x6b68e1bb9b702076e1bb9b69206de1baab75, 'vi', 0, 0, 0),
(93, 0x53e1bb912064c3b26e67, 'vi', 0, 0, 0),
(94, 0x2253e1bb912064c3b26e6722207068e1baa369206c60206de1bb99742073e1bb91206e677579c3aa6e2064c6b0c6a16e672e, 'vi', 0, 0, 0),
(95, 0x4769c3a1207472e1bb8b2063686f20256e616d65206b68c3b46e672068e1bba370206ce1bb872e, 'vi', 0, 0, 0),
(96, 0x6e6f64657265666572656e6365, 'vi', 0, 0, 0),
(97, 0xc490e1bb8b6e68206e6768c4a961206de1bb9974206b69e1bb8375207472c6b0e1bb9d6e6720c491e1bb83207468616d206b68e1baa36f20c491e1babf6e206de1bb9974206e6f64652074e1bbab206de1bb9974206e6f6465206b68c3a1632e203c656d3e4368c3ba20c3bd3a2079c3aa752063e1baa77520636f6e74656e742e6d6f64756c652e3c2f656d3e, 'vi', 0, 0, 0),
(98, 0x7468616d206b68e1baa36f206e6f64652074e1bbb120c491e1bb996e6720686f606e207468606e68, 'vi', 0, 0, 0),
(99, 0x4e68e1bbaf6e67206b69e1bb8375206ee1bb99692064756e672063c3b3207468e1bb8320c491c6b0e1bba363207468616d206b68e1baa36f20c491e1babf6e, 'vi', 0, 0, 0),
(100, 0x4b68c3b46e672074e1bb936e2074e1baa16920626069207669e1babf74206e606f2076e1bb9b69207469c3aa7520c491e1bb8120c491c3b32e, 'vi', 0, 0, 0),
(101, 0x73e1bb91, 'vi', 0, 0, 0),
(102, 0xc490e1bb8b6e68206e6768c4a9612063c3a163206b69e1bb8375207472c6b0e1bb9d6e672073e1bb912e203c656d3e4368c3ba20c3bd3a2059c3aa752063e1baa77520636f6e74656e742e6d6f64756c652e3c2f656d3e, 'vi', 0, 0, 0),
(103, 0x54e1bb916920746869e1bb8375, 'vi', 0, 0, 0),
(104, 0x54e1bb916920c49161, 'vi', 0, 0, 0),
(105, 0x43c3a163206769c3a1207472e1bb8b2063686f207068c3a970, 'vi', 0, 0, 0),
(106, 0x4e68e1bbaf6e67206769c3a1207472e1bb8b206d60207472c6b0e1bb9d6e67206e60792063c3b3207468e1bb83206d616e672e204e68e1bbaf6e67206769c3a1207472e1bb8b206b68c3a1632073e1babd207472e1baa32076e1bb81206ce1bb97692e20c49069e1bb816e206de1bb9769206769c3a1207472e1bb8b2076606f206de1bb97692064c3b26e672e, 'vi', 0, 0, 0),
(107, 0x2254e1bb916920746869e1bb837522207068e1baa369206c60206de1bb997420636f6e2073e1bb912e, 'vi', 0, 0, 0),
(108, 0x2254e1bb916920c4916122207068e1baa369206c60206de1bb997420636f6e2073e1bb912e, 'vi', 0, 0, 0),
(109, 0x4769c3a1207472e1bb8b2063e1bba76120256e616d65206b68c3b46e67207468e1bb83206e68e1bb8f2068c6a16e20256d696e2e, 'vi', 0, 0, 0),
(110, 0x4769c3a1207472e1bb8b2063e1bba76120256e616d65206b68c3b46e67207468e1bb83206ce1bb9b6e2068e1bb9b6e20256d61782e, 'vi', 0, 0, 0),
(111, 0x6f7074696f6e77696467657473, 'vi', 0, 0, 0),
(112, 0xc490e1bb8b6e68206e6768c4a9612068e1bb99702073656c6563742c20636865636b626f78207660206ec3ba7420726164696f2063686f2076c4836e2062e1baa36e2076602063c3a163207472c6b0e1bb9d6e672073e1bb912e203c656d3e4368c3ba20c3bd3a2059c3aa752063e1baa77520636f6e74656e742e6d6f64756c652c20746578742e6d6f64756c65207660206e756d6265722e6d6f64756c652e3c2f656d3e, 'vi', 0, 0, 0),
(113, 0x6bc3bd2074e1bbb1, 'vi', 0, 0, 0),
(114, 0xc490e1bb8b6e68206e6768c4a961206b69e1bb8375207472c6b0e1bb9d6e672076c4836e2062e1baa36e20c491c6a16e206769e1baa36e2e203c656d3e4368c3ba20c3bd3a2059c3aa752063e1baa77520636f6e74656e742e6d6f64756c652e3c2f656d3e, 'vi', 0, 0, 0),
(115, 0x56c4836e2062e1baa36e20c491c6b0e1bba363206ce1bb8d6320286e67c6b0e1bb9d692064c3b96e67206368e1bb8d6e20c491e1bb8b6e682064e1baa16e672064e1bbaf206c69e1bb87752076606f29, 'vi', 0, 0, 0),
(116, 0x4bc3bd2074e1bbb120c491c6a16e206769e1baa36e, 'vi', 0, 0, 0),
(117, 0x58e1bbad206cc3bd2076c4836e2062e1baa36e, 'vi', 0, 0, 0),
(118, 0x5472c6b0e1bb9d6e67206bc3bd2074e1bbb1, 'vi', 0, 0, 0),
(119, 0x757365727265666572656e6365, 'vi', 0, 0, 0),
(120, 0xc490e1bb8b6e68206e6768c4a961206b69e1bb8375207472c6b0e1bb9d6e6720c491e1bb83207468616d206b68e1baa36f206de1bb9974206e67c6b0e1bb9d692064c3b96e672074e1bbab206de1bb9974206e6f64652e203c656d3e4368c3ba20c3bd3a2059c3aa752063e1baa77520636f6e74656e742e6d6f64756c652e3c2f656d3e, 'vi', 0, 0, 0),
(121, 0x54c3aa6e206e67c6b0e1bb9d692064c3b96e67206b68c3b46e672068e1bba370206ce1bb872e, 'vi', 0, 0, 0),
(122, 0x77656275726c, 'vi', 0, 0, 0),
(123, 0xc490e1bb8b6e68206e6768c4a9612063c3a163206b69e1bb837520c491c6b0e1bb9d6e672064e1baab6e2077656220c491c6a16e206769e1baa36e2e203c656d3e4368c3ba20c3bd3a2059c3aa752063e1baa77520636f6e74656e742e6d6f64756c653c2f656d3e, 'vi', 0, 0, 0),
(124, 0xc490c6b0e1bb9d6e672064e1baab6e20776562206b68c3b46e672068e1bba370206ce1bb872e, 'vi', 0, 0, 0),
(140, 0x4c69c3aa6e2068e1bb87, 'vi', 0, 0, 0),
(315, 0x4c69c3aa6e2068e1bb87, 'vi', 0, 0, 0),
(485, 0x47e1bb9f692079c3aa752063e1baa775, 'vi', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `menu_custom`
--

CREATE TABLE IF NOT EXISTS `menu_custom` (
  `menu_name` varchar(32) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  PRIMARY KEY (`menu_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menu_custom`
--

INSERT INTO `menu_custom` (`menu_name`, `title`, `description`) VALUES
('navigation', 'Navigation', 'The navigation menu is provided by Drupal and is the main interactive menu for any site. It is usually the only menu that contains personalized links for authenticated users, and is often not even visible to anonymous users.'),
('primary-links', 'Primary links', 'Primary links are often used at the theme layer to show the major sections of a site. A typical representation for primary links would be tabs along the top.'),
('secondary-links', 'Secondary links', 'Secondary links are often used for pages like legal notices, contact details, and other secondary navigation items that play a lesser role than primary links'),
('devel', 'Development', 'Development links.');

-- --------------------------------------------------------

--
-- Table structure for table `menu_links`
--

CREATE TABLE IF NOT EXISTS `menu_links` (
  `menu_name` varchar(32) NOT NULL DEFAULT '',
  `mlid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plid` int(10) unsigned NOT NULL DEFAULT '0',
  `link_path` varchar(255) NOT NULL DEFAULT '',
  `router_path` varchar(255) NOT NULL DEFAULT '',
  `link_title` varchar(255) NOT NULL DEFAULT '',
  `options` text,
  `module` varchar(255) NOT NULL DEFAULT 'system',
  `hidden` smallint(6) NOT NULL DEFAULT '0',
  `external` smallint(6) NOT NULL DEFAULT '0',
  `has_children` smallint(6) NOT NULL DEFAULT '0',
  `expanded` smallint(6) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `depth` smallint(6) NOT NULL DEFAULT '0',
  `customized` smallint(6) NOT NULL DEFAULT '0',
  `p1` int(10) unsigned NOT NULL DEFAULT '0',
  `p2` int(10) unsigned NOT NULL DEFAULT '0',
  `p3` int(10) unsigned NOT NULL DEFAULT '0',
  `p4` int(10) unsigned NOT NULL DEFAULT '0',
  `p5` int(10) unsigned NOT NULL DEFAULT '0',
  `p6` int(10) unsigned NOT NULL DEFAULT '0',
  `p7` int(10) unsigned NOT NULL DEFAULT '0',
  `p8` int(10) unsigned NOT NULL DEFAULT '0',
  `p9` int(10) unsigned NOT NULL DEFAULT '0',
  `updated` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mlid`),
  KEY `path_menu` (`link_path`(128),`menu_name`),
  KEY `menu_plid_expand_child` (`menu_name`,`plid`,`expanded`,`has_children`),
  KEY `menu_parents` (`menu_name`,`p1`,`p2`,`p3`,`p4`,`p5`,`p6`,`p7`,`p8`,`p9`),
  KEY `router_path` (`router_path`(128))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=628 ;

--
-- Dumping data for table `menu_links`
--

INSERT INTO `menu_links` (`menu_name`, `mlid`, `plid`, `link_path`, `router_path`, `link_title`, `options`, `module`, `hidden`, `external`, `has_children`, `expanded`, `weight`, `depth`, `customized`, `p1`, `p2`, `p3`, `p4`, `p5`, `p6`, `p7`, `p8`, `p9`, `updated`) VALUES
('navigation', 1, 0, 'batch', 'batch', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 2, 0, 'admin', 'admin', 'Administer', 'a:0:{}', 'system', 0, 0, 1, 0, 9, 1, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 3, 0, 'node', 'node', 'Content', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 4, 0, 'logout', 'logout', 'Log out', 'a:0:{}', 'system', 0, 0, 0, 0, 10, 1, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 5, 0, 'rss.xml', 'rss.xml', 'RSS feed', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 6, 0, 'user', 'user', 'User account', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 7, 0, 'node/%', 'node/%', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 8, 2, 'admin/compact', 'admin/compact', 'Compact mode', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 2, 0, 2, 8, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 9, 0, 'filter/tips', 'filter/tips', 'Compose tips', 'a:0:{}', 'system', 1, 0, 0, 0, 0, 1, 0, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 10, 2, 'admin/content', 'admin/content', 'Content management', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:27:"Manage your site''s content.";}}', 'system', 0, 0, 1, 0, -10, 2, 0, 2, 10, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 11, 0, 'node/add', 'node/add', 'Create content', 'a:0:{}', 'system', 0, 0, 1, 0, 1, 1, 0, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 12, 0, 'comment/delete', 'comment/delete', 'Delete comment', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 13, 0, 'comment/edit', 'comment/edit', 'Edit comment', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 13, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 14, 0, 'system/files', 'system/files', 'File download', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 14, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 15, 2, 'admin/help', 'admin/help', 'Help', 'a:0:{}', 'system', 0, 0, 0, 0, 9, 2, 0, 2, 15, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 16, 2, 'admin/reports', 'admin/reports', 'Reports', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:59:"View reports from system logs and other status information.";}}', 'system', 0, 0, 1, 0, 5, 2, 0, 2, 16, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 17, 2, 'admin/build', 'admin/build', 'Site building', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:38:"Control how your site looks and feels.";}}', 'system', 0, 0, 1, 0, -10, 2, 0, 2, 17, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 18, 2, 'admin/settings', 'admin/settings', 'Site configuration', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:40:"Adjust basic site configuration options.";}}', 'system', 0, 0, 1, 0, -5, 2, 0, 2, 18, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 19, 0, 'user/autocomplete', 'user/autocomplete', 'User autocomplete', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 19, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 20, 2, 'admin/user', 'admin/user', 'User management', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:61:"Manage your site''s users, groups and access to site features.";}}', 'system', 0, 0, 1, 0, 0, 2, 0, 2, 20, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 21, 0, 'user/%', 'user/%', 'My account', 'a:0:{}', 'system', 0, 0, 0, 0, 0, 1, 0, 21, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 22, 20, 'admin/user/rules', 'admin/user/rules', 'Access rules', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:80:"List and create rules to disallow usernames, e-mail addresses, and IP addresses.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 20, 22, 0, 0, 0, 0, 0, 0, 0),
('navigation', 23, 18, 'admin/settings/actions', 'admin/settings/actions', 'Actions', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:41:"Manage the actions defined for your site.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 23, 0, 0, 0, 0, 0, 0, 0),
('navigation', 24, 18, 'admin/settings/admin', 'admin/settings/admin', 'Administration theme', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:55:"Settings for how your administrative pages should look.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 24, 0, 0, 0, 0, 0, 0, 0),
('navigation', 25, 17, 'admin/build/block', 'admin/build/block', 'Blocks', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:79:"Configure what block content appears in your site''s sidebars and other regions.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 17, 25, 0, 0, 0, 0, 0, 0, 0),
('navigation', 26, 18, 'admin/settings/clean-urls', 'admin/settings/clean-urls', 'Clean URLs', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:43:"Enable or disable clean URLs for your site.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 26, 0, 0, 0, 0, 0, 0, 0),
('navigation', 27, 10, 'admin/content/comment', 'admin/content/comment', 'Comments', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:61:"List and edit site comments and the comment moderation queue.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 10, 27, 0, 0, 0, 0, 0, 0, 0),
('navigation', 28, 10, 'admin/content/node', 'admin/content/node', 'Content', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:43:"View, edit, and delete your site''s content.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 10, 28, 0, 0, 0, 0, 0, 0, 0),
('navigation', 29, 10, 'admin/content/types', 'admin/content/types', 'Content types', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:82:"Manage posts by content type, including default status, front page promotion, etc.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 10, 29, 0, 0, 0, 0, 0, 0, 0),
('navigation', 30, 18, 'admin/settings/date-time', 'admin/settings/date-time', 'Date and time', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:89:"Settings for how Drupal displays date and time, as well as the system''s default timezone.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 30, 0, 0, 0, 0, 0, 0, 0),
('navigation', 31, 0, 'node/%/delete', 'node/%/delete', 'Delete', 'a:0:{}', 'system', -1, 0, 0, 0, 1, 1, 0, 31, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 32, 21, 'user/%/delete', 'user/%/delete', 'Delete', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 2, 0, 21, 32, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 33, 18, 'admin/settings/error-reporting', 'admin/settings/error-reporting', 'Error reporting', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:93:"Control how Drupal deals with errors including 403/404 errors as well as PHP error reporting.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 33, 0, 0, 0, 0, 0, 0, 0),
('navigation', 34, 18, 'admin/settings/file-system', 'admin/settings/file-system', 'File system', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:68:"Tell Drupal where to store uploaded files and how they are accessed.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 34, 0, 0, 0, 0, 0, 0, 0),
('navigation', 35, 18, 'admin/settings/image-toolkit', 'admin/settings/image-toolkit', 'Image toolkit', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:74:"Choose which image toolkit to use if you have installed optional toolkits.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 35, 0, 0, 0, 0, 0, 0, 0),
('navigation', 36, 18, 'admin/settings/filters', 'admin/settings/filters', 'Input formats', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:127:"Configure how content input by users is filtered, including allowed HTML tags. Also allows enabling of module-provided filters.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 36, 0, 0, 0, 0, 0, 0, 0),
('navigation', 37, 18, 'admin/settings/logging', 'admin/settings/logging', 'Logging and alerts', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:156:"Settings for logging and alerts modules. Various modules can route Drupal''s system events to different destination, such as syslog, database, email, ...etc.";}}', 'system', 0, 0, 1, 0, 0, 3, 0, 2, 18, 37, 0, 0, 0, 0, 0, 0, 0),
('navigation', 38, 17, 'admin/build/menu', 'admin/build/menu', 'Menus', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:116:"Control your site''s navigation menu, primary links and secondary links, as well as rename and reorganize menu items.";}}', 'system', 0, 0, 1, 0, 0, 3, 0, 2, 17, 38, 0, 0, 0, 0, 0, 0, 0),
('navigation', 39, 17, 'admin/build/modules', 'admin/build/modules', 'Modules', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:47:"Enable or disable add-on modules for your site.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 17, 39, 0, 0, 0, 0, 0, 0, 0),
('navigation', 40, 18, 'admin/settings/performance', 'admin/settings/performance', 'Performance', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:101:"Enable or disable page caching for anonymous users and set CSS and JS bandwidth optimization options.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 40, 0, 0, 0, 0, 0, 0, 0),
('navigation', 41, 20, 'admin/user/permissions', 'admin/user/permissions', 'Permissions', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:64:"Determine access to features by selecting permissions for roles.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 20, 41, 0, 0, 0, 0, 0, 0, 0),
('navigation', 42, 10, 'admin/content/node-settings', 'admin/content/node-settings', 'Post settings', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:126:"Control posting behavior, such as teaser length, requiring previews before posting, and the number of posts on the front page.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 10, 42, 0, 0, 0, 0, 0, 0, 0),
('navigation', 43, 10, 'admin/content/rss-publishing', 'admin/content/rss-publishing', 'RSS publishing', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:92:"Configure the number of items per feed and whether feeds should be titles/teasers/full-text.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 10, 43, 0, 0, 0, 0, 0, 0, 0),
('navigation', 44, 0, 'comment/reply/%', 'comment/reply/%', 'Reply to comment', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 44, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 45, 20, 'admin/user/roles', 'admin/user/roles', 'Roles', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:30:"List, edit, or add user roles.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 20, 45, 0, 0, 0, 0, 0, 0, 0),
('navigation', 46, 18, 'admin/settings/site-information', 'admin/settings/site-information', 'Site information', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:107:"Change basic site information, such as the site name, slogan, e-mail address, mission, front page and more.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 46, 0, 0, 0, 0, 0, 0, 0),
('navigation', 47, 18, 'admin/settings/site-maintenance', 'admin/settings/site-maintenance', 'Site maintenance', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:63:"Take the site off-line for maintenance or bring it back online.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 47, 0, 0, 0, 0, 0, 0, 0),
('navigation', 48, 16, 'admin/reports/status', 'admin/reports/status', 'Status report', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:74:"Get a status report about your site''s operation and any detected problems.";}}', 'system', 0, 0, 0, 0, 10, 3, 0, 2, 16, 48, 0, 0, 0, 0, 0, 0, 0),
('navigation', 49, 17, 'admin/build/themes', 'admin/build/themes', 'Themes', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:57:"Change which theme your site uses or allows users to set.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 17, 49, 0, 0, 0, 0, 0, 0, 0),
('navigation', 50, 20, 'admin/user/settings', 'admin/user/settings', 'User settings', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:101:"Configure default behavior of users, including registration requirements, e-mails, and user pictures.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 20, 50, 0, 0, 0, 0, 0, 0, 0),
('navigation', 51, 20, 'admin/user/user', 'admin/user/user', 'Users', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:26:"List, add, and edit users.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 20, 51, 0, 0, 0, 0, 0, 0, 0),
('navigation', 52, 15, 'admin/help/block', 'admin/help/block', 'block', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 52, 0, 0, 0, 0, 0, 0, 0),
('navigation', 53, 15, 'admin/help/color', 'admin/help/color', 'color', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 53, 0, 0, 0, 0, 0, 0, 0),
('navigation', 54, 15, 'admin/help/comment', 'admin/help/comment', 'comment', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 54, 0, 0, 0, 0, 0, 0, 0),
('navigation', 55, 15, 'admin/help/filter', 'admin/help/filter', 'filter', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 55, 0, 0, 0, 0, 0, 0, 0),
('navigation', 56, 15, 'admin/help/help', 'admin/help/help', 'help', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 56, 0, 0, 0, 0, 0, 0, 0),
('navigation', 57, 15, 'admin/help/menu', 'admin/help/menu', 'menu', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 57, 0, 0, 0, 0, 0, 0, 0),
('navigation', 58, 15, 'admin/help/node', 'admin/help/node', 'node', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 58, 0, 0, 0, 0, 0, 0, 0),
('navigation', 59, 15, 'admin/help/system', 'admin/help/system', 'system', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 59, 0, 0, 0, 0, 0, 0, 0),
('navigation', 60, 15, 'admin/help/user', 'admin/help/user', 'user', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 60, 0, 0, 0, 0, 0, 0, 0),
('navigation', 61, 36, 'admin/settings/filters/%', 'admin/settings/filters/%', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 18, 36, 61, 0, 0, 0, 0, 0, 0),
('navigation', 62, 26, 'admin/settings/clean-urls/check', 'admin/settings/clean-urls/check', 'Clean URL check', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 18, 26, 62, 0, 0, 0, 0, 0, 0),
('navigation', 63, 23, 'admin/settings/actions/configure', 'admin/settings/actions/configure', 'Configure an advanced action', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 18, 23, 63, 0, 0, 0, 0, 0, 0),
('navigation', 64, 25, 'admin/build/block/configure', 'admin/build/block/configure', 'Configure block', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 25, 64, 0, 0, 0, 0, 0, 0),
('navigation', 65, 17, 'admin/build/menu-customize/%', 'admin/build/menu-customize/%', 'Customize menu', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 17, 65, 0, 0, 0, 0, 0, 0, 0),
('navigation', 66, 30, 'admin/settings/date-time/lookup', 'admin/settings/date-time/lookup', 'Date and time lookup', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 18, 30, 66, 0, 0, 0, 0, 0, 0),
('navigation', 67, 25, 'admin/build/block/delete', 'admin/build/block/delete', 'Delete block', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 25, 67, 0, 0, 0, 0, 0, 0),
('navigation', 68, 36, 'admin/settings/filters/delete', 'admin/settings/filters/delete', 'Delete input format', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 18, 36, 68, 0, 0, 0, 0, 0, 0),
('navigation', 69, 22, 'admin/user/rules/delete', 'admin/user/rules/delete', 'Delete rule', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 20, 22, 69, 0, 0, 0, 0, 0, 0),
('navigation', 70, 45, 'admin/user/roles/edit', 'admin/user/roles/edit', 'Edit role', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 20, 45, 70, 0, 0, 0, 0, 0, 0),
('navigation', 71, 22, 'admin/user/rules/edit', 'admin/user/rules/edit', 'Edit rule', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 20, 22, 71, 0, 0, 0, 0, 0, 0),
('navigation', 72, 48, 'admin/reports/status/php', 'admin/reports/status/php', 'PHP', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 16, 48, 72, 0, 0, 0, 0, 0, 0),
('navigation', 73, 42, 'admin/content/node-settings/rebuild', 'admin/content/node-settings/rebuild', 'Rebuild permissions', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 10, 42, 73, 0, 0, 0, 0, 0, 0),
('navigation', 74, 23, 'admin/settings/actions/orphan', 'admin/settings/actions/orphan', 'Remove orphans', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 18, 23, 74, 0, 0, 0, 0, 0, 0),
('navigation', 75, 48, 'admin/reports/status/run-cron', 'admin/reports/status/run-cron', 'Run cron', 'a:1:{s:5:"alter";b:1;}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 16, 48, 75, 0, 0, 0, 0, 0, 0),
('navigation', 76, 48, 'admin/reports/status/sql', 'admin/reports/status/sql', 'SQL', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 16, 48, 76, 0, 0, 0, 0, 0, 0),
('navigation', 77, 23, 'admin/settings/actions/delete/%', 'admin/settings/actions/delete/%', 'Delete action', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:17:"Delete an action.";}}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 18, 23, 77, 0, 0, 0, 0, 0, 0),
('navigation', 78, 0, 'admin/build/menu-customize/%/delete', 'admin/build/menu-customize/%/delete', 'Delete menu', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 78, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 79, 25, 'admin/build/block/list/js', 'admin/build/block/list/js', 'JavaScript List Form', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 25, 79, 0, 0, 0, 0, 0, 0),
('navigation', 80, 39, 'admin/build/modules/list/confirm', 'admin/build/modules/list/confirm', 'List', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 39, 80, 0, 0, 0, 0, 0, 0),
('navigation', 81, 0, 'user/reset/%/%/%', 'user/reset/%/%/%', 'Reset password', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 81, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 82, 39, 'admin/build/modules/uninstall/confirm', 'admin/build/modules/uninstall/confirm', 'Uninstall', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 39, 82, 0, 0, 0, 0, 0, 0),
('navigation', 83, 0, 'node/%/revisions/%/delete', 'node/%/revisions/%/delete', 'Delete earlier revision', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 83, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 84, 0, 'node/%/revisions/%/revert', 'node/%/revisions/%/revert', 'Revert to earlier revision', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 84, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 85, 0, 'node/%/revisions/%/view', 'node/%/revisions/%/view', 'Revisions', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 85, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 86, 38, 'admin/build/menu/item/%/delete', 'admin/build/menu/item/%/delete', 'Delete menu item', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 38, 86, 0, 0, 0, 0, 0, 0),
('navigation', 87, 38, 'admin/build/menu/item/%/edit', 'admin/build/menu/item/%/edit', 'Edit menu item', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 38, 87, 0, 0, 0, 0, 0, 0),
('navigation', 88, 38, 'admin/build/menu/item/%/reset', 'admin/build/menu/item/%/reset', 'Reset menu item', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 38, 88, 0, 0, 0, 0, 0, 0),
('navigation', 89, 38, 'admin/build/menu-customize/navigation', 'admin/build/menu-customize/%', 'Navigation', 'a:0:{}', 'menu', 0, 0, 0, 0, 0, 4, 0, 2, 17, 38, 89, 0, 0, 0, 0, 0, 0),
('navigation', 90, 38, 'admin/build/menu-customize/primary-links', 'admin/build/menu-customize/%', 'Primary links', 'a:0:{}', 'menu', 0, 0, 0, 0, 0, 4, 0, 2, 17, 38, 90, 0, 0, 0, 0, 0, 0),
('navigation', 91, 38, 'admin/build/menu-customize/secondary-links', 'admin/build/menu-customize/%', 'Secondary links', 'a:0:{}', 'menu', 0, 0, 0, 0, 0, 4, 0, 2, 17, 38, 91, 0, 0, 0, 0, 0, 0),
('navigation', 92, 0, 'taxonomy/autocomplete', 'taxonomy/autocomplete', 'Autocomplete taxonomy', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 92, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 93, 16, 'admin/reports/dblog', 'admin/reports/dblog', 'Recent log entries', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:43:"View events that have recently been logged.";}}', 'system', 0, 0, 0, 0, -1, 3, 0, 2, 16, 93, 0, 0, 0, 0, 0, 0, 0),
('navigation', 94, 10, 'admin/content/taxonomy', 'admin/content/taxonomy', 'Taxonomy', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:67:"Manage tagging, categorization, and classification of your content.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 10, 94, 0, 0, 0, 0, 0, 0, 0),
('navigation', 95, 0, 'taxonomy/term/%', 'taxonomy/term/%', 'Taxonomy term', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 95, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 96, 16, 'admin/reports/access-denied', 'admin/reports/access-denied', 'Top ''access denied'' errors', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:35:"View ''access denied'' errors (403s).";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 16, 96, 0, 0, 0, 0, 0, 0, 0),
('navigation', 97, 16, 'admin/reports/page-not-found', 'admin/reports/page-not-found', 'Top ''page not found'' errors', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:36:"View ''page not found'' errors (404s).";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 16, 97, 0, 0, 0, 0, 0, 0, 0),
('navigation', 98, 15, 'admin/help/dblog', 'admin/help/dblog', 'dblog', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 98, 0, 0, 0, 0, 0, 0, 0),
('navigation', 99, 15, 'admin/help/taxonomy', 'admin/help/taxonomy', 'taxonomy', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 99, 0, 0, 0, 0, 0, 0, 0),
('navigation', 100, 37, 'admin/settings/logging/dblog', 'admin/settings/logging/dblog', 'Database logging', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:169:"Settings for logging to the Drupal database logs. This is the most common method for small to medium sites on shared hosting. The logs are viewable from the admin pages.";}}', 'system', 0, 0, 0, 0, 0, 4, 0, 2, 18, 37, 100, 0, 0, 0, 0, 0, 0),
('navigation', 101, 16, 'admin/reports/event/%', 'admin/reports/event/%', 'Details', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 16, 101, 0, 0, 0, 0, 0, 0, 0),
('navigation', 102, 94, 'admin/content/taxonomy/%', 'admin/content/taxonomy/%', 'List terms', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 10, 94, 102, 0, 0, 0, 0, 0, 0),
('navigation', 103, 94, 'admin/content/taxonomy/edit/term', 'admin/content/taxonomy/edit/term', 'Edit term', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 10, 94, 103, 0, 0, 0, 0, 0, 0),
('navigation', 104, 94, 'admin/content/taxonomy/edit/vocabulary/%', 'admin/content/taxonomy/edit/vocabulary/%', 'Edit vocabulary', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 10, 94, 104, 0, 0, 0, 0, 0, 0),
('navigation', 105, 16, 'admin/reports/updates', 'admin/reports/updates', 'Available updates', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:82:"Get a status report about available updates for your installed modules and themes.";}}', 'system', 0, 0, 0, 0, 10, 3, 0, 2, 16, 105, 0, 0, 0, 0, 0, 0, 0),
('navigation', 106, 11, 'node/add/page', 'node/add/page', 'Page', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:296:"A <em>page</em>, similar in form to a <em>story</em>, is a simple method for creating and displaying information that rarely changes, such as an "About us" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site''s initial home page.";}}', 'system', 0, 0, 0, 0, 0, 2, 0, 11, 106, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 107, 11, 'node/add/story', 'node/add/story', 'Story', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:392:"A <em>story</em>, similar in form to a <em>page</em>, is ideal for creating and displaying content that informs or engages website visitors. Press releases, site announcements, and informal blog-like entries may all be created with a <em>story</em> entry. By default, a <em>story</em> entry is automatically featured on the site''s initial home page, and provides the ability to post comments.";}}', 'system', 0, 0, 0, 0, 0, 2, 0, 11, 107, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 108, 15, 'admin/help/update', 'admin/help/update', 'update', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 108, 0, 0, 0, 0, 0, 0, 0),
('navigation', 109, 105, 'admin/reports/updates/check', 'admin/reports/updates/check', 'Manual update check', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 16, 105, 109, 0, 0, 0, 0, 0, 0),
('navigation', 110, 10, 'admin/content/node-type/page', 'admin/content/node-type/page', 'Page', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 10, 110, 0, 0, 0, 0, 0, 0, 0),
('navigation', 111, 10, 'admin/content/node-type/story', 'admin/content/node-type/story', 'Story', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 10, 111, 0, 0, 0, 0, 0, 0, 0),
('navigation', 112, 0, 'admin/content/node-type/page/delete', 'admin/content/node-type/page/delete', 'Delete', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 112, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 113, 0, 'admin/content/node-type/story/delete', 'admin/content/node-type/story/delete', 'Delete', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 113, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 114, 0, 'admin_menu/toggle-modules', 'admin_menu/toggle-modules', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 114, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 115, 0, 'admin_menu/flush-cache', 'admin_menu/flush-cache', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 115, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 116, 18, 'admin/settings/admin_menu', 'admin/settings/admin_menu', 'Administration menu', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:36:"Adjust administration menu settings.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 116, 0, 0, 0, 0, 0, 0, 0),
('navigation', 117, 15, 'admin/help/admin_menu', 'admin/help/admin_menu', 'admin_menu', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 117, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 118, 0, '<front>', '', '<img class="admin-menu-icon" src="/goodmilk/misc/favicon.ico" width="16" height="16" alt="Home" />', 'a:3:{s:11:"extra class";s:15:"admin-menu-icon";s:4:"html";b:1;s:5:"alter";b:1;}', 'admin_menu', 0, 1, 1, 0, -100, 1, 0, 118, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 119, 0, 'logout', 'logout', 'Log out @username', 'a:3:{s:11:"extra class";s:35:"admin-menu-action admin-menu-logout";s:1:"t";a:0:{}s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, -100, 1, 0, 119, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 120, 0, 'user', 'user', 'icon_users', 'a:3:{s:11:"extra class";s:50:"admin-menu-action admin-menu-icon admin-menu-users";s:4:"html";b:1;s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -90, 1, 0, 120, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 121, 0, 'admin/content', 'admin/content', 'Content management', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, -10, 1, 0, 121, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 122, 0, 'admin/help', 'admin/help', 'Help', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 9, 1, 0, 122, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 123, 0, 'admin/reports', 'admin/reports', 'Reports', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 5, 1, 0, 123, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 124, 0, 'admin/build', 'admin/build', 'Site building', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, -10, 1, 0, 124, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 125, 0, 'admin/settings', 'admin/settings', 'Site configuration', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, -5, 1, 0, 125, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 126, 0, 'admin/user', 'admin/user', 'User management', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 1, 0, 126, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 127, 126, 'admin/user/rules', 'admin/user/rules', 'Access rules', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 126, 127, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 128, 125, 'admin/settings/actions', 'admin/settings/actions', 'Actions', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 125, 128, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 129, 125, 'admin/settings/admin_menu', 'admin/settings/admin_menu', 'Administration menu', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 125, 129, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 130, 125, 'admin/settings/admin', 'admin/settings/admin', 'Administration theme', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 125, 130, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 131, 123, 'admin/reports/updates', 'admin/reports/updates', 'Available updates', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 10, 2, 0, 123, 131, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 132, 124, 'admin/build/block', 'admin/build/block', 'Blocks', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 124, 132, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 133, 125, 'admin/settings/clean-urls', 'admin/settings/clean-urls', 'Clean URLs', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 125, 133, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 134, 121, 'admin/content/comment', 'admin/content/comment', 'Comments', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 121, 134, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 135, 121, 'admin/content/node', 'admin/content/node', 'Content', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 121, 135, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 136, 121, 'admin/content/types', 'admin/content/types', 'Content types', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 121, 136, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 137, 125, 'admin/settings/date-time', 'admin/settings/date-time', 'Date and time', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 125, 137, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 138, 125, 'admin/settings/error-reporting', 'admin/settings/error-reporting', 'Error reporting', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 125, 138, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 139, 125, 'admin/settings/file-system', 'admin/settings/file-system', 'File system', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 125, 139, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 140, 125, 'admin/settings/image-toolkit', 'admin/settings/image-toolkit', 'Image toolkit', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 125, 140, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 141, 125, 'admin/settings/filters', 'admin/settings/filters', 'Input formats', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 125, 141, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 142, 125, 'admin/settings/logging', 'admin/settings/logging', 'Logging and alerts', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 125, 142, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 143, 124, 'admin/build/menu', 'admin/build/menu', 'Menus', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 124, 143, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 144, 124, 'admin/build/modules', 'admin/build/modules', 'Modules', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 124, 144, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 145, 125, 'admin/settings/performance', 'admin/settings/performance', 'Performance', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 125, 145, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 146, 126, 'admin/user/permissions', 'admin/user/permissions', 'Permissions', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 126, 146, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 147, 121, 'admin/content/node-settings', 'admin/content/node-settings', 'Post settings', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 121, 147, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 148, 121, 'admin/content/rss-publishing', 'admin/content/rss-publishing', 'RSS publishing', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 121, 148, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 149, 123, 'admin/reports/dblog', 'admin/reports/dblog', 'Recent log entries', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -1, 2, 0, 123, 149, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 150, 126, 'admin/user/roles', 'admin/user/roles', 'Roles', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 126, 150, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 151, 125, 'admin/settings/site-information', 'admin/settings/site-information', 'Site information', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 125, 151, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 152, 125, 'admin/settings/site-maintenance', 'admin/settings/site-maintenance', 'Site maintenance', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 125, 152, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 153, 123, 'admin/reports/status', 'admin/reports/status', 'Status report', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 10, 2, 0, 123, 153, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 154, 121, 'admin/content/taxonomy', 'admin/content/taxonomy', 'Taxonomy', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 121, 154, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 155, 124, 'admin/build/themes', 'admin/build/themes', 'Themes', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 124, 155, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 156, 123, 'admin/reports/access-denied', 'admin/reports/access-denied', 'Top ''access denied'' errors', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 123, 156, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 157, 123, 'admin/reports/page-not-found', 'admin/reports/page-not-found', 'Top ''page not found'' errors', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 123, 157, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 158, 126, 'admin/user/settings', 'admin/user/settings', 'User settings', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 126, 158, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 159, 126, 'admin/user/user', 'admin/user/user', 'Users', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 126, 159, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 160, 132, 'admin/build/block/add', 'admin/build/block/add', 'Add block', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 124, 132, 160, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 161, 136, 'admin/content/types/add', 'admin/content/types/add', 'Add content type', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 121, 136, 161, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 162, 141, 'admin/settings/filters/add', 'admin/settings/filters/add', 'Add input format', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 3, 0, 125, 141, 162, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 163, 143, 'admin/build/menu/add', 'admin/build/menu/add', 'Add menu', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 124, 143, 163, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 164, 127, 'admin/user/rules/add', 'admin/user/rules/add', 'Add rule', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 126, 127, 164, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 165, 159, 'admin/user/user/create', 'admin/user/user/create', 'Add user', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 126, 159, 165, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 166, 134, 'admin/content/comment/approval', 'admin/content/comment/approval', 'Approval queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 121, 134, 166, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 167, 127, 'admin/user/rules/check', 'admin/user/rules/check', 'Check rules', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 126, 127, 167, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 168, 155, 'admin/build/themes/settings', 'admin/build/themes/settings', 'Configure', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 3, 0, 124, 155, 168, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 169, 142, 'admin/settings/logging/dblog', 'admin/settings/logging/dblog', 'Database logging', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 125, 142, 169, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 170, 132, 'admin/build/block/list', 'admin/build/block/list', 'List', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, -10, 3, 0, 124, 132, 170, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 171, 135, 'admin/content/node/overview', 'admin/content/node/overview', 'List', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -10, 3, 0, 121, 135, 171, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 172, 154, 'admin/content/taxonomy/list', 'admin/content/taxonomy/list', 'List', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -10, 3, 0, 121, 154, 172, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 173, 136, 'admin/content/types/list', 'admin/content/types/list', 'List', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -10, 3, 0, 121, 136, 173, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 174, 127, 'admin/user/rules/list', 'admin/user/rules/list', 'List', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -10, 3, 0, 126, 127, 174, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 175, 131, 'admin/reports/updates/list', 'admin/reports/updates/list', 'List', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 123, 131, 175, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 176, 159, 'admin/user/user/list', 'admin/user/user/list', 'List', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -10, 3, 0, 126, 159, 176, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 177, 144, 'admin/build/modules/list', 'admin/build/modules/list', 'List', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 124, 144, 177, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 178, 155, 'admin/build/themes/select', 'admin/build/themes/select', 'List', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -1, 3, 0, 124, 155, 178, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 179, 141, 'admin/settings/filters/list', 'admin/settings/filters/list', 'List', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 125, 141, 179, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 180, 143, 'admin/build/menu/list', 'admin/build/menu/list', 'List menus', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -10, 3, 0, 124, 143, 180, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 181, 128, 'admin/settings/actions/manage', 'admin/settings/actions/manage', 'Manage actions', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -2, 3, 0, 125, 128, 181, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 182, 134, 'admin/content/comment/new', 'admin/content/comment/new', 'Published comments', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -10, 3, 0, 121, 134, 182, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 183, 143, 'admin/build/menu/settings', 'admin/build/menu/settings', 'Settings', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 5, 3, 0, 124, 143, 183, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 184, 131, 'admin/reports/updates/settings', 'admin/reports/updates/settings', 'Settings', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 123, 131, 184, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 185, 144, 'admin/build/modules/uninstall', 'admin/build/modules/uninstall', 'Uninstall', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 124, 144, 185, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 186, 170, 'admin/build/block/list/bluemarine', 'admin/build/block/list/bluemarine', 'Bluemarine', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 132, 170, 186, 0, 0, 0, 0, 0, 0),
('admin_menu', 187, 168, 'admin/build/themes/settings/bluemarine', 'admin/build/themes/settings/bluemarine', 'Bluemarine', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 155, 168, 187, 0, 0, 0, 0, 0, 0),
('admin_menu', 188, 170, 'admin/build/block/list/chameleon', 'admin/build/block/list/chameleon', 'Chameleon', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 132, 170, 188, 0, 0, 0, 0, 0, 0),
('admin_menu', 189, 168, 'admin/build/themes/settings/chameleon', 'admin/build/themes/settings/chameleon', 'Chameleon', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 155, 168, 189, 0, 0, 0, 0, 0, 0),
('admin_menu', 190, 170, 'admin/build/block/list/garland', 'admin/build/block/list/garland', 'Garland', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 132, 170, 190, 0, 0, 0, 0, 0, 0),
('admin_menu', 191, 168, 'admin/build/themes/settings/garland', 'admin/build/themes/settings/garland', 'Garland', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 155, 168, 191, 0, 0, 0, 0, 0, 0),
('admin_menu', 192, 168, 'admin/build/themes/settings/global', 'admin/build/themes/settings/global', 'Global settings', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -1, 4, 0, 124, 155, 168, 192, 0, 0, 0, 0, 0, 0),
('admin_menu', 193, 170, 'admin/build/block/list/marvin', 'admin/build/block/list/marvin', 'Marvin', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 132, 170, 193, 0, 0, 0, 0, 0, 0),
('admin_menu', 194, 168, 'admin/build/themes/settings/marvin', 'admin/build/themes/settings/marvin', 'Marvin', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 155, 168, 194, 0, 0, 0, 0, 0, 0),
('admin_menu', 195, 170, 'admin/build/block/list/minnelli', 'admin/build/block/list/minnelli', 'Minnelli', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 132, 170, 195, 0, 0, 0, 0, 0, 0),
('admin_menu', 196, 168, 'admin/build/themes/settings/minnelli', 'admin/build/themes/settings/minnelli', 'Minnelli', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 155, 168, 196, 0, 0, 0, 0, 0, 0),
('admin_menu', 197, 170, 'admin/build/block/list/pushbutton', 'admin/build/block/list/pushbutton', 'Pushbutton', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 132, 170, 197, 0, 0, 0, 0, 0, 0),
('admin_menu', 198, 168, 'admin/build/themes/settings/pushbutton', 'admin/build/themes/settings/pushbutton', 'Pushbutton', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 155, 168, 198, 0, 0, 0, 0, 0, 0),
('admin_menu', 199, 170, 'admin/build/block/list/visikard', 'admin/build/block/list/visikard', 'Visi Kard', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 132, 170, 199, 0, 0, 0, 0, 0, 0),
('admin_menu', 200, 168, 'admin/build/themes/settings/visikard', 'admin/build/themes/settings/visikard', 'Visi Kard', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 155, 168, 200, 0, 0, 0, 0, 0, 0),
('admin_menu', 201, 170, 'admin/build/block/list/zen', 'admin/build/block/list/zen', 'Zen', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 132, 170, 201, 0, 0, 0, 0, 0, 0),
('admin_menu', 202, 168, 'admin/build/themes/settings/zen', 'admin/build/themes/settings/zen', 'Zen', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 155, 168, 202, 0, 0, 0, 0, 0, 0),
('admin_menu', 432, 168, 'admin/build/themes/settings/bootstrap', 'admin/build/themes/settings/bootstrap', 'Bootstrap', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 155, 168, 432, 0, 0, 0, 0, 0, 0),
('admin_menu', 205, 154, 'admin/content/taxonomy/add/vocabulary', 'admin/content/taxonomy/add/vocabulary', 'Add vocabulary', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 121, 154, 205, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 206, 118, 'admin/reports/status/run-cron', 'admin/reports/status/run-cron', 'Run cron', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 50, 2, 0, 118, 206, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 208, 125, 'admin/by-module', 'admin/by-module', 'By module', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -10, 2, 0, 125, 208, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 209, 118, 'http://drupal.org', '', 'Drupal.org', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 1, 0, 100, 2, 0, 118, 209, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 210, 209, 'http://drupal.org/project/issues/drupal', '', 'Drupal issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, -10, 3, 0, 118, 209, 210, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 211, 209, 'http://drupal.org/project/issues/admin_menu', '', 'Administration menu issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 211, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 212, 121, 'node/add', 'node/add', 'Create content', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 121, 212, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 213, 212, 'node/add/page', 'node/add/page', 'Page', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 121, 212, 213, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 214, 212, 'node/add/story', 'node/add/story', 'Story', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 121, 212, 214, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 215, 136, 'admin/content/node-type/page', 'admin/content/node-type/page', 'Edit !content-type', 'a:2:{s:1:"t";a:1:{s:13:"!content-type";s:4:"Page";}s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 3, 0, 121, 136, 215, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 216, 136, 'admin/content/node-type/story', 'admin/content/node-type/story', 'Edit !content-type', 'a:2:{s:1:"t";a:1:{s:13:"!content-type";s:5:"Story";}s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 3, 0, 121, 136, 216, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 217, 118, 'admin_menu/flush-cache', 'admin_menu/flush-cache', 'Flush all caches', 'a:2:{s:5:"alter";b:1;s:5:"query";s:11:"destination";}', 'admin_menu', 0, 0, 1, 0, 20, 2, 0, 118, 217, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 218, 217, 'admin_menu/flush-cache/admin_menu', 'admin_menu/flush-cache', 'Administration menu', 'a:2:{s:5:"alter";b:1;s:5:"query";s:11:"destination";}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 118, 217, 218, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 219, 217, 'admin_menu/flush-cache/cache', 'admin_menu/flush-cache', 'Cache tables', 'a:2:{s:5:"alter";b:1;s:5:"query";s:11:"destination";}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 118, 217, 219, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 220, 217, 'admin_menu/flush-cache/menu', 'admin_menu/flush-cache', 'Menu', 'a:2:{s:5:"alter";b:1;s:5:"query";s:11:"destination";}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 118, 217, 220, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 221, 217, 'admin_menu/flush-cache/requisites', 'admin_menu/flush-cache', 'Page requisites', 'a:2:{s:5:"alter";b:1;s:5:"query";s:11:"destination";}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 118, 217, 221, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 222, 217, 'admin_menu/flush-cache/theme', 'admin_menu/flush-cache', 'Theme registry', 'a:2:{s:5:"alter";b:1;s:5:"query";s:11:"destination";}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 118, 217, 222, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 223, 118, 'admin_menu/toggle-modules', 'admin_menu/toggle-modules', 'Disable developer modules', 'a:2:{s:5:"query";s:11:"destination";s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 88, 2, 0, 118, 223, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 236, 136, 'admin/content/types/export', 'admin/content/types/export', 'Export', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 3, 3, 0, 121, 136, 236, 0, 0, 0, 0, 0, 0, 0),
('primary-links', 225, 0, 'home', 'home', 'Trang Chu', 'a:2:{s:10:"attributes";a:1:{s:5:"title";s:0:"";}s:5:"alter";b:1;}', 'menu', 0, 0, 0, 0, -50, 1, 1, 225, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 226, 0, 'content/js_add_more', 'content/js_add_more', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 226, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 227, 0, 'filefield/progress', 'filefield/progress', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 227, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 228, 0, 'nodereference/autocomplete', 'nodereference/autocomplete', 'Nodereference autocomplete', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 228, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 229, 0, 'userreference/autocomplete', 'userreference/autocomplete', 'Userreference autocomplete', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 229, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 230, 15, 'admin/help/content', 'admin/help/content', 'content', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 230, 0, 0, 0, 0, 0, 0, 0),
('navigation', 231, 0, 'filefield/ahah/%/%/%', 'filefield/ahah/%/%/%', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 231, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 232, 0, 'admin/content/node-type/page/groups/%', 'admin/content/node-type/page/groups/%', 'Edit group', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 232, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 233, 0, 'admin/content/node-type/story/groups/%', 'admin/content/node-type/story/groups/%', 'Edit group', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 233, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 234, 0, 'admin/content/node-type/page/groups/%/remove', 'admin/content/node-type/page/groups/%/remove', 'Edit group', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 234, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 235, 0, 'admin/content/node-type/story/groups/%/remove', 'admin/content/node-type/story/groups/%/remove', 'Edit group', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 235, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 237, 136, 'admin/content/types/fields', 'admin/content/types/fields', 'Fields', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 121, 136, 237, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 238, 136, 'admin/content/types/import', 'admin/content/types/import', 'Import', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 4, 3, 0, 121, 136, 238, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 274, 125, 'admin/settings/imageapi', 'admin/settings/imageapi', 'ImageAPI', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 125, 274, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 240, 209, 'http://drupal.org/project/issues/cck', '', 'Content issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 240, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 241, 209, 'http://drupal.org/project/issues/filefield', '', 'FileField issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 241, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 242, 209, 'http://drupal.org/project/issues/imagefield', '', 'ImageField issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 242, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 243, 215, 'admin/content/node-type/page/display', 'admin/content/node-type/page/display', 'Display fields', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 2, 4, 0, 121, 136, 215, 243, 0, 0, 0, 0, 0, 0),
('admin_menu', 244, 243, 'admin/content/node-type/page/display/basic', 'admin/content/node-type/page/display/basic', 'Basic', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 215, 243, 244, 0, 0, 0, 0, 0),
('admin_menu', 245, 243, 'admin/content/node-type/page/display/rss', 'admin/content/node-type/page/display/rss', 'RSS', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 215, 243, 245, 0, 0, 0, 0, 0),
('admin_menu', 246, 215, 'admin/content/node-type/page/fields', 'admin/content/node-type/page/fields', 'Manage fields', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 4, 0, 121, 136, 215, 246, 0, 0, 0, 0, 0, 0),
('admin_menu', 247, 216, 'admin/content/node-type/story/display', 'admin/content/node-type/story/display', 'Display fields', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 2, 4, 0, 121, 136, 216, 247, 0, 0, 0, 0, 0, 0),
('admin_menu', 248, 247, 'admin/content/node-type/story/display/basic', 'admin/content/node-type/story/display/basic', 'Basic', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 216, 247, 248, 0, 0, 0, 0, 0),
('admin_menu', 249, 247, 'admin/content/node-type/story/display/rss', 'admin/content/node-type/story/display/rss', 'RSS', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 216, 247, 249, 0, 0, 0, 0, 0);
INSERT INTO `menu_links` (`menu_name`, `mlid`, `plid`, `link_path`, `router_path`, `link_title`, `options`, `module`, `hidden`, `external`, `has_children`, `expanded`, `weight`, `depth`, `customized`, `p1`, `p2`, `p3`, `p4`, `p5`, `p6`, `p7`, `p8`, `p9`, `updated`) VALUES
('admin_menu', 250, 216, 'admin/content/node-type/story/fields', 'admin/content/node-type/story/fields', 'Manage fields', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 4, 0, 121, 136, 216, 250, 0, 0, 0, 0, 0, 0),
('navigation', 251, 0, 'views/ajax', 'views/ajax', 'Views', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:31:"Ajax callback for view loading.";}}', 'system', -1, 0, 0, 0, 0, 1, 0, 251, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 252, 0, 'system/files/imagecache', 'system/files/imagecache', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 252, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 253, 18, 'admin/settings/imageapi', 'admin/settings/imageapi', 'ImageAPI', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:19:"Configure ImageAPI.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 253, 0, 0, 0, 0, 0, 0, 0),
('navigation', 254, 15, 'admin/help/views_ui', 'admin/help/views_ui', 'views_ui', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 254, 0, 0, 0, 0, 0, 0, 0),
('navigation', 255, 15, 'admin/help/viewsphpfilter', 'admin/help/viewsphpfilter', 'viewsphpfilter', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 255, 0, 0, 0, 0, 0, 0, 0),
('navigation', 256, 17, 'admin/build/views', 'admin/build/views', 'Views', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:144:"Views are customized lists of content on your system; they are highly configurable and give you control over how lists of content are presented.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 17, 256, 0, 0, 0, 0, 0, 0, 0),
('navigation', 257, 0, 'sites/default/files/imagecache', 'sites/default/files/imagecache', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 257, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 258, 17, 'admin/build/views1/convert', 'admin/build/views1/convert', 'Convert view', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 17, 258, 0, 0, 0, 0, 0, 0, 0),
('navigation', 259, 17, 'admin/build/views1/delete', 'admin/build/views1/delete', 'Delete view', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 17, 259, 0, 0, 0, 0, 0, 0, 0),
('navigation', 260, 256, 'admin/build/views/export/%', 'admin/build/views/export/%', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 256, 260, 0, 0, 0, 0, 0, 0),
('navigation', 261, 2, 'admin/views/ajax/autocomplete/user', 'admin/views/ajax/autocomplete/user', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 2, 0, 2, 261, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 262, 2, 'admin/views/ajax/autocomplete/tag', 'admin/views/ajax/autocomplete/tag', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 2, 0, 2, 262, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 263, 256, 'admin/build/views/clone/%', 'admin/build/views/clone/%', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 256, 263, 0, 0, 0, 0, 0, 0),
('navigation', 264, 256, 'admin/build/views/disable/%', 'admin/build/views/disable/%', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 256, 264, 0, 0, 0, 0, 0, 0),
('navigation', 265, 256, 'admin/build/views/enable/%', 'admin/build/views/enable/%', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 256, 265, 0, 0, 0, 0, 0, 0),
('navigation', 266, 256, 'admin/build/views/break-lock/%', 'admin/build/views/break-lock/%', 'Delete view', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 256, 266, 0, 0, 0, 0, 0, 0),
('navigation', 267, 256, 'admin/build/views/delete/%', 'admin/build/views/delete/%', 'Delete view', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 256, 267, 0, 0, 0, 0, 0, 0),
('navigation', 268, 256, 'admin/build/views/tools/export/results', 'admin/build/views/tools/export/results', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 256, 268, 0, 0, 0, 0, 0, 0),
('navigation', 269, 256, 'admin/build/views/%/add-display/%', 'admin/build/views/%/add-display/%', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 256, 269, 0, 0, 0, 0, 0, 0),
('navigation', 270, 256, 'admin/build/views/%/%/%', 'admin/build/views/%/%/%', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 256, 270, 0, 0, 0, 0, 0, 0),
('navigation', 271, 256, 'admin/build/views/%/analyze/%', 'admin/build/views/%/analyze/%', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 256, 271, 0, 0, 0, 0, 0, 0),
('navigation', 272, 256, 'admin/build/views/%/details/%', 'admin/build/views/%/details/%', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 256, 272, 0, 0, 0, 0, 0, 0),
('navigation', 273, 256, 'admin/build/views/%/preview/%', 'admin/build/views/%/preview/%', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 256, 273, 0, 0, 0, 0, 0, 0),
('admin_menu', 275, 124, 'admin/build/views', 'admin/build/views', 'Views', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 124, 275, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 276, 275, 'admin/build/views/import', 'admin/build/views/import', 'Import', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 124, 275, 276, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 277, 275, 'admin/build/views/add', 'admin/build/views/add', 'Add', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 124, 275, 277, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 278, 275, 'admin/build/views/list', 'admin/build/views/list', 'List', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -1, 3, 0, 124, 275, 278, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 279, 275, 'admin/build/views/tools', 'admin/build/views/tools', 'Tools', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 3, 0, 124, 275, 279, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 280, 279, 'admin/build/views/tools/export', 'admin/build/views/tools/export', 'Bulk export', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 124, 275, 279, 280, 0, 0, 0, 0, 0, 0),
('admin_menu', 281, 279, 'admin/build/views/tools/convert', 'admin/build/views/tools/convert', 'Convert', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 4, 0, 124, 275, 279, 281, 0, 0, 0, 0, 0, 0),
('admin_menu', 282, 279, 'admin/build/views/tools/basic', 'admin/build/views/tools/basic', 'Basic', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -10, 4, 0, 124, 275, 279, 282, 0, 0, 0, 0, 0, 0),
('admin_menu', 366, 123, 'admin/reports/settings', 'admin/reports/settings', 'Access log settings', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 3, 2, 0, 123, 366, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 284, 209, 'http://drupal.org/project/issues/imageapi', '', 'ImageAPI issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 284, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 285, 209, 'http://drupal.org/project/issues/imagecache', '', 'ImageCache issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 285, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 286, 209, 'http://drupal.org/project/issues/views', '', 'Views issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 286, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 287, 209, 'http://drupal.org/project/issues/views_customfield', '', 'Views Custom Field issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 287, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 288, 209, 'http://drupal.org/project/issues/views_galleriffic', '', 'Views Galleriffic issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 288, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 289, 209, 'http://drupal.org/project/issues/viewsphpfilter', '', 'Views PHP Filter issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 289, 0, 0, 0, 0, 0, 0, 0),
('devel', 290, 0, 'admin/reports/status/run-cron', 'admin/reports/status/run-cron', 'Run cron', 'a:0:{}', 'devel', 0, 0, 0, 0, 0, 1, 0, 290, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('devel', 291, 0, 'admin/settings/devel', 'admin/settings', 'Devel settings', 'a:0:{}', 'devel', 0, 0, 0, 0, 0, 1, 0, 291, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 292, 0, 'contact', 'contact', 'Contact', 'a:0:{}', 'system', 1, 0, 0, 0, 0, 1, 0, 292, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 293, 0, 'imce', 'imce', 'File browser', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 293, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 294, 0, 'search', 'search', 'Search', 'a:0:{}', 'system', 1, 0, 0, 0, 0, 1, 0, 294, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 295, 292, 'contact/lightbox2', 'contact/lightbox2', 'Contact', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 2, 0, 292, 295, 0, 0, 0, 0, 0, 0, 0, 0),
('devel', 296, 0, 'devel/queries', 'devel/queries', 'Database queries', 'a:0:{}', 'system', 0, 0, 1, 0, 0, 1, 0, 296, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('devel', 297, 0, 'devel/php', 'devel/php', 'Execute PHP Code', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:21:"Execute some PHP code";}}', 'system', 0, 0, 0, 0, 0, 1, 0, 297, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('devel', 298, 0, 'devel/reference', 'devel/reference', 'Function reference', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:73:"View a list of currently defined user functions with documentation links.";}}', 'system', 0, 0, 0, 0, 0, 1, 0, 298, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 299, 0, 'wysiwyg/%', 'wysiwyg/%', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 299, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('devel', 300, 0, 'devel/elements', 'devel/elements', 'Hook_elements()', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:51:"View the active form/render elements for this site.";}}', 'system', 0, 0, 0, 0, 0, 1, 0, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('devel', 301, 0, 'devel/phpinfo', 'devel/phpinfo', 'PHPinfo()', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:36:"View your server''s PHP configuration";}}', 'system', 0, 0, 0, 0, 0, 1, 0, 301, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('devel', 302, 0, 'devel/reinstall', 'devel/reinstall', 'Reinstall modules', 'a:2:{s:10:"attributes";a:1:{s:5:"title";s:64:"Run hook_uninstall() and then hook_install() for a given module.";}s:5:"alter";b:1;}', 'system', 0, 0, 0, 0, 0, 1, 0, 302, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('devel', 303, 0, 'devel/session', 'devel/session', 'Session viewer', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:31:"List the contents of $_SESSION.";}}', 'system', 0, 0, 0, 0, 0, 1, 0, 303, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('devel', 304, 0, 'devel/switch', 'devel/switch', 'Switch user', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 304, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 305, 0, 'user/timezone', 'user/timezone', 'User timezone', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 305, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('devel', 306, 0, 'devel/variable', 'devel/variable', 'Variable editor', 'a:2:{s:10:"attributes";a:1:{s:5:"title";s:31:"Edit and delete site variables.";}s:5:"alter";b:1;}', 'system', 0, 0, 0, 0, 0, 1, 0, 306, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 307, 16, 'admin/reports/settings', 'admin/reports/settings', 'Access log settings', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:50:"Control details about what and how your site logs.";}}', 'system', 0, 0, 0, 0, 3, 3, 0, 2, 16, 307, 0, 0, 0, 0, 0, 0, 0),
('navigation', 308, 17, 'admin/build/contact', 'admin/build/contact', 'Contact form', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:71:"Create a system contact form and set up categories for the form to use.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 17, 308, 0, 0, 0, 0, 0, 0, 0),
('navigation', 309, 18, 'admin/settings/devel', 'admin/settings/devel', 'Devel settings', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:164:"Helper functions, pages, and blocks to assist Drupal developers. The devel blocks can be managed via the <a href="/admin/build/block">block administration</a> page.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 309, 0, 0, 0, 0, 0, 0, 0),
('devel', 310, 0, 'devel/cache/clear', 'devel/cache/clear', 'Empty cache', 'a:2:{s:10:"attributes";a:1:{s:5:"title";s:100:"Clear the CSS cache and all database cache tables which store page, node, theme and variable caches.";}s:5:"alter";b:1;}', 'system', 0, 0, 0, 0, 0, 1, 0, 310, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('devel', 311, 296, 'devel/queries/empty', 'devel/queries/empty', 'Empty database queries', 'a:0:{}', 'system', 0, 0, 0, 0, 0, 2, 0, 296, 311, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 312, 0, 'system/lightbox2/filter-xss', 'system/lightbox2/filter-xss', 'Filter XSS', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 312, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 313, 18, 'admin/settings/googleanalytics', 'admin/settings/googleanalytics', 'Google Analytics', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:76:"Configure the settings used to generate your Google Analytics tracking code.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 313, 0, 0, 0, 0, 0, 0, 0),
('navigation', 314, 18, 'admin/settings/imce', 'admin/settings/imce', 'IMCE', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:42:"Control how your image/file browser works.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 314, 0, 0, 0, 0, 0, 0, 0),
('navigation', 315, 18, 'admin/settings/language', 'admin/settings/language', 'Languages', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:55:"Configure languages for content and the user interface.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 315, 0, 0, 0, 0, 0, 0, 0),
('navigation', 316, 18, 'admin/settings/lightbox2', 'admin/settings/lightbox2', 'Lightbox2', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:51:"Allows the user to configure the lightbox2 settings";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 316, 0, 0, 0, 0, 0, 0, 0),
('navigation', 317, 0, 'user/login/lightbox2', 'user/login/lightbox2', 'Login', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 317, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 318, 18, 'admin/settings/nice_menus', 'admin/settings/nice_menus', 'Nice menus', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:21:"Configure Nice menus.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 318, 0, 0, 0, 0, 0, 0, 0),
('devel', 319, 0, 'devel/menu/reset', 'devel/menu/reset', 'Rebuild menus', 'a:2:{s:10:"attributes";a:1:{s:5:"title";s:113:"Rebuild menu based on hook_menu() and revert any custom changes. All menu items return to their default settings.";}s:5:"alter";b:1;}', 'system', 0, 0, 0, 0, 0, 1, 0, 319, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 320, 16, 'admin/reports/hits', 'admin/reports/hits', 'Recent hits', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:43:"View pages that have recently been visited.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 16, 320, 0, 0, 0, 0, 0, 0, 0),
('navigation', 321, 18, 'admin/settings/search', 'admin/settings/search', 'Search settings', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:66:"Configure relevance settings for search and other indexing options";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 321, 0, 0, 0, 0, 0, 0, 0),
('devel', 322, 0, 'devel/theme/registry', 'devel/theme/registry', 'Theme registry', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:63:"View a list of available theme functions across the whole site.";}}', 'system', 0, 0, 0, 0, 0, 1, 0, 322, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 323, 16, 'admin/reports/pages', 'admin/reports/pages', 'Top pages', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:41:"View pages that have been hit frequently.";}}', 'system', 0, 0, 0, 0, 1, 3, 0, 2, 16, 323, 0, 0, 0, 0, 0, 0, 0),
('navigation', 324, 16, 'admin/reports/referrers', 'admin/reports/referrers', 'Top referrers', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:19:"View top referrers.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 16, 324, 0, 0, 0, 0, 0, 0, 0),
('navigation', 325, 16, 'admin/reports/search', 'admin/reports/search', 'Top search phrases', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:33:"View most popular search phrases.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 16, 325, 0, 0, 0, 0, 0, 0, 0),
('navigation', 326, 16, 'admin/reports/visitors', 'admin/reports/visitors', 'Top visitors', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:34:"View visitors that hit many pages.";}}', 'system', 0, 0, 0, 0, 2, 3, 0, 2, 16, 326, 0, 0, 0, 0, 0, 0, 0),
('navigation', 327, 17, 'admin/build/translate', 'admin/build/translate', 'Translate interface', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:59:"Translate the built in interface and optionally other text.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 17, 327, 0, 0, 0, 0, 0, 0, 0),
('navigation', 328, 17, 'admin/build/path', 'admin/build/path', 'URL aliases', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:46:"Change your site''s URL paths by aliasing them.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 17, 328, 0, 0, 0, 0, 0, 0, 0),
('navigation', 329, 18, 'admin/settings/wysiwyg', 'admin/settings/wysiwyg', 'Wysiwyg profiles', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:30:"Configure client-side editors.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 18, 329, 0, 0, 0, 0, 0, 0, 0),
('navigation', 330, 15, 'admin/help/better_formats', 'admin/help/better_formats', 'better_formats', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 330, 0, 0, 0, 0, 0, 0, 0),
('navigation', 331, 15, 'admin/help/contact', 'admin/help/contact', 'contact', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 331, 0, 0, 0, 0, 0, 0, 0),
('navigation', 332, 15, 'admin/help/date', 'admin/help/date', 'date', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 332, 0, 0, 0, 0, 0, 0, 0),
('navigation', 333, 15, 'admin/help/devel', 'admin/help/devel', 'devel', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 333, 0, 0, 0, 0, 0, 0, 0),
('navigation', 334, 15, 'admin/help/googleanalytics', 'admin/help/googleanalytics', 'googleanalytics', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 334, 0, 0, 0, 0, 0, 0, 0),
('navigation', 335, 15, 'admin/help/lightbox2', 'admin/help/lightbox2', 'lightbox2', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 335, 0, 0, 0, 0, 0, 0, 0),
('navigation', 336, 15, 'admin/help/locale', 'admin/help/locale', 'locale', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 336, 0, 0, 0, 0, 0, 0, 0),
('navigation', 337, 15, 'admin/help/nice_menus', 'admin/help/nice_menus', 'nice_menus', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 337, 0, 0, 0, 0, 0, 0, 0),
('navigation', 338, 15, 'admin/help/path', 'admin/help/path', 'path', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 338, 0, 0, 0, 0, 0, 0, 0),
('navigation', 339, 15, 'admin/help/pathauto', 'admin/help/pathauto', 'pathauto', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 339, 0, 0, 0, 0, 0, 0, 0),
('navigation', 340, 15, 'admin/help/php', 'admin/help/php', 'php', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 340, 0, 0, 0, 0, 0, 0, 0),
('navigation', 341, 15, 'admin/help/search', 'admin/help/search', 'search', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 341, 0, 0, 0, 0, 0, 0, 0),
('navigation', 342, 15, 'admin/help/statistics', 'admin/help/statistics', 'statistics', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 342, 0, 0, 0, 0, 0, 0, 0),
('navigation', 343, 15, 'admin/help/syslog', 'admin/help/syslog', 'syslog', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 343, 0, 0, 0, 0, 0, 0, 0),
('navigation', 344, 15, 'admin/help/token', 'admin/help/token', 'token', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 344, 0, 0, 0, 0, 0, 0, 0),
('navigation', 345, 15, 'admin/help/translation', 'admin/help/translation', 'translation', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 345, 0, 0, 0, 0, 0, 0, 0),
('navigation', 346, 15, 'admin/help/wysiwyg', 'admin/help/wysiwyg', 'wysiwyg', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 346, 0, 0, 0, 0, 0, 0, 0),
('navigation', 347, 314, 'admin/settings/imce/profile', 'admin/settings/imce/profile', 'Add new profile', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 18, 314, 347, 0, 0, 0, 0, 0, 0),
('navigation', 348, 321, 'admin/settings/search/wipe', 'admin/settings/search/wipe', 'Clear index', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 18, 321, 348, 0, 0, 0, 0, 0, 0),
('navigation', 349, 328, 'admin/build/path/delete', 'admin/build/path/delete', 'Delete alias', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 328, 349, 0, 0, 0, 0, 0, 0),
('navigation', 350, 16, 'admin/reports/access/%', 'admin/reports/access/%', 'Details', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:16:"View access log.";}}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 16, 350, 0, 0, 0, 0, 0, 0, 0),
('navigation', 351, 328, 'admin/build/path/edit', 'admin/build/path/edit', 'Edit alias', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 328, 351, 0, 0, 0, 0, 0, 0),
('navigation', 352, 37, 'admin/settings/logging/syslog', 'admin/settings/logging/syslog', 'Syslog', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:262:"Settings for syslog logging. Syslog is an operating system administrative logging tool used in systems management and security auditing. Most suited to medium and large sites, syslog provides filtering tools that allow messages to be routed by type and severity.";}}', 'system', 0, 0, 0, 0, 0, 4, 0, 2, 18, 37, 352, 0, 0, 0, 0, 0, 0),
('devel', 353, 306, 'devel/variable/edit/%', 'devel/variable/edit/%', 'Variable editor', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 2, 0, 306, 353, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 354, 308, 'admin/build/contact/%/edit', 'admin/build/contact/%/edit', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 308, 354, 0, 0, 0, 0, 0, 0),
('navigation', 355, 308, 'admin/build/contact/add/%', 'admin/build/contact/add/%', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 308, 355, 0, 0, 0, 0, 0, 0),
('navigation', 356, 308, 'admin/build/contact/%/delete', 'admin/build/contact/%/delete', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 308, 356, 0, 0, 0, 0, 0, 0),
('navigation', 357, 315, 'admin/settings/language/delete/%', 'admin/settings/language/delete/%', 'Confirm', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 18, 315, 357, 0, 0, 0, 0, 0, 0),
('navigation', 358, 30, 'admin/settings/date-time/formats/lookup', 'admin/settings/date-time/formats/lookup', 'Date and time lookup', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 18, 30, 358, 0, 0, 0, 0, 0, 0),
('navigation', 359, 308, 'admin/build/contact/delete/%', 'admin/build/contact/delete/%', 'Delete contact', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 308, 359, 0, 0, 0, 0, 0, 0),
('navigation', 360, 30, 'admin/settings/date-time/delete/%', 'admin/settings/date-time/delete/%', 'Delete date format type', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:52:"Allow users to delete a configured date format type.";}}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 18, 30, 360, 0, 0, 0, 0, 0, 0),
('navigation', 361, 327, 'admin/build/translate/delete/%', 'admin/build/translate/delete/%', 'Delete string', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 327, 361, 0, 0, 0, 0, 0, 0),
('navigation', 362, 308, 'admin/build/contact/edit/%', 'admin/build/contact/edit/%', 'Edit contact category', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 308, 362, 0, 0, 0, 0, 0, 0),
('navigation', 363, 315, 'admin/settings/language/edit/%', 'admin/settings/language/edit/%', 'Edit language', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 18, 315, 363, 0, 0, 0, 0, 0, 0),
('navigation', 364, 327, 'admin/build/translate/edit/%', 'admin/build/translate/edit/%', 'Edit string', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 17, 327, 364, 0, 0, 0, 0, 0, 0),
('navigation', 365, 30, 'admin/settings/date-time/formats/delete/%', 'admin/settings/date-time/formats/delete/%', 'Delete date format', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:47:"Allow users to delete a configured date format.";}}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 18, 30, 365, 0, 0, 0, 0, 0, 0),
('admin_menu', 367, 124, 'admin/build/contact', 'admin/build/contact', 'Contact form', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 124, 367, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 368, 125, 'admin/settings/devel', 'admin/settings/devel', 'Devel settings', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 125, 368, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 369, 125, 'admin/settings/googleanalytics', 'admin/settings/googleanalytics', 'Google Analytics', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 125, 369, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 370, 125, 'admin/settings/imce', 'admin/settings/imce', 'IMCE', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 125, 370, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 371, 125, 'admin/settings/language', 'admin/settings/language', 'Languages', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 125, 371, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 372, 125, 'admin/settings/lightbox2', 'admin/settings/lightbox2', 'Lightbox2', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 125, 372, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 373, 125, 'admin/settings/nice_menus', 'admin/settings/nice_menus', 'Nice menus', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 125, 373, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 374, 123, 'admin/reports/hits', 'admin/reports/hits', 'Recent hits', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 123, 374, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 375, 125, 'admin/settings/search', 'admin/settings/search', 'Search settings', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 125, 375, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 376, 123, 'admin/reports/pages', 'admin/reports/pages', 'Top pages', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 2, 0, 123, 376, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 377, 123, 'admin/reports/referrers', 'admin/reports/referrers', 'Top referrers', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 123, 377, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 378, 123, 'admin/reports/search', 'admin/reports/search', 'Top search phrases', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 123, 378, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 379, 123, 'admin/reports/visitors', 'admin/reports/visitors', 'Top visitors', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 2, 2, 0, 123, 379, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 380, 124, 'admin/build/translate', 'admin/build/translate', 'Translate interface', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 124, 380, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 381, 124, 'admin/build/path', 'admin/build/path', 'URL aliases', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 124, 381, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 382, 125, 'admin/settings/wysiwyg', 'admin/settings/wysiwyg', 'Wysiwyg profiles', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 2, 0, 125, 382, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 383, 381, 'admin/build/path/add', 'admin/build/path/add', 'Add alias', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 124, 381, 383, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 384, 367, 'admin/build/contact/add', 'admin/build/contact/add', 'Add category', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 3, 0, 124, 367, 384, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 385, 371, 'admin/settings/language/add', 'admin/settings/language/add', 'Add language', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 5, 3, 0, 125, 371, 385, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 386, 381, 'admin/build/path/pathauto', 'admin/build/path/pathauto', 'Automated alias settings', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 10, 3, 0, 124, 381, 386, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 387, 372, 'admin/settings/lightbox2/automatic', 'admin/settings/lightbox2/automatic', 'Automatic image handling', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 3, 3, 0, 125, 372, 387, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 388, 371, 'admin/settings/language/configure', 'admin/settings/language/configure', 'Configure', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 10, 3, 0, 125, 371, 388, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 389, 137, 'admin/settings/date-time/configure', 'admin/settings/date-time/configure', 'Date and time', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 125, 137, 389, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 390, 141, 'admin/settings/filters/defaults', 'admin/settings/filters/defaults', 'Defaults', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 2, 3, 0, 125, 141, 390, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 391, 381, 'admin/build/path/delete_bulk', 'admin/build/path/delete_bulk', 'Delete aliases', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 30, 3, 0, 124, 381, 391, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 392, 380, 'admin/build/translate/export', 'admin/build/translate/export', 'Export', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 30, 3, 0, 124, 380, 392, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 393, 137, 'admin/settings/date-time/formats', 'admin/settings/date-time/formats', 'Formats', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 1, 3, 0, 125, 137, 393, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 394, 372, 'admin/settings/lightbox2/general', 'admin/settings/lightbox2/general', 'General', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 125, 372, 394, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 395, 372, 'admin/settings/lightbox2/html_content', 'admin/settings/lightbox2/html_content', 'HTML Content', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 2, 3, 0, 125, 372, 395, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 396, 380, 'admin/build/translate/import', 'admin/build/translate/import', 'Import', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 20, 3, 0, 124, 380, 396, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 397, 381, 'admin/build/path/list', 'admin/build/path/list', 'List', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -10, 3, 0, 124, 381, 397, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 398, 367, 'admin/build/contact/display', 'admin/build/contact/display', 'Message template', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 50, 3, 0, 124, 367, 398, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 399, 367, 'admin/build/contact/list', 'admin/build/contact/list', 'List', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 124, 367, 399, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 400, 367, 'admin/build/contact/manage', 'admin/build/contact/manage', 'Manage fields', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 49, 3, 0, 124, 367, 400, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 401, 382, 'admin/settings/wysiwyg/profile', 'admin/settings/wysiwyg/profile', 'List', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 125, 382, 401, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 402, 371, 'admin/settings/language/overview', 'admin/settings/language/overview', 'List', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 125, 371, 402, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 403, 380, 'admin/build/translate/overview', 'admin/build/translate/overview', 'Overview', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 124, 380, 403, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 404, 380, 'admin/build/translate/search', 'admin/build/translate/search', 'Search', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 10, 3, 0, 124, 380, 404, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 405, 141, 'admin/settings/filters/settings', 'admin/settings/filters/settings', 'Settings', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 3, 3, 0, 125, 141, 405, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 406, 367, 'admin/build/contact/settings', 'admin/build/contact/settings', 'Settings', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 2, 3, 0, 124, 367, 406, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 407, 372, 'admin/settings/lightbox2/slideshow', 'admin/settings/lightbox2/slideshow', 'Slideshow', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 3, 0, 125, 372, 407, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 408, 142, 'admin/settings/logging/syslog', 'admin/settings/logging/syslog', 'Syslog', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 125, 142, 408, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 409, 393, 'admin/settings/date-time/formats/add', 'admin/settings/date-time/formats/add', 'Add format', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 3, 4, 0, 125, 137, 393, 409, 0, 0, 0, 0, 0, 0),
('admin_menu', 410, 393, 'admin/settings/date-time/formats/configure', 'admin/settings/date-time/formats/configure', 'Configure', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 4, 0, 125, 137, 393, 410, 0, 0, 0, 0, 0, 0),
('admin_menu', 411, 393, 'admin/settings/date-time/formats/custom', 'admin/settings/date-time/formats/custom', 'Custom formats', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 2, 4, 0, 125, 137, 393, 411, 0, 0, 0, 0, 0, 0),
('admin_menu', 431, 170, 'admin/build/block/list/bootstrap', 'admin/build/block/list/bootstrap', 'Bootstrap', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -10, 4, 0, 124, 132, 170, 431, 0, 0, 0, 0, 0, 0),
('admin_menu', 413, 209, 'http://drupal.org/project/issues/better_formats', '', 'Better Formats issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 413, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 414, 209, 'http://drupal.org/project/issues/contact_field', '', 'Contact fields issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 414, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 415, 209, 'http://drupal.org/project/issues/date', '', 'Date issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 415, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 416, 209, 'http://drupal.org/project/issues/devel', '', 'Devel issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 416, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 417, 209, 'http://drupal.org/project/issues/google_analytics', '', 'Google Analytics issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 417, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 418, 209, 'http://drupal.org/project/issues/imce', '', 'IMCE issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 418, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 419, 209, 'http://drupal.org/project/issues/imce_wysiwyg', '', 'IMCE Wysiwyg API bridge issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 419, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 420, 209, 'http://drupal.org/project/issues/insert', '', 'Insert issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 420, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 421, 209, 'http://drupal.org/project/issues/lightbox2', '', 'Lightbox2 issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 421, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 422, 209, 'http://drupal.org/project/issues/nice_menus', '', 'Nice Menus issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 422, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 423, 209, 'http://drupal.org/project/issues/pathauto', '', 'Pathauto issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 423, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 424, 209, 'http://drupal.org/project/issues/token', '', 'Token issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 424, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 425, 209, 'http://drupal.org/project/issues/wysiwyg', '', 'Wysiwyg issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 425, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 426, 243, 'admin/content/node-type/page/display/search', 'admin/content/node-type/page/display/search', 'Search', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 215, 243, 426, 0, 0, 0, 0, 0),
('admin_menu', 427, 247, 'admin/content/node-type/story/display/search', 'admin/content/node-type/story/display/search', 'Search', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 216, 247, 427, 0, 0, 0, 0, 0),
('admin_menu', 428, 118, 'devel/variable', 'devel/variable', 'Variable editor', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 20, 2, 0, 118, 428, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 429, 119, 'devel/switch/root', 'devel/switch', '<em>root</em>', 'a:3:{s:5:"query";s:63:"destination=admin%2Fcontent%2Fnode-type%2Fdistribution%2Ffields";s:4:"html";b:1;s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 119, 429, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 434, 243, 'admin/content/node-type/page/display/token', 'admin/content/node-type/page/display/token', 'Token', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 215, 243, 434, 0, 0, 0, 0, 0),
('admin_menu', 435, 247, 'admin/content/node-type/story/display/token', 'admin/content/node-type/story/display/token', 'Token', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 216, 247, 435, 0, 0, 0, 0, 0),
('primary-links', 444, 0, 'contact', 'contact', 'Liện hệ', 'a:2:{s:10:"attributes";a:1:{s:5:"title";s:0:"";}s:5:"alter";b:1;}', 'menu', 0, 0, 0, 0, -47, 1, 1, 444, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 585, 11, 'node/add/home', 'node/add/home', 'Home', 'a:0:{}', 'system', 0, 0, 0, 0, 0, 2, 0, 11, 585, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 447, 11, 'node/add/contact', 'node/add/contact', 'Contact', 'a:0:{}', 'system', 0, 0, 0, 0, 0, 2, 0, 11, 447, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 448, 10, 'admin/content/node-type/contact', 'admin/content/node-type/contact', 'Contact', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 10, 448, 0, 0, 0, 0, 0, 0, 0),
('navigation', 449, 0, 'admin/content/node-type/contact/delete', 'admin/content/node-type/contact/delete', 'Delete', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 449, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 450, 0, 'admin/content/node-type/contact/groups/%', 'admin/content/node-type/contact/groups/%', 'Edit group', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 450, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 451, 0, 'admin/content/node-type/contact/groups/%/remove', 'admin/content/node-type/contact/groups/%/remove', 'Edit group', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 451, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 453, 212, 'node/add/contact', 'node/add/contact', 'Contact', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 121, 212, 453, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 454, 136, 'admin/content/node-type/contact', 'admin/content/node-type/contact', 'Edit !content-type', 'a:2:{s:1:"t";a:1:{s:13:"!content-type";s:7:"Contact";}s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 3, 0, 121, 136, 454, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 455, 454, 'admin/content/node-type/contact/display', 'admin/content/node-type/contact/display', 'Display fields', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 2, 4, 0, 121, 136, 454, 455, 0, 0, 0, 0, 0, 0),
('admin_menu', 456, 455, 'admin/content/node-type/contact/display/basic', 'admin/content/node-type/contact/display/basic', 'Basic', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 454, 455, 456, 0, 0, 0, 0, 0),
('admin_menu', 457, 455, 'admin/content/node-type/contact/display/rss', 'admin/content/node-type/contact/display/rss', 'RSS', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 454, 455, 457, 0, 0, 0, 0, 0),
('admin_menu', 458, 455, 'admin/content/node-type/contact/display/search', 'admin/content/node-type/contact/display/search', 'Search', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 454, 455, 458, 0, 0, 0, 0, 0),
('admin_menu', 459, 455, 'admin/content/node-type/contact/display/token', 'admin/content/node-type/contact/display/token', 'Token', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 454, 455, 459, 0, 0, 0, 0, 0),
('admin_menu', 460, 454, 'admin/content/node-type/contact/fields', 'admin/content/node-type/contact/fields', 'Manage fields', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 1, 4, 0, 121, 136, 454, 460, 0, 0, 0, 0, 0, 0),
('navigation', 494, 0, 'admin/content/node-type/contact/fields/field_contact_phone/remove', 'admin/content/node-type/contact/fields/field_contact_phone/remove', 'Remove field', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 494, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 485, 0, 'admin/content/node-type/contact/fields/field_contact_email/remove', 'admin/content/node-type/contact/fields/field_contact_email/remove', 'Remove field', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 485, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 487, 460, 'admin/content/node-type/contact/fields/field_contact_email', 'admin/content/node-type/contact/fields/field_contact_email', 'Email', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 454, 460, 487, 0, 0, 0, 0, 0),
('navigation', 502, 0, 'poll', 'poll', 'Polls', 'a:0:{}', 'system', 1, 0, 0, 0, 0, 1, 0, 502, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 529, 0, 'admin/content/node-type/poll/groups/%', 'admin/content/node-type/poll/groups/%', 'Edit group', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 529, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 481, 0, 'admin/content/node-type/contact/fields/field_contact_address/remove', 'admin/content/node-type/contact/fields/field_contact_address/remove', 'Remove field', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 481, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 483, 460, 'admin/content/node-type/contact/fields/field_contact_address', 'admin/content/node-type/contact/fields/field_contact_address', 'Address', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 454, 460, 483, 0, 0, 0, 0, 0),
('navigation', 488, 0, 'admin/content/node-type/contact/fields/field_contact_fax/remove', 'admin/content/node-type/contact/fields/field_contact_fax/remove', 'Remove field', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 488, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 490, 460, 'admin/content/node-type/contact/fields/field_contact_fax', 'admin/content/node-type/contact/fields/field_contact_fax', 'Fax', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 454, 460, 490, 0, 0, 0, 0, 0),
('navigation', 491, 0, 'admin/content/node-type/contact/fields/field_contact_mobile/remove', 'admin/content/node-type/contact/fields/field_contact_mobile/remove', 'Remove field', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 491, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 493, 460, 'admin/content/node-type/contact/fields/field_contact_mobile', 'admin/content/node-type/contact/fields/field_contact_mobile', 'Mobile', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 454, 460, 493, 0, 0, 0, 0, 0),
('admin_menu', 496, 460, 'admin/content/node-type/contact/fields/field_contact_phone', 'admin/content/node-type/contact/fields/field_contact_phone', 'Phone', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 454, 460, 496, 0, 0, 0, 0, 0),
('navigation', 497, 0, 'admin/content/node-type/contact/fields/field_contact_website/remove', 'admin/content/node-type/contact/fields/field_contact_website/remove', 'Remove field', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 497, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 499, 460, 'admin/content/node-type/contact/fields/field_contact_website', 'admin/content/node-type/contact/fields/field_contact_website', 'Website', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 454, 460, 499, 0, 0, 0, 0, 0),
('navigation', 503, 0, 'profile', 'profile', 'User list', 'a:0:{}', 'system', 1, 0, 0, 0, 0, 1, 0, 503, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 504, 502, 'poll/js', 'poll/js', 'Javascript Choice Form', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 2, 0, 502, 504, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 505, 503, 'profile/autocomplete', 'profile/autocomplete', 'Profile autocomplete', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 2, 0, 503, 505, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 506, 0, 'i18nstrings/save', 'i18nstrings/save', 'Save string', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 506, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 507, 0, 'i18n/node/autocomplete', 'i18n/node/autocomplete', 'Node title autocomplete', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 507, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 508, 11, 'node/add/poll', 'node/add/poll', 'Poll', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:191:"A <em>poll</em> is a question with a set of possible responses. A <em>poll</em>, once created, automatically provides a simple running count of the number of votes received for each response.";}}', 'system', 0, 0, 0, 0, 0, 2, 0, 11, 508, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 509, 20, 'admin/user/profile', 'admin/user/profile', 'Profiles', 'a:1:{s:10:"attributes";a:1:{s:5:"title";s:42:"Create customizable fields for your users.";}}', 'system', 0, 0, 0, 0, 0, 3, 0, 2, 20, 509, 0, 0, 0, 0, 0, 0, 0),
('navigation', 510, 15, 'admin/help/i18n', 'admin/help/i18n', 'i18n', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 510, 0, 0, 0, 0, 0, 0, 0),
('navigation', 511, 15, 'admin/help/i18nblocks', 'admin/help/i18nblocks', 'i18nblocks', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 511, 0, 0, 0, 0, 0, 0, 0),
('navigation', 512, 15, 'admin/help/i18ncontent', 'admin/help/i18ncontent', 'i18ncontent', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 512, 0, 0, 0, 0, 0, 0, 0),
('navigation', 513, 15, 'admin/help/i18nmenu', 'admin/help/i18nmenu', 'i18nmenu', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 513, 0, 0, 0, 0, 0, 0, 0),
('navigation', 514, 15, 'admin/help/i18nprofile', 'admin/help/i18nprofile', 'i18nprofile', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 514, 0, 0, 0, 0, 0, 0, 0),
('navigation', 515, 15, 'admin/help/i18nstrings', 'admin/help/i18nstrings', 'i18nstrings', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 515, 0, 0, 0, 0, 0, 0, 0),
('navigation', 516, 15, 'admin/help/i18nsync', 'admin/help/i18nsync', 'i18nsync', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 516, 0, 0, 0, 0, 0, 0, 0),
('navigation', 517, 15, 'admin/help/i18ntaxonomy', 'admin/help/i18ntaxonomy', 'i18ntaxonomy', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 517, 0, 0, 0, 0, 0, 0, 0),
('navigation', 518, 15, 'admin/help/languageicons', 'admin/help/languageicons', 'languageicons', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 518, 0, 0, 0, 0, 0, 0, 0),
('navigation', 519, 15, 'admin/help/poll', 'admin/help/poll', 'poll', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 519, 0, 0, 0, 0, 0, 0, 0),
('navigation', 520, 15, 'admin/help/profile', 'admin/help/profile', 'profile', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 15, 520, 0, 0, 0, 0, 0, 0, 0),
('navigation', 521, 509, 'admin/user/profile/add', 'admin/user/profile/add', 'Add field', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 20, 509, 521, 0, 0, 0, 0, 0, 0),
('navigation', 522, 509, 'admin/user/profile/delete', 'admin/user/profile/delete', 'Delete field', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 20, 509, 522, 0, 0, 0, 0, 0, 0),
('navigation', 523, 509, 'admin/user/profile/edit', 'admin/user/profile/edit', 'Edit field', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 20, 509, 523, 0, 0, 0, 0, 0, 0),
('navigation', 524, 10, 'admin/content/node-type/poll', 'admin/content/node-type/poll', 'Poll', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 10, 524, 0, 0, 0, 0, 0, 0, 0),
('navigation', 525, 509, 'admin/user/profile/autocomplete', 'admin/user/profile/autocomplete', 'Profile category autocomplete', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 4, 0, 2, 20, 509, 525, 0, 0, 0, 0, 0, 0),
('navigation', 526, 0, 'admin/content/node-type/poll/delete', 'admin/content/node-type/poll/delete', 'Delete', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 526, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 532, 371, 'admin/settings/language/icons', 'admin/settings/language/icons', 'Icons', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 10, 3, 0, 125, 371, 532, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 531, 126, 'admin/user/profile', 'admin/user/profile', 'Profiles', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 2, 0, 126, 531, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 530, 0, 'admin/content/node-type/poll/groups/%/remove', 'admin/content/node-type/poll/groups/%/remove', 'Edit group', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 530, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 533, 371, 'admin/settings/language/i18n', 'admin/settings/language/i18n', 'Multilingual system', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 10, 3, 0, 125, 371, 533, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 534, 380, 'admin/build/translate/refresh', 'admin/build/translate/refresh', 'Refresh', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 20, 3, 0, 124, 380, 534, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 535, 388, 'admin/settings/language/configure/language', 'admin/settings/language/configure/language', 'Language negotiation', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, -10, 4, 0, 125, 371, 388, 535, 0, 0, 0, 0, 0, 0),
('admin_menu', 536, 533, 'admin/settings/language/i18n/configure', 'admin/settings/language/i18n/configure', 'Options', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 125, 371, 533, 536, 0, 0, 0, 0, 0, 0),
('admin_menu', 537, 388, 'admin/settings/language/configure/strings', 'admin/settings/language/configure/strings', 'String translation', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 20, 4, 0, 125, 371, 388, 537, 0, 0, 0, 0, 0, 0),
('admin_menu', 538, 533, 'admin/settings/language/i18n/variables', 'admin/settings/language/i18n/variables', 'Variables', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 4, 0, 125, 371, 533, 538, 0, 0, 0, 0, 0, 0),
('admin_menu', 626, 118, 'update.php', '', 'Run updates', 'a:2:{s:8:"external";b:1;s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 50, 2, 0, 118, 626, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 540, 209, 'http://drupal.org/project/issues/i18n', '', 'Internationalization issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 540, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 541, 209, 'http://drupal.org/project/issues/languageicons', '', 'Language icons issue queue', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 1, 0, 0, 0, 3, 0, 118, 209, 541, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 542, 212, 'node/add/poll', 'node/add/poll', 'Poll', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 121, 212, 542, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 543, 136, 'admin/content/node-type/poll', 'admin/content/node-type/poll', 'Edit !content-type', 'a:2:{s:1:"t";a:1:{s:13:"!content-type";s:4:"Poll";}s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 3, 0, 121, 136, 543, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 544, 543, 'admin/content/node-type/poll/display', 'admin/content/node-type/poll/display', 'Display fields', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 2, 4, 0, 121, 136, 543, 544, 0, 0, 0, 0, 0, 0);
INSERT INTO `menu_links` (`menu_name`, `mlid`, `plid`, `link_path`, `router_path`, `link_title`, `options`, `module`, `hidden`, `external`, `has_children`, `expanded`, `weight`, `depth`, `customized`, `p1`, `p2`, `p3`, `p4`, `p5`, `p6`, `p7`, `p8`, `p9`, `updated`) VALUES
('admin_menu', 545, 544, 'admin/content/node-type/poll/display/basic', 'admin/content/node-type/poll/display/basic', 'Basic', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 543, 544, 545, 0, 0, 0, 0, 0),
('admin_menu', 546, 544, 'admin/content/node-type/poll/display/rss', 'admin/content/node-type/poll/display/rss', 'RSS', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 543, 544, 546, 0, 0, 0, 0, 0),
('admin_menu', 547, 544, 'admin/content/node-type/poll/display/search', 'admin/content/node-type/poll/display/search', 'Search', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 543, 544, 547, 0, 0, 0, 0, 0),
('admin_menu', 548, 544, 'admin/content/node-type/poll/display/token', 'admin/content/node-type/poll/display/token', 'Token', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 543, 544, 548, 0, 0, 0, 0, 0),
('admin_menu', 549, 543, 'admin/content/node-type/poll/fields', 'admin/content/node-type/poll/fields', 'Manage fields', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 4, 0, 121, 136, 543, 549, 0, 0, 0, 0, 0, 0),
('navigation', 555, 0, 'intro', 'intro', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 555, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('primary-links', 557, 0, 'intro', 'intro', 'Gioi Thieu', 'a:2:{s:10:"attributes";a:1:{s:5:"title";s:0:"";}s:5:"alter";b:1;}', 'menu', 0, 0, 0, 0, -49, 1, 1, 557, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 560, 10, 'admin/content/node-type/intro', 'admin/content/node-type/intro', 'Intro', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 10, 560, 0, 0, 0, 0, 0, 0, 0),
('navigation', 559, 11, 'node/add/intro', 'node/add/intro', 'Intro', 'a:0:{}', 'system', 0, 0, 0, 0, 0, 2, 0, 11, 559, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 561, 0, 'admin/content/node-type/intro/delete', 'admin/content/node-type/intro/delete', 'Delete', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 561, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 562, 0, 'admin/content/node-type/intro/groups/%', 'admin/content/node-type/intro/groups/%', 'Edit group', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 562, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 563, 0, 'admin/content/node-type/intro/groups/%/remove', 'admin/content/node-type/intro/groups/%/remove', 'Edit group', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 563, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 565, 212, 'node/add/intro', 'node/add/intro', 'Intro', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 121, 212, 565, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 566, 136, 'admin/content/node-type/intro', 'admin/content/node-type/intro', 'Edit !content-type', 'a:2:{s:1:"t";a:1:{s:13:"!content-type";s:5:"Intro";}s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 3, 0, 121, 136, 566, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 567, 566, 'admin/content/node-type/intro/display', 'admin/content/node-type/intro/display', 'Display fields', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 2, 4, 0, 121, 136, 566, 567, 0, 0, 0, 0, 0, 0),
('admin_menu', 568, 567, 'admin/content/node-type/intro/display/basic', 'admin/content/node-type/intro/display/basic', 'Basic', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 566, 567, 568, 0, 0, 0, 0, 0),
('admin_menu', 569, 567, 'admin/content/node-type/intro/display/rss', 'admin/content/node-type/intro/display/rss', 'RSS', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 566, 567, 569, 0, 0, 0, 0, 0),
('admin_menu', 570, 567, 'admin/content/node-type/intro/display/search', 'admin/content/node-type/intro/display/search', 'Search', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 566, 567, 570, 0, 0, 0, 0, 0),
('admin_menu', 571, 567, 'admin/content/node-type/intro/display/token', 'admin/content/node-type/intro/display/token', 'Token', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 566, 567, 571, 0, 0, 0, 0, 0),
('admin_menu', 572, 566, 'admin/content/node-type/intro/fields', 'admin/content/node-type/intro/fields', 'Manage fields', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 1, 4, 0, 121, 136, 566, 572, 0, 0, 0, 0, 0, 0),
('navigation', 573, 0, 'admin/content/node-type/intro/fields/field_intro_embed/remove', 'admin/content/node-type/intro/fields/field_intro_embed/remove', 'Remove field', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 573, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 575, 572, 'admin/content/node-type/intro/fields/field_intro_embed', 'admin/content/node-type/intro/fields/field_intro_embed', 'Embed', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 566, 572, 575, 0, 0, 0, 0, 0),
('navigation', 580, 0, 'home', 'home', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 580, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 576, 0, 'admin/content/node-type/intro/fields/field_intro_content/remove', 'admin/content/node-type/intro/fields/field_intro_content/remove', 'Remove field', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 576, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 578, 572, 'admin/content/node-type/intro/fields/field_intro_content', 'admin/content/node-type/intro/fields/field_intro_content', 'Content', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 566, 572, 578, 0, 0, 0, 0, 0),
('navigation', 586, 10, 'admin/content/node-type/home', 'admin/content/node-type/home', 'Home', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 10, 586, 0, 0, 0, 0, 0, 0, 0),
('navigation', 587, 0, 'admin/content/node-type/home/delete', 'admin/content/node-type/home/delete', 'Delete', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 587, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 588, 0, 'admin/content/node-type/home/groups/%', 'admin/content/node-type/home/groups/%', 'Edit group', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 588, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 589, 0, 'admin/content/node-type/home/groups/%/remove', 'admin/content/node-type/home/groups/%/remove', 'Edit group', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 589, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 591, 212, 'node/add/home', 'node/add/home', 'Home', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 121, 212, 591, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 592, 136, 'admin/content/node-type/home', 'admin/content/node-type/home', 'Edit !content-type', 'a:2:{s:1:"t";a:1:{s:13:"!content-type";s:4:"Home";}s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 3, 0, 121, 136, 592, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 593, 592, 'admin/content/node-type/home/display', 'admin/content/node-type/home/display', 'Display fields', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 2, 4, 0, 121, 136, 592, 593, 0, 0, 0, 0, 0, 0),
('admin_menu', 594, 593, 'admin/content/node-type/home/display/basic', 'admin/content/node-type/home/display/basic', 'Basic', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 592, 593, 594, 0, 0, 0, 0, 0),
('admin_menu', 595, 593, 'admin/content/node-type/home/display/rss', 'admin/content/node-type/home/display/rss', 'RSS', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 592, 593, 595, 0, 0, 0, 0, 0),
('admin_menu', 596, 593, 'admin/content/node-type/home/display/search', 'admin/content/node-type/home/display/search', 'Search', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 592, 593, 596, 0, 0, 0, 0, 0),
('admin_menu', 597, 593, 'admin/content/node-type/home/display/token', 'admin/content/node-type/home/display/token', 'Token', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 592, 593, 597, 0, 0, 0, 0, 0),
('admin_menu', 598, 592, 'admin/content/node-type/home/fields', 'admin/content/node-type/home/fields', 'Manage fields', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 1, 4, 0, 121, 136, 592, 598, 0, 0, 0, 0, 0, 0),
('navigation', 599, 0, 'admin/content/node-type/home/fields/field_home_company_info/remove', 'admin/content/node-type/home/fields/field_home_company_info/remove', 'Remove field', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 599, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 601, 598, 'admin/content/node-type/home/fields/field_home_company_info', 'admin/content/node-type/home/fields/field_home_company_info', 'Company info', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 592, 598, 601, 0, 0, 0, 0, 0),
('primary-links', 610, 0, 'distribution', 'distribution', 'HT Phân Phối', 'a:2:{s:10:"attributes";a:1:{s:5:"title";s:0:"";}s:5:"alter";b:1;}', 'menu', 0, 0, 0, 0, -48, 1, 1, 610, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 602, 0, 'admin/content/node-type/home/fields/field_home_trophic_info/remove', 'admin/content/node-type/home/fields/field_home_trophic_info/remove', 'Remove field', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 602, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 604, 598, 'admin/content/node-type/home/fields/field_home_trophic_info', 'admin/content/node-type/home/fields/field_home_trophic_info', 'Trophic info', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 592, 598, 604, 0, 0, 0, 0, 0),
('navigation', 605, 0, 'admin/content/node-type/home/fields/field_home_embed/remove', 'admin/content/node-type/home/fields/field_home_embed/remove', 'Remove field', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 605, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 607, 598, 'admin/content/node-type/home/fields/field_home_embed', 'admin/content/node-type/home/fields/field_home_embed', 'Embed', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 592, 598, 607, 0, 0, 0, 0, 0),
('navigation', 608, 0, 'distribution', 'distribution', '', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 608, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 611, 11, 'node/add/distribution', 'node/add/distribution', 'Distribution', 'a:0:{}', 'system', 0, 0, 0, 0, 0, 2, 0, 11, 611, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 612, 10, 'admin/content/node-type/distribution', 'admin/content/node-type/distribution', 'Distribution', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 3, 0, 2, 10, 612, 0, 0, 0, 0, 0, 0, 0),
('navigation', 613, 0, 'admin/content/node-type/distribution/delete', 'admin/content/node-type/distribution/delete', 'Delete', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 613, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 614, 0, 'admin/content/node-type/distribution/groups/%', 'admin/content/node-type/distribution/groups/%', 'Edit group', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 614, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('navigation', 615, 0, 'admin/content/node-type/distribution/groups/%/remove', 'admin/content/node-type/distribution/groups/%/remove', 'Edit group', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 615, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 617, 212, 'node/add/distribution', 'node/add/distribution', 'Distribution', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 3, 0, 121, 212, 617, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 618, 136, 'admin/content/node-type/distribution', 'admin/content/node-type/distribution', 'Edit !content-type', 'a:2:{s:1:"t";a:1:{s:13:"!content-type";s:12:"Distribution";}s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 0, 3, 0, 121, 136, 618, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 619, 618, 'admin/content/node-type/distribution/display', 'admin/content/node-type/distribution/display', 'Display fields', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 2, 4, 0, 121, 136, 618, 619, 0, 0, 0, 0, 0, 0),
('admin_menu', 620, 619, 'admin/content/node-type/distribution/display/basic', 'admin/content/node-type/distribution/display/basic', 'Basic', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 618, 619, 620, 0, 0, 0, 0, 0),
('admin_menu', 621, 619, 'admin/content/node-type/distribution/display/rss', 'admin/content/node-type/distribution/display/rss', 'RSS', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 618, 619, 621, 0, 0, 0, 0, 0),
('admin_menu', 622, 619, 'admin/content/node-type/distribution/display/search', 'admin/content/node-type/distribution/display/search', 'Search', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 618, 619, 622, 0, 0, 0, 0, 0),
('admin_menu', 623, 619, 'admin/content/node-type/distribution/display/token', 'admin/content/node-type/distribution/display/token', 'Token', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 1, 5, 0, 121, 136, 618, 619, 623, 0, 0, 0, 0, 0),
('admin_menu', 624, 618, 'admin/content/node-type/distribution/fields', 'admin/content/node-type/distribution/fields', 'Manage fields', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 1, 0, 1, 4, 0, 121, 136, 618, 624, 0, 0, 0, 0, 0, 0),
('navigation', 625, 0, 'admin/content/node-type/distribution/fields/field_distribution_content/remove', 'admin/content/node-type/distribution/fields/field_distribution_content/remove', 'Remove field', 'a:0:{}', 'system', -1, 0, 0, 0, 0, 1, 0, 625, 0, 0, 0, 0, 0, 0, 0, 0, 0),
('admin_menu', 627, 624, 'admin/content/node-type/distribution/fields/field_distribution_content', 'admin/content/node-type/distribution/fields/field_distribution_content', 'Content', 'a:1:{s:5:"alter";b:1;}', 'admin_menu', 0, 0, 0, 0, 0, 5, 0, 121, 136, 618, 624, 627, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `menu_router`
--

CREATE TABLE IF NOT EXISTS `menu_router` (
  `path` varchar(255) NOT NULL DEFAULT '',
  `load_functions` text NOT NULL,
  `to_arg_functions` text NOT NULL,
  `access_callback` varchar(255) NOT NULL DEFAULT '',
  `access_arguments` text,
  `page_callback` varchar(255) NOT NULL DEFAULT '',
  `page_arguments` text,
  `fit` int(11) NOT NULL DEFAULT '0',
  `number_parts` smallint(6) NOT NULL DEFAULT '0',
  `tab_parent` varchar(255) NOT NULL DEFAULT '',
  `tab_root` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `title_callback` varchar(255) NOT NULL DEFAULT '',
  `title_arguments` varchar(255) NOT NULL DEFAULT '',
  `type` int(11) NOT NULL DEFAULT '0',
  `block_callback` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `position` varchar(255) NOT NULL DEFAULT '',
  `weight` int(11) NOT NULL DEFAULT '0',
  `file` mediumtext,
  PRIMARY KEY (`path`),
  KEY `fit` (`fit`),
  KEY `tab_parent` (`tab_parent`),
  KEY `tab_root_weight_title` (`tab_root`(64),`weight`,`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menu_router`
--

INSERT INTO `menu_router` (`path`, `load_functions`, `to_arg_functions`, `access_callback`, `access_arguments`, `page_callback`, `page_arguments`, `fit`, `number_parts`, `tab_parent`, `tab_root`, `title`, `title_callback`, `title_arguments`, `type`, `block_callback`, `description`, `position`, `weight`, `file`) VALUES
('distribution', '', '', 'user_access', 'a:1:{i:0;s:14:"access content";}', 'my_distribution', 'a:0:{}', 1, 1, '', 'distribution', '', 't', '', 4, '', '', '', 0, ''),
('home', '', '', 'user_access', 'a:1:{i:0;s:14:"access content";}', 'my_home', 'a:0:{}', 1, 1, '', 'home', '', 't', '', 4, '', '', '', 0, ''),
('intro', '', '', 'user_access', 'a:1:{i:0;s:14:"access content";}', 'my_intro', 'a:0:{}', 1, 1, '', 'intro', '', 't', '', 4, '', '', '', 0, ''),
('node', '', '', 'user_access', 'a:1:{i:0;s:14:"access content";}', 'node_page_default', 'a:0:{}', 1, 1, '', 'node', 'Content', 't', '', 4, '', '', '', 0, ''),
('rss.xml', '', '', 'user_access', 'a:1:{i:0;s:14:"access content";}', 'node_feed', 'a:0:{}', 1, 1, '', 'rss.xml', 'RSS feed', 't', '', 4, '', '', '', 0, ''),
('admin', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'system_main_admin_page', 'a:0:{}', 1, 1, '', 'admin', 'Administer', 't', '', 6, '', '', '', 9, 'modules/system/system.admin.inc'),
('contact', '', '', 'user_access', 'a:1:{i:0;s:29:"access site-wide contact form";}', 'contact_site_page', 'a:0:{}', 1, 1, '', 'contact', 'Contact', 't', '', 20, '', '', '', 0, 'modules/contact/contact.pages.inc'),
('imce', '', '', 'imce_access', 'a:0:{}', 'imce', 'a:0:{}', 1, 1, '', 'imce', 'File browser', 't', '', 4, '', '', '', 0, 'sites/all/modules/imce/inc/imce.page.inc'),
('logout', '', '', 'user_is_logged_in', 'a:0:{}', 'user_logout', 'a:0:{}', 1, 1, '', 'logout', 'Log out', 't', '', 6, '', '', '', 10, 'modules/user/user.pages.inc'),
('poll', '', '', 'user_access', 'a:1:{i:0;s:14:"access content";}', 'poll_page', 'a:0:{}', 1, 1, '', 'poll', 'Polls', 't', '', 20, '', '', '', 0, 'modules/poll/poll.pages.inc'),
('search', '', '', 'user_access', 'a:1:{i:0;s:14:"search content";}', 'search_view', 'a:0:{}', 1, 1, '', 'search', 'Search', 't', '', 20, '', '', '', 0, 'modules/search/search.pages.inc'),
('batch', '', '', '1', 'a:0:{}', 'system_batch_page', 'a:0:{}', 1, 1, '', 'batch', '', 't', '', 4, '', '', '', 0, 'modules/system/system.admin.inc'),
('user', '', '', '1', 'a:0:{}', 'user_page', 'a:0:{}', 1, 1, '', 'user', 'User account', 't', '', 4, '', '', '', 0, 'modules/user/user.pages.inc'),
('profile', '', '', 'user_access', 'a:1:{i:0;s:20:"access user profiles";}', 'profile_browse', 'a:0:{}', 1, 1, '', 'profile', 'User list', 't', '', 20, '', '', '', 0, 'modules/profile/profile.pages.inc'),
('user/login', '', '', 'user_is_anonymous', 'a:0:{}', 'user_page', 'a:0:{}', 3, 2, 'user', 'user', 'Log in', 't', '', 136, '', '', '', 0, 'modules/user/user.pages.inc'),
('contact/lightbox2', '', '', 'user_access', 'a:1:{i:0;s:29:"access site-wide contact form";}', 'lightbox2_contact', 'a:0:{}', 3, 2, '', 'contact/lightbox2', 'Contact', 't', '', 4, '', '', '', 0, ''),
('system/files', '', '', '1', 'a:0:{}', 'file_download', 'a:0:{}', 3, 2, '', 'system/files', 'File download', 't', '', 4, '', '', '', 0, ''),
('filefield/progress', '', '', 'user_access', 'a:1:{i:0;s:14:"access content";}', 'filefield_progress', 'a:0:{}', 3, 2, '', 'filefield/progress', '', 't', '', 4, '', '', '', 0, ''),
('poll/js', '', '', 'user_access', 'a:1:{i:0;s:14:"access content";}', 'poll_choice_js', 'a:0:{}', 3, 2, '', 'poll/js', 'Javascript Choice Form', 't', '', 4, '', '', '', 0, ''),
('i18nstrings/save', '', '', 'user_access', 'a:1:{i:0;s:23:"use on-page translation";}', 'i18nstrings_save_string', 'a:0:{}', 3, 2, '', 'i18nstrings/save', 'Save string', 't', '', 4, '', '', '', 0, ''),
('user/timezone', '', '', '1', 'a:0:{}', 'user_timezone', 'a:0:{}', 3, 2, '', 'user/timezone', 'User timezone', 't', '', 4, '', '', '', 0, ''),
('userreference/autocomplete', '', '', 'user_access', 'a:1:{i:0;s:14:"access content";}', 'userreference_autocomplete', 'a:0:{}', 3, 2, '', 'userreference/autocomplete', 'Userreference autocomplete', 't', '', 4, '', '', '', 0, ''),
('admin_menu/flush-cache', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'admin_menu_flush_cache', 'a:0:{}', 3, 2, '', 'admin_menu/flush-cache', '', 't', '', 4, '', '', '', 0, 'sites/all/modules/admin_menu/admin_menu.inc'),
('admin_menu/toggle-modules', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'admin_menu_toggle_modules', 'a:0:{}', 3, 2, '', 'admin_menu/toggle-modules', '', 't', '', 4, '', '', '', 0, 'sites/all/modules/admin_menu/admin_menu.inc'),
('content/js_add_more', '', '', 'user_access', 'a:1:{i:0;s:14:"access content";}', 'content_add_more_js', 'a:0:{}', 3, 2, '', 'content/js_add_more', '', 't', '', 4, '', '', '', 0, 'sites/all/modules/cck/includes/content.node_form.inc'),
('taxonomy/autocomplete', '', '', 'user_access', 'a:1:{i:0;s:14:"access content";}', 'i18ntaxonomy_autocomplete', 'a:0:{}', 3, 2, '', 'taxonomy/autocomplete', 'Autocomplete taxonomy', 't', '', 4, '', '', '', 0, 'sites/all/modules/i18n/i18ntaxonomy/i18ntaxonomy.pages.inc'),
('admin/by-module', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'system_admin_by_module', 'a:0:{}', 3, 2, 'admin', 'admin', 'By module', 't', '', 128, '', '', '', 2, 'modules/system/system.admin.inc'),
('admin/by-task', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'system_main_admin_page', 'a:0:{}', 3, 2, 'admin', 'admin', 'By task', 't', '', 136, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/compact', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'system_admin_compact_page', 'a:0:{}', 3, 2, '', 'admin/compact', 'Compact mode', 't', '', 4, '', '', '', 0, 'modules/system/system.admin.inc'),
('filter/tips', '', '', '1', 'a:0:{}', 'filter_tips_long', 'a:0:{}', 3, 2, '', 'filter/tips', 'Compose tips', 't', '', 20, '', '', '', 0, 'modules/filter/filter.pages.inc'),
('node/add', '', '', '_node_add_access', 'a:0:{}', 'i18ncontent_node_add_page', 'a:0:{}', 3, 2, '', 'node/add', 'Create content', 't', '', 6, '', '', '', 1, 'modules/node/node.pages.inc'),
('comment/delete', '', '', 'user_access', 'a:1:{i:0;s:19:"administer comments";}', 'comment_delete', 'a:0:{}', 3, 2, '', 'comment/delete', 'Delete comment', 't', '', 4, '', '', '', 0, 'modules/comment/comment.admin.inc'),
('comment/edit', '', '', 'user_access', 'a:1:{i:0;s:13:"post comments";}', 'comment_edit', 'a:0:{}', 3, 2, '', 'comment/edit', 'Edit comment', 't', '', 4, '', '', '', 0, 'modules/comment/comment.pages.inc'),
('admin/help', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_main', 'a:0:{}', 3, 2, '', 'admin/help', 'Help', 't', '', 6, '', '', '', 9, 'modules/help/help.admin.inc'),
('nodereference/autocomplete', '', '', 'nodereference_autocomplete_access', 'a:1:{i:0;i:2;}', 'nodereference_autocomplete', 'a:0:{}', 3, 2, '', 'nodereference/autocomplete', 'Nodereference autocomplete', 't', '', 4, '', '', '', 0, ''),
('profile/autocomplete', '', '', 'user_access', 'a:1:{i:0;s:20:"access user profiles";}', 'profile_autocomplete', 'a:0:{}', 3, 2, '', 'profile/autocomplete', 'Profile autocomplete', 't', '', 4, '', '', '', 0, 'modules/profile/profile.pages.inc'),
('devel/switch', '', '', 'user_access', 'a:1:{i:0;s:12:"switch users";}', 'devel_switch_user', 'a:0:{}', 3, 2, '', 'devel/switch', 'Switch user', 't', '', 4, '', '', '', 0, ''),
('user/register', '', '', 'user_register_access', 'a:0:{}', 'drupal_get_form', 'a:1:{i:0;s:13:"user_register";}', 3, 2, 'user', 'user', 'Create new account', 't', '', 128, '', '', '', 0, 'modules/user/user.pages.inc'),
('devel/queries', '', '', 'devel_menu_access_store_queries', 'a:0:{}', 'devel_queries', 'a:0:{}', 3, 2, '', 'devel/queries', 'Database queries', 't', '', 6, '', '', '', 0, ''),
('devel/reference', '', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'devel_function_reference', 'a:0:{}', 3, 2, '', 'devel/reference', 'Function reference', 't', '', 6, '', 'View a list of currently defined user functions with documentation links.', '', 0, ''),
('devel/elements', '', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'devel_elements_page', 'a:0:{}', 3, 2, '', 'devel/elements', 'Hook_elements()', 't', '', 6, '', 'View the active form/render elements for this site.', '', 0, ''),
('devel/phpinfo', '', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'devel_phpinfo', 'a:0:{}', 3, 2, '', 'devel/phpinfo', 'PHPinfo()', 't', '', 6, '', 'View your server''s PHP configuration', '', 0, ''),
('user/password', '', '', 'user_is_anonymous', 'a:0:{}', 'drupal_get_form', 'a:1:{i:0;s:9:"user_pass";}', 3, 2, 'user', 'user', 'Request new password', 't', '', 128, '', '', '', 0, 'modules/user/user.pages.inc'),
('devel/session', '', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'devel_session', 'a:0:{}', 3, 2, '', 'devel/session', 'Session viewer', 't', '', 6, '', 'List the contents of $_SESSION.', '', 0, ''),
('user/autocomplete', '', '', 'user_access', 'a:1:{i:0;s:20:"access user profiles";}', 'user_autocomplete', 'a:0:{}', 3, 2, '', 'user/autocomplete', 'User autocomplete', 't', '', 4, '', '', '', 0, 'modules/user/user.pages.inc'),
('devel/variable', '', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'devel_variable_page', 'a:0:{}', 3, 2, '', 'devel/variable', 'Variable editor', 't', '', 6, '', 'Edit and delete site variables.', '', 0, ''),
('wysiwyg/%', 'a:1:{i:1;N;}', '', 'user_access', 'a:1:{i:0;s:14:"access content";}', 'wysiwyg_dialog', 'a:1:{i:0;i:1;}', 2, 2, '', 'wysiwyg/%', '', 't', '', 4, '', '', '', 0, 'sites/all/modules/wysiwyg/wysiwyg.dialog.inc'),
('views/ajax', '', '', '1', 'a:0:{}', 'views_ajax', 'a:0:{}', 3, 2, '', 'views/ajax', 'Views', 't', '', 4, '', 'Ajax callback for view loading.', '', 0, 'sites/all/modules/views/includes/ajax.inc'),
('admin/content', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'system_admin_menu_block_page', 'a:0:{}', 3, 2, '', 'admin/content', 'Content management', 't', '', 6, '', 'Manage your site''s content.', 'left', -10, 'modules/system/system.admin.inc'),
('devel/php', '', '', 'user_access', 'a:1:{i:0;s:16:"execute php code";}', 'drupal_get_form', 'a:1:{i:0;s:18:"devel_execute_form";}', 3, 2, '', 'devel/php', 'Execute PHP Code', 't', '', 6, '', 'Execute some PHP code', '', 0, ''),
('devel/reinstall', '', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'drupal_get_form', 'a:1:{i:0;s:15:"devel_reinstall";}', 3, 2, '', 'devel/reinstall', 'Reinstall modules', 't', '', 6, '', 'Run hook_uninstall() and then hook_install() for a given module.', '', 0, ''),
('admin/reports', '', '', 'user_access', 'a:1:{i:0;s:19:"access site reports";}', 'system_admin_menu_block_page', 'a:0:{}', 3, 2, '', 'admin/reports', 'Reports', 't', '', 6, '', 'View reports from system logs and other status information.', 'left', 5, 'modules/system/system.admin.inc'),
('admin/build', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'system_admin_menu_block_page', 'a:0:{}', 3, 2, '', 'admin/build', 'Site building', 't', '', 6, '', 'Control how your site looks and feels.', 'right', -10, 'modules/system/system.admin.inc'),
('admin/settings', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'system_settings_overview', 'a:0:{}', 3, 2, '', 'admin/settings', 'Site configuration', 't', '', 6, '', 'Adjust basic site configuration options.', 'right', -5, 'modules/system/system.admin.inc'),
('node/%', 'a:1:{i:1;s:9:"node_load";}', '', 'node_access', 'a:2:{i:0;s:4:"view";i:1;i:1;}', 'node_page_view', 'a:1:{i:0;i:1;}', 2, 2, '', 'node/%', '', 'node_page_title', 'a:1:{i:0;i:1;}', 4, '', '', '', 0, ''),
('admin/user', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'system_admin_menu_block_page', 'a:0:{}', 3, 2, '', 'admin/user', 'User management', 't', '', 6, '', 'Manage your site''s users, groups and access to site features.', 'left', 0, 'modules/system/system.admin.inc'),
('user/%', 'a:1:{i:1;s:22:"user_uid_optional_load";}', 'a:1:{i:1;s:24:"user_uid_optional_to_arg";}', 'user_view_access', 'a:1:{i:0;i:1;}', 'user_view', 'a:1:{i:0;i:1;}', 2, 2, '', 'user/%', 'My account', 'user_page_title', 'a:1:{i:0;i:1;}', 6, '', '', '', 0, 'modules/user/user.pages.inc'),
('node/%/view', 'a:1:{i:1;s:9:"node_load";}', '', 'node_access', 'a:2:{i:0;s:4:"view";i:1;i:1;}', 'node_page_view', 'a:1:{i:0;i:1;}', 5, 3, 'node/%', 'node/%', 'View', 't', '', 136, '', '', '', -10, ''),
('user/%/view', 'a:1:{i:1;s:9:"user_load";}', '', 'user_view_access', 'a:1:{i:0;i:1;}', 'user_view', 'a:1:{i:0;i:1;}', 5, 3, 'user/%', 'user/%', 'View', 't', '', 136, '', '', '', -10, 'modules/user/user.pages.inc'),
('system/files/imagecache', '', '', '1', 'a:0:{}', 'imagecache_cache_private', 'a:0:{}', 7, 3, '', 'system/files/imagecache', '', 't', '', 4, '', '', '', 0, ''),
('system/lightbox2/filter-xss', '', '', '1', 'a:0:{}', 'lightbox2_filter_xss', 'a:0:{}', 7, 3, '', 'system/lightbox2/filter-xss', 'Filter XSS', 't', '', 4, '', '', '', 0, ''),
('user/login/lightbox2', '', '', 'user_is_anonymous', 'a:0:{}', 'lightbox2_login', 'a:0:{}', 7, 3, '', 'user/login/lightbox2', 'Login', 't', '', 4, '', '', '', 0, ''),
('admin/settings/actions', '', '', 'user_access', 'a:1:{i:0;s:18:"administer actions";}', 'system_actions_manage', 'a:0:{}', 7, 3, '', 'admin/settings/actions', 'Actions', 't', '', 6, '', 'Manage the actions defined for your site.', '', 0, ''),
('i18n/node/autocomplete', '', '', 'user_access', 'a:1:{i:0;s:14:"access content";}', 'i18n_node_autocomplete', 'a:0:{}', 7, 3, '', 'i18n/node/autocomplete', 'Node title autocomplete', 't', '', 4, '', '', '', 0, 'sites/all/modules/i18n/i18n.pages.inc'),
('admin/user/rules', '', '', 'user_access', 'a:1:{i:0;s:22:"administer permissions";}', 'user_admin_access', 'a:0:{}', 7, 3, '', 'admin/user/rules', 'Access rules', 't', '', 6, '', 'List and create rules to disallow usernames, e-mail addresses, and IP addresses.', '', 0, 'modules/user/user.admin.inc'),
('admin/reports/updates', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'update_status', 'a:0:{}', 7, 3, '', 'admin/reports/updates', 'Available updates', 't', '', 6, '', 'Get a status report about available updates for your installed modules and themes.', '', 10, 'modules/update/update.report.inc'),
('admin/build/block', '', '', 'user_access', 'a:1:{i:0;s:17:"administer blocks";}', 'block_admin_display', 'a:0:{}', 7, 3, '', 'admin/build/block', 'Blocks', 't', '', 6, '', 'Configure what block content appears in your site''s sidebars and other regions.', '', 0, 'modules/block/block.admin.inc'),
('admin/content/comment', '', '', 'user_access', 'a:1:{i:0;s:19:"administer comments";}', 'comment_admin', 'a:0:{}', 7, 3, '', 'admin/content/comment', 'Comments', 't', '', 6, '', 'List and edit site comments and the comment moderation queue.', '', 0, 'modules/comment/comment.admin.inc'),
('admin/build/contact', '', '', 'user_access', 'a:1:{i:0;s:33:"administer site-wide contact form";}', 'contact_admin_categories', 'a:0:{}', 7, 3, '', 'admin/build/contact', 'Contact form', 't', '', 6, '', 'Create a system contact form and set up categories for the form to use.', '', 0, 'modules/contact/contact.admin.inc'),
('node/%/devel', 'a:1:{i:1;s:9:"node_load";}', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'devel_load_object', 'a:2:{i:0;i:1;i:1;s:4:"node";}', 5, 3, 'node/%', 'node/%', 'Devel', 't', '', 128, '', '', '', 100, ''),
('user/%/devel', 'a:1:{i:1;s:9:"user_load";}', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'devel_load_object', 'a:2:{i:0;i:1;i:1;s:4:"user";}', 5, 3, 'user/%', 'user/%', 'Devel', 't', '', 128, '', '', '', 100, ''),
('devel/cache/clear', '', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'devel_cache_clear', 'a:0:{}', 7, 3, '', 'devel/cache/clear', 'Empty cache', 't', '', 6, '', 'Clear the CSS cache and all database cache tables which store page, node, theme and variable caches.', '', 0, ''),
('devel/queries/empty', '', '', 'devel_menu_access_store_queries', 'a:0:{}', 'devel_queries_empty', 'a:0:{}', 7, 3, '', 'devel/queries/empty', 'Empty database queries', 't', '', 6, '', '', '', 0, ''),
('admin/settings/imce', '', '', 'user_access', 'a:1:{i:0;s:28:"administer imce(execute PHP)";}', 'imce_admin', 'a:0:{}', 7, 3, '', 'admin/settings/imce', 'IMCE', 't', '', 6, '', 'Control how your image/file browser works.', '', 0, 'sites/all/modules/imce/inc/imce.admin.inc'),
('admin/settings/imageapi', '', '', 'user_access', 'a:1:{i:0;s:19:"administer imageapi";}', 'drupal_get_form', 'a:1:{i:0;s:17:"imageapi_settings";}', 7, 3, '', 'admin/settings/imageapi', 'ImageAPI', 't', '', 6, '', 'Configure ImageAPI.', '', 0, ''),
('admin/settings/language', '', '', 'user_access', 'a:1:{i:0;s:20:"administer languages";}', 'locale_inc_callback', 'a:2:{i:0;s:15:"drupal_get_form";i:1;s:30:"locale_languages_overview_form";}', 7, 3, '', 'admin/settings/language', 'Languages', 't', '', 6, '', 'Configure languages for content and the user interface.', '', 0, ''),
('admin/settings/logging', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'system_logging_overview', 'a:0:{}', 7, 3, '', 'admin/settings/logging', 'Logging and alerts', 't', '', 6, '', 'Settings for logging and alerts modules. Various modules can route Drupal''s system events to different destination, such as syslog, database, email, ...etc.', '', 0, 'modules/system/system.admin.inc'),
('admin/settings/nice_menus', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:25:"nice_menus_admin_settings";}', 7, 3, '', 'admin/settings/nice_menus', 'Nice menus', 't', '', 6, '', 'Configure Nice menus.', '', 0, ''),
('admin/reports/hits', '', '', 'user_access', 'a:1:{i:0;s:17:"access statistics";}', 'statistics_recent_hits', 'a:0:{}', 7, 3, '', 'admin/reports/hits', 'Recent hits', 't', '', 6, '', 'View pages that have recently been visited.', '', 0, 'modules/statistics/statistics.admin.inc'),
('admin/reports/dblog', '', '', 'user_access', 'a:1:{i:0;s:19:"access site reports";}', 'dblog_overview', 'a:0:{}', 7, 3, '', 'admin/reports/dblog', 'Recent log entries', 't', '', 6, '', 'View events that have recently been logged.', '', -1, 'modules/dblog/dblog.admin.inc'),
('admin/reports/status', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'system_status', 'a:0:{}', 7, 3, '', 'admin/reports/status', 'Status report', 't', '', 6, '', 'Get a status report about your site''s operation and any detected problems.', '', 10, 'modules/system/system.admin.inc'),
('taxonomy/term/%', 'a:1:{i:2;N;}', '', 'user_access', 'a:1:{i:0;s:14:"access content";}', 'i18ntaxonomy_term_page', 'a:1:{i:0;i:2;}', 6, 3, '', 'taxonomy/term/%', 'Taxonomy term', 't', '', 4, '', '', '', 0, 'sites/all/modules/i18n/i18ntaxonomy/i18ntaxonomy.pages.inc'),
('devel/theme/registry', '', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'devel_theme_registry', 'a:0:{}', 7, 3, '', 'devel/theme/registry', 'Theme registry', 't', '', 6, '', 'View a list of available theme functions across the whole site.', '', 0, ''),
('admin/reports/pages', '', '', 'user_access', 'a:1:{i:0;s:17:"access statistics";}', 'statistics_top_pages', 'a:0:{}', 7, 3, '', 'admin/reports/pages', 'Top pages', 't', '', 6, '', 'View pages that have been hit frequently.', '', 1, 'modules/statistics/statistics.admin.inc'),
('admin/reports/referrers', '', '', 'user_access', 'a:1:{i:0;s:17:"access statistics";}', 'statistics_top_referrers', 'a:0:{}', 7, 3, '', 'admin/reports/referrers', 'Top referrers', 't', '', 6, '', 'View top referrers.', '', 0, 'modules/statistics/statistics.admin.inc'),
('admin/reports/visitors', '', '', 'user_access', 'a:1:{i:0;s:17:"access statistics";}', 'statistics_top_visitors', 'a:0:{}', 7, 3, '', 'admin/reports/visitors', 'Top visitors', 't', '', 6, '', 'View visitors that hit many pages.', '', 2, 'modules/statistics/statistics.admin.inc'),
('node/%/track', 'a:1:{i:1;s:9:"node_load";}', '', 'user_access', 'a:1:{i:0;s:17:"access statistics";}', 'statistics_node_tracker', 'a:0:{}', 5, 3, 'node/%', 'node/%', 'Track', 't', '', 128, '', '', '', 2, 'modules/statistics/statistics.pages.inc'),
('admin/build/translate', '', '', 'user_access', 'a:1:{i:0;s:19:"translate interface";}', 'locale_inc_callback', 'a:1:{i:0;s:32:"locale_translate_overview_screen";}', 7, 3, '', 'admin/build/translate', 'Translate interface', 't', '', 6, '', 'Translate the built in interface and optionally other text.', '', 0, ''),
('admin/build/path', '', '', 'user_access', 'a:1:{i:0;s:22:"administer url aliases";}', 'path_admin_overview', 'a:0:{}', 7, 3, '', 'admin/build/path', 'URL aliases', 't', '', 6, '', 'Change your site''s URL paths by aliasing them.', '', 0, 'modules/path/path.admin.inc'),
('admin/help/admin_menu', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/admin_menu', 'admin_menu', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/better_formats', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/better_formats', 'better_formats', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/block', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/block', 'block', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/color', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/color', 'color', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/comment', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/comment', 'comment', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/contact', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/contact', 'contact', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/content', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/content', 'content', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/date', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/date', 'date', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/dblog', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/dblog', 'dblog', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/devel', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/devel', 'devel', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/filter', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/filter', 'filter', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/googleanalytics', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/googleanalytics', 'googleanalytics', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/help', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/help', 'help', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/i18n', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/i18n', 'i18n', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/i18nblocks', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/i18nblocks', 'i18nblocks', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/i18ncontent', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/i18ncontent', 'i18ncontent', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/i18nmenu', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/i18nmenu', 'i18nmenu', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/i18nprofile', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/i18nprofile', 'i18nprofile', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/i18nstrings', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/i18nstrings', 'i18nstrings', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/i18nsync', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/i18nsync', 'i18nsync', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/i18ntaxonomy', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/i18ntaxonomy', 'i18ntaxonomy', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/languageicons', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/languageicons', 'languageicons', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/lightbox2', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/lightbox2', 'lightbox2', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/locale', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/locale', 'locale', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/menu', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/menu', 'menu', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/nice_menus', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/nice_menus', 'nice_menus', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/node', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/node', 'node', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/path', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/path', 'path', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/pathauto', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/pathauto', 'pathauto', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/php', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/php', 'php', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/poll', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/poll', 'poll', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/profile', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/profile', 'profile', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/search', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/search', 'search', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/statistics', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/statistics', 'statistics', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/syslog', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/syslog', 'syslog', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/system', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/system', 'system', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/taxonomy', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/taxonomy', 'taxonomy', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/token', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/token', 'token', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/translation', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/translation', 'translation', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/update', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/update', 'update', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/user', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/user', 'user', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/views_ui', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/views_ui', 'views_ui', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/viewsphpfilter', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/viewsphpfilter', 'viewsphpfilter', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/help/wysiwyg', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'help_page', 'a:1:{i:0;i:2;}', 7, 3, '', 'admin/help/wysiwyg', 'wysiwyg', 't', '', 4, '', '', '', 0, 'modules/help/help.admin.inc'),
('admin/reports/settings', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:34:"statistics_access_logging_settings";}', 7, 3, '', 'admin/reports/settings', 'Access log settings', 't', '', 6, '', 'Control details about what and how your site logs.', '', 3, 'modules/statistics/statistics.admin.inc'),
('admin/settings/admin_menu', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:25:"admin_menu_theme_settings";}', 7, 3, '', 'admin/settings/admin_menu', 'Administration menu', 't', '', 6, '', 'Adjust administration menu settings.', '', 0, 'sites/all/modules/admin_menu/admin_menu.inc'),
('admin/settings/clean-urls', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:25:"system_clean_url_settings";}', 7, 3, '', 'admin/settings/clean-urls', 'Clean URLs', 't', '', 6, '', 'Enable or disable clean URLs for your site.', '', 0, 'modules/system/system.admin.inc'),
('user/%/contact', 'a:1:{i:1;s:9:"user_load";}', '', '_contact_user_tab_access', 'a:1:{i:0;i:1;}', 'contact_user_page', 'a:1:{i:0;i:1;}', 5, 3, 'user/%', 'user/%', 'Contact', 't', '', 128, '', '', '', 2, 'modules/contact/contact.pages.inc'),
('admin/content/node', '', '', 'user_access', 'a:1:{i:0;s:16:"administer nodes";}', 'drupal_get_form', 'a:1:{i:0;s:18:"node_admin_content";}', 7, 3, '', 'admin/content/node', 'Content', 't', '', 6, '', 'View, edit, and delete your site''s content.', '', 0, 'modules/node/node.admin.inc'),
('admin/content/types', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'content_types_overview', 'a:0:{}', 7, 3, '', 'admin/content/types', 'Content types', 't', '', 6, '', 'Manage posts by content type, including default status, front page promotion, etc.', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/settings/date-time', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:25:"system_date_time_settings";}', 7, 3, '', 'admin/settings/date-time', 'Date and time', 't', '', 6, '', 'Settings for how Drupal displays date and time, as well as the system''s default timezone.', '', 0, 'modules/system/system.admin.inc'),
('node/%/delete', 'a:1:{i:1;s:9:"node_load";}', '', 'node_access', 'a:2:{i:0;s:6:"delete";i:1;i:1;}', 'drupal_get_form', 'a:2:{i:0;s:19:"node_delete_confirm";i:1;i:1;}', 5, 3, '', 'node/%/delete', 'Delete', 't', '', 4, '', '', '', 1, 'modules/node/node.pages.inc'),
('user/%/delete', 'a:1:{i:1;s:9:"user_load";}', '', 'user_access', 'a:1:{i:0;s:16:"administer users";}', 'drupal_get_form', 'a:2:{i:0;s:19:"user_confirm_delete";i:1;i:1;}', 5, 3, '', 'user/%/delete', 'Delete', 't', '', 4, '', '', '', 0, 'modules/user/user.pages.inc'),
('admin/settings/devel', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:20:"devel_admin_settings";}', 7, 3, '', 'admin/settings/devel', 'Devel settings', 't', '', 6, '', 'Helper functions, pages, and blocks to assist Drupal developers. The devel blocks can be managed via the <a href="/admin/build/block">block administration</a> page.', '', 0, ''),
('node/%/edit', 'a:1:{i:1;s:9:"node_load";}', '', 'node_access', 'a:2:{i:0;s:6:"update";i:1;i:1;}', 'node_page_edit', 'a:1:{i:0;i:1;}', 5, 3, 'node/%', 'node/%', 'Edit', 't', '', 128, '', '', '', 1, 'modules/node/node.pages.inc'),
('admin/settings/error-reporting', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:31:"system_error_reporting_settings";}', 7, 3, '', 'admin/settings/error-reporting', 'Error reporting', 't', '', 6, '', 'Control how Drupal deals with errors including 403/404 errors as well as PHP error reporting.', '', 0, 'modules/system/system.admin.inc'),
('user/%/imce', 'a:1:{i:1;s:9:"user_load";}', '', 'imce_user_page_access', 'a:1:{i:0;i:1;}', 'imce_user_page', 'a:1:{i:0;i:1;}', 5, 3, 'user/%', 'user/%', 'File browser', 't', '', 128, '', '', '', 10, 'sites/all/modules/imce/inc/imce.page.inc'),
('admin/settings/file-system', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:27:"system_file_system_settings";}', 7, 3, '', 'admin/settings/file-system', 'File system', 't', '', 6, '', 'Tell Drupal where to store uploaded files and how they are accessed.', '', 0, 'modules/system/system.admin.inc'),
('admin/settings/googleanalytics', '', '', 'user_access', 'a:1:{i:0;s:27:"administer google analytics";}', 'drupal_get_form', 'a:1:{i:0;s:35:"googleanalytics_admin_settings_form";}', 7, 3, '', 'admin/settings/googleanalytics', 'Google Analytics', 't', '', 6, '', 'Configure the settings used to generate your Google Analytics tracking code.', '', 0, 'sites/all/modules/google_analytics/googleanalytics.admin.inc'),
('admin/settings/image-toolkit', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:29:"system_image_toolkit_settings";}', 7, 3, '', 'admin/settings/image-toolkit', 'Image toolkit', 't', '', 6, '', 'Choose which image toolkit to use if you have installed optional toolkits.', '', 0, 'modules/system/system.admin.inc'),
('admin/settings/filters', '', '', 'user_access', 'a:1:{i:0;s:18:"administer filters";}', 'drupal_get_form', 'a:1:{i:0;s:21:"filter_admin_overview";}', 7, 3, '', 'admin/settings/filters', 'Input formats', 't', '', 6, '', 'Configure how content input by users is filtered, including allowed HTML tags. Also allows enabling of module-provided filters.', '', 0, 'modules/filter/filter.admin.inc'),
('admin/settings/lightbox2', '', '', 'user_access', 'a:1:{i:0;s:20:"administer lightbox2";}', 'lightbox2_settings_page', 'a:0:{}', 7, 3, '', 'admin/settings/lightbox2', 'Lightbox2', 't', '', 6, '', 'Allows the user to configure the lightbox2 settings', '', 0, 'sites/all/modules/lightbox2/lightbox2.admin.inc'),
('admin/build/menu', '', '', 'user_access', 'a:1:{i:0;s:15:"administer menu";}', 'menu_overview_page', 'a:0:{}', 7, 3, '', 'admin/build/menu', 'Menus', 't', '', 6, '', 'Control your site''s navigation menu, primary links and secondary links, as well as rename and reorganize menu items.', '', 0, 'modules/menu/menu.admin.inc'),
('admin/build/modules', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:14:"system_modules";}', 7, 3, '', 'admin/build/modules', 'Modules', 't', '', 6, '', 'Enable or disable add-on modules for your site.', '', 0, 'modules/system/system.admin.inc'),
('admin/settings/performance', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:27:"system_performance_settings";}', 7, 3, '', 'admin/settings/performance', 'Performance', 't', '', 6, '', 'Enable or disable page caching for anonymous users and set CSS and JS bandwidth optimization options.', '', 0, 'modules/system/system.admin.inc'),
('admin/user/permissions', '', '', 'user_access', 'a:1:{i:0;s:22:"administer permissions";}', 'drupal_get_form', 'a:1:{i:0;s:15:"user_admin_perm";}', 7, 3, '', 'admin/user/permissions', 'Permissions', 't', '', 6, '', 'Determine access to features by selecting permissions for roles.', '', 0, 'modules/user/user.admin.inc'),
('admin/content/node-settings', '', '', 'user_access', 'a:1:{i:0;s:16:"administer nodes";}', 'drupal_get_form', 'a:1:{i:0;s:14:"node_configure";}', 7, 3, '', 'admin/content/node-settings', 'Post settings', 't', '', 6, '', 'Control posting behavior, such as teaser length, requiring previews before posting, and the number of posts on the front page.', '', 0, 'modules/node/node.admin.inc'),
('admin/user/profile', '', '', 'user_access', 'a:1:{i:0;s:16:"administer users";}', 'drupal_get_form', 'a:1:{i:0;s:22:"profile_admin_overview";}', 7, 3, '', 'admin/user/profile', 'Profiles', 't', '', 6, '', 'Create customizable fields for your users.', '', 0, 'modules/profile/profile.admin.inc'),
('admin/content/rss-publishing', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:25:"system_rss_feeds_settings";}', 7, 3, '', 'admin/content/rss-publishing', 'RSS publishing', 't', '', 6, '', 'Configure the number of items per feed and whether feeds should be titles/teasers/full-text.', '', 0, 'modules/system/system.admin.inc'),
('devel/menu/reset', '', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'drupal_get_form', 'a:1:{i:0;s:18:"devel_menu_rebuild";}', 7, 3, '', 'devel/menu/reset', 'Rebuild menus', 't', '', 6, '', 'Rebuild menu based on hook_menu() and revert any custom changes. All menu items return to their default settings.', '', 0, ''),
('comment/reply/%', 'a:1:{i:2;s:9:"node_load";}', '', 'node_access', 'a:2:{i:0;s:4:"view";i:1;i:2;}', 'comment_reply', 'a:1:{i:0;i:2;}', 6, 3, '', 'comment/reply/%', 'Reply to comment', 't', '', 4, '', '', '', 0, 'modules/comment/comment.pages.inc'),
('node/%/results', 'a:1:{i:1;s:9:"node_load";}', '', '_poll_menu_access', 'a:3:{i:0;i:1;i:1;s:14:"access content";i:2;b:1;}', 'poll_results', 'a:1:{i:0;i:1;}', 5, 3, 'node/%', 'node/%', 'Results', 't', '', 128, '', '', '', 3, 'modules/poll/poll.pages.inc'),
('node/%/revisions', 'a:1:{i:1;s:9:"node_load";}', '', '_node_revision_access', 'a:1:{i:0;i:1;}', 'node_revision_overview', 'a:1:{i:0;i:1;}', 5, 3, 'node/%', 'node/%', 'Revisions', 't', '', 128, '', '', '', 2, 'modules/node/node.pages.inc'),
('admin/user/roles', '', '', 'user_access', 'a:1:{i:0;s:22:"administer permissions";}', 'drupal_get_form', 'a:1:{i:0;s:19:"user_admin_new_role";}', 7, 3, '', 'admin/user/roles', 'Roles', 't', '', 6, '', 'List, edit, or add user roles.', '', 0, 'modules/user/user.admin.inc'),
('admin/settings/search', '', '', 'user_access', 'a:1:{i:0;s:17:"administer search";}', 'drupal_get_form', 'a:1:{i:0;s:21:"search_admin_settings";}', 7, 3, '', 'admin/settings/search', 'Search settings', 't', '', 6, '', 'Configure relevance settings for search and other indexing options', '', 0, 'modules/search/search.admin.inc'),
('admin/settings/site-information', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:32:"system_site_information_settings";}', 7, 3, '', 'admin/settings/site-information', 'Site information', 't', '', 6, '', 'Change basic site information, such as the site name, slogan, e-mail address, mission, front page and more.', '', 0, 'modules/system/system.admin.inc'),
('admin/settings/site-maintenance', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:32:"system_site_maintenance_settings";}', 7, 3, '', 'admin/settings/site-maintenance', 'Site maintenance', 't', '', 6, '', 'Take the site off-line for maintenance or bring it back online.', '', 0, 'modules/system/system.admin.inc'),
('admin/content/taxonomy', '', '', 'user_access', 'a:1:{i:0;s:19:"administer taxonomy";}', 'drupal_get_form', 'a:1:{i:0;s:30:"taxonomy_overview_vocabularies";}', 7, 3, '', 'admin/content/taxonomy', 'Taxonomy', 't', '', 6, '', 'Manage tagging, categorization, and classification of your content.', '', 0, 'modules/taxonomy/taxonomy.admin.inc'),
('admin/build/themes', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:2:{i:0;s:18:"system_themes_form";i:1;N;}', 7, 3, '', 'admin/build/themes', 'Themes', 't', '', 6, '', 'Change which theme your site uses or allows users to set.', '', 0, 'modules/system/system.admin.inc'),
('admin/reports/access-denied', '', '', 'user_access', 'a:1:{i:0;s:19:"access site reports";}', 'dblog_top', 'a:1:{i:0;s:13:"access denied";}', 7, 3, '', 'admin/reports/access-denied', 'Top ''access denied'' errors', 't', '', 6, '', 'View ''access denied'' errors (403s).', '', 0, 'modules/dblog/dblog.admin.inc'),
('admin/reports/page-not-found', '', '', 'user_access', 'a:1:{i:0;s:19:"access site reports";}', 'dblog_top', 'a:1:{i:0;s:14:"page not found";}', 7, 3, '', 'admin/reports/page-not-found', 'Top ''page not found'' errors', 't', '', 6, '', 'View ''page not found'' errors (404s).', '', 0, 'modules/dblog/dblog.admin.inc'),
('node/%/translate', 'a:1:{i:1;s:9:"node_load";}', '', '_translation_tab_access', 'a:1:{i:0;i:1;}', 'i18n_translation_node_overview', 'a:1:{i:0;i:1;}', 5, 3, 'node/%', 'node/%', 'Translate', 't', '', 128, '', '', '', 2, 'sites/all/modules/i18n/i18n.pages.inc'),
('admin/user/settings', '', '', 'user_access', 'a:1:{i:0;s:16:"administer users";}', 'drupal_get_form', 'a:1:{i:0;s:19:"user_admin_settings";}', 7, 3, '', 'admin/user/settings', 'User settings', 't', '', 6, '', 'Configure default behavior of users, including registration requirements, e-mails, and user pictures.', '', 0, 'modules/user/user.admin.inc'),
('admin/user/user', '', '', 'user_access', 'a:1:{i:0;s:16:"administer users";}', 'user_admin', 'a:1:{i:0;s:4:"list";}', 7, 3, '', 'admin/user/user', 'Users', 't', '', 6, '', 'List, add, and edit users.', '', 0, 'modules/user/user.admin.inc'),
('admin/settings/wysiwyg', '', '', 'user_access', 'a:1:{i:0;s:18:"administer filters";}', 'drupal_get_form', 'a:1:{i:0;s:24:"wysiwyg_profile_overview";}', 7, 3, '', 'admin/settings/wysiwyg', 'Wysiwyg profiles', 't', '', 6, '', 'Configure client-side editors.', '', 0, 'sites/all/modules/wysiwyg/wysiwyg.admin.inc'),
('admin/build/views', '', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'views_ui_list_views', 'a:0:{}', 7, 3, '', 'admin/build/views', 'Views', 't', '', 6, '', 'Views are customized lists of content on your system; they are highly configurable and give you control over how lists of content are presented.', '', 0, 'sites/all/modules/views/includes/admin.inc'),
('node/%/votes', 'a:1:{i:1;s:9:"node_load";}', '', '_poll_menu_access', 'a:3:{i:0;i:1;i:1;s:17:"inspect all votes";i:2;b:0;}', 'poll_votes', 'a:1:{i:0;i:1;}', 5, 3, 'node/%', 'node/%', 'Votes', 't', '', 128, '', '', '', 3, 'modules/poll/poll.pages.inc'),
('user/%/edit', 'a:1:{i:1;a:1:{s:18:"user_category_load";a:2:{i:0;s:4:"%map";i:1;s:6:"%index";}}}', '', 'user_edit_access', 'a:1:{i:0;i:1;}', 'user_edit', 'a:1:{i:0;i:1;}', 5, 3, 'user/%', 'user/%', 'Edit', 't', '', 128, '', '', '', 0, 'modules/user/user.pages.inc'),
('admin/reports/search', '', '', 'user_access', 'a:1:{i:0;s:19:"access site reports";}', 'dblog_top', 'a:1:{i:0;s:6:"search";}', 7, 3, '', 'admin/reports/search', 'Top search phrases', 't', '', 6, '', 'View most popular search phrases.', '', 0, 'modules/dblog/dblog.admin.inc'),
('admin/settings/admin', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:27:"system_admin_theme_settings";}', 7, 3, '', 'admin/settings/admin', 'Administration theme', 't', '', 6, 'system_admin_theme_settings', 'Settings for how your administrative pages should look.', 'left', 0, 'modules/system/system.admin.inc'),
('search/node/%', 'a:1:{i:2;N;}', 'a:1:{i:2;s:16:"menu_tail_to_arg";}', '_search_menu', 'a:1:{i:0;s:4:"node";}', 'search_view', 'a:1:{i:0;s:4:"node";}', 6, 3, 'search', 'search', '', 'module_invoke', 'a:4:{i:0;s:4:"node";i:1;s:6:"search";i:2;s:4:"name";i:3;b:1;}', 128, '', '', '', 0, 'modules/search/search.pages.inc'),
('node/add/distribution', '', '', 'node_access', 'a:2:{i:0;s:6:"create";i:1;s:12:"distribution";}', 'i18ncontent_node_add', 'a:1:{i:0;i:2;}', 7, 3, '', 'node/add/distribution', 'Distribution', 'i18nstrings_title_callback', 'a:2:{i:0;s:31:"nodetype:type:distribution:name";i:1;s:12:"Distribution";}', 6, '', '', '', 0, 'modules/node/node.pages.inc'),
('search/user/%', 'a:1:{i:2;N;}', 'a:1:{i:2;s:16:"menu_tail_to_arg";}', '_search_menu', 'a:1:{i:0;s:4:"user";}', 'search_view', 'a:1:{i:0;s:4:"user";}', 6, 3, 'search', 'search', '', 'module_invoke', 'a:4:{i:0;s:4:"user";i:1;s:6:"search";i:2;s:4:"name";i:3;b:1;}', 128, '', '', '', 0, 'modules/search/search.pages.inc'),
('node/add/contact', '', '', 'node_access', 'a:2:{i:0;s:6:"create";i:1;s:7:"contact";}', 'i18ncontent_node_add', 'a:1:{i:0;i:2;}', 7, 3, '', 'node/add/contact', 'Contact', 'i18nstrings_title_callback', 'a:2:{i:0;s:26:"nodetype:type:contact:name";i:1;s:7:"Contact";}', 6, '', '', '', 0, 'modules/node/node.pages.inc'),
('node/add/home', '', '', 'node_access', 'a:2:{i:0;s:6:"create";i:1;s:4:"home";}', 'i18ncontent_node_add', 'a:1:{i:0;i:2;}', 7, 3, '', 'node/add/home', 'Home', 'i18nstrings_title_callback', 'a:2:{i:0;s:23:"nodetype:type:home:name";i:1;s:4:"Home";}', 6, '', '', '', 0, 'modules/node/node.pages.inc'),
('node/add/intro', '', '', 'node_access', 'a:2:{i:0;s:6:"create";i:1;s:5:"intro";}', 'i18ncontent_node_add', 'a:1:{i:0;i:2;}', 7, 3, '', 'node/add/intro', 'Intro', 'i18nstrings_title_callback', 'a:2:{i:0;s:24:"nodetype:type:intro:name";i:1;s:5:"Intro";}', 6, '', '', '', 0, 'modules/node/node.pages.inc'),
('node/add/page', '', '', 'node_access', 'a:2:{i:0;s:6:"create";i:1;s:4:"page";}', 'i18ncontent_node_add', 'a:1:{i:0;i:2;}', 7, 3, '', 'node/add/page', 'Page', 'i18nstrings_title_callback', 'a:2:{i:0;s:23:"nodetype:type:page:name";i:1;s:4:"Page";}', 6, '', 'A <em>page</em>, similar in form to a <em>story</em>, is a simple method for creating and displaying information that rarely changes, such as an "About us" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site''s initial home page.', '', 0, 'modules/node/node.pages.inc'),
('node/add/poll', '', '', 'node_access', 'a:2:{i:0;s:6:"create";i:1;s:4:"poll";}', 'i18ncontent_node_add', 'a:1:{i:0;i:2;}', 7, 3, '', 'node/add/poll', 'Poll', 'i18nstrings_title_callback', 'a:2:{i:0;s:23:"nodetype:type:poll:name";i:1;s:4:"Poll";}', 6, '', 'A <em>poll</em> is a question with a set of possible responses. A <em>poll</em>, once created, automatically provides a simple running count of the number of votes received for each response.', '', 0, 'modules/node/node.pages.inc'),
('node/add/story', '', '', 'node_access', 'a:2:{i:0;s:6:"create";i:1;s:5:"story";}', 'i18ncontent_node_add', 'a:1:{i:0;i:2;}', 7, 3, '', 'node/add/story', 'Story', 'i18nstrings_title_callback', 'a:2:{i:0;s:24:"nodetype:type:story:name";i:1;s:5:"Story";}', 6, '', 'A <em>story</em>, similar in form to a <em>page</em>, is ideal for creating and displaying content that informs or engages website visitors. Press releases, site announcements, and informal blog-like entries may all be created with a <em>story</em> entry. By default, a <em>story</em> entry is automatically featured on the site''s initial home page, and provides the ability to post comments.', '', 0, 'modules/node/node.pages.inc'),
('admin/build/block/list', '', '', 'user_access', 'a:1:{i:0;s:17:"administer blocks";}', 'block_admin_display', 'a:0:{}', 15, 4, 'admin/build/block', 'admin/build/block', 'List', 't', '', 136, '', '', '', -10, 'modules/block/block.admin.inc'),
('admin/content/node/overview', '', '', 'user_access', 'a:1:{i:0;s:16:"administer nodes";}', 'drupal_get_form', 'a:1:{i:0;s:18:"node_admin_content";}', 15, 4, 'admin/content/node', 'admin/content/node', 'List', 't', '', 136, '', '', '', -10, 'modules/node/node.admin.inc');
INSERT INTO `menu_router` (`path`, `load_functions`, `to_arg_functions`, `access_callback`, `access_arguments`, `page_callback`, `page_arguments`, `fit`, `number_parts`, `tab_parent`, `tab_root`, `title`, `title_callback`, `title_arguments`, `type`, `block_callback`, `description`, `position`, `weight`, `file`) VALUES
('admin/content/types/list', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'content_types_overview', 'a:0:{}', 15, 4, 'admin/content/types', 'admin/content/types', 'List', 't', '', 136, '', '', '', -10, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/build/path/list', '', '', 'user_access', 'a:1:{i:0;s:22:"administer url aliases";}', 'path_admin_overview', 'a:0:{}', 15, 4, 'admin/build/path', 'admin/build/path', 'List', 't', '', 136, '', '', '', -10, 'modules/path/path.admin.inc'),
('admin/content/taxonomy/list', '', '', 'user_access', 'a:1:{i:0;s:19:"administer taxonomy";}', 'drupal_get_form', 'a:1:{i:0;s:30:"taxonomy_overview_vocabularies";}', 15, 4, 'admin/content/taxonomy', 'admin/content/taxonomy', 'List', 't', '', 136, '', '', '', -10, 'modules/taxonomy/taxonomy.admin.inc'),
('admin/user/rules/list', '', '', 'user_access', 'a:1:{i:0;s:22:"administer permissions";}', 'user_admin_access', 'a:0:{}', 15, 4, 'admin/user/rules', 'admin/user/rules', 'List', 't', '', 136, '', '', '', -10, 'modules/user/user.admin.inc'),
('admin/user/user/list', '', '', 'user_access', 'a:1:{i:0;s:16:"administer users";}', 'user_admin', 'a:1:{i:0;s:4:"list";}', 15, 4, 'admin/user/user', 'admin/user/user', 'List', 't', '', 136, '', '', '', -10, 'modules/user/user.admin.inc'),
('admin/settings/filters/list', '', '', 'user_access', 'a:1:{i:0;s:18:"administer filters";}', 'drupal_get_form', 'a:1:{i:0;s:21:"filter_admin_overview";}', 15, 4, 'admin/settings/filters', 'admin/settings/filters', 'List', 't', '', 136, '', '', '', 0, 'modules/filter/filter.admin.inc'),
('admin/settings/language/overview', '', '', 'user_access', 'a:1:{i:0;s:20:"administer languages";}', 'locale_inc_callback', 'a:2:{i:0;s:15:"drupal_get_form";i:1;s:30:"locale_languages_overview_form";}', 15, 4, 'admin/settings/language', 'admin/settings/language', 'List', 't', '', 136, '', '', '', 0, ''),
('admin/build/modules/list', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:14:"system_modules";}', 15, 4, 'admin/build/modules', 'admin/build/modules', 'List', 't', '', 136, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/settings/wysiwyg/profile', '', '', 'user_access', 'a:1:{i:0;s:18:"administer filters";}', 'drupal_get_form', 'a:1:{i:0;s:24:"wysiwyg_profile_overview";}', 15, 4, 'admin/settings/wysiwyg', 'admin/settings/wysiwyg', 'List', 't', '', 136, '', '', '', 0, 'sites/all/modules/wysiwyg/wysiwyg.admin.inc'),
('admin/build/translate/overview', '', '', 'user_access', 'a:1:{i:0;s:19:"translate interface";}', 'locale_inc_callback', 'a:1:{i:0;s:32:"locale_translate_overview_screen";}', 15, 4, 'admin/build/translate', 'admin/build/translate', 'Overview', 't', '', 136, '', '', '', 0, ''),
('admin/content/comment/new', '', '', 'user_access', 'a:1:{i:0;s:19:"administer comments";}', 'comment_admin', 'a:0:{}', 15, 4, 'admin/content/comment', 'admin/content/comment', 'Published comments', 't', '', 136, '', '', '', -10, 'modules/comment/comment.admin.inc'),
('user/%/edit/account', 'a:1:{i:1;a:1:{s:18:"user_category_load";a:2:{i:0;s:4:"%map";i:1;s:6:"%index";}}}', '', 'user_edit_access', 'a:1:{i:0;i:1;}', 'user_edit', 'a:1:{i:0;i:1;}', 11, 4, 'user/%/edit', 'user/%', 'Account', 't', '', 136, '', '', '', 0, 'modules/user/user.pages.inc'),
('admin/build/themes/select', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:2:{i:0;s:18:"system_themes_form";i:1;N;}', 15, 4, 'admin/build/themes', 'admin/build/themes', 'List', 't', '', 136, '', 'Select the default theme.', '', -1, 'modules/system/system.admin.inc'),
('admin/build/menu/list', '', '', 'user_access', 'a:1:{i:0;s:15:"administer menu";}', 'menu_overview_page', 'a:0:{}', 15, 4, 'admin/build/menu', 'admin/build/menu', 'List menus', 't', '', 136, '', '', '', -10, 'modules/menu/menu.admin.inc'),
('sites/default/files/imagecache', '', '', '_imagecache_menu_access_public_files', 'a:0:{}', 'imagecache_cache', 'a:0:{}', 15, 4, '', 'sites/default/files/imagecache', '', 't', '', 4, '', '', '', 0, ''),
('admin/build/themes/settings', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:21:"system_theme_settings";}', 15, 4, 'admin/build/themes', 'admin/build/themes', 'Configure', 't', '', 128, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/build/contact/list', '', '', 'user_access', 'a:1:{i:0;s:33:"administer site-wide contact form";}', 'contact_admin_categories', 'a:0:{}', 15, 4, 'admin/build/contact', 'admin/build/contact', 'List', 't', '', 136, '', '', '', 0, 'modules/contact/contact.admin.inc'),
('admin/settings/actions/manage', '', '', 'user_access', 'a:1:{i:0;s:18:"administer actions";}', 'system_actions_manage', 'a:0:{}', 15, 4, 'admin/settings/actions', 'admin/settings/actions', 'Manage actions', 't', '', 136, '', 'Manage the actions defined for your site.', '', -2, ''),
('admin/settings/actions/orphan', '', '', 'user_access', 'a:1:{i:0;s:18:"administer actions";}', 'system_actions_remove_orphans', 'a:0:{}', 15, 4, '', 'admin/settings/actions/orphan', 'Remove orphans', 't', '', 4, '', '', '', 0, ''),
('admin/build/modules/uninstall', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:24:"system_modules_uninstall";}', 15, 4, 'admin/build/modules', 'admin/build/modules', 'Uninstall', 't', '', 128, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/build/path/add', '', '', 'user_access', 'a:1:{i:0;s:22:"administer url aliases";}', 'path_admin_edit', 'a:0:{}', 15, 4, 'admin/build/path', 'admin/build/path', 'Add alias', 't', '', 128, '', '', '', 0, 'modules/path/path.admin.inc'),
('admin/settings/filters/add', '', '', 'user_access', 'a:1:{i:0;s:18:"administer filters";}', 'filter_admin_format_page', 'a:0:{}', 15, 4, 'admin/settings/filters', 'admin/settings/filters', 'Add input format', 't', '', 128, '', '', '', 1, 'modules/filter/filter.admin.inc'),
('admin/settings/language/add', '', '', 'user_access', 'a:1:{i:0;s:20:"administer languages";}', 'locale_inc_callback', 'a:1:{i:0;s:27:"locale_languages_add_screen";}', 15, 4, 'admin/settings/language', 'admin/settings/language', 'Add language', 't', '', 128, '', '', '', 5, ''),
('admin/settings/imce/profile', '', '', 'user_access', 'a:1:{i:0;s:28:"administer imce(execute PHP)";}', 'imce_profile_operations', 'a:0:{}', 15, 4, '', 'admin/settings/imce/profile', 'Add new profile', 't', '', 4, '', '', '', 0, 'sites/all/modules/imce/inc/imce.admin.inc'),
('admin/user/rules/add', '', '', 'user_access', 'a:1:{i:0;s:22:"administer permissions";}', 'user_admin_access_add', 'a:0:{}', 15, 4, 'admin/user/rules', 'admin/user/rules', 'Add rule', 't', '', 128, '', '', '', 0, 'modules/user/user.admin.inc'),
('admin/user/user/create', '', '', 'user_access', 'a:1:{i:0;s:16:"administer users";}', 'user_admin', 'a:1:{i:0;s:6:"create";}', 15, 4, 'admin/user/user', 'admin/user/user', 'Add user', 't', '', 128, '', '', '', 0, 'modules/user/user.admin.inc'),
('admin/content/comment/approval', '', '', 'user_access', 'a:1:{i:0;s:19:"administer comments";}', 'comment_admin', 'a:1:{i:0;s:8:"approval";}', 15, 4, 'admin/content/comment', 'admin/content/comment', 'Approval queue', 't', '', 128, '', '', '', 0, 'modules/comment/comment.admin.inc'),
('admin/user/rules/check', '', '', 'user_access', 'a:1:{i:0;s:22:"administer permissions";}', 'user_admin_access_check', 'a:0:{}', 15, 4, 'admin/user/rules', 'admin/user/rules', 'Check rules', 't', '', 128, '', '', '', 0, 'modules/user/user.admin.inc'),
('admin/settings/clean-urls/check', '', '', '1', 'a:0:{}', 'drupal_json', 'a:1:{i:0;a:1:{s:6:"status";b:1;}}', 15, 4, '', 'admin/settings/clean-urls/check', 'Clean URL check', 't', '', 4, '', '', '', 0, ''),
('admin/settings/language/configure', '', '', 'user_access', 'a:1:{i:0;s:20:"administer languages";}', 'locale_inc_callback', 'a:2:{i:0;s:15:"drupal_get_form";i:1;s:31:"locale_languages_configure_form";}', 15, 4, 'admin/settings/language', 'admin/settings/language', 'Configure', 't', '', 128, '', '', '', 10, ''),
('admin/settings/actions/configure', '', '', 'user_access', 'a:1:{i:0;s:18:"administer actions";}', 'drupal_get_form', 'a:1:{i:0;s:24:"system_actions_configure";}', 15, 4, '', 'admin/settings/actions/configure', 'Configure an advanced action', 't', '', 4, '', '', '', 0, ''),
('admin/settings/date-time/lookup', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'system_date_time_lookup', 'a:0:{}', 15, 4, '', 'admin/settings/date-time/lookup', 'Date and time lookup', 't', '', 4, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/build/path/edit', '', '', 'user_access', 'a:1:{i:0;s:22:"administer url aliases";}', 'path_admin_edit', 'a:0:{}', 15, 4, '', 'admin/build/path/edit', 'Edit alias', 't', '', 4, '', '', '', 0, 'modules/path/path.admin.inc'),
('admin/user/roles/edit', '', '', 'user_access', 'a:1:{i:0;s:22:"administer permissions";}', 'drupal_get_form', 'a:1:{i:0;s:15:"user_admin_role";}', 15, 4, '', 'admin/user/roles/edit', 'Edit role', 't', '', 4, '', '', '', 0, 'modules/user/user.admin.inc'),
('admin/user/rules/edit', '', '', 'user_access', 'a:1:{i:0;s:22:"administer permissions";}', 'user_admin_access_edit', 'a:0:{}', 15, 4, '', 'admin/user/rules/edit', 'Edit rule', 't', '', 4, '', '', '', 0, 'modules/user/user.admin.inc'),
('admin/content/types/export', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:1:{i:0;s:24:"content_copy_export_form";}', 15, 4, 'admin/content/types', 'admin/content/types', 'Export', 't', '', 128, '', '', '', 3, ''),
('admin/build/translate/export', '', '', 'user_access', 'a:1:{i:0;s:19:"translate interface";}', 'locale_inc_callback', 'a:1:{i:0;s:30:"locale_translate_export_screen";}', 15, 4, 'admin/build/translate', 'admin/build/translate', 'Export', 't', '', 128, '', '', '', 30, ''),
('admin/content/types/fields', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'content_fields_list', 'a:0:{}', 15, 4, 'admin/content/types', 'admin/content/types', 'Fields', 't', '', 128, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/types/import', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:1:{i:0;s:24:"content_copy_import_form";}', 15, 4, 'admin/content/types', 'admin/content/types', 'Import', 't', '', 128, '', '', '', 4, ''),
('admin/build/translate/import', '', '', 'user_access', 'a:1:{i:0;s:19:"translate interface";}', 'locale_inc_callback', 'a:2:{i:0;s:15:"drupal_get_form";i:1;s:28:"locale_translate_import_form";}', 15, 4, 'admin/build/translate', 'admin/build/translate', 'Import', 't', '', 128, '', '', '', 20, ''),
('admin/reports/updates/list', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'update_status', 'a:0:{}', 15, 4, 'admin/reports/updates', 'admin/reports/updates', 'List', 't', '', 136, '', '', '', 0, 'modules/update/update.report.inc'),
('admin/reports/updates/check', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'update_manual_status', 'a:0:{}', 15, 4, '', 'admin/reports/updates/check', 'Manual update check', 't', '', 4, '', '', '', 0, 'modules/update/update.fetch.inc'),
('admin/reports/status/php', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'system_php', 'a:0:{}', 15, 4, '', 'admin/reports/status/php', 'PHP', 't', '', 4, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/user/profile/autocomplete', '', '', 'user_access', 'a:1:{i:0;s:16:"administer users";}', 'profile_admin_settings_autocomplete', 'a:0:{}', 15, 4, '', 'admin/user/profile/autocomplete', 'Profile category autocomplete', 't', '', 4, '', '', '', 0, 'modules/profile/profile.admin.inc'),
('admin/content/node-settings/rebuild', '', '', 'user_access', 'a:1:{i:0;s:27:"access administration pages";}', 'drupal_get_form', 'a:1:{i:0;s:30:"node_configure_rebuild_confirm";}', 15, 4, '', 'admin/content/node-settings/rebuild', 'Rebuild permissions', 't', '', 4, '', '', '', 0, 'modules/node/node.admin.inc'),
('admin/build/translate/refresh', '', '', 'user_access', 'a:1:{i:0;s:19:"translate interface";}', 'i18nstrings_admin_refresh_page', 'a:0:{}', 15, 4, 'admin/build/translate', 'admin/build/translate', 'Refresh', 't', '', 128, '', '', '', 20, 'sites/all/modules/i18n/i18nstrings/i18nstrings.admin.inc'),
('admin/reports/status/run-cron', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'system_run_cron', 'a:0:{}', 15, 4, '', 'admin/reports/status/run-cron', 'Run cron', 't', '', 4, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/reports/status/sql', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'system_sql', 'a:0:{}', 15, 4, '', 'admin/reports/status/sql', 'SQL', 't', '', 4, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/build/translate/search', '', '', 'user_access', 'a:1:{i:0;s:19:"translate interface";}', 'locale_inc_callback', 'a:1:{i:0;s:28:"locale_translate_seek_screen";}', 15, 4, 'admin/build/translate', 'admin/build/translate', 'Search', 't', '', 128, '', '', '', 10, ''),
('admin/build/block/add', '', '', 'user_access', 'a:1:{i:0;s:17:"administer blocks";}', 'drupal_get_form', 'a:1:{i:0;s:20:"block_add_block_form";}', 15, 4, 'admin/build/block', 'admin/build/block', 'Add block', 't', '', 128, '', '', '', 0, 'modules/block/block.admin.inc'),
('admin/build/contact/add', '', '', 'user_access', 'a:1:{i:0;s:33:"administer site-wide contact form";}', 'drupal_get_form', 'a:2:{i:0;s:18:"contact_admin_edit";i:1;i:3;}', 15, 4, 'admin/build/contact', 'admin/build/contact', 'Add category', 't', '', 128, '', '', '', 1, 'modules/contact/contact.admin.inc'),
('admin/content/types/add', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:1:{i:0;s:14:"node_type_form";}', 15, 4, 'admin/content/types', 'admin/content/types', 'Add content type', 't', '', 128, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/user/profile/add', '', '', 'user_access', 'a:1:{i:0;s:16:"administer users";}', 'drupal_get_form', 'a:1:{i:0;s:18:"profile_field_form";}', 15, 4, '', 'admin/user/profile/add', 'Add field', 't', '', 4, '', '', '', 0, 'modules/profile/profile.admin.inc'),
('admin/build/menu/add', '', '', 'user_access', 'a:1:{i:0;s:15:"administer menu";}', 'drupal_get_form', 'a:2:{i:0;s:14:"menu_edit_menu";i:1;s:3:"add";}', 15, 4, 'admin/build/menu', 'admin/build/menu', 'Add menu', 't', '', 128, '', '', '', 0, 'modules/menu/menu.admin.inc'),
('admin/build/path/pathauto', '', '', 'user_access', 'a:1:{i:0;s:19:"administer pathauto";}', 'drupal_get_form', 'a:1:{i:0;s:23:"pathauto_admin_settings";}', 15, 4, 'admin/build/path', 'admin/build/path', 'Automated alias settings', 't', '', 128, '', '', '', 10, 'sites/all/modules/pathauto/pathauto.admin.inc'),
('admin/settings/search/wipe', '', '', 'user_access', 'a:1:{i:0;s:17:"administer search";}', 'drupal_get_form', 'a:1:{i:0;s:19:"search_wipe_confirm";}', 15, 4, '', 'admin/settings/search/wipe', 'Clear index', 't', '', 4, '', '', '', 0, 'modules/search/search.admin.inc'),
('admin/build/block/configure', '', '', 'user_access', 'a:1:{i:0;s:17:"administer blocks";}', 'drupal_get_form', 'a:1:{i:0;s:21:"block_admin_configure";}', 15, 4, '', 'admin/build/block/configure', 'Configure block', 't', '', 4, '', '', '', 0, 'modules/block/block.admin.inc'),
('admin/content/node-type/contact', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:14:"node_type_form";i:1;O:8:"stdClass":14:{s:4:"type";s:7:"contact";s:4:"name";s:7:"Contact";s:6:"module";s:4:"node";s:11:"description";s:0:"";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"0";s:10:"body_label";s:0:"";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:0:"";}}', 15, 4, '', 'admin/content/node-type/contact', 'Contact', 't', '', 4, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/build/path/delete', '', '', 'user_access', 'a:1:{i:0;s:22:"administer url aliases";}', 'drupal_get_form', 'a:1:{i:0;s:25:"path_admin_delete_confirm";}', 15, 4, '', 'admin/build/path/delete', 'Delete alias', 't', '', 4, '', '', '', 0, 'modules/path/path.admin.inc'),
('admin/build/path/delete_bulk', '', '', 'user_access', 'a:1:{i:0;s:22:"administer url aliases";}', 'drupal_get_form', 'a:1:{i:0;s:21:"pathauto_admin_delete";}', 15, 4, 'admin/build/path', 'admin/build/path', 'Delete aliases', 't', '', 128, '', '', '', 30, 'sites/all/modules/pathauto/pathauto.admin.inc'),
('admin/build/block/delete', '', '', 'user_access', 'a:1:{i:0;s:17:"administer blocks";}', 'drupal_get_form', 'a:1:{i:0;s:16:"block_box_delete";}', 15, 4, '', 'admin/build/block/delete', 'Delete block', 't', '', 4, '', '', '', 0, 'modules/block/block.admin.inc'),
('admin/user/profile/delete', '', '', 'user_access', 'a:1:{i:0;s:16:"administer users";}', 'drupal_get_form', 'a:1:{i:0;s:20:"profile_field_delete";}', 15, 4, '', 'admin/user/profile/delete', 'Delete field', 't', '', 4, '', '', '', 0, 'modules/profile/profile.admin.inc'),
('admin/settings/filters/delete', '', '', 'user_access', 'a:1:{i:0;s:18:"administer filters";}', 'drupal_get_form', 'a:1:{i:0;s:19:"filter_admin_delete";}', 15, 4, '', 'admin/settings/filters/delete', 'Delete input format', 't', '', 4, '', '', '', 0, 'modules/filter/filter.admin.inc'),
('admin/user/rules/delete', '', '', 'user_access', 'a:1:{i:0;s:22:"administer permissions";}', 'drupal_get_form', 'a:1:{i:0;s:32:"user_admin_access_delete_confirm";}', 15, 4, '', 'admin/user/rules/delete', 'Delete rule', 't', '', 4, '', '', '', 0, 'modules/user/user.admin.inc'),
('admin/reports/event/%', 'a:1:{i:3;N;}', '', 'user_access', 'a:1:{i:0;s:19:"access site reports";}', 'dblog_event', 'a:1:{i:0;i:3;}', 14, 4, '', 'admin/reports/event/%', 'Details', 't', '', 4, '', '', '', 0, 'modules/dblog/dblog.admin.inc'),
('node/%/devel/load', 'a:1:{i:1;s:9:"node_load";}', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'devel_load_object', 'a:2:{i:0;i:1;i:1;s:4:"node";}', 11, 4, 'node/%/devel', 'node/%', 'Dev load', 't', '', 136, '', '', '', 0, ''),
('user/%/devel/load', 'a:1:{i:1;s:9:"user_load";}', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'devel_load_object', 'a:2:{i:0;i:1;i:1;s:4:"user";}', 11, 4, 'user/%/devel', 'user/%', 'Dev load', 't', '', 136, '', '', '', 0, ''),
('node/%/devel/render', 'a:1:{i:1;s:9:"node_load";}', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'devel_render_object', 'a:2:{i:0;s:4:"node";i:1;i:1;}', 11, 4, 'node/%/devel', 'node/%', 'Dev render', 't', '', 128, '', '', '', 10, ''),
('user/%/devel/render', 'a:1:{i:1;s:9:"user_load";}', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'devel_render_object', 'a:2:{i:0;s:4:"user";i:1;i:1;}', 11, 4, 'user/%/devel', 'user/%', 'Dev render', 't', '', 128, '', '', '', 10, ''),
('admin/content/node-type/distribution', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:14:"node_type_form";i:1;O:8:"stdClass":14:{s:4:"type";s:12:"distribution";s:4:"name";s:12:"Distribution";s:6:"module";s:4:"node";s:11:"description";s:0:"";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"0";s:10:"body_label";s:0:"";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:0:"";}}', 15, 4, '', 'admin/content/node-type/distribution', 'Distribution', 't', '', 4, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/user/profile/edit', '', '', 'user_access', 'a:1:{i:0;s:16:"administer users";}', 'drupal_get_form', 'a:1:{i:0;s:18:"profile_field_form";}', 15, 4, '', 'admin/user/profile/edit', 'Edit field', 't', '', 4, '', '', '', 0, 'modules/profile/profile.admin.inc'),
('admin/content/node-type/home', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:14:"node_type_form";i:1;O:8:"stdClass":14:{s:4:"type";s:4:"home";s:4:"name";s:4:"Home";s:6:"module";s:4:"node";s:11:"description";s:0:"";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"0";s:10:"body_label";s:0:"";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:0:"";}}', 15, 4, '', 'admin/content/node-type/home', 'Home', 't', '', 4, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/settings/language/icons', '', '', 'user_access', 'a:1:{i:0;s:20:"administer languages";}', 'drupal_get_form', 'a:1:{i:0;s:28:"languageicons_admin_settings";}', 15, 4, 'admin/settings/language', 'admin/settings/language', 'Icons', 't', '', 128, '', '', '', 10, 'sites/all/modules/languageicons/languageicons.admin.inc'),
('admin/content/node-type/intro', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:14:"node_type_form";i:1;O:8:"stdClass":14:{s:4:"type";s:5:"intro";s:4:"name";s:5:"Intro";s:6:"module";s:4:"node";s:11:"description";s:0:"";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"0";s:10:"body_label";s:0:"";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:0:"";}}', 15, 4, '', 'admin/content/node-type/intro', 'Intro', 't', '', 4, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/build/contact/settings', '', '', 'user_access', 'a:1:{i:0;s:33:"administer site-wide contact form";}', 'drupal_get_form', 'a:1:{i:0;s:22:"contact_admin_settings";}', 15, 4, 'admin/build/contact', 'admin/build/contact', 'Settings', 't', '', 128, '', '', '', 2, 'modules/contact/contact.admin.inc'),
('admin/content/node-type/story', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:14:"node_type_form";i:1;O:8:"stdClass":14:{s:4:"type";s:5:"story";s:4:"name";s:5:"Story";s:6:"module";s:4:"node";s:11:"description";s:392:"A <em>story</em>, similar in form to a <em>page</em>, is ideal for creating and displaying content that informs or engages website visitors. Press releases, site announcements, and informal blog-like entries may all be created with a <em>story</em> entry. By default, a <em>story</em> entry is automatically featured on the site''s initial home page, and provides the ability to post comments.";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"1";s:10:"body_label";s:4:"Body";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:5:"story";}}', 15, 4, '', 'admin/content/node-type/story', 'Story', 't', '', 4, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/settings/logging/syslog', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:21:"syslog_admin_settings";}', 15, 4, '', 'admin/settings/logging/syslog', 'Syslog', 't', '', 6, '', 'Settings for syslog logging. Syslog is an operating system administrative logging tool used in systems management and security auditing. Most suited to medium and large sites, syslog provides filtering tools that allow messages to be routed by type and severity.', '', 0, ''),
('node/%/devel/token', 'a:1:{i:1;s:9:"node_load";}', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'token_devel_token_object', 'a:2:{i:0;s:4:"node";i:1;i:1;}', 11, 4, 'node/%/devel', 'node/%', 'Tokens', 't', '', 128, '', '', '', 5, 'sites/all/modules/token/token.pages.inc'),
('user/%/devel/token', 'a:1:{i:1;s:9:"user_load";}', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'token_devel_token_object', 'a:2:{i:0;s:4:"user";i:1;i:1;}', 11, 4, 'user/%/devel', 'user/%', 'Tokens', 't', '', 128, '', '', '', 5, 'sites/all/modules/token/token.pages.inc'),
('user/%/track/navigation', 'a:1:{i:1;s:9:"user_load";}', '', 'user_access', 'a:1:{i:0;s:17:"access statistics";}', 'statistics_user_tracker', 'a:0:{}', 11, 4, 'user/%', 'user/%', 'Track page visits', 't', '', 128, '', '', '', 2, 'modules/statistics/statistics.pages.inc'),
('devel/variable/edit/%', 'a:1:{i:3;N;}', '', 'user_access', 'a:1:{i:0;s:24:"access devel information";}', 'drupal_get_form', 'a:2:{i:0;s:19:"devel_variable_edit";i:1;i:3;}', 14, 4, '', 'devel/variable/edit/%', 'Variable editor', 't', '', 4, '', '', '', 0, ''),
('admin/build/views/add', '', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'views_ui_add_page', 'a:0:{}', 15, 4, 'admin/build/views', 'admin/build/views', 'Add', 't', '', 128, '', '', '', 0, 'sites/all/modules/views/includes/admin.inc'),
('admin/build/views/list', '', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'views_ui_list_views', 'a:0:{}', 15, 4, 'admin/build/views', 'admin/build/views', 'List', 't', '', 136, '', '', '', -1, 'sites/all/modules/views/includes/admin.inc'),
('admin/content/taxonomy/%', 'a:1:{i:3;s:24:"taxonomy_vocabulary_load";}', '', 'user_access', 'a:1:{i:0;s:19:"administer taxonomy";}', 'drupal_get_form', 'a:2:{i:0;s:23:"taxonomy_overview_terms";i:1;i:3;}', 14, 4, '', 'admin/content/taxonomy/%', 'List terms', 't', '', 4, '', '', '', 0, 'modules/taxonomy/taxonomy.admin.inc'),
('admin/content/node-type/page', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:14:"node_type_form";i:1;O:8:"stdClass":14:{s:4:"type";s:4:"page";s:4:"name";s:4:"Page";s:6:"module";s:4:"node";s:11:"description";s:296:"A <em>page</em>, similar in form to a <em>story</em>, is a simple method for creating and displaying information that rarely changes, such as an "About us" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site''s initial home page.";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"1";s:10:"body_label";s:4:"Body";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:4:"page";}}', 15, 4, '', 'admin/content/node-type/page', 'Page', 't', '', 4, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/content/node-type/poll', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:14:"node_type_form";i:1;O:8:"stdClass":14:{s:4:"name";s:4:"Poll";s:6:"module";s:4:"poll";s:11:"description";s:191:"A <em>poll</em> is a question with a set of possible responses. A <em>poll</em>, once created, automatically provides a simple running count of the number of votes received for each response.";s:11:"title_label";s:8:"Question";s:8:"has_body";b:0;s:4:"type";s:4:"poll";s:9:"has_title";b:1;s:4:"help";s:0:"";s:14:"min_word_count";i:0;s:6:"custom";b:0;s:8:"modified";b:0;s:6:"locked";b:1;s:9:"orig_type";s:4:"poll";s:6:"is_new";b:1;}}', 15, 4, '', 'admin/content/node-type/poll', 'Poll', 't', '', 4, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/build/menu/settings', '', '', 'user_access', 'a:1:{i:0;s:15:"administer menu";}', 'drupal_get_form', 'a:1:{i:0;s:14:"menu_configure";}', 15, 4, 'admin/build/menu', 'admin/build/menu', 'Settings', 't', '', 128, '', '', '', 5, 'modules/menu/menu.admin.inc'),
('admin/reports/updates/settings', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:15:"update_settings";}', 15, 4, 'admin/reports/updates', 'admin/reports/updates', 'Settings', 't', '', 128, '', '', '', 0, 'modules/update/update.settings.inc'),
('admin/settings/logging/dblog', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:20:"dblog_admin_settings";}', 15, 4, '', 'admin/settings/logging/dblog', 'Database logging', 't', '', 6, '', 'Settings for logging to the Drupal database logs. This is the most common method for small to medium sites on shared hosting. The logs are viewable from the admin pages.', '', 0, 'modules/dblog/dblog.admin.inc'),
('admin/build/views1/convert', '', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'views_ui_convert1', 'a:1:{i:0;i:4;}', 15, 4, '', 'admin/build/views1/convert', 'Convert view', 't', '', 4, '', '', '', 0, 'sites/all/modules/views/includes/convert.inc'),
('admin/settings/date-time/configure', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:25:"system_date_time_settings";}', 15, 4, 'admin/settings/date-time', 'admin/settings/date-time', 'Date and time', 't', '', 136, '', 'Settings for how Drupal displays date and time, as well as the system''s default timezone.', '', 0, 'modules/system/system.admin.inc'),
('admin/settings/filters/defaults', '', '', 'user_access', 'a:1:{i:0;s:18:"administer filters";}', 'drupal_get_form', 'a:1:{i:0;s:34:"better_formats_defaults_admin_form";}', 15, 4, 'admin/settings/filters', 'admin/settings/filters', 'Defaults', 't', '', 128, '', 'Manage input formats', '', 2, 'sites/all/modules/better_formats/better_formats_defaults.admin.inc'),
('admin/reports/access/%', 'a:1:{i:3;N;}', '', 'user_access', 'a:1:{i:0;s:17:"access statistics";}', 'statistics_access_log', 'a:1:{i:0;i:3;}', 14, 4, '', 'admin/reports/access/%', 'Details', 't', '', 4, '', 'View access log.', '', 0, 'modules/statistics/statistics.admin.inc'),
('admin/settings/date-time/formats', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:26:"date_api_date_formats_form";}', 15, 4, 'admin/settings/date-time', 'admin/settings/date-time', 'Formats', 't', '', 128, '', 'Allow users to configure date formats', '', 1, 'sites/all/modules/date/date_api.admin.inc'),
('admin/build/views/import', '', '', 'views_import_access', 'a:1:{i:0;s:16:"administer views";}', 'drupal_get_form', 'a:1:{i:0;s:20:"views_ui_import_page";}', 15, 4, 'admin/build/views', 'admin/build/views', 'Import', 't', '', 128, '', '', '', 0, 'sites/all/modules/views/includes/admin.inc'),
('admin/settings/language/i18n', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:19:"i18n_admin_settings";}', 15, 4, 'admin/settings/language', 'admin/settings/language', 'Multilingual system', 't', '', 128, '', 'Configure extended options for multilingual content and translations.', '', 10, 'sites/all/modules/i18n/i18n.admin.inc'),
('admin/settings/filters/settings', '', '', 'user_access', 'a:1:{i:0;s:18:"administer filters";}', 'drupal_get_form', 'a:1:{i:0;s:34:"better_formats_settings_admin_form";}', 15, 4, 'admin/settings/filters', 'admin/settings/filters', 'Settings', 't', '', 128, '', 'Manage input formats', '', 3, 'sites/all/modules/better_formats/better_formats_settings.admin.inc'),
('admin/build/views/tools', '', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'drupal_get_form', 'a:1:{i:0;s:20:"views_ui_admin_tools";}', 15, 4, 'admin/build/views', 'admin/build/views', 'Tools', 't', '', 128, '', '', '', 0, 'sites/all/modules/views/includes/admin.inc'),
('admin/build/views1/delete', '', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'drupal_get_form', 'a:2:{i:0;s:24:"views_ui_delete1_confirm";i:1;i:4;}', 15, 4, '', 'admin/build/views1/delete', 'Delete view', 't', '', 4, '', '', '', 0, 'sites/all/modules/views/includes/convert.inc'),
('admin/settings/filters/%', 'a:1:{i:3;s:18:"filter_format_load";}', '', 'user_access', 'a:1:{i:0;s:18:"administer filters";}', 'filter_admin_format_page', 'a:1:{i:0;i:3;}', 14, 4, '', 'admin/settings/filters/%', '', 'filter_admin_format_title', 'a:1:{i:0;i:3;}', 4, '', '', '', 0, 'modules/filter/filter.admin.inc'),
('admin/settings/lightbox2/automatic', '', '', 'user_access', 'a:1:{i:0;s:20:"administer lightbox2";}', 'drupal_get_form', 'a:1:{i:0;s:43:"lightbox2_auto_image_handling_settings_form";}', 15, 4, 'admin/settings/lightbox2', 'admin/settings/lightbox2', 'Automatic image handling', 't', '', 128, '', 'Allows the user to configure the lightbox2 automatic image handling settings', '', 3, 'sites/all/modules/lightbox2/lightbox2.admin.inc'),
('admin/build/menu-customize/%', 'a:1:{i:3;s:9:"menu_load";}', '', 'user_access', 'a:1:{i:0;s:15:"administer menu";}', 'drupal_get_form', 'a:2:{i:0;s:18:"menu_overview_form";i:1;i:3;}', 14, 4, '', 'admin/build/menu-customize/%', 'Customize menu', 'menu_overview_title', 'a:1:{i:0;i:3;}', 4, '', '', '', 0, 'modules/menu/menu.admin.inc'),
('admin/settings/lightbox2/html_content', '', '', 'user_access', 'a:1:{i:0;s:20:"administer lightbox2";}', 'drupal_get_form', 'a:1:{i:0;s:30:"lightbox2_iframe_settings_form";}', 15, 4, 'admin/settings/lightbox2', 'admin/settings/lightbox2', 'HTML Content', 't', '', 128, '', 'Allows the user to configure the lightbox2 HTML content functionality.', '', 2, 'sites/all/modules/lightbox2/lightbox2.admin.inc'),
('admin/build/contact/manage', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:24:"contact_field_list_field";}', 15, 4, 'admin/build/contact', 'admin/build/contact', 'Manage fields', 't', '', 128, '', '', '', 49, 'sites/all/modules/contact_field/contact_field_admin.inc'),
('admin/build/contact/display', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:27:"contact_field_display_field";}', 15, 4, 'admin/build/contact', 'admin/build/contact', 'Message template', 't', '', 128, '', '', '', 50, 'sites/all/modules/contact_field/contact_field_admin.inc'),
('admin/settings/lightbox2/general', '', '', 'user_access', 'a:1:{i:0;s:20:"administer lightbox2";}', 'drupal_get_form', 'a:1:{i:0;s:31:"lightbox2_general_settings_form";}', 15, 4, 'admin/settings/lightbox2', 'admin/settings/lightbox2', 'General', 't', '', 136, '', 'Allows the user to configure the lightbox2 settings', '', 0, 'sites/all/modules/lightbox2/lightbox2.admin.inc'),
('admin/settings/lightbox2/slideshow', '', '', 'user_access', 'a:1:{i:0;s:20:"administer lightbox2";}', 'drupal_get_form', 'a:1:{i:0;s:33:"lightbox2_slideshow_settings_form";}', 15, 4, 'admin/settings/lightbox2', 'admin/settings/lightbox2', 'Slideshow', 't', '', 128, '', 'Allows the user to configure the lightbox2 slideshow functionality', '', 1, 'sites/all/modules/lightbox2/lightbox2.admin.inc'),
('admin/content/node-type/contact/edit', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:14:"node_type_form";i:1;O:8:"stdClass":14:{s:4:"type";s:7:"contact";s:4:"name";s:7:"Contact";s:6:"module";s:4:"node";s:11:"description";s:0:"";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"0";s:10:"body_label";s:0:"";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:0:"";}}', 31, 5, 'admin/content/node-type/contact', 'admin/content/node-type/contact', 'Edit', 't', '', 136, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/content/node-type/distribution/edit', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:14:"node_type_form";i:1;O:8:"stdClass":14:{s:4:"type";s:12:"distribution";s:4:"name";s:12:"Distribution";s:6:"module";s:4:"node";s:11:"description";s:0:"";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"0";s:10:"body_label";s:0:"";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:0:"";}}', 31, 5, 'admin/content/node-type/distribution', 'admin/content/node-type/distribution', 'Edit', 't', '', 136, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/content/node-type/home/edit', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:14:"node_type_form";i:1;O:8:"stdClass":14:{s:4:"type";s:4:"home";s:4:"name";s:4:"Home";s:6:"module";s:4:"node";s:11:"description";s:0:"";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"0";s:10:"body_label";s:0:"";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:0:"";}}', 31, 5, 'admin/content/node-type/home', 'admin/content/node-type/home', 'Edit', 't', '', 136, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/content/node-type/intro/edit', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:14:"node_type_form";i:1;O:8:"stdClass":14:{s:4:"type";s:5:"intro";s:4:"name";s:5:"Intro";s:6:"module";s:4:"node";s:11:"description";s:0:"";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"0";s:10:"body_label";s:0:"";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:0:"";}}', 31, 5, 'admin/content/node-type/intro', 'admin/content/node-type/intro', 'Edit', 't', '', 136, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/content/node-type/page/edit', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:14:"node_type_form";i:1;O:8:"stdClass":14:{s:4:"type";s:4:"page";s:4:"name";s:4:"Page";s:6:"module";s:4:"node";s:11:"description";s:296:"A <em>page</em>, similar in form to a <em>story</em>, is a simple method for creating and displaying information that rarely changes, such as an "About us" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site''s initial home page.";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"1";s:10:"body_label";s:4:"Body";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:4:"page";}}', 31, 5, 'admin/content/node-type/page', 'admin/content/node-type/page', 'Edit', 't', '', 136, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/content/node-type/poll/edit', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:14:"node_type_form";i:1;O:8:"stdClass":14:{s:4:"name";s:4:"Poll";s:6:"module";s:4:"poll";s:11:"description";s:191:"A <em>poll</em> is a question with a set of possible responses. A <em>poll</em>, once created, automatically provides a simple running count of the number of votes received for each response.";s:11:"title_label";s:8:"Question";s:8:"has_body";b:0;s:4:"type";s:4:"poll";s:9:"has_title";b:1;s:4:"help";s:0:"";s:14:"min_word_count";i:0;s:6:"custom";b:0;s:8:"modified";b:0;s:6:"locked";b:1;s:9:"orig_type";s:4:"poll";s:6:"is_new";b:1;}}', 31, 5, 'admin/content/node-type/poll', 'admin/content/node-type/poll', 'Edit', 't', '', 136, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/content/node-type/story/edit', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:14:"node_type_form";i:1;O:8:"stdClass":14:{s:4:"type";s:5:"story";s:4:"name";s:5:"Story";s:6:"module";s:4:"node";s:11:"description";s:392:"A <em>story</em>, similar in form to a <em>page</em>, is ideal for creating and displaying content that informs or engages website visitors. Press releases, site announcements, and informal blog-like entries may all be created with a <em>story</em> entry. By default, a <em>story</em> entry is automatically featured on the site''s initial home page, and provides the ability to post comments.";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"1";s:10:"body_label";s:4:"Body";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:5:"story";}}', 31, 5, 'admin/content/node-type/story', 'admin/content/node-type/story', 'Edit', 't', '', 136, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/build/themes/settings/global', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:21:"system_theme_settings";}', 31, 5, 'admin/build/themes/settings', 'admin/build/themes', 'Global settings', 't', '', 136, '', '', '', -1, 'modules/system/system.admin.inc'),
('admin/content/taxonomy/%/list', 'a:1:{i:3;s:24:"taxonomy_vocabulary_load";}', '', 'user_access', 'a:1:{i:0;s:19:"administer taxonomy";}', 'drupal_get_form', 'a:2:{i:0;s:23:"taxonomy_overview_terms";i:1;i:3;}', 29, 5, 'admin/content/taxonomy/%', 'admin/content/taxonomy/%', 'List', 't', '', 136, '', '', '', -10, 'modules/taxonomy/taxonomy.admin.inc'),
('admin/settings/filters/%/edit', 'a:1:{i:3;s:18:"filter_format_load";}', '', 'user_access', 'a:1:{i:0;s:18:"administer filters";}', 'filter_admin_format_page', 'a:1:{i:0;i:3;}', 29, 5, 'admin/settings/filters/%', 'admin/settings/filters/%', 'Edit', 't', '', 136, '', '', '', 0, 'modules/filter/filter.admin.inc'),
('admin/build/modules/list/confirm', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:14:"system_modules";}', 31, 5, '', 'admin/build/modules/list/confirm', 'List', 't', '', 4, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/build/menu-customize/%/list', 'a:1:{i:3;s:9:"menu_load";}', '', 'user_access', 'a:1:{i:0;s:15:"administer menu";}', 'drupal_get_form', 'a:2:{i:0;s:18:"menu_overview_form";i:1;i:3;}', 29, 5, 'admin/build/menu-customize/%', 'admin/build/menu-customize/%', 'List items', 't', '', 136, '', '', '', -10, 'modules/menu/menu.admin.inc'),
('admin/build/modules/uninstall/confirm', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:24:"system_modules_uninstall";}', 31, 5, '', 'admin/build/modules/uninstall/confirm', 'Uninstall', 't', '', 4, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/build/views/tools/export', '', '', 'user_access', 'a:1:{i:0;s:18:"use views exporter";}', 'views_export_export', 'a:0:{}', 31, 5, 'admin/build/views/tools', 'admin/build/views', 'Bulk export', 't', '', 128, '', '', '', 0, ''),
('admin/settings/date-time/formats/lookup', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'date_api_date_time_lookup', 'a:0:{}', 31, 5, '', 'admin/settings/date-time/formats/lookup', 'Date and time lookup', 't', '', 4, '', '', '', 0, ''),
('admin/settings/language/i18n/configure', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:19:"i18n_admin_settings";}', 31, 5, 'admin/settings/language/i18n', 'admin/settings/language', 'Options', 't', '', 136, '', 'Configure extended options for multilingual content and translations.', '', 0, 'sites/all/modules/i18n/i18n.admin.inc'),
('admin/build/themes/settings/bluemarine', '', '', '_system_themes_access', 'a:1:{i:0;O:8:"stdClass":12:{s:8:"filename";s:33:"themes/bluemarine/bluemarine.info";s:4:"name";s:10:"bluemarine";s:4:"type";s:5:"theme";s:5:"owner";s:45:"themes/engines/phptemplate/phptemplate.engine";s:6:"status";s:1:"0";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:13:{s:4:"name";s:10:"Bluemarine";s:11:"description";s:66:"Table-based multi-column theme with a marine and ash color scheme.";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:6:"engine";s:11:"phptemplate";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:7:"regions";a:5:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";s:7:"content";s:7:"Content";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";}s:8:"features";a:10:{i:0;s:20:"comment_user_picture";i:1;s:7:"favicon";i:2;s:7:"mission";i:3;s:4:"logo";i:4;s:4:"name";i:5;s:17:"node_user_picture";i:6;s:6:"search";i:7;s:6:"slogan";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:27:"themes/bluemarine/style.css";}}s:7:"scripts";a:1:{s:9:"script.js";s:27:"themes/bluemarine/script.js";}s:10:"screenshot";s:32:"themes/bluemarine/screenshot.png";s:3:"php";s:5:"4.3.5";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:27:"themes/bluemarine/style.css";}}s:6:"engine";s:11:"phptemplate";}}', 'drupal_get_form', 'a:2:{i:0;s:21:"system_theme_settings";i:1;s:10:"bluemarine";}', 31, 5, 'admin/build/themes/settings', 'admin/build/themes', 'Bluemarine', 't', '', 128, '', '', '', 0, 'modules/system/system.admin.inc');
INSERT INTO `menu_router` (`path`, `load_functions`, `to_arg_functions`, `access_callback`, `access_arguments`, `page_callback`, `page_arguments`, `fit`, `number_parts`, `tab_parent`, `tab_root`, `title`, `title_callback`, `title_arguments`, `type`, `block_callback`, `description`, `position`, `weight`, `file`) VALUES
('admin/build/themes/settings/bootstrap', '', '', '_system_themes_access', 'a:1:{i:0;O:8:"stdClass":14:{s:8:"filename";s:41:"sites/all/themes/bootstrap/bootstrap.info";s:4:"name";s:9:"bootstrap";s:4:"type";s:5:"theme";s:5:"owner";s:45:"themes/engines/phptemplate/phptemplate.engine";s:6:"status";s:1:"1";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:12:{s:4:"name";s:9:"Bootstrap";s:11:"description";s:125:"Read the <a href="http://drupal.org/node/629510">online docs</a> or the included README.txt on how to create a Zen sub-theme.";s:10:"screenshot";s:41:"sites/all/themes/bootstrap/screenshot.png";s:4:"core";s:3:"6.x";s:10:"base theme";s:3:"zen";s:11:"stylesheets";a:1:{s:3:"all";a:18:{s:18:"css/html-reset.css";s:45:"sites/all/themes/bootstrap/css/html-reset.css";s:20:"css/layout-fixed.css";s:47:"sites/all/themes/bootstrap/css/layout-fixed.css";s:24:"css/page-backgrounds.css";s:51:"sites/all/themes/bootstrap/css/page-backgrounds.css";s:12:"css/tabs.css";s:39:"sites/all/themes/bootstrap/css/tabs.css";s:16:"css/messages.css";s:43:"sites/all/themes/bootstrap/css/messages.css";s:13:"css/pages.css";s:40:"sites/all/themes/bootstrap/css/pages.css";s:21:"css/block-editing.css";s:48:"sites/all/themes/bootstrap/css/block-editing.css";s:14:"css/blocks.css";s:41:"sites/all/themes/bootstrap/css/blocks.css";s:18:"css/navigation.css";s:45:"sites/all/themes/bootstrap/css/navigation.css";s:21:"css/panels-styles.css";s:48:"sites/all/themes/bootstrap/css/panels-styles.css";s:20:"css/views-styles.css";s:47:"sites/all/themes/bootstrap/css/views-styles.css";s:13:"css/nodes.css";s:40:"sites/all/themes/bootstrap/css/nodes.css";s:16:"css/comments.css";s:43:"sites/all/themes/bootstrap/css/comments.css";s:13:"css/forms.css";s:40:"sites/all/themes/bootstrap/css/forms.css";s:14:"css/fields.css";s:41:"sites/all/themes/bootstrap/css/fields.css";s:17:"css/bootstrap.css";s:44:"sites/all/themes/bootstrap/css/bootstrap.css";s:28:"css/bootstrap-responsive.css";s:55:"sites/all/themes/bootstrap/css/bootstrap-responsive.css";s:24:"css/bootstrap-custom.css";s:51:"sites/all/themes/bootstrap/css/bootstrap-custom.css";}}s:7:"scripts";a:4:{s:12:"js/jquery.js";s:39:"sites/all/themes/bootstrap/js/jquery.js";s:11:"js/slick.js";s:38:"sites/all/themes/bootstrap/js/slick.js";s:12:"js/script.js";s:39:"sites/all/themes/bootstrap/js/script.js";s:15:"js/bootstrap.js";s:42:"sites/all/themes/bootstrap/js/bootstrap.js";}s:7:"regions";a:9:{s:13:"sidebar_first";s:13:"First sidebar";s:14:"sidebar_second";s:14:"Second sidebar";s:10:"navigation";s:14:"Navigation bar";s:9:"highlight";s:19:"Highlighted content";s:11:"content_top";s:11:"Content top";s:14:"content_bottom";s:14:"Content bottom";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";s:12:"page_closure";s:12:"Page closure";}s:8:"features";a:10:{i:0;s:4:"logo";i:1;s:4:"name";i:2;s:6:"slogan";i:3;s:7:"mission";i:4;s:17:"node_user_picture";i:5;s:20:"comment_user_picture";i:6;s:6:"search";i:7;s:7:"favicon";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:8:"settings";a:8:{s:17:"zen_block_editing";s:1:"1";s:14:"zen_breadcrumb";s:3:"yes";s:24:"zen_breadcrumb_separator";s:5:" › ";s:19:"zen_breadcrumb_home";s:1:"1";s:23:"zen_breadcrumb_trailing";s:1:"1";s:20:"zen_breadcrumb_title";s:1:"0";s:20:"zen_rebuild_registry";s:1:"1";s:14:"zen_wireframes";s:1:"0";}s:3:"php";s:5:"4.3.5";s:6:"engine";s:11:"phptemplate";}s:11:"stylesheets";a:1:{s:3:"all";a:18:{s:18:"css/html-reset.css";s:45:"sites/all/themes/bootstrap/css/html-reset.css";s:20:"css/layout-fixed.css";s:47:"sites/all/themes/bootstrap/css/layout-fixed.css";s:24:"css/page-backgrounds.css";s:51:"sites/all/themes/bootstrap/css/page-backgrounds.css";s:12:"css/tabs.css";s:39:"sites/all/themes/bootstrap/css/tabs.css";s:16:"css/messages.css";s:43:"sites/all/themes/bootstrap/css/messages.css";s:13:"css/pages.css";s:40:"sites/all/themes/bootstrap/css/pages.css";s:21:"css/block-editing.css";s:48:"sites/all/themes/bootstrap/css/block-editing.css";s:14:"css/blocks.css";s:41:"sites/all/themes/bootstrap/css/blocks.css";s:18:"css/navigation.css";s:45:"sites/all/themes/bootstrap/css/navigation.css";s:21:"css/panels-styles.css";s:48:"sites/all/themes/bootstrap/css/panels-styles.css";s:20:"css/views-styles.css";s:47:"sites/all/themes/bootstrap/css/views-styles.css";s:13:"css/nodes.css";s:40:"sites/all/themes/bootstrap/css/nodes.css";s:16:"css/comments.css";s:43:"sites/all/themes/bootstrap/css/comments.css";s:13:"css/forms.css";s:40:"sites/all/themes/bootstrap/css/forms.css";s:14:"css/fields.css";s:41:"sites/all/themes/bootstrap/css/fields.css";s:17:"css/bootstrap.css";s:44:"sites/all/themes/bootstrap/css/bootstrap.css";s:28:"css/bootstrap-responsive.css";s:55:"sites/all/themes/bootstrap/css/bootstrap-responsive.css";s:24:"css/bootstrap-custom.css";s:51:"sites/all/themes/bootstrap/css/bootstrap-custom.css";}}s:7:"scripts";a:4:{s:12:"js/jquery.js";s:39:"sites/all/themes/bootstrap/js/jquery.js";s:11:"js/slick.js";s:38:"sites/all/themes/bootstrap/js/slick.js";s:12:"js/script.js";s:39:"sites/all/themes/bootstrap/js/script.js";s:15:"js/bootstrap.js";s:42:"sites/all/themes/bootstrap/js/bootstrap.js";}s:6:"engine";s:11:"phptemplate";s:10:"base_theme";s:3:"zen";}}', 'drupal_get_form', 'a:2:{i:0;s:21:"system_theme_settings";i:1;s:9:"bootstrap";}', 31, 5, 'admin/build/themes/settings', 'admin/build/themes', 'Bootstrap', 't', '', 128, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/build/themes/settings/chameleon', '', '', '_system_themes_access', 'a:1:{i:0;O:8:"stdClass":11:{s:8:"filename";s:31:"themes/chameleon/chameleon.info";s:4:"name";s:9:"chameleon";s:4:"type";s:5:"theme";s:5:"owner";s:32:"themes/chameleon/chameleon.theme";s:6:"status";s:1:"0";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:12:{s:4:"name";s:9:"Chameleon";s:11:"description";s:42:"Minimalist tabled theme with light colors.";s:7:"regions";a:2:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";}s:8:"features";a:4:{i:0;s:4:"logo";i:1;s:7:"favicon";i:2;s:4:"name";i:3;s:6:"slogan";}s:11:"stylesheets";a:1:{s:3:"all";a:2:{s:9:"style.css";s:26:"themes/chameleon/style.css";s:10:"common.css";s:27:"themes/chameleon/common.css";}}s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:7:"scripts";a:1:{s:9:"script.js";s:26:"themes/chameleon/script.js";}s:10:"screenshot";s:31:"themes/chameleon/screenshot.png";s:3:"php";s:5:"4.3.5";}s:11:"stylesheets";a:1:{s:3:"all";a:2:{s:9:"style.css";s:26:"themes/chameleon/style.css";s:10:"common.css";s:27:"themes/chameleon/common.css";}}}}', 'drupal_get_form', 'a:2:{i:0;s:21:"system_theme_settings";i:1;s:9:"chameleon";}', 31, 5, 'admin/build/themes/settings', 'admin/build/themes', 'Chameleon', 't', '', 128, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/settings/language/delete/%', 'a:1:{i:4;N;}', '', 'user_access', 'a:1:{i:0;s:20:"administer languages";}', 'locale_inc_callback', 'a:3:{i:0;s:15:"drupal_get_form";i:1;s:28:"locale_languages_delete_form";i:2;i:4;}', 30, 5, '', 'admin/settings/language/delete/%', 'Confirm', 't', '', 4, '', '', '', 0, ''),
('admin/content/node-type/contact/delete', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:24:"node_type_delete_confirm";i:1;O:8:"stdClass":14:{s:4:"type";s:7:"contact";s:4:"name";s:7:"Contact";s:6:"module";s:4:"node";s:11:"description";s:0:"";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"0";s:10:"body_label";s:0:"";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:0:"";}}', 31, 5, '', 'admin/content/node-type/contact/delete', 'Delete', 't', '', 4, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/content/node-type/distribution/delete', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:24:"node_type_delete_confirm";i:1;O:8:"stdClass":14:{s:4:"type";s:12:"distribution";s:4:"name";s:12:"Distribution";s:6:"module";s:4:"node";s:11:"description";s:0:"";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"0";s:10:"body_label";s:0:"";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:0:"";}}', 31, 5, '', 'admin/content/node-type/distribution/delete', 'Delete', 't', '', 4, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/content/node-type/home/delete', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:24:"node_type_delete_confirm";i:1;O:8:"stdClass":14:{s:4:"type";s:4:"home";s:4:"name";s:4:"Home";s:6:"module";s:4:"node";s:11:"description";s:0:"";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"0";s:10:"body_label";s:0:"";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:0:"";}}', 31, 5, '', 'admin/content/node-type/home/delete', 'Delete', 't', '', 4, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/content/node-type/intro/delete', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:24:"node_type_delete_confirm";i:1;O:8:"stdClass":14:{s:4:"type";s:5:"intro";s:4:"name";s:5:"Intro";s:6:"module";s:4:"node";s:11:"description";s:0:"";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"0";s:10:"body_label";s:0:"";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:0:"";}}', 31, 5, '', 'admin/content/node-type/intro/delete', 'Delete', 't', '', 4, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/content/node-type/page/delete', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:24:"node_type_delete_confirm";i:1;O:8:"stdClass":14:{s:4:"type";s:4:"page";s:4:"name";s:4:"Page";s:6:"module";s:4:"node";s:11:"description";s:296:"A <em>page</em>, similar in form to a <em>story</em>, is a simple method for creating and displaying information that rarely changes, such as an "About us" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site''s initial home page.";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"1";s:10:"body_label";s:4:"Body";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:4:"page";}}', 31, 5, '', 'admin/content/node-type/page/delete', 'Delete', 't', '', 4, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/content/node-type/poll/delete', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:24:"node_type_delete_confirm";i:1;O:8:"stdClass":14:{s:4:"name";s:4:"Poll";s:6:"module";s:4:"poll";s:11:"description";s:191:"A <em>poll</em> is a question with a set of possible responses. A <em>poll</em>, once created, automatically provides a simple running count of the number of votes received for each response.";s:11:"title_label";s:8:"Question";s:8:"has_body";b:0;s:4:"type";s:4:"poll";s:9:"has_title";b:1;s:4:"help";s:0:"";s:14:"min_word_count";i:0;s:6:"custom";b:0;s:8:"modified";b:0;s:6:"locked";b:1;s:9:"orig_type";s:4:"poll";s:6:"is_new";b:1;}}', 31, 5, '', 'admin/content/node-type/poll/delete', 'Delete', 't', '', 4, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/build/contact/%/delete', 'a:1:{i:3;N;}', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'contact_field_delete_field', 'a:1:{i:0;i:3;}', 29, 5, '', 'admin/build/contact/%/delete', '', 't', '', 4, '', '', '', 0, ''),
('admin/content/node-type/story/delete', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:24:"node_type_delete_confirm";i:1;O:8:"stdClass":14:{s:4:"type";s:5:"story";s:4:"name";s:5:"Story";s:6:"module";s:4:"node";s:11:"description";s:392:"A <em>story</em>, similar in form to a <em>page</em>, is ideal for creating and displaying content that informs or engages website visitors. Press releases, site announcements, and informal blog-like entries may all be created with a <em>story</em> entry. By default, a <em>story</em> entry is automatically featured on the site''s initial home page, and provides the ability to post comments.";s:4:"help";s:0:"";s:9:"has_title";s:1:"1";s:11:"title_label";s:5:"Title";s:8:"has_body";s:1:"1";s:10:"body_label";s:4:"Body";s:14:"min_word_count";s:1:"0";s:6:"custom";s:1:"1";s:8:"modified";s:1:"1";s:6:"locked";s:1:"0";s:9:"orig_type";s:5:"story";}}', 31, 5, '', 'admin/content/node-type/story/delete', 'Delete', 't', '', 4, '', '', '', 0, 'modules/node/content_types.inc'),
('admin/build/translate/delete/%', 'a:1:{i:4;N;}', '', 'user_access', 'a:1:{i:0;s:19:"translate interface";}', 'locale_inc_callback', 'a:2:{i:0;s:28:"locale_translate_delete_page";i:1;i:4;}', 30, 5, '', 'admin/build/translate/delete/%', 'Delete string', 't', '', 4, '', '', '', 0, ''),
('admin/settings/language/edit/%', 'a:1:{i:4;N;}', '', 'user_access', 'a:1:{i:0;s:20:"administer languages";}', 'locale_inc_callback', 'a:3:{i:0;s:15:"drupal_get_form";i:1;s:26:"locale_languages_edit_form";i:2;i:4;}', 30, 5, '', 'admin/settings/language/edit/%', 'Edit language', 't', '', 4, '', '', '', 0, ''),
('admin/build/translate/edit/%', 'a:1:{i:4;N;}', '', 'user_access', 'a:1:{i:0;s:19:"translate interface";}', 'locale_inc_callback', 'a:3:{i:0;s:15:"drupal_get_form";i:1;s:26:"locale_translate_edit_form";i:2;i:4;}', 30, 5, '', 'admin/build/translate/edit/%', 'Edit string', 't', '', 4, '', '', '', 0, ''),
('admin/content/taxonomy/edit/term', '', '', 'user_access', 'a:1:{i:0;s:19:"administer taxonomy";}', 'taxonomy_admin_term_edit', 'a:0:{}', 31, 5, '', 'admin/content/taxonomy/edit/term', 'Edit term', 't', '', 4, '', '', '', 0, 'modules/taxonomy/taxonomy.admin.inc'),
('admin/build/themes/settings/garland', '', '', '_system_themes_access', 'a:1:{i:0;O:8:"stdClass":12:{s:8:"filename";s:27:"themes/garland/garland.info";s:4:"name";s:7:"garland";s:4:"type";s:5:"theme";s:5:"owner";s:45:"themes/engines/phptemplate/phptemplate.engine";s:6:"status";s:1:"1";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:13:{s:4:"name";s:7:"Garland";s:11:"description";s:66:"Tableless, recolorable, multi-column, fluid width theme (default).";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:6:"engine";s:11:"phptemplate";s:11:"stylesheets";a:2:{s:3:"all";a:1:{s:9:"style.css";s:24:"themes/garland/style.css";}s:5:"print";a:1:{s:9:"print.css";s:24:"themes/garland/print.css";}}s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:7:"regions";a:5:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";s:7:"content";s:7:"Content";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";}s:8:"features";a:10:{i:0;s:20:"comment_user_picture";i:1;s:7:"favicon";i:2;s:7:"mission";i:3;s:4:"logo";i:4;s:4:"name";i:5;s:17:"node_user_picture";i:6;s:6:"search";i:7;s:6:"slogan";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:7:"scripts";a:1:{s:9:"script.js";s:24:"themes/garland/script.js";}s:10:"screenshot";s:29:"themes/garland/screenshot.png";s:3:"php";s:5:"4.3.5";}s:11:"stylesheets";a:2:{s:3:"all";a:1:{s:9:"style.css";s:24:"themes/garland/style.css";}s:5:"print";a:1:{s:9:"print.css";s:24:"themes/garland/print.css";}}s:6:"engine";s:11:"phptemplate";}}', 'drupal_get_form', 'a:2:{i:0;s:21:"system_theme_settings";i:1;s:7:"garland";}', 31, 5, 'admin/build/themes/settings', 'admin/build/themes', 'Garland', 't', '', 128, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/build/block/list/js', '', '', 'user_access', 'a:1:{i:0;s:17:"administer blocks";}', 'block_admin_display_js', 'a:0:{}', 31, 5, '', 'admin/build/block/list/js', 'JavaScript List Form', 't', '', 4, '', '', '', 0, 'modules/block/block.admin.inc'),
('admin/settings/language/configure/language', '', '', 'user_access', 'a:1:{i:0;s:20:"administer languages";}', 'locale_inc_callback', 'a:2:{i:0;s:15:"drupal_get_form";i:1;s:31:"locale_languages_configure_form";}', 31, 5, 'admin/settings/language/configure', 'admin/settings/language', 'Language negotiation', 't', '', 136, '', '', '', -10, ''),
('admin/build/themes/settings/marvin', '', '', '_system_themes_access', 'a:1:{i:0;O:8:"stdClass":12:{s:8:"filename";s:35:"themes/chameleon/marvin/marvin.info";s:4:"name";s:6:"marvin";s:4:"type";s:5:"theme";s:5:"owner";s:0:"";s:6:"status";s:1:"0";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:13:{s:4:"name";s:6:"Marvin";s:11:"description";s:31:"Boxy tabled theme in all grays.";s:7:"regions";a:2:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";}s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:10:"base theme";s:9:"chameleon";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:8:"features";a:10:{i:0;s:20:"comment_user_picture";i:1;s:7:"favicon";i:2;s:7:"mission";i:3;s:4:"logo";i:4;s:4:"name";i:5;s:17:"node_user_picture";i:6;s:6:"search";i:7;s:6:"slogan";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:33:"themes/chameleon/marvin/style.css";}}s:7:"scripts";a:1:{s:9:"script.js";s:33:"themes/chameleon/marvin/script.js";}s:10:"screenshot";s:38:"themes/chameleon/marvin/screenshot.png";s:3:"php";s:5:"4.3.5";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:33:"themes/chameleon/marvin/style.css";}}s:10:"base_theme";s:9:"chameleon";}}', 'drupal_get_form', 'a:2:{i:0;s:21:"system_theme_settings";i:1;s:6:"marvin";}', 31, 5, 'admin/build/themes/settings', 'admin/build/themes', 'Marvin', 't', '', 128, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/build/themes/settings/minnelli', '', '', '_system_themes_access', 'a:1:{i:0;O:8:"stdClass":13:{s:8:"filename";s:37:"themes/garland/minnelli/minnelli.info";s:4:"name";s:8:"minnelli";s:4:"type";s:5:"theme";s:5:"owner";s:45:"themes/engines/phptemplate/phptemplate.engine";s:6:"status";s:1:"0";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:14:{s:4:"name";s:8:"Minnelli";s:11:"description";s:56:"Tableless, recolorable, multi-column, fixed width theme.";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:10:"base theme";s:7:"garland";s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:12:"minnelli.css";s:36:"themes/garland/minnelli/minnelli.css";}}s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:7:"regions";a:5:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";s:7:"content";s:7:"Content";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";}s:8:"features";a:10:{i:0;s:20:"comment_user_picture";i:1;s:7:"favicon";i:2;s:7:"mission";i:3;s:4:"logo";i:4;s:4:"name";i:5;s:17:"node_user_picture";i:6;s:6:"search";i:7;s:6:"slogan";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:7:"scripts";a:1:{s:9:"script.js";s:33:"themes/garland/minnelli/script.js";}s:10:"screenshot";s:38:"themes/garland/minnelli/screenshot.png";s:3:"php";s:5:"4.3.5";s:6:"engine";s:11:"phptemplate";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:12:"minnelli.css";s:36:"themes/garland/minnelli/minnelli.css";}}s:6:"engine";s:11:"phptemplate";s:10:"base_theme";s:7:"garland";}}', 'drupal_get_form', 'a:2:{i:0;s:21:"system_theme_settings";i:1;s:8:"minnelli";}', 31, 5, 'admin/build/themes/settings', 'admin/build/themes', 'Minnelli', 't', '', 128, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/build/themes/settings/pushbutton', '', '', '_system_themes_access', 'a:1:{i:0;O:8:"stdClass":12:{s:8:"filename";s:33:"themes/pushbutton/pushbutton.info";s:4:"name";s:10:"pushbutton";s:4:"type";s:5:"theme";s:5:"owner";s:45:"themes/engines/phptemplate/phptemplate.engine";s:6:"status";s:1:"0";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:13:{s:4:"name";s:10:"Pushbutton";s:11:"description";s:52:"Tabled, multi-column theme in blue and orange tones.";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:6:"engine";s:11:"phptemplate";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:7:"regions";a:5:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";s:7:"content";s:7:"Content";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";}s:8:"features";a:10:{i:0;s:20:"comment_user_picture";i:1;s:7:"favicon";i:2;s:7:"mission";i:3;s:4:"logo";i:4;s:4:"name";i:5;s:17:"node_user_picture";i:6;s:6:"search";i:7;s:6:"slogan";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:27:"themes/pushbutton/style.css";}}s:7:"scripts";a:1:{s:9:"script.js";s:27:"themes/pushbutton/script.js";}s:10:"screenshot";s:32:"themes/pushbutton/screenshot.png";s:3:"php";s:5:"4.3.5";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:27:"themes/pushbutton/style.css";}}s:6:"engine";s:11:"phptemplate";}}', 'drupal_get_form', 'a:2:{i:0;s:21:"system_theme_settings";i:1;s:10:"pushbutton";}', 31, 5, 'admin/build/themes/settings', 'admin/build/themes', 'Pushbutton', 't', '', 128, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/build/themes/settings/visikard', '', '', '_system_themes_access', 'a:1:{i:0;O:8:"stdClass":13:{s:8:"filename";s:39:"sites/all/themes/visikard/visikard.info";s:4:"name";s:8:"visikard";s:4:"type";s:5:"theme";s:5:"owner";s:45:"themes/engines/phptemplate/phptemplate.engine";s:6:"status";s:1:"0";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:14:{s:4:"name";s:9:"Visi Kard";s:11:"description";s:18:"Visi Kard Company.";s:10:"screenshot";s:40:"sites/all/themes/visikard/screenshot.png";s:7:"version";s:7:"6.x-1.0";s:4:"core";s:3:"6.x";s:10:"base theme";s:3:"zen";s:11:"stylesheets";a:2:{s:3:"all";a:16:{s:18:"css/html-reset.css";s:44:"sites/all/themes/visikard/css/html-reset.css";s:18:"css/wireframes.css";s:44:"sites/all/themes/visikard/css/wireframes.css";s:20:"css/layout-fixed.css";s:46:"sites/all/themes/visikard/css/layout-fixed.css";s:24:"css/page-backgrounds.css";s:50:"sites/all/themes/visikard/css/page-backgrounds.css";s:12:"css/tabs.css";s:38:"sites/all/themes/visikard/css/tabs.css";s:16:"css/messages.css";s:42:"sites/all/themes/visikard/css/messages.css";s:13:"css/pages.css";s:39:"sites/all/themes/visikard/css/pages.css";s:21:"css/block-editing.css";s:47:"sites/all/themes/visikard/css/block-editing.css";s:14:"css/blocks.css";s:40:"sites/all/themes/visikard/css/blocks.css";s:18:"css/navigation.css";s:44:"sites/all/themes/visikard/css/navigation.css";s:21:"css/panels-styles.css";s:47:"sites/all/themes/visikard/css/panels-styles.css";s:20:"css/views-styles.css";s:46:"sites/all/themes/visikard/css/views-styles.css";s:13:"css/nodes.css";s:39:"sites/all/themes/visikard/css/nodes.css";s:16:"css/comments.css";s:42:"sites/all/themes/visikard/css/comments.css";s:13:"css/forms.css";s:39:"sites/all/themes/visikard/css/forms.css";s:14:"css/fields.css";s:40:"sites/all/themes/visikard/css/fields.css";}s:5:"print";a:1:{s:13:"css/print.css";s:39:"sites/all/themes/visikard/css/print.css";}}s:23:"conditional-stylesheets";a:2:{s:5:"if IE";a:1:{s:3:"all";a:1:{i:0;s:10:"css/ie.css";}}s:11:"if lte IE 6";a:1:{s:3:"all";a:1:{i:0;s:11:"css/ie6.css";}}}s:7:"regions";a:12:{s:10:"admin_menu";s:10:"Admin Menu";s:13:"sidebar_first";s:13:"First sidebar";s:14:"sidebar_second";s:14:"Second sidebar";s:10:"navigation";s:14:"Navigation bar";s:10:"slide_show";s:10:"Slide show";s:9:"highlight";s:19:"Highlighted content";s:11:"content_top";s:11:"Content top";s:14:"content_bottom";s:14:"Content bottom";s:6:"header";s:6:"Header";s:6:"scroll";s:6:"Scroll";s:6:"footer";s:6:"Footer";s:12:"page_closure";s:12:"Page closure";}s:8:"features";a:10:{i:0;s:4:"logo";i:1;s:4:"name";i:2;s:6:"slogan";i:3;s:7:"mission";i:4;s:17:"node_user_picture";i:5;s:20:"comment_user_picture";i:6;s:6:"search";i:7;s:7:"favicon";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:8:"settings";a:8:{s:17:"zen_block_editing";s:1:"1";s:14:"zen_breadcrumb";s:3:"yes";s:24:"zen_breadcrumb_separator";s:5:" › ";s:19:"zen_breadcrumb_home";s:1:"1";s:23:"zen_breadcrumb_trailing";s:1:"1";s:20:"zen_breadcrumb_title";s:1:"0";s:20:"zen_rebuild_registry";s:1:"1";s:14:"zen_wireframes";s:1:"0";}s:7:"scripts";a:1:{s:9:"script.js";s:35:"sites/all/themes/visikard/script.js";}s:3:"php";s:5:"4.3.5";s:6:"engine";s:11:"phptemplate";}s:11:"stylesheets";a:2:{s:3:"all";a:16:{s:18:"css/html-reset.css";s:44:"sites/all/themes/visikard/css/html-reset.css";s:18:"css/wireframes.css";s:44:"sites/all/themes/visikard/css/wireframes.css";s:20:"css/layout-fixed.css";s:46:"sites/all/themes/visikard/css/layout-fixed.css";s:24:"css/page-backgrounds.css";s:50:"sites/all/themes/visikard/css/page-backgrounds.css";s:12:"css/tabs.css";s:38:"sites/all/themes/visikard/css/tabs.css";s:16:"css/messages.css";s:42:"sites/all/themes/visikard/css/messages.css";s:13:"css/pages.css";s:39:"sites/all/themes/visikard/css/pages.css";s:21:"css/block-editing.css";s:47:"sites/all/themes/visikard/css/block-editing.css";s:14:"css/blocks.css";s:40:"sites/all/themes/visikard/css/blocks.css";s:18:"css/navigation.css";s:44:"sites/all/themes/visikard/css/navigation.css";s:21:"css/panels-styles.css";s:47:"sites/all/themes/visikard/css/panels-styles.css";s:20:"css/views-styles.css";s:46:"sites/all/themes/visikard/css/views-styles.css";s:13:"css/nodes.css";s:39:"sites/all/themes/visikard/css/nodes.css";s:16:"css/comments.css";s:42:"sites/all/themes/visikard/css/comments.css";s:13:"css/forms.css";s:39:"sites/all/themes/visikard/css/forms.css";s:14:"css/fields.css";s:40:"sites/all/themes/visikard/css/fields.css";}s:5:"print";a:1:{s:13:"css/print.css";s:39:"sites/all/themes/visikard/css/print.css";}}s:6:"engine";s:11:"phptemplate";s:10:"base_theme";s:3:"zen";}}', 'drupal_get_form', 'a:2:{i:0;s:21:"system_theme_settings";i:1;s:8:"visikard";}', 31, 5, 'admin/build/themes/settings', 'admin/build/themes', 'Visi Kard', 't', '', 128, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/build/themes/settings/zen', '', '', '_system_themes_access', 'a:1:{i:0;O:8:"stdClass":12:{s:8:"filename";s:29:"sites/all/themes/zen/zen.info";s:4:"name";s:3:"zen";s:4:"type";s:5:"theme";s:5:"owner";s:45:"themes/engines/phptemplate/phptemplate.engine";s:6:"status";s:1:"1";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:15:{s:4:"name";s:3:"Zen";s:11:"description";s:194:"Zen sub-themes are the ultimate starting themes for Drupal 6. Read the <a href="http://drupal.org/node/873778">online docs</a> or the included README-FIRST.txt on how to create a theme with Zen.";s:10:"screenshot";s:49:"sites/all/themes/zen/zen-internals/screenshot.png";s:4:"core";s:3:"6.x";s:6:"engine";s:11:"phptemplate";s:7:"regions";a:9:{s:13:"sidebar_first";s:13:"First sidebar";s:14:"sidebar_second";s:14:"Second sidebar";s:10:"navigation";s:14:"Navigation bar";s:9:"highlight";s:19:"Highlighted content";s:11:"content_top";s:11:"Content top";s:14:"content_bottom";s:14:"Content bottom";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";s:12:"page_closure";s:12:"Page closure";}s:8:"features";a:10:{i:0;s:4:"logo";i:1;s:4:"name";i:2;s:6:"slogan";i:3;s:7:"mission";i:4;s:17:"node_user_picture";i:5;s:20:"comment_user_picture";i:6;s:6:"search";i:7;s:7:"favicon";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:8:"settings";a:9:{s:17:"zen_block_editing";s:1:"1";s:14:"zen_breadcrumb";s:3:"yes";s:24:"zen_breadcrumb_separator";s:5:" › ";s:19:"zen_breadcrumb_home";s:1:"1";s:23:"zen_breadcrumb_trailing";s:1:"1";s:20:"zen_breadcrumb_title";s:1:"0";s:10:"zen_layout";s:18:"zen-columns-liquid";s:20:"zen_rebuild_registry";s:1:"0";s:14:"zen_wireframes";s:1:"0";}s:7:"plugins";a:1:{s:6:"panels";a:1:{s:7:"layouts";s:7:"layouts";}}s:7:"version";s:7:"6.x-2.1";s:7:"project";s:3:"zen";s:9:"datestamp";s:10:"1302017816";s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:30:"sites/all/themes/zen/style.css";}}s:7:"scripts";a:1:{s:9:"script.js";s:30:"sites/all/themes/zen/script.js";}s:3:"php";s:5:"4.3.5";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:30:"sites/all/themes/zen/style.css";}}s:6:"engine";s:11:"phptemplate";}}', 'drupal_get_form', 'a:2:{i:0;s:21:"system_theme_settings";i:1;s:3:"zen";}', 31, 5, 'admin/build/themes/settings', 'admin/build/themes', 'Zen', 't', '', 128, '', '', '', 0, 'modules/system/system.admin.inc'),
('admin/build/block/list/bluemarine', '', '', '_block_themes_access', 'a:1:{i:0;O:8:"stdClass":12:{s:8:"filename";s:33:"themes/bluemarine/bluemarine.info";s:4:"name";s:10:"bluemarine";s:4:"type";s:5:"theme";s:5:"owner";s:45:"themes/engines/phptemplate/phptemplate.engine";s:6:"status";s:1:"0";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:13:{s:4:"name";s:10:"Bluemarine";s:11:"description";s:66:"Table-based multi-column theme with a marine and ash color scheme.";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:6:"engine";s:11:"phptemplate";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:7:"regions";a:5:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";s:7:"content";s:7:"Content";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";}s:8:"features";a:10:{i:0;s:20:"comment_user_picture";i:1;s:7:"favicon";i:2;s:7:"mission";i:3;s:4:"logo";i:4;s:4:"name";i:5;s:17:"node_user_picture";i:6;s:6:"search";i:7;s:6:"slogan";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:27:"themes/bluemarine/style.css";}}s:7:"scripts";a:1:{s:9:"script.js";s:27:"themes/bluemarine/script.js";}s:10:"screenshot";s:32:"themes/bluemarine/screenshot.png";s:3:"php";s:5:"4.3.5";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:27:"themes/bluemarine/style.css";}}s:6:"engine";s:11:"phptemplate";}}', 'block_admin_display', 'a:1:{i:0;s:10:"bluemarine";}', 31, 5, 'admin/build/block/list', 'admin/build/block', 'Bluemarine', 't', '', 128, '', '', '', 0, 'modules/block/block.admin.inc'),
('admin/content/node-type/intro/display', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:29:"content_display_overview_form";i:1;s:5:"intro";}', 31, 5, 'admin/content/node-type/intro', 'admin/content/node-type/intro', 'Display fields', 't', '', 128, '', '', '', 2, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/page/display', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:29:"content_display_overview_form";i:1;s:4:"page";}', 31, 5, 'admin/content/node-type/page', 'admin/content/node-type/page', 'Display fields', 't', '', 128, '', '', '', 2, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/intro/fields', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:27:"content_field_overview_form";i:1;s:5:"intro";}', 31, 5, 'admin/content/node-type/intro', 'admin/content/node-type/intro', 'Manage fields', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/page/fields', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:27:"content_field_overview_form";i:1;s:4:"page";}', 31, 5, 'admin/content/node-type/page', 'admin/content/node-type/page', 'Manage fields', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/build/block/list/visikard', '', '', '_block_themes_access', 'a:1:{i:0;O:8:"stdClass":13:{s:8:"filename";s:39:"sites/all/themes/visikard/visikard.info";s:4:"name";s:8:"visikard";s:4:"type";s:5:"theme";s:5:"owner";s:45:"themes/engines/phptemplate/phptemplate.engine";s:6:"status";s:1:"0";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:14:{s:4:"name";s:9:"Visi Kard";s:11:"description";s:18:"Visi Kard Company.";s:10:"screenshot";s:40:"sites/all/themes/visikard/screenshot.png";s:7:"version";s:7:"6.x-1.0";s:4:"core";s:3:"6.x";s:10:"base theme";s:3:"zen";s:11:"stylesheets";a:2:{s:3:"all";a:16:{s:18:"css/html-reset.css";s:44:"sites/all/themes/visikard/css/html-reset.css";s:18:"css/wireframes.css";s:44:"sites/all/themes/visikard/css/wireframes.css";s:20:"css/layout-fixed.css";s:46:"sites/all/themes/visikard/css/layout-fixed.css";s:24:"css/page-backgrounds.css";s:50:"sites/all/themes/visikard/css/page-backgrounds.css";s:12:"css/tabs.css";s:38:"sites/all/themes/visikard/css/tabs.css";s:16:"css/messages.css";s:42:"sites/all/themes/visikard/css/messages.css";s:13:"css/pages.css";s:39:"sites/all/themes/visikard/css/pages.css";s:21:"css/block-editing.css";s:47:"sites/all/themes/visikard/css/block-editing.css";s:14:"css/blocks.css";s:40:"sites/all/themes/visikard/css/blocks.css";s:18:"css/navigation.css";s:44:"sites/all/themes/visikard/css/navigation.css";s:21:"css/panels-styles.css";s:47:"sites/all/themes/visikard/css/panels-styles.css";s:20:"css/views-styles.css";s:46:"sites/all/themes/visikard/css/views-styles.css";s:13:"css/nodes.css";s:39:"sites/all/themes/visikard/css/nodes.css";s:16:"css/comments.css";s:42:"sites/all/themes/visikard/css/comments.css";s:13:"css/forms.css";s:39:"sites/all/themes/visikard/css/forms.css";s:14:"css/fields.css";s:40:"sites/all/themes/visikard/css/fields.css";}s:5:"print";a:1:{s:13:"css/print.css";s:39:"sites/all/themes/visikard/css/print.css";}}s:23:"conditional-stylesheets";a:2:{s:5:"if IE";a:1:{s:3:"all";a:1:{i:0;s:10:"css/ie.css";}}s:11:"if lte IE 6";a:1:{s:3:"all";a:1:{i:0;s:11:"css/ie6.css";}}}s:7:"regions";a:12:{s:10:"admin_menu";s:10:"Admin Menu";s:13:"sidebar_first";s:13:"First sidebar";s:14:"sidebar_second";s:14:"Second sidebar";s:10:"navigation";s:14:"Navigation bar";s:10:"slide_show";s:10:"Slide show";s:9:"highlight";s:19:"Highlighted content";s:11:"content_top";s:11:"Content top";s:14:"content_bottom";s:14:"Content bottom";s:6:"header";s:6:"Header";s:6:"scroll";s:6:"Scroll";s:6:"footer";s:6:"Footer";s:12:"page_closure";s:12:"Page closure";}s:8:"features";a:10:{i:0;s:4:"logo";i:1;s:4:"name";i:2;s:6:"slogan";i:3;s:7:"mission";i:4;s:17:"node_user_picture";i:5;s:20:"comment_user_picture";i:6;s:6:"search";i:7;s:7:"favicon";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:8:"settings";a:8:{s:17:"zen_block_editing";s:1:"1";s:14:"zen_breadcrumb";s:3:"yes";s:24:"zen_breadcrumb_separator";s:5:" › ";s:19:"zen_breadcrumb_home";s:1:"1";s:23:"zen_breadcrumb_trailing";s:1:"1";s:20:"zen_breadcrumb_title";s:1:"0";s:20:"zen_rebuild_registry";s:1:"1";s:14:"zen_wireframes";s:1:"0";}s:7:"scripts";a:1:{s:9:"script.js";s:35:"sites/all/themes/visikard/script.js";}s:3:"php";s:5:"4.3.5";s:6:"engine";s:11:"phptemplate";}s:11:"stylesheets";a:2:{s:3:"all";a:16:{s:18:"css/html-reset.css";s:44:"sites/all/themes/visikard/css/html-reset.css";s:18:"css/wireframes.css";s:44:"sites/all/themes/visikard/css/wireframes.css";s:20:"css/layout-fixed.css";s:46:"sites/all/themes/visikard/css/layout-fixed.css";s:24:"css/page-backgrounds.css";s:50:"sites/all/themes/visikard/css/page-backgrounds.css";s:12:"css/tabs.css";s:38:"sites/all/themes/visikard/css/tabs.css";s:16:"css/messages.css";s:42:"sites/all/themes/visikard/css/messages.css";s:13:"css/pages.css";s:39:"sites/all/themes/visikard/css/pages.css";s:21:"css/block-editing.css";s:47:"sites/all/themes/visikard/css/block-editing.css";s:14:"css/blocks.css";s:40:"sites/all/themes/visikard/css/blocks.css";s:18:"css/navigation.css";s:44:"sites/all/themes/visikard/css/navigation.css";s:21:"css/panels-styles.css";s:47:"sites/all/themes/visikard/css/panels-styles.css";s:20:"css/views-styles.css";s:46:"sites/all/themes/visikard/css/views-styles.css";s:13:"css/nodes.css";s:39:"sites/all/themes/visikard/css/nodes.css";s:16:"css/comments.css";s:42:"sites/all/themes/visikard/css/comments.css";s:13:"css/forms.css";s:39:"sites/all/themes/visikard/css/forms.css";s:14:"css/fields.css";s:40:"sites/all/themes/visikard/css/fields.css";}s:5:"print";a:1:{s:13:"css/print.css";s:39:"sites/all/themes/visikard/css/print.css";}}s:6:"engine";s:11:"phptemplate";s:10:"base_theme";s:3:"zen";}}', 'block_admin_display', 'a:1:{i:0;s:8:"visikard";}', 31, 5, 'admin/build/block/list', 'admin/build/block', 'Visi Kard', 't', '', 128, '', '', '', 0, 'modules/block/block.admin.inc'),
('filefield/ahah/%/%/%', 'a:3:{i:2;N;i:3;N;i:4;N;}', '', 'filefield_edit_access', 'a:2:{i:0;i:2;i:1;i:3;}', 'filefield_js', 'a:3:{i:0;i:2;i:1;i:3;i:2;i:4;}', 24, 5, '', 'filefield/ahah/%/%/%', '', 't', '', 4, '', '', '', 0, ''),
('admin/build/menu-customize/%/add', 'a:1:{i:3;s:9:"menu_load";}', '', 'user_access', 'a:1:{i:0;s:15:"administer menu";}', 'drupal_get_form', 'a:4:{i:0;s:14:"menu_edit_item";i:1;s:3:"add";i:2;N;i:3;i:3;}', 29, 5, 'admin/build/menu-customize/%', 'admin/build/menu-customize/%', 'Add item', 't', '', 128, '', '', '', 0, 'modules/menu/menu.admin.inc'),
('admin/build/block/list/bootstrap', '', '', '_block_themes_access', 'a:1:{i:0;O:8:"stdClass":14:{s:8:"filename";s:41:"sites/all/themes/bootstrap/bootstrap.info";s:4:"name";s:9:"bootstrap";s:4:"type";s:5:"theme";s:5:"owner";s:45:"themes/engines/phptemplate/phptemplate.engine";s:6:"status";s:1:"1";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:12:{s:4:"name";s:9:"Bootstrap";s:11:"description";s:125:"Read the <a href="http://drupal.org/node/629510">online docs</a> or the included README.txt on how to create a Zen sub-theme.";s:10:"screenshot";s:41:"sites/all/themes/bootstrap/screenshot.png";s:4:"core";s:3:"6.x";s:10:"base theme";s:3:"zen";s:11:"stylesheets";a:1:{s:3:"all";a:18:{s:18:"css/html-reset.css";s:45:"sites/all/themes/bootstrap/css/html-reset.css";s:20:"css/layout-fixed.css";s:47:"sites/all/themes/bootstrap/css/layout-fixed.css";s:24:"css/page-backgrounds.css";s:51:"sites/all/themes/bootstrap/css/page-backgrounds.css";s:12:"css/tabs.css";s:39:"sites/all/themes/bootstrap/css/tabs.css";s:16:"css/messages.css";s:43:"sites/all/themes/bootstrap/css/messages.css";s:13:"css/pages.css";s:40:"sites/all/themes/bootstrap/css/pages.css";s:21:"css/block-editing.css";s:48:"sites/all/themes/bootstrap/css/block-editing.css";s:14:"css/blocks.css";s:41:"sites/all/themes/bootstrap/css/blocks.css";s:18:"css/navigation.css";s:45:"sites/all/themes/bootstrap/css/navigation.css";s:21:"css/panels-styles.css";s:48:"sites/all/themes/bootstrap/css/panels-styles.css";s:20:"css/views-styles.css";s:47:"sites/all/themes/bootstrap/css/views-styles.css";s:13:"css/nodes.css";s:40:"sites/all/themes/bootstrap/css/nodes.css";s:16:"css/comments.css";s:43:"sites/all/themes/bootstrap/css/comments.css";s:13:"css/forms.css";s:40:"sites/all/themes/bootstrap/css/forms.css";s:14:"css/fields.css";s:41:"sites/all/themes/bootstrap/css/fields.css";s:17:"css/bootstrap.css";s:44:"sites/all/themes/bootstrap/css/bootstrap.css";s:28:"css/bootstrap-responsive.css";s:55:"sites/all/themes/bootstrap/css/bootstrap-responsive.css";s:24:"css/bootstrap-custom.css";s:51:"sites/all/themes/bootstrap/css/bootstrap-custom.css";}}s:7:"scripts";a:4:{s:12:"js/jquery.js";s:39:"sites/all/themes/bootstrap/js/jquery.js";s:11:"js/slick.js";s:38:"sites/all/themes/bootstrap/js/slick.js";s:12:"js/script.js";s:39:"sites/all/themes/bootstrap/js/script.js";s:15:"js/bootstrap.js";s:42:"sites/all/themes/bootstrap/js/bootstrap.js";}s:7:"regions";a:9:{s:13:"sidebar_first";s:13:"First sidebar";s:14:"sidebar_second";s:14:"Second sidebar";s:10:"navigation";s:14:"Navigation bar";s:9:"highlight";s:19:"Highlighted content";s:11:"content_top";s:11:"Content top";s:14:"content_bottom";s:14:"Content bottom";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";s:12:"page_closure";s:12:"Page closure";}s:8:"features";a:10:{i:0;s:4:"logo";i:1;s:4:"name";i:2;s:6:"slogan";i:3;s:7:"mission";i:4;s:17:"node_user_picture";i:5;s:20:"comment_user_picture";i:6;s:6:"search";i:7;s:7:"favicon";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:8:"settings";a:8:{s:17:"zen_block_editing";s:1:"1";s:14:"zen_breadcrumb";s:3:"yes";s:24:"zen_breadcrumb_separator";s:5:" › ";s:19:"zen_breadcrumb_home";s:1:"1";s:23:"zen_breadcrumb_trailing";s:1:"1";s:20:"zen_breadcrumb_title";s:1:"0";s:20:"zen_rebuild_registry";s:1:"1";s:14:"zen_wireframes";s:1:"0";}s:3:"php";s:5:"4.3.5";s:6:"engine";s:11:"phptemplate";}s:11:"stylesheets";a:1:{s:3:"all";a:18:{s:18:"css/html-reset.css";s:45:"sites/all/themes/bootstrap/css/html-reset.css";s:20:"css/layout-fixed.css";s:47:"sites/all/themes/bootstrap/css/layout-fixed.css";s:24:"css/page-backgrounds.css";s:51:"sites/all/themes/bootstrap/css/page-backgrounds.css";s:12:"css/tabs.css";s:39:"sites/all/themes/bootstrap/css/tabs.css";s:16:"css/messages.css";s:43:"sites/all/themes/bootstrap/css/messages.css";s:13:"css/pages.css";s:40:"sites/all/themes/bootstrap/css/pages.css";s:21:"css/block-editing.css";s:48:"sites/all/themes/bootstrap/css/block-editing.css";s:14:"css/blocks.css";s:41:"sites/all/themes/bootstrap/css/blocks.css";s:18:"css/navigation.css";s:45:"sites/all/themes/bootstrap/css/navigation.css";s:21:"css/panels-styles.css";s:48:"sites/all/themes/bootstrap/css/panels-styles.css";s:20:"css/views-styles.css";s:47:"sites/all/themes/bootstrap/css/views-styles.css";s:13:"css/nodes.css";s:40:"sites/all/themes/bootstrap/css/nodes.css";s:16:"css/comments.css";s:43:"sites/all/themes/bootstrap/css/comments.css";s:13:"css/forms.css";s:40:"sites/all/themes/bootstrap/css/forms.css";s:14:"css/fields.css";s:41:"sites/all/themes/bootstrap/css/fields.css";s:17:"css/bootstrap.css";s:44:"sites/all/themes/bootstrap/css/bootstrap.css";s:28:"css/bootstrap-responsive.css";s:55:"sites/all/themes/bootstrap/css/bootstrap-responsive.css";s:24:"css/bootstrap-custom.css";s:51:"sites/all/themes/bootstrap/css/bootstrap-custom.css";}}s:7:"scripts";a:4:{s:12:"js/jquery.js";s:39:"sites/all/themes/bootstrap/js/jquery.js";s:11:"js/slick.js";s:38:"sites/all/themes/bootstrap/js/slick.js";s:12:"js/script.js";s:39:"sites/all/themes/bootstrap/js/script.js";s:15:"js/bootstrap.js";s:42:"sites/all/themes/bootstrap/js/bootstrap.js";}s:6:"engine";s:11:"phptemplate";s:10:"base_theme";s:3:"zen";}}', 'block_admin_display', 'a:1:{i:0;s:9:"bootstrap";}', 31, 5, 'admin/build/block/list', 'admin/build/block', 'Bootstrap', 't', '', 136, '', '', '', -10, 'modules/block/block.admin.inc'),
('admin/build/block/list/chameleon', '', '', '_block_themes_access', 'a:1:{i:0;O:8:"stdClass":11:{s:8:"filename";s:31:"themes/chameleon/chameleon.info";s:4:"name";s:9:"chameleon";s:4:"type";s:5:"theme";s:5:"owner";s:32:"themes/chameleon/chameleon.theme";s:6:"status";s:1:"0";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:12:{s:4:"name";s:9:"Chameleon";s:11:"description";s:42:"Minimalist tabled theme with light colors.";s:7:"regions";a:2:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";}s:8:"features";a:4:{i:0;s:4:"logo";i:1;s:7:"favicon";i:2;s:4:"name";i:3;s:6:"slogan";}s:11:"stylesheets";a:1:{s:3:"all";a:2:{s:9:"style.css";s:26:"themes/chameleon/style.css";s:10:"common.css";s:27:"themes/chameleon/common.css";}}s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:7:"scripts";a:1:{s:9:"script.js";s:26:"themes/chameleon/script.js";}s:10:"screenshot";s:31:"themes/chameleon/screenshot.png";s:3:"php";s:5:"4.3.5";}s:11:"stylesheets";a:1:{s:3:"all";a:2:{s:9:"style.css";s:26:"themes/chameleon/style.css";s:10:"common.css";s:27:"themes/chameleon/common.css";}}}}', 'block_admin_display', 'a:1:{i:0;s:9:"chameleon";}', 31, 5, 'admin/build/block/list', 'admin/build/block', 'Chameleon', 't', '', 128, '', '', '', 0, 'modules/block/block.admin.inc'),
('admin/settings/filters/%/configure', 'a:1:{i:3;s:18:"filter_format_load";}', '', 'user_access', 'a:1:{i:0;s:18:"administer filters";}', 'filter_admin_configure_page', 'a:1:{i:0;i:3;}', 29, 5, 'admin/settings/filters/%', 'admin/settings/filters/%', 'Configure', 't', '', 128, '', '', '', 1, 'modules/filter/filter.admin.inc'),
('admin/settings/date-time/formats/custom', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'date_api_configure_custom_date_formats', 'a:0:{}', 31, 5, 'admin/settings/date-time/formats', 'admin/settings/date-time', 'Custom formats', 't', '', 128, '', 'Allow users to configure custom date formats.', '', 2, 'sites/all/modules/date/date_api.admin.inc'),
('admin/settings/actions/delete/%', 'a:1:{i:4;s:12:"actions_load";}', '', 'user_access', 'a:1:{i:0;s:18:"administer actions";}', 'drupal_get_form', 'a:2:{i:0;s:26:"system_actions_delete_form";i:1;i:4;}', 30, 5, '', 'admin/settings/actions/delete/%', 'Delete action', 't', '', 4, '', 'Delete an action.', '', 0, ''),
('admin/build/contact/delete/%', 'a:1:{i:4;s:12:"contact_load";}', '', 'user_access', 'a:1:{i:0;s:33:"administer site-wide contact form";}', 'drupal_get_form', 'a:2:{i:0;s:20:"contact_admin_delete";i:1;i:4;}', 30, 5, '', 'admin/build/contact/delete/%', 'Delete contact', 't', '', 4, '', '', '', 0, 'modules/contact/contact.admin.inc'),
('admin/build/menu-customize/%/delete', 'a:1:{i:3;s:9:"menu_load";}', '', 'user_access', 'a:1:{i:0;s:15:"administer menu";}', 'menu_delete_menu_page', 'a:1:{i:0;i:3;}', 29, 5, '', 'admin/build/menu-customize/%/delete', 'Delete menu', 't', '', 4, '', '', '', 0, 'modules/menu/menu.admin.inc'),
('admin/content/node-type/contact/display', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:29:"content_display_overview_form";i:1;s:7:"contact";}', 31, 5, 'admin/content/node-type/contact', 'admin/content/node-type/contact', 'Display fields', 't', '', 128, '', '', '', 2, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/distribution/display', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:29:"content_display_overview_form";i:1;s:12:"distribution";}', 31, 5, 'admin/content/node-type/distribution', 'admin/content/node-type/distribution', 'Display fields', 't', '', 128, '', '', '', 2, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/views/ajax/autocomplete/tag', '', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'views_ui_autocomplete_tag', 'a:0:{}', 31, 5, '', 'admin/views/ajax/autocomplete/tag', '', 't', '', 4, '', '', '', 0, 'sites/all/modules/views/includes/admin.inc'),
('admin/content/node-type/home/display', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:29:"content_display_overview_form";i:1;s:4:"home";}', 31, 5, 'admin/content/node-type/home', 'admin/content/node-type/home', 'Display fields', 't', '', 128, '', '', '', 2, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/poll/display', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:29:"content_display_overview_form";i:1;s:4:"poll";}', 31, 5, 'admin/content/node-type/poll', 'admin/content/node-type/poll', 'Display fields', 't', '', 128, '', '', '', 2, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/story/display', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:29:"content_display_overview_form";i:1;s:5:"story";}', 31, 5, 'admin/content/node-type/story', 'admin/content/node-type/story', 'Display fields', 't', '', 128, '', '', '', 2, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/build/contact/edit/%', 'a:1:{i:4;s:12:"contact_load";}', '', 'user_access', 'a:1:{i:0;s:33:"administer site-wide contact form";}', 'drupal_get_form', 'a:3:{i:0;s:18:"contact_admin_edit";i:1;i:3;i:2;i:4;}', 30, 5, '', 'admin/build/contact/edit/%', 'Edit contact category', 't', '', 4, '', '', '', 0, 'modules/contact/contact.admin.inc'),
('admin/build/menu-customize/%/edit', 'a:1:{i:3;s:9:"menu_load";}', '', 'user_access', 'a:1:{i:0;s:15:"administer menu";}', 'drupal_get_form', 'a:3:{i:0;s:14:"menu_edit_menu";i:1;s:4:"edit";i:2;i:3;}', 29, 5, 'admin/build/menu-customize/%', 'admin/build/menu-customize/%', 'Edit menu', 't', '', 128, '', '', '', 0, 'modules/menu/menu.admin.inc');
INSERT INTO `menu_router` (`path`, `load_functions`, `to_arg_functions`, `access_callback`, `access_arguments`, `page_callback`, `page_arguments`, `fit`, `number_parts`, `tab_parent`, `tab_root`, `title`, `title_callback`, `title_arguments`, `type`, `block_callback`, `description`, `position`, `weight`, `file`) VALUES
('admin/build/block/list/garland', '', '', '_block_themes_access', 'a:1:{i:0;O:8:"stdClass":12:{s:8:"filename";s:27:"themes/garland/garland.info";s:4:"name";s:7:"garland";s:4:"type";s:5:"theme";s:5:"owner";s:45:"themes/engines/phptemplate/phptemplate.engine";s:6:"status";s:1:"1";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:13:{s:4:"name";s:7:"Garland";s:11:"description";s:66:"Tableless, recolorable, multi-column, fluid width theme (default).";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:6:"engine";s:11:"phptemplate";s:11:"stylesheets";a:2:{s:3:"all";a:1:{s:9:"style.css";s:24:"themes/garland/style.css";}s:5:"print";a:1:{s:9:"print.css";s:24:"themes/garland/print.css";}}s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:7:"regions";a:5:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";s:7:"content";s:7:"Content";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";}s:8:"features";a:10:{i:0;s:20:"comment_user_picture";i:1;s:7:"favicon";i:2;s:7:"mission";i:3;s:4:"logo";i:4;s:4:"name";i:5;s:17:"node_user_picture";i:6;s:6:"search";i:7;s:6:"slogan";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:7:"scripts";a:1:{s:9:"script.js";s:24:"themes/garland/script.js";}s:10:"screenshot";s:29:"themes/garland/screenshot.png";s:3:"php";s:5:"4.3.5";}s:11:"stylesheets";a:2:{s:3:"all";a:1:{s:9:"style.css";s:24:"themes/garland/style.css";}s:5:"print";a:1:{s:9:"print.css";s:24:"themes/garland/print.css";}}s:6:"engine";s:11:"phptemplate";}}', 'block_admin_display', 'a:1:{i:0;s:7:"garland";}', 31, 5, 'admin/build/block/list', 'admin/build/block', 'Garland', 't', '', 128, '', '', '', 0, 'modules/block/block.admin.inc'),
('admin/content/node-type/contact/fields', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:27:"content_field_overview_form";i:1;s:7:"contact";}', 31, 5, 'admin/content/node-type/contact', 'admin/content/node-type/contact', 'Manage fields', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/distribution/fields', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:27:"content_field_overview_form";i:1;s:12:"distribution";}', 31, 5, 'admin/content/node-type/distribution', 'admin/content/node-type/distribution', 'Manage fields', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/home/fields', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:27:"content_field_overview_form";i:1;s:4:"home";}', 31, 5, 'admin/content/node-type/home', 'admin/content/node-type/home', 'Manage fields', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/poll/fields', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:27:"content_field_overview_form";i:1;s:4:"poll";}', 31, 5, 'admin/content/node-type/poll', 'admin/content/node-type/poll', 'Manage fields', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/story/fields', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:2:{i:0;s:27:"content_field_overview_form";i:1;s:5:"story";}', 31, 5, 'admin/content/node-type/story', 'admin/content/node-type/story', 'Manage fields', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/build/block/list/marvin', '', '', '_block_themes_access', 'a:1:{i:0;O:8:"stdClass":12:{s:8:"filename";s:35:"themes/chameleon/marvin/marvin.info";s:4:"name";s:6:"marvin";s:4:"type";s:5:"theme";s:5:"owner";s:0:"";s:6:"status";s:1:"0";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:13:{s:4:"name";s:6:"Marvin";s:11:"description";s:31:"Boxy tabled theme in all grays.";s:7:"regions";a:2:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";}s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:10:"base theme";s:9:"chameleon";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:8:"features";a:10:{i:0;s:20:"comment_user_picture";i:1;s:7:"favicon";i:2;s:7:"mission";i:3;s:4:"logo";i:4;s:4:"name";i:5;s:17:"node_user_picture";i:6;s:6:"search";i:7;s:6:"slogan";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:33:"themes/chameleon/marvin/style.css";}}s:7:"scripts";a:1:{s:9:"script.js";s:33:"themes/chameleon/marvin/script.js";}s:10:"screenshot";s:38:"themes/chameleon/marvin/screenshot.png";s:3:"php";s:5:"4.3.5";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:33:"themes/chameleon/marvin/style.css";}}s:10:"base_theme";s:9:"chameleon";}}', 'block_admin_display', 'a:1:{i:0;s:6:"marvin";}', 31, 5, 'admin/build/block/list', 'admin/build/block', 'Marvin', 't', '', 128, '', '', '', 0, 'modules/block/block.admin.inc'),
('admin/build/block/list/minnelli', '', '', '_block_themes_access', 'a:1:{i:0;O:8:"stdClass":13:{s:8:"filename";s:37:"themes/garland/minnelli/minnelli.info";s:4:"name";s:8:"minnelli";s:4:"type";s:5:"theme";s:5:"owner";s:45:"themes/engines/phptemplate/phptemplate.engine";s:6:"status";s:1:"0";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:14:{s:4:"name";s:8:"Minnelli";s:11:"description";s:56:"Tableless, recolorable, multi-column, fixed width theme.";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:10:"base theme";s:7:"garland";s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:12:"minnelli.css";s:36:"themes/garland/minnelli/minnelli.css";}}s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:7:"regions";a:5:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";s:7:"content";s:7:"Content";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";}s:8:"features";a:10:{i:0;s:20:"comment_user_picture";i:1;s:7:"favicon";i:2;s:7:"mission";i:3;s:4:"logo";i:4;s:4:"name";i:5;s:17:"node_user_picture";i:6;s:6:"search";i:7;s:6:"slogan";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:7:"scripts";a:1:{s:9:"script.js";s:33:"themes/garland/minnelli/script.js";}s:10:"screenshot";s:38:"themes/garland/minnelli/screenshot.png";s:3:"php";s:5:"4.3.5";s:6:"engine";s:11:"phptemplate";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:12:"minnelli.css";s:36:"themes/garland/minnelli/minnelli.css";}}s:6:"engine";s:11:"phptemplate";s:10:"base_theme";s:7:"garland";}}', 'block_admin_display', 'a:1:{i:0;s:8:"minnelli";}', 31, 5, 'admin/build/block/list', 'admin/build/block', 'Minnelli', 't', '', 128, '', '', '', 0, 'modules/block/block.admin.inc'),
('admin/build/block/list/pushbutton', '', '', '_block_themes_access', 'a:1:{i:0;O:8:"stdClass":12:{s:8:"filename";s:33:"themes/pushbutton/pushbutton.info";s:4:"name";s:10:"pushbutton";s:4:"type";s:5:"theme";s:5:"owner";s:45:"themes/engines/phptemplate/phptemplate.engine";s:6:"status";s:1:"0";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:13:{s:4:"name";s:10:"Pushbutton";s:11:"description";s:52:"Tabled, multi-column theme in blue and orange tones.";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:6:"engine";s:11:"phptemplate";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:7:"regions";a:5:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";s:7:"content";s:7:"Content";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";}s:8:"features";a:10:{i:0;s:20:"comment_user_picture";i:1;s:7:"favicon";i:2;s:7:"mission";i:3;s:4:"logo";i:4;s:4:"name";i:5;s:17:"node_user_picture";i:6;s:6:"search";i:7;s:6:"slogan";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:27:"themes/pushbutton/style.css";}}s:7:"scripts";a:1:{s:9:"script.js";s:27:"themes/pushbutton/script.js";}s:10:"screenshot";s:32:"themes/pushbutton/screenshot.png";s:3:"php";s:5:"4.3.5";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:27:"themes/pushbutton/style.css";}}s:6:"engine";s:11:"phptemplate";}}', 'block_admin_display', 'a:1:{i:0;s:10:"pushbutton";}', 31, 5, 'admin/build/block/list', 'admin/build/block', 'Pushbutton', 't', '', 128, '', '', '', 0, 'modules/block/block.admin.inc'),
('admin/settings/filters/%/order', 'a:1:{i:3;s:18:"filter_format_load";}', '', 'user_access', 'a:1:{i:0;s:18:"administer filters";}', 'filter_admin_order_page', 'a:1:{i:0;i:3;}', 29, 5, 'admin/settings/filters/%', 'admin/settings/filters/%', 'Rearrange', 't', '', 128, '', '', '', 2, 'modules/filter/filter.admin.inc'),
('user/reset/%/%/%', 'a:3:{i:2;N;i:3;N;i:4;N;}', '', '1', 'a:0:{}', 'drupal_get_form', 'a:4:{i:0;s:15:"user_pass_reset";i:1;i:2;i:2;i:3;i:3;i:4;}', 24, 5, '', 'user/reset/%/%/%', 'Reset password', 't', '', 4, '', '', '', 0, 'modules/user/user.pages.inc'),
('admin/settings/language/configure/strings', '', '', 'user_access', 'a:1:{i:0;s:18:"administer filters";}', 'drupal_get_form', 'a:1:{i:0;s:26:"i18nstrings_admin_settings";}', 31, 5, 'admin/settings/language/configure', 'admin/settings/language', 'String translation', 't', '', 128, '', '', '', 20, 'sites/all/modules/i18n/i18nstrings/i18nstrings.admin.inc'),
('admin/build/block/list/zen', '', '', '_block_themes_access', 'a:1:{i:0;O:8:"stdClass":12:{s:8:"filename";s:29:"sites/all/themes/zen/zen.info";s:4:"name";s:3:"zen";s:4:"type";s:5:"theme";s:5:"owner";s:45:"themes/engines/phptemplate/phptemplate.engine";s:6:"status";s:1:"1";s:8:"throttle";s:1:"0";s:9:"bootstrap";s:1:"0";s:14:"schema_version";s:2:"-1";s:6:"weight";s:1:"0";s:4:"info";a:15:{s:4:"name";s:3:"Zen";s:11:"description";s:194:"Zen sub-themes are the ultimate starting themes for Drupal 6. Read the <a href="http://drupal.org/node/873778">online docs</a> or the included README-FIRST.txt on how to create a theme with Zen.";s:10:"screenshot";s:49:"sites/all/themes/zen/zen-internals/screenshot.png";s:4:"core";s:3:"6.x";s:6:"engine";s:11:"phptemplate";s:7:"regions";a:9:{s:13:"sidebar_first";s:13:"First sidebar";s:14:"sidebar_second";s:14:"Second sidebar";s:10:"navigation";s:14:"Navigation bar";s:9:"highlight";s:19:"Highlighted content";s:11:"content_top";s:11:"Content top";s:14:"content_bottom";s:14:"Content bottom";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";s:12:"page_closure";s:12:"Page closure";}s:8:"features";a:10:{i:0;s:4:"logo";i:1;s:4:"name";i:2;s:6:"slogan";i:3;s:7:"mission";i:4;s:17:"node_user_picture";i:5;s:20:"comment_user_picture";i:6;s:6:"search";i:7;s:7:"favicon";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:8:"settings";a:9:{s:17:"zen_block_editing";s:1:"1";s:14:"zen_breadcrumb";s:3:"yes";s:24:"zen_breadcrumb_separator";s:5:" › ";s:19:"zen_breadcrumb_home";s:1:"1";s:23:"zen_breadcrumb_trailing";s:1:"1";s:20:"zen_breadcrumb_title";s:1:"0";s:10:"zen_layout";s:18:"zen-columns-liquid";s:20:"zen_rebuild_registry";s:1:"0";s:14:"zen_wireframes";s:1:"0";}s:7:"plugins";a:1:{s:6:"panels";a:1:{s:7:"layouts";s:7:"layouts";}}s:7:"version";s:7:"6.x-2.1";s:7:"project";s:3:"zen";s:9:"datestamp";s:10:"1302017816";s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:30:"sites/all/themes/zen/style.css";}}s:7:"scripts";a:1:{s:9:"script.js";s:30:"sites/all/themes/zen/script.js";}s:3:"php";s:5:"4.3.5";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:30:"sites/all/themes/zen/style.css";}}s:6:"engine";s:11:"phptemplate";}}', 'block_admin_display', 'a:1:{i:0;s:3:"zen";}', 31, 5, 'admin/build/block/list', 'admin/build/block', 'Zen', 't', '', 128, '', '', '', 0, 'modules/block/block.admin.inc'),
('admin/views/ajax/autocomplete/user', '', '', 'user_access', 'a:1:{i:0;s:14:"access content";}', 'views_ajax_autocomplete_user', 'a:0:{}', 31, 5, '', 'admin/views/ajax/autocomplete/user', '', 't', '', 4, '', '', '', 0, 'sites/all/modules/views/includes/ajax.inc'),
('admin/build/contact/%/edit', 'a:1:{i:3;N;}', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'contact_field_add_field', 'a:1:{i:0;i:3;}', 29, 5, '', 'admin/build/contact/%/edit', '', 't', '', 4, '', '', '', 0, 'sites/all/modules/contact_field/contact_field_admin.inc'),
('admin/build/contact/add/%', 'a:1:{i:4;N;}', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'contact_field_add_field', 'a:2:{i:0;i:3;i:1;i:4;}', 30, 5, '', 'admin/build/contact/add/%', '', 't', '', 4, '', '', '', 0, 'sites/all/modules/contact_field/contact_field_admin.inc'),
('admin/build/views/export/%', 'a:1:{i:4;s:19:"views_ui_cache_load";}', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'drupal_get_form', 'a:2:{i:0;s:20:"views_ui_export_page";i:1;i:4;}', 30, 5, '', 'admin/build/views/export/%', '', 't', '', 4, '', '', '', 0, 'sites/all/modules/views/includes/admin.inc'),
('admin/build/views/clone/%', 'a:1:{i:4;s:19:"views_ui_cache_load";}', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'views_ui_clone_page', 'a:1:{i:0;i:4;}', 30, 5, '', 'admin/build/views/clone/%', '', 't', '', 4, '', '', '', 0, 'sites/all/modules/views/includes/admin.inc'),
('admin/build/views/disable/%', 'a:1:{i:4;s:21:"views_ui_default_load";}', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'views_ui_disable_page', 'a:1:{i:0;i:4;}', 30, 5, '', 'admin/build/views/disable/%', '', 't', '', 4, '', '', '', 0, 'sites/all/modules/views/includes/admin.inc'),
('admin/settings/date-time/formats/add', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:30:"date_api_add_date_formats_form";}', 31, 5, 'admin/settings/date-time/formats', 'admin/settings/date-time', 'Add format', 't', '', 128, '', 'Allow users to add additional date formats.', '', 3, 'sites/all/modules/date/date_api.admin.inc'),
('admin/build/views/enable/%', 'a:1:{i:4;s:21:"views_ui_default_load";}', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'views_ui_enable_page', 'a:1:{i:0;i:4;}', 30, 5, '', 'admin/build/views/enable/%', '', 't', '', 4, '', '', '', 0, 'sites/all/modules/views/includes/admin.inc'),
('admin/content/taxonomy/add/vocabulary', '', '', 'user_access', 'a:1:{i:0;s:19:"administer taxonomy";}', 'drupal_get_form', 'a:1:{i:0;s:24:"taxonomy_form_vocabulary";}', 31, 5, 'admin/content/taxonomy', 'admin/content/taxonomy', 'Add vocabulary', 't', '', 128, '', '', '', 0, 'modules/taxonomy/taxonomy.admin.inc'),
('admin/settings/date-time/formats/configure', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:26:"date_api_date_formats_form";}', 31, 5, 'admin/settings/date-time/formats', 'admin/settings/date-time', 'Configure', 't', '', 136, '', 'Allow users to configure date formats', '', 1, 'sites/all/modules/date/date_api.admin.inc'),
('admin/build/views/tools/convert', '', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'views_ui_admin_convert', 'a:0:{}', 31, 5, 'admin/build/views/tools', 'admin/build/views', 'Convert', 't', '', 128, '', 'Convert stored Views 1 views.', '', 1, 'sites/all/modules/views/includes/convert.inc'),
('admin/settings/date-time/delete/%', 'a:1:{i:4;N;}', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:2:{i:0;s:32:"date_api_delete_format_type_form";i:1;i:4;}', 30, 5, '', 'admin/settings/date-time/delete/%', 'Delete date format type', 't', '', 4, '', 'Allow users to delete a configured date format type.', '', 0, 'sites/all/modules/date/date_api.admin.inc'),
('admin/build/views/break-lock/%', 'a:1:{i:4;s:19:"views_ui_cache_load";}', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'drupal_get_form', 'a:2:{i:0;s:27:"views_ui_break_lock_confirm";i:1;i:4;}', 30, 5, '', 'admin/build/views/break-lock/%', 'Delete view', 't', '', 4, '', '', '', 0, 'sites/all/modules/views/includes/admin.inc'),
('node/%/revisions/%/view', 'a:2:{i:1;a:1:{s:9:"node_load";a:1:{i:0;i:3;}}i:3;N;}', '', '_node_revision_access', 'a:1:{i:0;i:1;}', 'node_show', 'a:3:{i:0;i:1;i:1;N;i:2;b:1;}', 21, 5, '', 'node/%/revisions/%/view', 'Revisions', 't', '', 4, '', '', '', 0, ''),
('admin/build/views/tools/basic', '', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'drupal_get_form', 'a:1:{i:0;s:20:"views_ui_admin_tools";}', 31, 5, 'admin/build/views/tools', 'admin/build/views', 'Basic', 't', '', 136, '', '', '', -10, 'sites/all/modules/views/includes/admin.inc'),
('admin/settings/language/i18n/variables', '', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:1:{i:0;s:25:"i18n_admin_variables_form";}', 31, 5, 'admin/settings/language/i18n', 'admin/settings/language', 'Variables', 't', '', 128, '', 'Multilingual variables.', '', 0, 'sites/all/modules/i18n/i18n.admin.inc'),
('admin/build/views/delete/%', 'a:1:{i:4;s:19:"views_ui_cache_load";}', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'drupal_get_form', 'a:2:{i:0;s:23:"views_ui_delete_confirm";i:1;i:4;}', 30, 5, '', 'admin/build/views/delete/%', 'Delete view', 't', '', 4, '', '', '', 0, 'sites/all/modules/views/includes/admin.inc'),
('admin/build/views/edit/%', 'a:1:{i:4;s:19:"views_ui_cache_load";}', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'views_ui_edit_page', 'a:1:{i:0;i:4;}', 30, 5, 'admin/build/views', 'admin/build/views', 'Edit', 't', '', 128, '', '', '', 0, 'sites/all/modules/views/includes/admin.inc'),
('node/%/revisions/%/delete', 'a:2:{i:1;a:1:{s:9:"node_load";a:1:{i:0;i:3;}}i:3;N;}', '', '_node_revision_access', 'a:2:{i:0;i:1;i:1;s:6:"delete";}', 'drupal_get_form', 'a:2:{i:0;s:28:"node_revision_delete_confirm";i:1;i:1;}', 21, 5, '', 'node/%/revisions/%/delete', 'Delete earlier revision', 't', '', 4, '', '', '', 0, 'modules/node/node.pages.inc'),
('node/%/revisions/%/revert', 'a:2:{i:1;a:1:{s:9:"node_load";a:1:{i:0;i:3;}}i:3;N;}', '', '_node_revision_access', 'a:2:{i:0;i:1;i:1;s:6:"update";}', 'drupal_get_form', 'a:2:{i:0;s:28:"node_revision_revert_confirm";i:1;i:1;}', 21, 5, '', 'node/%/revisions/%/revert', 'Revert to earlier revision', 't', '', 4, '', '', '', 0, 'modules/node/node.pages.inc'),
('admin/content/taxonomy/%/translation', 'a:1:{i:3;s:24:"taxonomy_vocabulary_load";}', '', '_i18ntaxonomy_translation_tab', 'a:1:{i:0;i:3;}', 'i18ntaxonomy_page_vocabulary', 'a:3:{i:0;i:3;i:1;i:5;i:2;i:6;}', 29, 5, 'admin/content/taxonomy/%', 'admin/content/taxonomy/%', 'Translation', 't', '', 128, '', '', '', 0, 'sites/all/modules/i18n/i18ntaxonomy/i18ntaxonomy.admin.inc'),
('admin/content/node-type/contact/display/basic', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:7:"contact";i:2;s:5:"basic";}', 63, 6, 'admin/content/node-type/contact/display', 'admin/content/node-type/contact', 'Basic', 't', '', 136, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/distribution/display/basic', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:12:"distribution";i:2;s:5:"basic";}', 63, 6, 'admin/content/node-type/distribution/display', 'admin/content/node-type/distribution', 'Basic', 't', '', 136, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/home/display/basic', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:4:"home";i:2;s:5:"basic";}', 63, 6, 'admin/content/node-type/home/display', 'admin/content/node-type/home', 'Basic', 't', '', 136, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/intro/display/basic', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:5:"intro";i:2;s:5:"basic";}', 63, 6, 'admin/content/node-type/intro/display', 'admin/content/node-type/intro', 'Basic', 't', '', 136, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/page/display/basic', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:4:"page";i:2;s:5:"basic";}', 63, 6, 'admin/content/node-type/page/display', 'admin/content/node-type/page', 'Basic', 't', '', 136, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/poll/display/basic', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:4:"poll";i:2;s:5:"basic";}', 63, 6, 'admin/content/node-type/poll/display', 'admin/content/node-type/poll', 'Basic', 't', '', 136, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/story/display/basic', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:5:"story";i:2;s:5:"basic";}', 63, 6, 'admin/content/node-type/story/display', 'admin/content/node-type/story', 'Basic', 't', '', 136, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/contact/display/rss', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:7:"contact";i:2;s:3:"rss";}', 63, 6, 'admin/content/node-type/contact/display', 'admin/content/node-type/contact', 'RSS', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/distribution/display/rss', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:12:"distribution";i:2;s:3:"rss";}', 63, 6, 'admin/content/node-type/distribution/display', 'admin/content/node-type/distribution', 'RSS', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/home/display/rss', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:4:"home";i:2;s:3:"rss";}', 63, 6, 'admin/content/node-type/home/display', 'admin/content/node-type/home', 'RSS', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/intro/display/rss', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:5:"intro";i:2;s:3:"rss";}', 63, 6, 'admin/content/node-type/intro/display', 'admin/content/node-type/intro', 'RSS', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/poll/display/rss', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:4:"poll";i:2;s:3:"rss";}', 63, 6, 'admin/content/node-type/poll/display', 'admin/content/node-type/poll', 'RSS', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/build/views/tools/export/results', '', '', 'user_access', 'a:1:{i:0;s:18:"use views exporter";}', 'views_export_export', 'a:0:{}', 63, 6, '', 'admin/build/views/tools/export/results', '', 't', '', 4, '', '', '', 0, ''),
('admin/content/node-type/page/display/rss', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:4:"page";i:2;s:3:"rss";}', 63, 6, 'admin/content/node-type/page/display', 'admin/content/node-type/page', 'RSS', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/story/display/rss', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:5:"story";i:2;s:3:"rss";}', 63, 6, 'admin/content/node-type/story/display', 'admin/content/node-type/story', 'RSS', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/contact/display/search', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:7:"contact";i:2;s:6:"search";}', 63, 6, 'admin/content/node-type/contact/display', 'admin/content/node-type/contact', 'Search', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/distribution/display/search', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:12:"distribution";i:2;s:6:"search";}', 63, 6, 'admin/content/node-type/distribution/display', 'admin/content/node-type/distribution', 'Search', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/home/display/search', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:4:"home";i:2;s:6:"search";}', 63, 6, 'admin/content/node-type/home/display', 'admin/content/node-type/home', 'Search', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/intro/display/search', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:5:"intro";i:2;s:6:"search";}', 63, 6, 'admin/content/node-type/intro/display', 'admin/content/node-type/intro', 'Search', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/page/display/search', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:4:"page";i:2;s:6:"search";}', 63, 6, 'admin/content/node-type/page/display', 'admin/content/node-type/page', 'Search', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/poll/display/search', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:4:"poll";i:2;s:6:"search";}', 63, 6, 'admin/content/node-type/poll/display', 'admin/content/node-type/poll', 'Search', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/story/display/search', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:5:"story";i:2;s:6:"search";}', 63, 6, 'admin/content/node-type/story/display', 'admin/content/node-type/story', 'Search', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/contact/display/token', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:7:"contact";i:2;s:5:"token";}', 63, 6, 'admin/content/node-type/contact/display', 'admin/content/node-type/contact', 'Token', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/distribution/display/token', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:12:"distribution";i:2;s:5:"token";}', 63, 6, 'admin/content/node-type/distribution/display', 'admin/content/node-type/distribution', 'Token', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/home/display/token', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:4:"home";i:2;s:5:"token";}', 63, 6, 'admin/content/node-type/home/display', 'admin/content/node-type/home', 'Token', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/intro/display/token', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:5:"intro";i:2;s:5:"token";}', 63, 6, 'admin/content/node-type/intro/display', 'admin/content/node-type/intro', 'Token', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/page/display/token', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:4:"page";i:2;s:5:"token";}', 63, 6, 'admin/content/node-type/page/display', 'admin/content/node-type/page', 'Token', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/poll/display/token', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:4:"poll";i:2;s:5:"token";}', 63, 6, 'admin/content/node-type/poll/display', 'admin/content/node-type/poll', 'Token', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/story/display/token', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:29:"content_display_overview_form";i:1;s:5:"story";i:2;s:5:"token";}', 63, 6, 'admin/content/node-type/story/display', 'admin/content/node-type/story', 'Token', 't', '', 128, '', '', '', 1, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/contact/groups/%', 'a:1:{i:5;N;}', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:26:"fieldgroup_group_edit_form";i:1;s:7:"contact";i:2;i:5;}', 62, 6, '', 'admin/content/node-type/contact/groups/%', 'Edit group', 't', '', 4, '', '', '', 0, ''),
('admin/content/node-type/distribution/groups/%', 'a:1:{i:5;N;}', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:26:"fieldgroup_group_edit_form";i:1;s:12:"distribution";i:2;i:5;}', 62, 6, '', 'admin/content/node-type/distribution/groups/%', 'Edit group', 't', '', 4, '', '', '', 0, ''),
('admin/content/node-type/home/groups/%', 'a:1:{i:5;N;}', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:26:"fieldgroup_group_edit_form";i:1;s:4:"home";i:2;i:5;}', 62, 6, '', 'admin/content/node-type/home/groups/%', 'Edit group', 't', '', 4, '', '', '', 0, ''),
('admin/content/node-type/intro/groups/%', 'a:1:{i:5;N;}', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:26:"fieldgroup_group_edit_form";i:1;s:5:"intro";i:2;i:5;}', 62, 6, '', 'admin/content/node-type/intro/groups/%', 'Edit group', 't', '', 4, '', '', '', 0, ''),
('admin/content/node-type/page/groups/%', 'a:1:{i:5;N;}', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:26:"fieldgroup_group_edit_form";i:1;s:4:"page";i:2;i:5;}', 62, 6, '', 'admin/content/node-type/page/groups/%', 'Edit group', 't', '', 4, '', '', '', 0, ''),
('admin/content/node-type/poll/groups/%', 'a:1:{i:5;N;}', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:26:"fieldgroup_group_edit_form";i:1;s:4:"poll";i:2;i:5;}', 62, 6, '', 'admin/content/node-type/poll/groups/%', 'Edit group', 't', '', 4, '', '', '', 0, ''),
('admin/content/node-type/story/groups/%', 'a:1:{i:5;N;}', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:26:"fieldgroup_group_edit_form";i:1;s:5:"story";i:2;i:5;}', 62, 6, '', 'admin/content/node-type/story/groups/%', 'Edit group', 't', '', 4, '', '', '', 0, ''),
('admin/content/node-type/contact/fields/field_contact_address', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"content_field_edit_form";i:1;s:7:"contact";i:2;s:21:"field_contact_address";}', 63, 6, 'admin/content/node-type/contact/fields', 'admin/content/node-type/contact', 'Address', 't', '', 128, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/home/fields/field_home_company_info', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"content_field_edit_form";i:1;s:4:"home";i:2;s:23:"field_home_company_info";}', 63, 6, 'admin/content/node-type/home/fields', 'admin/content/node-type/home', 'Company info', 't', '', 128, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/distribution/fields/field_distribution_content', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"content_field_edit_form";i:1;s:12:"distribution";i:2;s:26:"field_distribution_content";}', 63, 6, 'admin/content/node-type/distribution/fields', 'admin/content/node-type/distribution', 'Content', 't', '', 128, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/intro/fields/field_intro_content', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"content_field_edit_form";i:1;s:5:"intro";i:2;s:19:"field_intro_content";}', 63, 6, 'admin/content/node-type/intro/fields', 'admin/content/node-type/intro', 'Content', 't', '', 128, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/build/menu/item/%/delete', 'a:1:{i:4;s:14:"menu_link_load";}', '', 'user_access', 'a:1:{i:0;s:15:"administer menu";}', 'menu_item_delete_page', 'a:1:{i:0;i:4;}', 61, 6, '', 'admin/build/menu/item/%/delete', 'Delete menu item', 't', '', 4, '', '', '', 0, 'modules/menu/menu.admin.inc'),
('admin/build/menu/item/%/edit', 'a:1:{i:4;s:14:"menu_link_load";}', '', 'user_access', 'a:1:{i:0;s:15:"administer menu";}', 'drupal_get_form', 'a:4:{i:0;s:14:"menu_edit_item";i:1;s:4:"edit";i:2;i:4;i:3;N;}', 61, 6, '', 'admin/build/menu/item/%/edit', 'Edit menu item', 't', '', 4, '', '', '', 0, 'modules/menu/menu.admin.inc'),
('admin/content/taxonomy/edit/vocabulary/%', 'a:1:{i:5;s:24:"taxonomy_vocabulary_load";}', '', 'user_access', 'a:1:{i:0;s:19:"administer taxonomy";}', 'taxonomy_admin_vocabulary_edit', 'a:1:{i:0;i:5;}', 62, 6, '', 'admin/content/taxonomy/edit/vocabulary/%', 'Edit vocabulary', 't', '', 4, '', '', '', 0, 'modules/taxonomy/taxonomy.admin.inc'),
('admin/content/node-type/contact/fields/field_contact_email', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"content_field_edit_form";i:1;s:7:"contact";i:2;s:19:"field_contact_email";}', 63, 6, 'admin/content/node-type/contact/fields', 'admin/content/node-type/contact', 'Email', 't', '', 128, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/home/fields/field_home_embed', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"content_field_edit_form";i:1;s:4:"home";i:2;s:16:"field_home_embed";}', 63, 6, 'admin/content/node-type/home/fields', 'admin/content/node-type/home', 'Embed', 't', '', 128, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/intro/fields/field_intro_embed', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"content_field_edit_form";i:1;s:5:"intro";i:2;s:17:"field_intro_embed";}', 63, 6, 'admin/content/node-type/intro/fields', 'admin/content/node-type/intro', 'Embed', 't', '', 128, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/contact/fields/field_contact_fax', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"content_field_edit_form";i:1;s:7:"contact";i:2;s:17:"field_contact_fax";}', 63, 6, 'admin/content/node-type/contact/fields', 'admin/content/node-type/contact', 'Fax', 't', '', 128, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/contact/fields/field_contact_mobile', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"content_field_edit_form";i:1;s:7:"contact";i:2;s:20:"field_contact_mobile";}', 63, 6, 'admin/content/node-type/contact/fields', 'admin/content/node-type/contact', 'Mobile', 't', '', 128, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/contact/fields/field_contact_phone', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"content_field_edit_form";i:1;s:7:"contact";i:2;s:19:"field_contact_phone";}', 63, 6, 'admin/content/node-type/contact/fields', 'admin/content/node-type/contact', 'Phone', 't', '', 128, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/build/menu/item/%/reset', 'a:1:{i:4;s:14:"menu_link_load";}', '', 'user_access', 'a:1:{i:0;s:15:"administer menu";}', 'drupal_get_form', 'a:2:{i:0;s:23:"menu_reset_item_confirm";i:1;i:4;}', 61, 6, '', 'admin/build/menu/item/%/reset', 'Reset menu item', 't', '', 4, '', '', '', 0, 'modules/menu/menu.admin.inc'),
('admin/content/node-type/home/fields/field_home_trophic_info', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"content_field_edit_form";i:1;s:4:"home";i:2;s:23:"field_home_trophic_info";}', 63, 6, 'admin/content/node-type/home/fields', 'admin/content/node-type/home', 'Trophic info', 't', '', 128, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/contact/fields/field_contact_website', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"content_field_edit_form";i:1;s:7:"contact";i:2;s:21:"field_contact_website";}', 63, 6, 'admin/content/node-type/contact/fields', 'admin/content/node-type/contact', 'Website', 't', '', 128, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/build/views/%/%/%', 'a:3:{i:3;s:16:"views_ui_js_load";i:4;N;i:5;s:19:"views_ui_cache_load";}', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'views_ui_ajax_form', 'a:3:{i:0;i:3;i:1;i:4;i:2;i:5;}', 56, 6, '', 'admin/build/views/%/%/%', '', 't', '', 4, '', '', '', 0, 'sites/all/modules/views/includes/admin.inc'),
('admin/build/views/%/analyze/%', 'a:2:{i:3;s:16:"views_ui_js_load";i:5;s:19:"views_ui_cache_load";}', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'views_ui_analyze_view', 'a:2:{i:0;i:3;i:1;i:5;}', 58, 6, '', 'admin/build/views/%/analyze/%', '', 't', '', 4, '', '', '', 0, 'sites/all/modules/views/includes/admin.inc'),
('admin/content/taxonomy/%/add/term', 'a:1:{i:3;s:24:"taxonomy_vocabulary_load";}', '', 'user_access', 'a:1:{i:0;s:19:"administer taxonomy";}', 'taxonomy_add_term_page', 'a:1:{i:0;i:3;}', 59, 6, 'admin/content/taxonomy/%', 'admin/content/taxonomy/%', 'Add term', 't', '', 128, '', '', '', 0, 'modules/taxonomy/taxonomy.admin.inc'),
('admin/build/views/%/add-display/%', 'a:2:{i:3;s:16:"views_ui_js_load";i:5;s:19:"views_ui_cache_load";}', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'views_ui_add_display', 'a:2:{i:0;i:3;i:1;i:5;}', 58, 6, '', 'admin/build/views/%/add-display/%', '', 't', '', 4, '', '', '', 0, 'sites/all/modules/views/includes/admin.inc'),
('admin/build/views/%/details/%', 'a:2:{i:3;s:16:"views_ui_js_load";i:5;s:19:"views_ui_cache_load";}', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'views_ui_edit_details', 'a:2:{i:0;i:3;i:1;i:5;}', 58, 6, '', 'admin/build/views/%/details/%', '', 't', '', 4, '', '', '', 0, 'sites/all/modules/views/includes/admin.inc'),
('admin/settings/date-time/formats/delete/%', 'a:1:{i:5;N;}', '', 'user_access', 'a:1:{i:0;s:29:"administer site configuration";}', 'drupal_get_form', 'a:2:{i:0;s:27:"date_api_delete_format_form";i:1;i:5;}', 62, 6, '', 'admin/settings/date-time/formats/delete/%', 'Delete date format', 't', '', 4, '', 'Allow users to delete a configured date format.', '', 0, 'sites/all/modules/date/date_api.admin.inc'),
('admin/build/views/%/preview/%', 'a:2:{i:3;s:16:"views_ui_js_load";i:5;s:19:"views_ui_cache_load";}', '', 'user_access', 'a:1:{i:0;s:16:"administer views";}', 'views_ui_preview', 'a:2:{i:0;i:3;i:1;i:5;}', 58, 6, '', 'admin/build/views/%/preview/%', '', 't', '', 4, '', '', '', 0, 'sites/all/modules/views/includes/admin.inc'),
('admin/settings/wysiwyg/profile/%/edit', 'a:1:{i:4;s:20:"wysiwyg_profile_load";}', '', 'user_access', 'a:1:{i:0;s:18:"administer filters";}', 'drupal_get_form', 'a:2:{i:0;s:20:"wysiwyg_profile_form";i:1;i:4;}', 61, 6, 'admin/settings/wysiwyg/profile/%wysiwyg_profile', 'admin/settings/wysiwyg/profile', 'Edit', 't', '', 128, '', '', '', 0, 'sites/all/modules/wysiwyg/wysiwyg.admin.inc'),
('admin/settings/wysiwyg/profile/%/delete', 'a:1:{i:4;s:20:"wysiwyg_profile_load";}', '', 'user_access', 'a:1:{i:0;s:18:"administer filters";}', 'drupal_get_form', 'a:2:{i:0;s:30:"wysiwyg_profile_delete_confirm";i:1;i:4;}', 61, 6, 'admin/settings/wysiwyg/profile/%wysiwyg_profile', 'admin/settings/wysiwyg/profile', 'Remove', 't', '', 128, '', '', '', 10, 'sites/all/modules/wysiwyg/wysiwyg.admin.inc'),
('admin/content/node-type/contact/groups/%/remove', 'a:1:{i:5;N;}', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"fieldgroup_remove_group";i:1;s:7:"contact";i:2;i:5;}', 125, 7, '', 'admin/content/node-type/contact/groups/%/remove', 'Edit group', 't', '', 4, '', '', '', 0, ''),
('admin/content/node-type/distribution/groups/%/remove', 'a:1:{i:5;N;}', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"fieldgroup_remove_group";i:1;s:12:"distribution";i:2;i:5;}', 125, 7, '', 'admin/content/node-type/distribution/groups/%/remove', 'Edit group', 't', '', 4, '', '', '', 0, ''),
('admin/content/node-type/home/groups/%/remove', 'a:1:{i:5;N;}', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"fieldgroup_remove_group";i:1;s:4:"home";i:2;i:5;}', 125, 7, '', 'admin/content/node-type/home/groups/%/remove', 'Edit group', 't', '', 4, '', '', '', 0, ''),
('admin/content/node-type/intro/groups/%/remove', 'a:1:{i:5;N;}', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"fieldgroup_remove_group";i:1;s:5:"intro";i:2;i:5;}', 125, 7, '', 'admin/content/node-type/intro/groups/%/remove', 'Edit group', 't', '', 4, '', '', '', 0, ''),
('admin/content/node-type/page/groups/%/remove', 'a:1:{i:5;N;}', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"fieldgroup_remove_group";i:1;s:4:"page";i:2;i:5;}', 125, 7, '', 'admin/content/node-type/page/groups/%/remove', 'Edit group', 't', '', 4, '', '', '', 0, ''),
('admin/content/node-type/poll/groups/%/remove', 'a:1:{i:5;N;}', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"fieldgroup_remove_group";i:1;s:4:"poll";i:2;i:5;}', 125, 7, '', 'admin/content/node-type/poll/groups/%/remove', 'Edit group', 't', '', 4, '', '', '', 0, ''),
('admin/content/node-type/story/groups/%/remove', 'a:1:{i:5;N;}', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:23:"fieldgroup_remove_group";i:1;s:5:"story";i:2;i:5;}', 125, 7, '', 'admin/content/node-type/story/groups/%/remove', 'Edit group', 't', '', 4, '', '', '', 0, ''),
('admin/content/node-type/contact/fields/field_contact_address/remove', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:25:"content_field_remove_form";i:1;s:7:"contact";i:2;s:21:"field_contact_address";}', 127, 7, '', 'admin/content/node-type/contact/fields/field_contact_address/remove', 'Remove field', 't', '', 4, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/contact/fields/field_contact_email/remove', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:25:"content_field_remove_form";i:1;s:7:"contact";i:2;s:19:"field_contact_email";}', 127, 7, '', 'admin/content/node-type/contact/fields/field_contact_email/remove', 'Remove field', 't', '', 4, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/contact/fields/field_contact_fax/remove', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:25:"content_field_remove_form";i:1;s:7:"contact";i:2;s:17:"field_contact_fax";}', 127, 7, '', 'admin/content/node-type/contact/fields/field_contact_fax/remove', 'Remove field', 't', '', 4, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/contact/fields/field_contact_mobile/remove', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:25:"content_field_remove_form";i:1;s:7:"contact";i:2;s:20:"field_contact_mobile";}', 127, 7, '', 'admin/content/node-type/contact/fields/field_contact_mobile/remove', 'Remove field', 't', '', 4, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/contact/fields/field_contact_phone/remove', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:25:"content_field_remove_form";i:1;s:7:"contact";i:2;s:19:"field_contact_phone";}', 127, 7, '', 'admin/content/node-type/contact/fields/field_contact_phone/remove', 'Remove field', 't', '', 4, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/contact/fields/field_contact_website/remove', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:25:"content_field_remove_form";i:1;s:7:"contact";i:2;s:21:"field_contact_website";}', 127, 7, '', 'admin/content/node-type/contact/fields/field_contact_website/remove', 'Remove field', 't', '', 4, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/distribution/fields/field_distribution_content/remove', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:25:"content_field_remove_form";i:1;s:12:"distribution";i:2;s:26:"field_distribution_content";}', 127, 7, '', 'admin/content/node-type/distribution/fields/field_distribution_content/remove', 'Remove field', 't', '', 4, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/home/fields/field_home_company_info/remove', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:25:"content_field_remove_form";i:1;s:4:"home";i:2;s:23:"field_home_company_info";}', 127, 7, '', 'admin/content/node-type/home/fields/field_home_company_info/remove', 'Remove field', 't', '', 4, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/home/fields/field_home_embed/remove', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:25:"content_field_remove_form";i:1;s:4:"home";i:2;s:16:"field_home_embed";}', 127, 7, '', 'admin/content/node-type/home/fields/field_home_embed/remove', 'Remove field', 't', '', 4, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/home/fields/field_home_trophic_info/remove', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:25:"content_field_remove_form";i:1;s:4:"home";i:2;s:23:"field_home_trophic_info";}', 127, 7, '', 'admin/content/node-type/home/fields/field_home_trophic_info/remove', 'Remove field', 't', '', 4, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/intro/fields/field_intro_content/remove', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:25:"content_field_remove_form";i:1;s:5:"intro";i:2;s:19:"field_intro_content";}', 127, 7, '', 'admin/content/node-type/intro/fields/field_intro_content/remove', 'Remove field', 't', '', 4, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc'),
('admin/content/node-type/intro/fields/field_intro_embed/remove', '', '', 'user_access', 'a:1:{i:0;s:24:"administer content types";}', 'drupal_get_form', 'a:3:{i:0;s:25:"content_field_remove_form";i:1;s:5:"intro";i:2;s:17:"field_intro_embed";}', 127, 7, '', 'admin/content/node-type/intro/fields/field_intro_embed/remove', 'Remove field', 't', '', 4, '', '', '', 0, 'sites/all/modules/cck/includes/content.admin.inc');

-- --------------------------------------------------------

--
-- Table structure for table `node`
--

CREATE TABLE IF NOT EXISTS `node` (
  `nid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(32) NOT NULL DEFAULT '',
  `language` varchar(12) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `uid` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `created` int(11) NOT NULL DEFAULT '0',
  `changed` int(11) NOT NULL DEFAULT '0',
  `comment` int(11) NOT NULL DEFAULT '0',
  `promote` int(11) NOT NULL DEFAULT '0',
  `moderate` int(11) NOT NULL DEFAULT '0',
  `sticky` int(11) NOT NULL DEFAULT '0',
  `tnid` int(10) unsigned NOT NULL DEFAULT '0',
  `translate` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`nid`),
  UNIQUE KEY `vid` (`vid`),
  KEY `node_changed` (`changed`),
  KEY `node_created` (`created`),
  KEY `node_moderate` (`moderate`),
  KEY `node_promote_status` (`promote`,`status`),
  KEY `node_status_type` (`status`,`type`,`nid`),
  KEY `node_title_type` (`title`,`type`(4)),
  KEY `node_type` (`type`(4)),
  KEY `uid` (`uid`),
  KEY `tnid` (`tnid`),
  KEY `translate` (`translate`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `node`
--

INSERT INTO `node` (`nid`, `vid`, `type`, `language`, `title`, `uid`, `status`, `created`, `changed`, `comment`, `promote`, `moderate`, `sticky`, `tnid`, `translate`) VALUES
(1, 1, 'page', '', 'test', 1, 1, 1420945884, 1420945884, 0, 0, 0, 0, 0, 0),
(2, 2, 'page', 'en', 'Gioi Thieu', 1, 1, 1421058350, 1421058350, 0, 0, 0, 0, 0, 0),
(3, 3, 'page', 'en', 'San Pham', 1, 1, 1421058378, 1421058378, 0, 0, 0, 0, 0, 0),
(5, 5, 'contact', 'en', 'Liên hệ', 1, 1, 1421135792, 1421138039, 0, 1, 0, 0, 0, 0),
(7, 7, 'intro', '', 'Với hơn 5 năm hoạt động trong lĩnh vực dinh dưỡng chúng tôi đã đạt được những thành tựu sau', 1, 1, 1421144431, 1421144431, 0, 1, 0, 0, 0, 0),
(8, 8, 'home', '', 'Với hơn 10 dòng sản phẩm chính, đáp ứng nhu cầu dinh dưỡng hàng ngày cho mọi lứa tuổi', 1, 1, 1421304674, 1421304674, 0, 1, 0, 0, 0, 0),
(9, 9, 'distribution', '', 'HT Phân Phối', 1, 1, 1421309676, 1421309676, 0, 1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `node_access`
--

CREATE TABLE IF NOT EXISTS `node_access` (
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `gid` int(10) unsigned NOT NULL DEFAULT '0',
  `realm` varchar(255) NOT NULL DEFAULT '',
  `grant_view` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `grant_update` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `grant_delete` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`nid`,`gid`,`realm`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `node_access`
--

INSERT INTO `node_access` (`nid`, `gid`, `realm`, `grant_view`, `grant_update`, `grant_delete`) VALUES
(0, 0, 'all', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `node_comment_statistics`
--

CREATE TABLE IF NOT EXISTS `node_comment_statistics` (
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `last_comment_timestamp` int(11) NOT NULL DEFAULT '0',
  `last_comment_name` varchar(60) DEFAULT NULL,
  `last_comment_uid` int(11) NOT NULL DEFAULT '0',
  `comment_count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`nid`),
  KEY `node_comment_timestamp` (`last_comment_timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `node_comment_statistics`
--

INSERT INTO `node_comment_statistics` (`nid`, `last_comment_timestamp`, `last_comment_name`, `last_comment_uid`, `comment_count`) VALUES
(1, 1420945884, NULL, 1, 0),
(2, 1421058350, NULL, 1, 0),
(3, 1421058378, NULL, 1, 0),
(5, 1421135792, NULL, 1, 0),
(7, 1421144431, NULL, 1, 0),
(8, 1421304674, NULL, 1, 0),
(9, 1421309676, NULL, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `node_counter`
--

CREATE TABLE IF NOT EXISTS `node_counter` (
  `nid` int(11) NOT NULL DEFAULT '0',
  `totalcount` bigint(20) unsigned NOT NULL DEFAULT '0',
  `daycount` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `node_counter`
--


-- --------------------------------------------------------

--
-- Table structure for table `node_revisions`
--

CREATE TABLE IF NOT EXISTS `node_revisions` (
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `vid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `body` longtext NOT NULL,
  `teaser` longtext NOT NULL,
  `log` longtext NOT NULL,
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `format` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  KEY `nid` (`nid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `node_revisions`
--

INSERT INTO `node_revisions` (`nid`, `vid`, `uid`, `title`, `body`, `teaser`, `log`, `timestamp`, `format`) VALUES
(1, 1, 1, 'test', 'test', 'test', '', 1420945884, 1),
(2, 2, 1, 'Gioi Thieu', 'Gioi Thieu', 'Gioi Thieu', '', 1421058350, 1),
(3, 3, 1, 'San Pham', 'San Pham', 'San Pham', '', 1421058378, 1),
(7, 7, 1, 'Với hơn 5 năm hoạt động trong lĩnh vực dinh dưỡng chúng tôi đã đạt được những thành tựu sau', '', '', '', 1421144431, 0),
(5, 5, 1, 'Liên hệ', '', '', '', 1421138039, 0),
(8, 8, 1, 'Với hơn 10 dòng sản phẩm chính, đáp ứng nhu cầu dinh dưỡng hàng ngày cho mọi lứa tuổi', '', '', '', 1421304674, 0),
(9, 9, 1, 'HT Phân Phối', '', '', '', 1421309676, 0);

-- --------------------------------------------------------

--
-- Table structure for table `node_type`
--

CREATE TABLE IF NOT EXISTS `node_type` (
  `type` varchar(32) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `module` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `help` mediumtext NOT NULL,
  `has_title` tinyint(3) unsigned NOT NULL,
  `title_label` varchar(255) NOT NULL DEFAULT '',
  `has_body` tinyint(3) unsigned NOT NULL,
  `body_label` varchar(255) NOT NULL DEFAULT '',
  `min_word_count` smallint(5) unsigned NOT NULL,
  `custom` tinyint(4) NOT NULL DEFAULT '0',
  `modified` tinyint(4) NOT NULL DEFAULT '0',
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `orig_type` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `node_type`
--

INSERT INTO `node_type` (`type`, `name`, `module`, `description`, `help`, `has_title`, `title_label`, `has_body`, `body_label`, `min_word_count`, `custom`, `modified`, `locked`, `orig_type`) VALUES
('page', 'Page', 'node', 'A <em>page</em>, similar in form to a <em>story</em>, is a simple method for creating and displaying information that rarely changes, such as an "About us" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site''s initial home page.', '', 1, 'Title', 1, 'Body', 0, 1, 1, 0, 'page'),
('story', 'Story', 'node', 'A <em>story</em>, similar in form to a <em>page</em>, is ideal for creating and displaying content that informs or engages website visitors. Press releases, site announcements, and informal blog-like entries may all be created with a <em>story</em> entry. By default, a <em>story</em> entry is automatically featured on the site''s initial home page, and provides the ability to post comments.', '', 1, 'Title', 1, 'Body', 0, 1, 1, 0, 'story'),
('contact', 'Contact', 'node', '', '', 1, 'Title', 0, '', 0, 1, 1, 0, ''),
('poll', 'Poll', 'poll', 'A <em>poll</em> is a question with a set of possible responses. A <em>poll</em>, once created, automatically provides a simple running count of the number of votes received for each response.', '', 1, 'Question', 0, '', 0, 0, 0, 1, 'poll'),
('intro', 'Intro', 'node', '', '', 1, 'Title', 0, '', 0, 1, 1, 0, ''),
('home', 'Home', 'node', '', '', 1, 'Title', 0, '', 0, 1, 1, 0, ''),
('distribution', 'Distribution', 'node', '', '', 1, 'Title', 0, '', 0, 1, 1, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `permission`
--

CREATE TABLE IF NOT EXISTS `permission` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(10) unsigned NOT NULL DEFAULT '0',
  `perm` longtext,
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pid`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `permission`
--

INSERT INTO `permission` (`pid`, `rid`, `perm`, `tid`) VALUES
(3, 1, 'collapse format fieldset by default, collapsible format selection, show format selection for blocks, show format selection for comments, show format selection for nodes, show format tips, show more format tips link, access site-wide contact form, access content', 0),
(4, 2, 'collapse format fieldset by default, collapsible format selection, show format selection for blocks, show format selection for comments, show format selection for nodes, show format tips, show more format tips link, access comments, post comments, post comments without approval, access site-wide contact form, access content', 0);

-- --------------------------------------------------------

--
-- Table structure for table `poll`
--

CREATE TABLE IF NOT EXISTS `poll` (
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `runtime` int(11) NOT NULL DEFAULT '0',
  `active` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `poll`
--


-- --------------------------------------------------------

--
-- Table structure for table `poll_choices`
--

CREATE TABLE IF NOT EXISTS `poll_choices` (
  `chid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `chtext` varchar(128) NOT NULL DEFAULT '',
  `chvotes` int(11) NOT NULL DEFAULT '0',
  `chorder` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`chid`),
  KEY `nid` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `poll_choices`
--


-- --------------------------------------------------------

--
-- Table structure for table `poll_votes`
--

CREATE TABLE IF NOT EXISTS `poll_votes` (
  `nid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `chorder` int(11) NOT NULL DEFAULT '-1',
  `hostname` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`nid`,`uid`,`hostname`),
  KEY `hostname` (`hostname`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `poll_votes`
--


-- --------------------------------------------------------

--
-- Table structure for table `profile_fields`
--

CREATE TABLE IF NOT EXISTS `profile_fields` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `name` varchar(128) NOT NULL DEFAULT '',
  `explanation` text,
  `category` varchar(255) DEFAULT NULL,
  `page` varchar(255) DEFAULT NULL,
  `type` varchar(128) DEFAULT NULL,
  `weight` tinyint(4) NOT NULL DEFAULT '0',
  `required` tinyint(4) NOT NULL DEFAULT '0',
  `register` tinyint(4) NOT NULL DEFAULT '0',
  `visibility` tinyint(4) NOT NULL DEFAULT '0',
  `autocomplete` tinyint(4) NOT NULL DEFAULT '0',
  `options` text,
  PRIMARY KEY (`fid`),
  UNIQUE KEY `name` (`name`),
  KEY `category` (`category`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `profile_fields`
--


-- --------------------------------------------------------

--
-- Table structure for table `profile_values`
--

CREATE TABLE IF NOT EXISTS `profile_values` (
  `fid` int(10) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `value` text,
  PRIMARY KEY (`uid`,`fid`),
  KEY `fid` (`fid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `profile_values`
--


-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `rid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`rid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`rid`, `name`) VALUES
(1, 'anonymous user'),
(2, 'authenticated user');

-- --------------------------------------------------------

--
-- Table structure for table `search_dataset`
--

CREATE TABLE IF NOT EXISTS `search_dataset` (
  `sid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(16) DEFAULT NULL,
  `data` longtext NOT NULL,
  `reindex` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `sid_type` (`sid`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `search_dataset`
--


-- --------------------------------------------------------

--
-- Table structure for table `search_index`
--

CREATE TABLE IF NOT EXISTS `search_index` (
  `word` varchar(50) NOT NULL DEFAULT '',
  `sid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(16) DEFAULT NULL,
  `score` float DEFAULT NULL,
  UNIQUE KEY `word_sid_type` (`word`,`sid`,`type`),
  KEY `sid_type` (`sid`,`type`),
  KEY `word` (`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `search_index`
--


-- --------------------------------------------------------

--
-- Table structure for table `search_node_links`
--

CREATE TABLE IF NOT EXISTS `search_node_links` (
  `sid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(16) NOT NULL DEFAULT '',
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `caption` longtext,
  PRIMARY KEY (`sid`,`type`,`nid`),
  KEY `nid` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `search_node_links`
--


-- --------------------------------------------------------

--
-- Table structure for table `search_total`
--

CREATE TABLE IF NOT EXISTS `search_total` (
  `word` varchar(50) NOT NULL DEFAULT '',
  `count` float DEFAULT NULL,
  PRIMARY KEY (`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `search_total`
--


-- --------------------------------------------------------

--
-- Table structure for table `semaphore`
--

CREATE TABLE IF NOT EXISTS `semaphore` (
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  `expire` double NOT NULL,
  PRIMARY KEY (`name`),
  KEY `expire` (`expire`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `semaphore`
--


-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE IF NOT EXISTS `sessions` (
  `uid` int(10) unsigned NOT NULL,
  `sid` varchar(64) NOT NULL DEFAULT '',
  `hostname` varchar(128) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `cache` int(11) NOT NULL DEFAULT '0',
  `session` longtext,
  PRIMARY KEY (`sid`),
  KEY `timestamp` (`timestamp`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`uid`, `sid`, `hostname`, `timestamp`, `cache`, `session`) VALUES
(0, '3d0qi4lh3klgejjarh3mv09ls0', '127.0.0.1', 1421146371, 0, ''),
(0, 'mo1jieqm14t1s6418bujgqb6d7', '127.0.0.1', 1421140383, 0, ''),
(0, 'lbrtv9uj41148336bhelbnkoq7', '127.0.0.1', 1421303449, 0, ''),
(1, 'rhfddet3kf47atohr1blgv17r6', '127.0.0.1', 1421309676, 0, 'node_overview_filter|a:0:{}imce_directory|s:1:".";'),
(0, '60i1lurjvce241hvpdam34o767', '127.0.0.1', 1421309863, 0, ''),
(0, 'nras42982jrk2u101nupskjv47', '127.0.0.1', 1421309414, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `system`
--

CREATE TABLE IF NOT EXISTS `system` (
  `filename` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(255) NOT NULL DEFAULT '',
  `owner` varchar(255) NOT NULL DEFAULT '',
  `status` int(11) NOT NULL DEFAULT '0',
  `throttle` tinyint(4) NOT NULL DEFAULT '0',
  `bootstrap` int(11) NOT NULL DEFAULT '0',
  `schema_version` smallint(6) NOT NULL DEFAULT '-1',
  `weight` int(11) NOT NULL DEFAULT '0',
  `info` text,
  PRIMARY KEY (`filename`),
  KEY `modules` (`type`(12),`status`,`weight`,`filename`),
  KEY `bootstrap` (`type`(12),`status`,`bootstrap`,`weight`,`filename`),
  KEY `type_name` (`type`(12),`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `system`
--

INSERT INTO `system` (`filename`, `name`, `type`, `owner`, `status`, `throttle`, `bootstrap`, `schema_version`, `weight`, `info`) VALUES
('sites/all/themes/bootstrap/bootstrap.info', 'bootstrap', 'theme', 'themes/engines/phptemplate/phptemplate.engine', 1, 0, 0, -1, 0, 'a:12:{s:4:"name";s:9:"Bootstrap";s:11:"description";s:125:"Read the <a href="http://drupal.org/node/629510">online docs</a> or the included README.txt on how to create a Zen sub-theme.";s:10:"screenshot";s:41:"sites/all/themes/bootstrap/screenshot.png";s:4:"core";s:3:"6.x";s:10:"base theme";s:3:"zen";s:11:"stylesheets";a:1:{s:3:"all";a:18:{s:18:"css/html-reset.css";s:45:"sites/all/themes/bootstrap/css/html-reset.css";s:20:"css/layout-fixed.css";s:47:"sites/all/themes/bootstrap/css/layout-fixed.css";s:24:"css/page-backgrounds.css";s:51:"sites/all/themes/bootstrap/css/page-backgrounds.css";s:12:"css/tabs.css";s:39:"sites/all/themes/bootstrap/css/tabs.css";s:16:"css/messages.css";s:43:"sites/all/themes/bootstrap/css/messages.css";s:13:"css/pages.css";s:40:"sites/all/themes/bootstrap/css/pages.css";s:21:"css/block-editing.css";s:48:"sites/all/themes/bootstrap/css/block-editing.css";s:14:"css/blocks.css";s:41:"sites/all/themes/bootstrap/css/blocks.css";s:18:"css/navigation.css";s:45:"sites/all/themes/bootstrap/css/navigation.css";s:21:"css/panels-styles.css";s:48:"sites/all/themes/bootstrap/css/panels-styles.css";s:20:"css/views-styles.css";s:47:"sites/all/themes/bootstrap/css/views-styles.css";s:13:"css/nodes.css";s:40:"sites/all/themes/bootstrap/css/nodes.css";s:16:"css/comments.css";s:43:"sites/all/themes/bootstrap/css/comments.css";s:13:"css/forms.css";s:40:"sites/all/themes/bootstrap/css/forms.css";s:14:"css/fields.css";s:41:"sites/all/themes/bootstrap/css/fields.css";s:17:"css/bootstrap.css";s:44:"sites/all/themes/bootstrap/css/bootstrap.css";s:28:"css/bootstrap-responsive.css";s:55:"sites/all/themes/bootstrap/css/bootstrap-responsive.css";s:24:"css/bootstrap-custom.css";s:51:"sites/all/themes/bootstrap/css/bootstrap-custom.css";}}s:7:"scripts";a:4:{s:12:"js/jquery.js";s:39:"sites/all/themes/bootstrap/js/jquery.js";s:11:"js/slick.js";s:38:"sites/all/themes/bootstrap/js/slick.js";s:12:"js/script.js";s:39:"sites/all/themes/bootstrap/js/script.js";s:15:"js/bootstrap.js";s:42:"sites/all/themes/bootstrap/js/bootstrap.js";}s:7:"regions";a:9:{s:13:"sidebar_first";s:13:"First sidebar";s:14:"sidebar_second";s:14:"Second sidebar";s:10:"navigation";s:14:"Navigation bar";s:9:"highlight";s:19:"Highlighted content";s:11:"content_top";s:11:"Content top";s:14:"content_bottom";s:14:"Content bottom";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";s:12:"page_closure";s:12:"Page closure";}s:8:"features";a:10:{i:0;s:4:"logo";i:1;s:4:"name";i:2;s:6:"slogan";i:3;s:7:"mission";i:4;s:17:"node_user_picture";i:5;s:20:"comment_user_picture";i:6;s:6:"search";i:7;s:7:"favicon";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:8:"settings";a:8:{s:17:"zen_block_editing";s:1:"1";s:14:"zen_breadcrumb";s:3:"yes";s:24:"zen_breadcrumb_separator";s:5:" › ";s:19:"zen_breadcrumb_home";s:1:"1";s:23:"zen_breadcrumb_trailing";s:1:"1";s:20:"zen_breadcrumb_title";s:1:"0";s:20:"zen_rebuild_registry";s:1:"1";s:14:"zen_wireframes";s:1:"0";}s:3:"php";s:5:"4.3.5";s:6:"engine";s:11:"phptemplate";}'),
('themes/garland/garland.info', 'garland', 'theme', 'themes/engines/phptemplate/phptemplate.engine', 1, 0, 0, -1, 0, 'a:13:{s:4:"name";s:7:"Garland";s:11:"description";s:66:"Tableless, recolorable, multi-column, fluid width theme (default).";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:6:"engine";s:11:"phptemplate";s:11:"stylesheets";a:2:{s:3:"all";a:1:{s:9:"style.css";s:24:"themes/garland/style.css";}s:5:"print";a:1:{s:9:"print.css";s:24:"themes/garland/print.css";}}s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:7:"regions";a:5:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";s:7:"content";s:7:"Content";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";}s:8:"features";a:10:{i:0;s:20:"comment_user_picture";i:1;s:7:"favicon";i:2;s:7:"mission";i:3;s:4:"logo";i:4;s:4:"name";i:5;s:17:"node_user_picture";i:6;s:6:"search";i:7;s:6:"slogan";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:7:"scripts";a:1:{s:9:"script.js";s:24:"themes/garland/script.js";}s:10:"screenshot";s:29:"themes/garland/screenshot.png";s:3:"php";s:5:"4.3.5";}'),
('themes/chameleon/marvin/marvin.info', 'marvin', 'theme', '', 0, 0, 0, -1, 0, 'a:13:{s:4:"name";s:6:"Marvin";s:11:"description";s:31:"Boxy tabled theme in all grays.";s:7:"regions";a:2:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";}s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:10:"base theme";s:9:"chameleon";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:8:"features";a:10:{i:0;s:20:"comment_user_picture";i:1;s:7:"favicon";i:2;s:7:"mission";i:3;s:4:"logo";i:4;s:4:"name";i:5;s:17:"node_user_picture";i:6;s:6:"search";i:7;s:6:"slogan";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:33:"themes/chameleon/marvin/style.css";}}s:7:"scripts";a:1:{s:9:"script.js";s:33:"themes/chameleon/marvin/script.js";}s:10:"screenshot";s:38:"themes/chameleon/marvin/screenshot.png";s:3:"php";s:5:"4.3.5";}'),
('themes/chameleon/chameleon.info', 'chameleon', 'theme', 'themes/chameleon/chameleon.theme', 0, 0, 0, -1, 0, 'a:12:{s:4:"name";s:9:"Chameleon";s:11:"description";s:42:"Minimalist tabled theme with light colors.";s:7:"regions";a:2:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";}s:8:"features";a:4:{i:0;s:4:"logo";i:1;s:7:"favicon";i:2;s:4:"name";i:3;s:6:"slogan";}s:11:"stylesheets";a:1:{s:3:"all";a:2:{s:9:"style.css";s:26:"themes/chameleon/style.css";s:10:"common.css";s:27:"themes/chameleon/common.css";}}s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:7:"scripts";a:1:{s:9:"script.js";s:26:"themes/chameleon/script.js";}s:10:"screenshot";s:31:"themes/chameleon/screenshot.png";s:3:"php";s:5:"4.3.5";}'),
('themes/bluemarine/bluemarine.info', 'bluemarine', 'theme', 'themes/engines/phptemplate/phptemplate.engine', 0, 0, 0, -1, 0, 'a:13:{s:4:"name";s:10:"Bluemarine";s:11:"description";s:66:"Table-based multi-column theme with a marine and ash color scheme.";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:6:"engine";s:11:"phptemplate";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:7:"regions";a:5:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";s:7:"content";s:7:"Content";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";}s:8:"features";a:10:{i:0;s:20:"comment_user_picture";i:1;s:7:"favicon";i:2;s:7:"mission";i:3;s:4:"logo";i:4;s:4:"name";i:5;s:17:"node_user_picture";i:6;s:6:"search";i:7;s:6:"slogan";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:27:"themes/bluemarine/style.css";}}s:7:"scripts";a:1:{s:9:"script.js";s:27:"themes/bluemarine/script.js";}s:10:"screenshot";s:32:"themes/bluemarine/screenshot.png";s:3:"php";s:5:"4.3.5";}'),
('sites/all/themes/zen/zen.info', 'zen', 'theme', 'themes/engines/phptemplate/phptemplate.engine', 1, 0, 0, -1, 0, 'a:15:{s:4:"name";s:3:"Zen";s:11:"description";s:194:"Zen sub-themes are the ultimate starting themes for Drupal 6. Read the <a href="http://drupal.org/node/873778">online docs</a> or the included README-FIRST.txt on how to create a theme with Zen.";s:10:"screenshot";s:49:"sites/all/themes/zen/zen-internals/screenshot.png";s:4:"core";s:3:"6.x";s:6:"engine";s:11:"phptemplate";s:7:"regions";a:9:{s:13:"sidebar_first";s:13:"First sidebar";s:14:"sidebar_second";s:14:"Second sidebar";s:10:"navigation";s:14:"Navigation bar";s:9:"highlight";s:19:"Highlighted content";s:11:"content_top";s:11:"Content top";s:14:"content_bottom";s:14:"Content bottom";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";s:12:"page_closure";s:12:"Page closure";}s:8:"features";a:10:{i:0;s:4:"logo";i:1;s:4:"name";i:2;s:6:"slogan";i:3;s:7:"mission";i:4;s:17:"node_user_picture";i:5;s:20:"comment_user_picture";i:6;s:6:"search";i:7;s:7:"favicon";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:8:"settings";a:9:{s:17:"zen_block_editing";s:1:"1";s:14:"zen_breadcrumb";s:3:"yes";s:24:"zen_breadcrumb_separator";s:5:" › ";s:19:"zen_breadcrumb_home";s:1:"1";s:23:"zen_breadcrumb_trailing";s:1:"1";s:20:"zen_breadcrumb_title";s:1:"0";s:10:"zen_layout";s:18:"zen-columns-liquid";s:20:"zen_rebuild_registry";s:1:"0";s:14:"zen_wireframes";s:1:"0";}s:7:"plugins";a:1:{s:6:"panels";a:1:{s:7:"layouts";s:7:"layouts";}}s:7:"version";s:7:"6.x-2.1";s:7:"project";s:3:"zen";s:9:"datestamp";s:10:"1302017816";s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:30:"sites/all/themes/zen/style.css";}}s:7:"scripts";a:1:{s:9:"script.js";s:30:"sites/all/themes/zen/script.js";}s:3:"php";s:5:"4.3.5";}'),
('themes/pushbutton/pushbutton.info', 'pushbutton', 'theme', 'themes/engines/phptemplate/phptemplate.engine', 0, 0, 0, -1, 0, 'a:13:{s:4:"name";s:10:"Pushbutton";s:11:"description";s:52:"Tabled, multi-column theme in blue and orange tones.";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:6:"engine";s:11:"phptemplate";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:7:"regions";a:5:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";s:7:"content";s:7:"Content";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";}s:8:"features";a:10:{i:0;s:20:"comment_user_picture";i:1;s:7:"favicon";i:2;s:7:"mission";i:3;s:4:"logo";i:4;s:4:"name";i:5;s:17:"node_user_picture";i:6;s:6:"search";i:7;s:6:"slogan";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:9:"style.css";s:27:"themes/pushbutton/style.css";}}s:7:"scripts";a:1:{s:9:"script.js";s:27:"themes/pushbutton/script.js";}s:10:"screenshot";s:32:"themes/pushbutton/screenshot.png";s:3:"php";s:5:"4.3.5";}'),
('themes/garland/minnelli/minnelli.info', 'minnelli', 'theme', 'themes/engines/phptemplate/phptemplate.engine', 0, 0, 0, -1, 0, 'a:14:{s:4:"name";s:8:"Minnelli";s:11:"description";s:56:"Tableless, recolorable, multi-column, fixed width theme.";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:10:"base theme";s:7:"garland";s:11:"stylesheets";a:1:{s:3:"all";a:1:{s:12:"minnelli.css";s:36:"themes/garland/minnelli/minnelli.css";}}s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:7:"regions";a:5:{s:4:"left";s:12:"Left sidebar";s:5:"right";s:13:"Right sidebar";s:7:"content";s:7:"Content";s:6:"header";s:6:"Header";s:6:"footer";s:6:"Footer";}s:8:"features";a:10:{i:0;s:20:"comment_user_picture";i:1;s:7:"favicon";i:2;s:7:"mission";i:3;s:4:"logo";i:4;s:4:"name";i:5;s:17:"node_user_picture";i:6;s:6:"search";i:7;s:6:"slogan";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:7:"scripts";a:1:{s:9:"script.js";s:33:"themes/garland/minnelli/script.js";}s:10:"screenshot";s:38:"themes/garland/minnelli/screenshot.png";s:3:"php";s:5:"4.3.5";s:6:"engine";s:11:"phptemplate";}'),
('modules/system/system.module', 'system', 'module', '', 1, 0, 0, 6055, 0, 'a:10:{s:4:"name";s:6:"System";s:11:"description";s:54:"Handles general site configuration for administrators.";s:7:"package";s:15:"Core - required";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/admin_menu/admin_menu.module', 'admin_menu', 'module', '', 1, 0, 1, 6001, 0, 'a:10:{s:4:"name";s:19:"Administration menu";s:11:"description";s:123:"Provides a dropdown menu to most administrative tasks and other common destinations (to users with the proper permissions).";s:7:"package";s:14:"Administration";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-1.8";s:7:"project";s:10:"admin_menu";s:9:"datestamp";s:10:"1308238014";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/aggregator/aggregator.module', 'aggregator', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:10:"Aggregator";s:11:"description";s:57:"Aggregates syndicated content (RSS, RDF, and Atom feeds).";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/better_formats/better_formats.module', 'better_formats', 'module', '', 1, 0, 0, 6110, 100, 'a:9:{s:4:"name";s:14:"Better Formats";s:11:"description";s:85:"Enhances the core input format system by managing input format defaults and settings.";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-1.2";s:7:"project";s:14:"better_formats";s:9:"datestamp";s:10:"1265402405";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/block/block.module', 'block', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:5:"Block";s:11:"description";s:62:"Controls the boxes that are displayed around the main content.";s:7:"package";s:15:"Core - required";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/blog/blog.module', 'blog', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:4:"Blog";s:11:"description";s:69:"Enables keeping easily and regularly updated user web pages or blogs.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/blogapi/blogapi.module', 'blogapi', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:8:"Blog API";s:11:"description";s:79:"Allows users to post content using applications that support XML-RPC blog APIs.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/book/book.module', 'book', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:4:"Book";s:11:"description";s:63:"Allows users to structure site pages in a hierarchy or outline.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/captcha/captcha.module', 'captcha', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:7:"CAPTCHA";s:11:"description";s:61:"Base CAPTCHA module for adding challenges to arbitrary forms.";s:7:"package";s:12:"Spam control";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.4";s:7:"project";s:7:"captcha";s:9:"datestamp";s:10:"1297123619";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/color/color.module', 'color', 'module', '', 1, 0, 0, 6001, 0, 'a:10:{s:4:"name";s:5:"Color";s:11:"description";s:61:"Allows the user to change the color scheme of certain themes.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/comment/comment.module', 'comment', 'module', '', 1, 0, 0, 6003, 0, 'a:10:{s:4:"name";s:7:"Comment";s:11:"description";s:57:"Allows users to comment on and discuss published content.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/contact/contact.module', 'contact', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:7:"Contact";s:11:"description";s:61:"Enables the use of both personal and site-wide contact forms.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/contact_field/contact_field.module', 'contact_field', 'module', '', 1, 0, 0, 6021, 0, 'a:10:{s:4:"name";s:14:"Contact fields";s:11:"description";s:43:"Add custom fields to site wide contact form";s:7:"package";s:14:"Contact fields";s:4:"core";s:3:"6.x";s:12:"dependencies";a:1:{i:0;s:7:"contact";}s:7:"version";s:7:"6.x-2.2";s:7:"project";s:13:"contact_field";s:9:"datestamp";s:10:"1282972306";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/contact_field/contact_listfield/contact_listfield.module', 'contact_listfield', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:23:"Contact form list field";s:11:"description";s:32:"Add select boxes on contact form";s:7:"package";s:14:"Contact fields";s:4:"core";s:3:"6.x";s:12:"dependencies";a:1:{i:0;s:13:"contact_field";}s:7:"version";s:7:"6.x-2.2";s:7:"project";s:13:"contact_field";s:9:"datestamp";s:10:"1282972306";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/contact_field/contact_option/contact_option.module', 'contact_option', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:33:"Contact form radio/checkbox field";s:11:"description";s:41:"Add radios and checkboxes on contact form";s:7:"package";s:14:"Contact fields";s:4:"core";s:3:"6.x";s:12:"dependencies";a:1:{i:0;s:13:"contact_field";}s:7:"version";s:7:"6.x-2.2";s:7:"project";s:13:"contact_field";s:9:"datestamp";s:10:"1282972306";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/contact_field/contact_textfield/contact_textfield.module', 'contact_textfield', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:23:"Contact form Text field";s:11:"description";s:79:"Add text box on contact form. This module supports textbox and textarea fields.";s:7:"package";s:14:"Contact fields";s:4:"core";s:3:"6.x";s:12:"dependencies";a:1:{i:0;s:13:"contact_field";}s:7:"version";s:7:"6.x-2.2";s:7:"project";s:13:"contact_field";s:9:"datestamp";s:10:"1282972306";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/cck/content.module', 'content', 'module', '', 1, 0, 0, 6010, 0, 'a:10:{s:4:"name";s:7:"Content";s:11:"description";s:50:"Allows administrators to define new content types.";s:7:"package";s:3:"CCK";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.9";s:7:"project";s:3:"cck";s:9:"datestamp";s:10:"1294407979";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/cck/modules/content_copy/content_copy.module', 'content_copy', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:12:"Content Copy";s:11:"description";s:51:"Enables ability to import/export field definitions.";s:12:"dependencies";a:1:{i:0;s:7:"content";}s:7:"package";s:3:"CCK";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.9";s:7:"project";s:3:"cck";s:9:"datestamp";s:10:"1294407979";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/cck/modules/content_permissions/content_permissions.module', 'content_permissions', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:19:"Content Permissions";s:11:"description";s:43:"Set field-level permissions for CCK fields.";s:7:"package";s:3:"CCK";s:4:"core";s:3:"6.x";s:12:"dependencies";a:1:{i:0;s:7:"content";}s:7:"version";s:7:"6.x-2.9";s:7:"project";s:3:"cck";s:9:"datestamp";s:10:"1294407979";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/date/date/date.module', 'date', 'module', '', 1, 0, 0, 6005, 0, 'a:10:{s:4:"name";s:4:"Date";s:11:"description";s:41:"Defines CCK date/time fields and widgets.";s:12:"dependencies";a:3:{i:0;s:7:"content";i:1;s:8:"date_api";i:2;s:13:"date_timezone";}s:7:"package";s:9:"Date/Time";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.7";s:7:"project";s:4:"date";s:9:"datestamp";s:10:"1294059080";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/date/date_api.module', 'date_api', 'module', '', 1, 0, 0, 6006, 0, 'a:10:{s:4:"name";s:8:"Date API";s:11:"description";s:45:"A Date API that can be used by other modules.";s:7:"package";s:9:"Date/Time";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.7";s:7:"project";s:4:"date";s:9:"datestamp";s:10:"1294059080";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/date/date_locale/date_locale.module', 'date_locale', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:11:"Date Locale";s:11:"description";s:124:"Allows the site admin to configure multiple formats for date/time display to tailor dates for a specific locale or audience.";s:7:"package";s:9:"Date/Time";s:12:"dependencies";a:2:{i:0;s:8:"date_api";i:1;s:6:"locale";}s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.7";s:7:"project";s:4:"date";s:9:"datestamp";s:10:"1294059080";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/date/date_php4/date_php4.module', 'date_php4', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:9:"Date PHP4";s:11:"description";s:134:"Emulate PHP 5.2 date functions in PHP 4.x, PHP 5.0, and PHP 5.1. Required when using the Date API with PHP versions less than PHP 5.2.";s:7:"package";s:9:"Date/Time";s:12:"dependencies";a:1:{i:0;s:8:"date_api";}s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.7";s:7:"project";s:4:"date";s:9:"datestamp";s:10:"1294059080";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/date/date_popup/date_popup.module', 'date_popup', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:10:"Date Popup";s:11:"description";s:84:"Enables jquery popup calendars and time entry widgets for selecting dates and times.";s:12:"dependencies";a:2:{i:0;s:8:"date_api";i:1;s:13:"date_timezone";}s:7:"package";s:9:"Date/Time";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.7";s:7:"project";s:4:"date";s:9:"datestamp";s:10:"1294059080";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/date/date_repeat/date_repeat.module', 'date_repeat', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:15:"Date Repeat API";s:11:"description";s:73:"A Date Repeat API to calculate repeating dates and times from iCal rules.";s:12:"dependencies";a:1:{i:0;s:8:"date_api";}s:7:"package";s:9:"Date/Time";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.7";s:7:"project";s:4:"date";s:9:"datestamp";s:10:"1294059080";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/date/date_timezone/date_timezone.module', 'date_timezone', 'module', '', 1, 0, 0, 5200, 0, 'a:10:{s:4:"name";s:13:"Date Timezone";s:11:"description";s:111:"Needed when using Date API. Overrides site and user timezone handling to set timezone names instead of offsets.";s:7:"package";s:9:"Date/Time";s:12:"dependencies";a:1:{i:0;s:8:"date_api";}s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.7";s:7:"project";s:4:"date";s:9:"datestamp";s:10:"1294059080";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/date/date_tools/date_tools.module', 'date_tools', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:10:"Date Tools";s:11:"description";s:52:"Tools to import and auto-create dates and calendars.";s:12:"dependencies";a:2:{i:0;s:7:"content";i:1;s:4:"date";}s:7:"package";s:9:"Date/Time";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.7";s:7:"project";s:4:"date";s:9:"datestamp";s:10:"1294059080";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/dblog/dblog.module', 'dblog', 'module', '', 1, 0, 0, 6000, 0, 'a:10:{s:4:"name";s:16:"Database logging";s:11:"description";s:47:"Logs and records system events to the database.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/devel/devel.module', 'devel', 'module', '', 1, 0, 1, 6003, 88, 'a:10:{s:4:"name";s:5:"Devel";s:11:"description";s:52:"Various blocks, pages, and functions for developers.";s:7:"package";s:11:"Development";s:12:"dependencies";a:1:{i:0;s:4:"menu";}s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.26";s:7:"project";s:5:"devel";s:9:"datestamp";s:10:"1311355315";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/devel/devel_generate.module', 'devel_generate', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:14:"Devel generate";s:11:"description";s:48:"Generate dummy users, nodes, and taxonomy terms.";s:7:"package";s:11:"Development";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.26";s:7:"project";s:5:"devel";s:9:"datestamp";s:10:"1311355315";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/devel/devel_node_access.module', 'devel_node_access', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:17:"Devel node access";s:11:"description";s:67:"Developer block and page illustrating relevant node_access records.";s:7:"package";s:11:"Development";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.26";s:7:"project";s:5:"devel";s:9:"datestamp";s:10:"1311355315";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/cck/modules/fieldgroup/fieldgroup.module', 'fieldgroup', 'module', '', 1, 0, 0, 6007, 9, 'a:10:{s:4:"name";s:10:"Fieldgroup";s:11:"description";s:37:"Create display groups for CCK fields.";s:12:"dependencies";a:1:{i:0;s:7:"content";}s:7:"package";s:3:"CCK";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.9";s:7:"project";s:3:"cck";s:9:"datestamp";s:10:"1294407979";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/filefield/filefield.module', 'filefield', 'module', '', 1, 0, 0, 6104, 0, 'a:10:{s:4:"name";s:9:"FileField";s:11:"description";s:26:"Defines a file field type.";s:12:"dependencies";a:1:{i:0;s:7:"content";}s:7:"package";s:3:"CCK";s:4:"core";s:3:"6.x";s:3:"php";s:3:"5.0";s:7:"version";s:8:"6.x-3.10";s:7:"project";s:9:"filefield";s:9:"datestamp";s:10:"1303970816";s:10:"dependents";a:0:{}}'),
('sites/all/modules/filefield/filefield_meta/filefield_meta.module', 'filefield_meta', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:14:"FileField Meta";s:11:"description";s:48:"Add metadata gathering and storage to FileField.";s:12:"dependencies";a:2:{i:0;s:9:"filefield";i:1;s:6:"getid3";}s:7:"package";s:3:"CCK";s:4:"core";s:3:"6.x";s:3:"php";s:3:"5.0";s:7:"version";s:8:"6.x-3.10";s:7:"project";s:9:"filefield";s:9:"datestamp";s:10:"1303970816";s:10:"dependents";a:0:{}}'),
('modules/filter/filter.module', 'filter', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:6:"Filter";s:11:"description";s:60:"Handles the filtering of content in preparation for display.";s:7:"package";s:15:"Core - required";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/forum/forum.module', 'forum', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:5:"Forum";s:11:"description";s:50:"Enables threaded discussions about general topics.";s:12:"dependencies";a:2:{i:0;s:8:"taxonomy";i:1;s:7:"comment";}s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/google_analytics/googleanalytics.module', 'googleanalytics', 'module', '', 1, 0, 0, 6302, 0, 'a:10:{s:4:"name";s:16:"Google Analytics";s:11:"description";s:72:"Adds Google Analytics javascript tracking code to all your site''s pages.";s:4:"core";s:3:"6.x";s:7:"package";s:10:"Statistics";s:7:"version";s:7:"6.x-3.3";s:7:"project";s:16:"google_analytics";s:9:"datestamp";s:10:"1301340368";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/help/help.module', 'help', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:4:"Help";s:11:"description";s:35:"Manages the display of online help.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/i18n/i18n.module', 'i18n', 'module', '', 1, 0, 1, 9, 10, 'a:10:{s:4:"name";s:20:"Internationalization";s:11:"description";s:49:"Extends Drupal support for multilingual features.";s:12:"dependencies";a:2:{i:0;s:6:"locale";i:1;s:11:"translation";}s:7:"package";s:13:"Multilanguage";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.10";s:7:"project";s:4:"i18n";s:9:"datestamp";s:10:"1318336004";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/i18n/tests/i18n_test.module', 'i18n_test', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:26:"Internationalization tests";s:11:"description";s:55:"Helper module for testing i18n (do not enable manually)";s:12:"dependencies";a:3:{i:0;s:6:"locale";i:1;s:11:"translation";i:2;s:4:"i18n";}s:7:"package";s:7:"Testing";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.10";s:7:"project";s:4:"i18n";s:9:"datestamp";s:10:"1318336004";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/i18n/i18nblocks/i18nblocks.module', 'i18nblocks', 'module', '', 1, 0, 0, 6001, 0, 'a:10:{s:4:"name";s:17:"Block translation";s:11:"description";s:50:"Enables multilingual blocks and block translation.";s:12:"dependencies";a:2:{i:0;s:4:"i18n";i:1;s:11:"i18nstrings";}s:7:"package";s:13:"Multilanguage";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.10";s:7:"project";s:4:"i18n";s:9:"datestamp";s:10:"1318336004";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/i18n/i18ncck/i18ncck.module', 'i18ncck', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:15:"CCK translation";s:11:"description";s:56:"Supports translatable custom CCK fields and fieldgroups.";s:12:"dependencies";a:3:{i:0;s:4:"i18n";i:1;s:7:"content";i:2;s:11:"i18nstrings";}s:7:"package";s:13:"Multilanguage";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.10";s:7:"project";s:4:"i18n";s:9:"datestamp";s:10:"1318336004";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/i18n/i18ncontent/i18ncontent.module', 'i18ncontent', 'module', '', 1, 0, 0, 6002, 0, 'a:10:{s:4:"name";s:24:"Content type translation";s:11:"description";s:99:"Add multilingual options for content and translate related strings: name, description, help text...";s:12:"dependencies";a:1:{i:0;s:11:"i18nstrings";}s:7:"package";s:13:"Multilanguage";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.10";s:7:"project";s:4:"i18n";s:9:"datestamp";s:10:"1318336004";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/i18n/i18nmenu/i18nmenu.module', 'i18nmenu', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:16:"Menu translation";s:11:"description";s:40:"Supports translatable custom menu items.";s:12:"dependencies";a:4:{i:0;s:4:"i18n";i:1;s:4:"menu";i:2;s:10:"i18nblocks";i:3;s:11:"i18nstrings";}s:7:"package";s:13:"Multilanguage";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.10";s:7:"project";s:4:"i18n";s:9:"datestamp";s:10:"1318336004";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/i18n/i18npoll/i18npoll.module', 'i18npoll', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:14:"Poll aggregate";s:11:"description";s:45:"Aggregates poll results for all translations.";s:12:"dependencies";a:2:{i:0;s:11:"translation";i:1;s:4:"poll";}s:7:"package";s:13:"Multilanguage";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.10";s:7:"project";s:4:"i18n";s:9:"datestamp";s:10:"1318336004";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/i18n/i18nprofile/i18nprofile.module', 'i18nprofile', 'module', '', 1, 0, 0, 2, 0, 'a:10:{s:4:"name";s:19:"Profile translation";s:11:"description";s:36:"Enables multilingual profile fields.";s:12:"dependencies";a:2:{i:0;s:7:"profile";i:1;s:11:"i18nstrings";}s:7:"package";s:13:"Multilanguage";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.10";s:7:"project";s:4:"i18n";s:9:"datestamp";s:10:"1318336004";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/i18n/i18nstrings/i18nstrings.module', 'i18nstrings', 'module', '', 1, 0, 0, 6006, 10, 'a:10:{s:4:"name";s:18:"String translation";s:11:"description";s:57:"Provides support for translation of user defined strings.";s:12:"dependencies";a:1:{i:0;s:6:"locale";}s:7:"package";s:13:"Multilanguage";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.10";s:7:"project";s:4:"i18n";s:9:"datestamp";s:10:"1318336004";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/i18n/i18nsync/i18nsync.module', 'i18nsync', 'module', '', 1, 0, 0, 0, 100, 'a:10:{s:4:"name";s:24:"Synchronize translations";s:11:"description";s:74:"Synchronizes taxonomy and fields accross translations of the same content.";s:12:"dependencies";a:1:{i:0;s:4:"i18n";}s:7:"package";s:13:"Multilanguage";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.10";s:7:"project";s:4:"i18n";s:9:"datestamp";s:10:"1318336004";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/i18n/i18ntaxonomy/i18ntaxonomy.module', 'i18ntaxonomy', 'module', '', 1, 0, 0, 6002, 5, 'a:10:{s:4:"name";s:20:"Taxonomy translation";s:11:"description";s:30:"Enables multilingual taxonomy.";s:12:"dependencies";a:3:{i:0;s:4:"i18n";i:1;s:8:"taxonomy";i:2;s:11:"i18nstrings";}s:7:"package";s:13:"Multilanguage";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.10";s:7:"project";s:4:"i18n";s:9:"datestamp";s:10:"1318336004";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/captcha/image_captcha/image_captcha.module', 'image_captcha', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:13:"Image CAPTCHA";s:11:"description";s:32:"Provides an image based CAPTCHA.";s:7:"package";s:12:"Spam control";s:12:"dependencies";a:1:{i:0;s:7:"captcha";}s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.4";s:7:"project";s:7:"captcha";s:9:"datestamp";s:10:"1297123619";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/imageapi/imageapi.module', 'imageapi', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:8:"ImageAPI";s:11:"description";s:38:"ImageAPI supporting multiple toolkits.";s:7:"package";s:10:"ImageCache";s:4:"core";s:3:"6.x";s:3:"php";s:3:"5.1";s:7:"version";s:8:"6.x-1.10";s:7:"project";s:8:"imageapi";s:9:"datestamp";s:10:"1305563215";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}}'),
('sites/all/modules/imageapi/imageapi_gd.module', 'imageapi_gd', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:12:"ImageAPI GD2";s:11:"description";s:49:"Uses PHP''s built-in GD2 image processing support.";s:7:"package";s:10:"ImageCache";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.10";s:7:"project";s:8:"imageapi";s:9:"datestamp";s:10:"1305563215";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/imageapi/imageapi_imagemagick.module', 'imageapi_imagemagick', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:20:"ImageAPI ImageMagick";s:11:"description";s:33:"Command Line ImageMagick support.";s:7:"package";s:10:"ImageCache";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.10";s:7:"project";s:8:"imageapi";s:9:"datestamp";s:10:"1305563215";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/imagecache/imagecache.module', 'imagecache', 'module', '', 1, 0, 0, 6001, 0, 'a:10:{s:4:"name";s:10:"ImageCache";s:11:"description";s:36:"Dynamic image manipulator and cache.";s:7:"package";s:10:"ImageCache";s:12:"dependencies";a:1:{i:0;s:8:"imageapi";}s:4:"core";s:3:"6.x";s:7:"version";s:14:"6.x-2.0-beta12";s:7:"project";s:10:"imagecache";s:9:"datestamp";s:10:"1305566515";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/imagecache/imagecache_ui.module', 'imagecache_ui', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:13:"ImageCache UI";s:11:"description";s:26:"ImageCache User Interface.";s:12:"dependencies";a:2:{i:0;s:10:"imagecache";i:1;s:8:"imageapi";}s:7:"package";s:10:"ImageCache";s:4:"core";s:3:"6.x";s:7:"version";s:14:"6.x-2.0-beta12";s:7:"project";s:10:"imagecache";s:9:"datestamp";s:10:"1305566515";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/imagefield/imagefield.module', 'imagefield', 'module', '', 1, 0, 0, 6006, 0, 'a:10:{s:4:"name";s:10:"ImageField";s:11:"description";s:28:"Defines an image field type.";s:4:"core";s:3:"6.x";s:12:"dependencies";a:2:{i:0;s:7:"content";i:1;s:9:"filefield";}s:7:"package";s:3:"CCK";s:7:"version";s:8:"6.x-3.10";s:7:"project";s:10:"imagefield";s:9:"datestamp";s:10:"1303971115";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/imce/imce.module', 'imce', 'module', '', 1, 0, 0, 6201, 0, 'a:9:{s:4:"name";s:4:"IMCE";s:11:"description";s:82:"An image/file uploader and browser supporting personal directories and user quota.";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.3";s:7:"project";s:4:"imce";s:9:"datestamp";s:10:"1319104233";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/imce_wysiwyg/imce_wysiwyg.module', 'imce_wysiwyg', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:23:"IMCE Wysiwyg API bridge";s:11:"description";s:82:"Makes IMCE available as plugin for client-side editors integrated via Wysiwyg API.";s:7:"package";s:14:"User interface";s:4:"core";s:3:"6.x";s:12:"dependencies";a:2:{i:0;s:4:"imce";i:1;s:7:"wysiwyg";}s:7:"version";s:7:"6.x-1.1";s:7:"project";s:12:"imce_wysiwyg";s:9:"datestamp";s:10:"1268433606";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/insert/insert.module', 'insert', 'module', '', 1, 0, 0, 0, 15, 'a:9:{s:4:"name";s:6:"Insert";s:11:"description";s:91:"Assists in inserting files, images, or other media into the body field or other text areas.";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-1.1";s:7:"project";s:6:"insert";s:9:"datestamp";s:10:"1304092615";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/languageicons/languageicons.module', 'languageicons', 'module', '', 1, 0, 0, 6200, 0, 'a:10:{s:4:"name";s:14:"Language icons";s:11:"description";s:29:"Adds icons to language links.";s:12:"dependencies";a:1:{i:0;s:6:"locale";}s:7:"package";s:13:"Multilanguage";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.0";s:7:"project";s:13:"languageicons";s:9:"datestamp";s:10:"1267437008";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/lightbox2/lightbox2.module', 'lightbox2', 'module', '', 1, 0, 0, 6003, 0, 'a:9:{s:4:"name";s:9:"Lightbox2";s:11:"description";s:28:"Enables Lightbox2 for Drupal";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.11";s:7:"project";s:9:"lightbox2";s:9:"datestamp";s:10:"1285342563";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/locale/locale.module', 'locale', 'module', '', 1, 0, 0, 6006, 0, 'a:10:{s:4:"name";s:6:"Locale";s:11:"description";s:119:"Adds language handling functionality and enables the translation of the user interface to languages other than English.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/menu/menu.module', 'menu', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:4:"Menu";s:11:"description";s:60:"Allows administrators to customize the site navigation menu.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/nice_menus/nice_menus.module', 'nice_menus', 'module', '', 1, 0, 0, 6001, 0, 'a:9:{s:4:"name";s:10:"Nice Menus";s:11:"description";s:75:"CSS/jQuery drop-down, drop-right and drop-left menus to be placed in blocks";s:12:"dependencies";a:1:{i:0;s:4:"menu";}s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.1";s:7:"project";s:10:"nice_menus";s:9:"datestamp";s:10:"1287318691";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/node/node.module', 'node', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:4:"Node";s:11:"description";s:66:"Allows content to be submitted to the site and displayed on pages.";s:7:"package";s:15:"Core - required";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/cck/modules/nodereference/nodereference.module', 'nodereference', 'module', '', 1, 0, 0, 6001, 0, 'a:10:{s:4:"name";s:14:"Node Reference";s:11:"description";s:59:"Defines a field type for referencing one node from another.";s:12:"dependencies";a:3:{i:0;s:7:"content";i:1;s:4:"text";i:2;s:13:"optionwidgets";}s:7:"package";s:3:"CCK";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.9";s:7:"project";s:3:"cck";s:9:"datestamp";s:10:"1294407979";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/cck/modules/number/number.module', 'number', 'module', '', 1, 0, 0, 6000, 0, 'a:10:{s:4:"name";s:6:"Number";s:11:"description";s:28:"Defines numeric field types.";s:12:"dependencies";a:1:{i:0;s:7:"content";}s:7:"package";s:3:"CCK";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.9";s:7:"project";s:3:"cck";s:9:"datestamp";s:10:"1294407979";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/openid/openid.module', 'openid', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:6:"OpenID";s:11:"description";s:48:"Allows users to log into your site using OpenID.";s:7:"version";s:4:"6.22";s:7:"package";s:15:"Core - optional";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/cck/modules/optionwidgets/optionwidgets.module', 'optionwidgets', 'module', '', 1, 0, 0, 6001, 0, 'a:10:{s:4:"name";s:14:"Option Widgets";s:11:"description";s:82:"Defines selection, check box and radio button widgets for text and numeric fields.";s:12:"dependencies";a:1:{i:0;s:7:"content";}s:7:"package";s:3:"CCK";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.9";s:7:"project";s:3:"cck";s:9:"datestamp";s:10:"1294407979";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/path/path.module', 'path', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:4:"Path";s:11:"description";s:28:"Allows users to rename URLs.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/pathauto/pathauto.module', 'pathauto', 'module', '', 1, 0, 0, 7, 1, 'a:10:{s:4:"name";s:8:"Pathauto";s:11:"description";s:95:"Provides a mechanism for modules to automatically generate aliases for the content they manage.";s:12:"dependencies";a:2:{i:0;s:4:"path";i:1;s:5:"token";}s:4:"core";s:3:"6.x";s:10:"recommends";a:1:{i:0;s:13:"path_redirect";}s:7:"version";s:7:"6.x-1.5";s:7:"project";s:8:"pathauto";s:9:"datestamp";s:10:"1286469664";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/php/php.module', 'php', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:10:"PHP filter";s:11:"description";s:50:"Allows embedded PHP code/snippets to be evaluated.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/ping/ping.module', 'ping', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:4:"Ping";s:11:"description";s:51:"Alerts other sites when your site has been updated.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/pmt_mail/pmt_mail.module', 'pmt_mail', 'module', '', 0, 0, 0, -1, 0, 'a:8:{s:4:"name";s:8:"PMT Mail";s:11:"description";s:50:"This module will be control all of mail functions.";s:7:"package";s:11:"Phi Ma Tech";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-1.0";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/poll/poll.module', 'poll', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:4:"Poll";s:11:"description";s:95:"Allows your site to capture votes on different topics in the form of multiple choice questions.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/profile/profile.module', 'profile', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:7:"Profile";s:11:"description";s:36:"Supports configurable user profiles.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/search/search.module', 'search', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:6:"Search";s:11:"description";s:36:"Enables site-wide keyword searching.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/sharethis/sharethis.module', 'sharethis', 'module', '', 0, 0, 0, -1, 0, 'a:9:{s:4:"name";s:9:"ShareThis";s:11:"description";s:64:"Implements the ShareThis system created by Alex King into posts.";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-1.8";s:7:"project";s:9:"sharethis";s:9:"datestamp";s:10:"1268379306";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/smtp/smtp.module', 'smtp', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:27:"SMTP Authentication Support";s:11:"description";s:72:"Allows the sending of site e-mail through an SMTP server of your choice.";s:4:"core";s:3:"6.x";s:7:"package";s:4:"Mail";s:3:"php";s:5:"4.0.0";s:7:"version";s:13:"6.x-1.0-beta5";s:7:"project";s:4:"smtp";s:9:"datestamp";s:10:"1280945778";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}}'),
('modules/statistics/statistics.module', 'statistics', 'module', '', 1, 0, 1, 6000, 0, 'a:10:{s:4:"name";s:10:"Statistics";s:11:"description";s:37:"Logs access statistics for your site.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/syslog/syslog.module', 'syslog', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:6:"Syslog";s:11:"description";s:41:"Logs and records system events to syslog.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/taxonomy/taxonomy.module', 'taxonomy', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:8:"Taxonomy";s:11:"description";s:38:"Enables the categorization of content.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/cck/modules/text/text.module', 'text', 'module', '', 1, 0, 0, 6003, 0, 'a:10:{s:4:"name";s:4:"Text";s:11:"description";s:32:"Defines simple text field types.";s:12:"dependencies";a:1:{i:0;s:7:"content";}s:7:"package";s:3:"CCK";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.9";s:7:"project";s:3:"cck";s:9:"datestamp";s:10:"1294407979";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/throttle/throttle.module', 'throttle', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:8:"Throttle";s:11:"description";s:66:"Handles the auto-throttling mechanism, to control site congestion.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/token/token.module', 'token', 'module', '', 1, 0, 0, 1, 10, 'a:9:{s:4:"name";s:5:"Token";s:11:"description";s:79:"Provides a shared API for replacement of textual placeholders with actual data.";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.16";s:7:"project";s:5:"token";s:9:"datestamp";s:10:"1305745318";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/token/tokenSTARTER.module', 'tokenSTARTER', 'module', '', 0, 0, 0, -1, 0, 'a:9:{s:4:"name";s:12:"TokenSTARTER";s:11:"description";s:72:"Provides additional tokens and a base on which to build your own tokens.";s:12:"dependencies";a:1:{i:0;s:5:"token";}s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.16";s:7:"project";s:5:"token";s:9:"datestamp";s:10:"1305745318";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/token/token_actions.module', 'token_actions', 'module', '', 1, 0, 0, 0, 0, 'a:9:{s:4:"name";s:13:"Token actions";s:11:"description";s:73:"Provides enhanced versions of core Drupal actions using the Token module.";s:12:"dependencies";a:1:{i:0;s:5:"token";}s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-1.16";s:7:"project";s:5:"token";s:9:"datestamp";s:10:"1305745318";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/token/tests/token_test.module', 'token_test', 'module', '', 0, 0, 0, -1, 0, 'a:12:{s:4:"name";s:10:"Token Test";s:11:"description";s:39:"Testing module for token functionality.";s:7:"package";s:7:"Testing";s:4:"core";s:3:"6.x";s:5:"files";a:1:{i:0;s:17:"token_test.module";}s:6:"hidden";b:1;s:7:"version";s:8:"6.x-1.16";s:7:"project";s:5:"token";s:9:"datestamp";s:10:"1305745318";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}');
INSERT INTO `system` (`filename`, `name`, `type`, `owner`, `status`, `throttle`, `bootstrap`, `schema_version`, `weight`, `info`) VALUES
('modules/tracker/tracker.module', 'tracker', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:7:"Tracker";s:11:"description";s:43:"Enables tracking of recent posts for users.";s:12:"dependencies";a:1:{i:0;s:7:"comment";}s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/translation/translation.module', 'translation', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:19:"Content translation";s:11:"description";s:57:"Allows content to be translated into different languages.";s:12:"dependencies";a:1:{i:0;s:6:"locale";}s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/trigger/trigger.module', 'trigger', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:7:"Trigger";s:11:"description";s:90:"Enables actions to be fired on certain system events, such as when new content is created.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/update/update.module', 'update', 'module', '', 1, 0, 0, 6000, 0, 'a:10:{s:4:"name";s:13:"Update status";s:11:"description";s:88:"Checks the status of available updates for Drupal and your installed modules and themes.";s:7:"version";s:4:"6.22";s:7:"package";s:15:"Core - optional";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/upload/upload.module', 'upload', 'module', '', 0, 0, 0, -1, 0, 'a:10:{s:4:"name";s:6:"Upload";s:11:"description";s:51:"Allows users to upload and attach files to content.";s:7:"package";s:15:"Core - optional";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('modules/user/user.module', 'user', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:4:"User";s:11:"description";s:47:"Manages the user registration and login system.";s:7:"package";s:15:"Core - required";s:7:"version";s:4:"6.22";s:4:"core";s:3:"6.x";s:7:"project";s:6:"drupal";s:9:"datestamp";s:10:"1306357015";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/cck/modules/userreference/userreference.module', 'userreference', 'module', '', 1, 0, 0, 6002, 0, 'a:10:{s:4:"name";s:14:"User Reference";s:11:"description";s:56:"Defines a field type for referencing a user from a node.";s:12:"dependencies";a:3:{i:0;s:7:"content";i:1;s:4:"text";i:2;s:13:"optionwidgets";}s:7:"package";s:3:"CCK";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.9";s:7:"project";s:3:"cck";s:9:"datestamp";s:10:"1294407979";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/views/views.module', 'views', 'module', '', 1, 0, 0, 6009, 10, 'a:10:{s:4:"name";s:5:"Views";s:11:"description";s:55:"Create customized lists and queries from your database.";s:7:"package";s:5:"Views";s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-2.12";s:7:"project";s:5:"views";s:9:"datestamp";s:10:"1292446272";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/views_customfield/views_customfield.module', 'views_customfield', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:18:"Views Custom Field";s:11:"description";s:61:"Provides a number of custom fields (rownumber, phpcode, ...).";s:4:"core";s:3:"6.x";s:7:"package";s:5:"Views";s:12:"dependencies";a:1:{i:0;s:5:"views";}s:7:"version";s:7:"6.x-1.0";s:7:"project";s:17:"views_customfield";s:9:"datestamp";s:10:"1240962075";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/views/views_export/views_export.module', 'views_export', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:14:"Views exporter";s:11:"description";s:40:"Allows exporting multiple views at once.";s:7:"package";s:5:"Views";s:12:"dependencies";a:1:{i:0;s:5:"views";}s:4:"core";s:3:"6.x";s:7:"version";s:8:"6.x-2.12";s:7:"project";s:5:"views";s:9:"datestamp";s:10:"1292446272";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/views_galleriffic/views_galleriffic.module', 'views_galleriffic', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:17:"Views Galleriffic";s:11:"description";s:50:"Use Views to make JQuery Galleriffic image gallery";s:4:"core";s:3:"6.x";s:7:"package";s:5:"Views";s:12:"dependencies";a:4:{i:0;s:5:"views";i:1;s:10:"imagefield";i:2;s:7:"content";i:3;s:10:"imagecache";}s:7:"version";s:7:"6.x-1.4";s:7:"project";s:17:"views_galleriffic";s:9:"datestamp";s:10:"1312555321";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/views/views_ui.module', 'views_ui', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:8:"Views UI";s:11:"description";s:93:"Administrative interface to views. Without this module, you cannot create or edit your views.";s:7:"package";s:5:"Views";s:4:"core";s:3:"6.x";s:12:"dependencies";a:1:{i:0;s:5:"views";}s:7:"version";s:8:"6.x-2.12";s:7:"project";s:5:"views";s:9:"datestamp";s:10:"1292446272";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/viewsphpfilter/viewsphpfilter.module', 'viewsphpfilter', 'module', '', 1, 0, 0, 0, 0, 'a:10:{s:4:"name";s:16:"Views PHP Filter";s:11:"description";s:119:"Adds a filter to Views that takes PHP code, and uses the return value of the code as an array of Node IDs to filter on.";s:4:"core";s:3:"6.x";s:12:"dependencies";a:1:{i:0;s:5:"views";}s:7:"package";s:5:"Views";s:7:"version";s:7:"6.x-1.0";s:7:"project";s:14:"viewsphpfilter";s:9:"datestamp";s:10:"1294799569";s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/vsk_utilities/vsk_utilities.module', 'vsk_utilities', 'module', '', 0, 0, 0, -1, 0, 'a:8:{s:4:"name";s:13:"VSK_utilities";s:11:"description";s:25:"VisiKard utilities of TT.";s:7:"package";s:8:"VisiKard";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-1.0";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/wysiwyg/wysiwyg.module', 'wysiwyg', 'module', '', 1, 0, 0, 6201, 0, 'a:10:{s:4:"name";s:7:"Wysiwyg";s:11:"description";s:55:"Allows users to edit contents with client-side editors.";s:7:"package";s:14:"User interface";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-2.3";s:7:"project";s:7:"wysiwyg";s:9:"datestamp";s:10:"1296430415";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/modules/my_utilities/my_utilities.module', 'my_utilities', 'module', '', 1, 0, 0, 0, 0, 'a:8:{s:4:"name";s:12:"My_utilities";s:11:"description";s:25:"My utilities of LinhTran.";s:7:"package";s:2:"My";s:4:"core";s:3:"6.x";s:7:"version";s:7:"6.x-1.0";s:12:"dependencies";a:0:{}s:10:"dependents";a:0:{}s:3:"php";s:5:"4.3.5";}'),
('sites/all/themes/visikard/visikard.info', 'visikard', 'theme', 'themes/engines/phptemplate/phptemplate.engine', 0, 0, 0, -1, 0, 'a:14:{s:4:"name";s:9:"Visi Kard";s:11:"description";s:18:"Visi Kard Company.";s:10:"screenshot";s:40:"sites/all/themes/visikard/screenshot.png";s:7:"version";s:7:"6.x-1.0";s:4:"core";s:3:"6.x";s:10:"base theme";s:3:"zen";s:11:"stylesheets";a:2:{s:3:"all";a:16:{s:18:"css/html-reset.css";s:44:"sites/all/themes/visikard/css/html-reset.css";s:18:"css/wireframes.css";s:44:"sites/all/themes/visikard/css/wireframes.css";s:20:"css/layout-fixed.css";s:46:"sites/all/themes/visikard/css/layout-fixed.css";s:24:"css/page-backgrounds.css";s:50:"sites/all/themes/visikard/css/page-backgrounds.css";s:12:"css/tabs.css";s:38:"sites/all/themes/visikard/css/tabs.css";s:16:"css/messages.css";s:42:"sites/all/themes/visikard/css/messages.css";s:13:"css/pages.css";s:39:"sites/all/themes/visikard/css/pages.css";s:21:"css/block-editing.css";s:47:"sites/all/themes/visikard/css/block-editing.css";s:14:"css/blocks.css";s:40:"sites/all/themes/visikard/css/blocks.css";s:18:"css/navigation.css";s:44:"sites/all/themes/visikard/css/navigation.css";s:21:"css/panels-styles.css";s:47:"sites/all/themes/visikard/css/panels-styles.css";s:20:"css/views-styles.css";s:46:"sites/all/themes/visikard/css/views-styles.css";s:13:"css/nodes.css";s:39:"sites/all/themes/visikard/css/nodes.css";s:16:"css/comments.css";s:42:"sites/all/themes/visikard/css/comments.css";s:13:"css/forms.css";s:39:"sites/all/themes/visikard/css/forms.css";s:14:"css/fields.css";s:40:"sites/all/themes/visikard/css/fields.css";}s:5:"print";a:1:{s:13:"css/print.css";s:39:"sites/all/themes/visikard/css/print.css";}}s:23:"conditional-stylesheets";a:2:{s:5:"if IE";a:1:{s:3:"all";a:1:{i:0;s:10:"css/ie.css";}}s:11:"if lte IE 6";a:1:{s:3:"all";a:1:{i:0;s:11:"css/ie6.css";}}}s:7:"regions";a:12:{s:10:"admin_menu";s:10:"Admin Menu";s:13:"sidebar_first";s:13:"First sidebar";s:14:"sidebar_second";s:14:"Second sidebar";s:10:"navigation";s:14:"Navigation bar";s:10:"slide_show";s:10:"Slide show";s:9:"highlight";s:19:"Highlighted content";s:11:"content_top";s:11:"Content top";s:14:"content_bottom";s:14:"Content bottom";s:6:"header";s:6:"Header";s:6:"scroll";s:6:"Scroll";s:6:"footer";s:6:"Footer";s:12:"page_closure";s:12:"Page closure";}s:8:"features";a:10:{i:0;s:4:"logo";i:1;s:4:"name";i:2;s:6:"slogan";i:3;s:7:"mission";i:4;s:17:"node_user_picture";i:5;s:20:"comment_user_picture";i:6;s:6:"search";i:7;s:7:"favicon";i:8;s:13:"primary_links";i:9;s:15:"secondary_links";}s:8:"settings";a:8:{s:17:"zen_block_editing";s:1:"1";s:14:"zen_breadcrumb";s:3:"yes";s:24:"zen_breadcrumb_separator";s:5:" › ";s:19:"zen_breadcrumb_home";s:1:"1";s:23:"zen_breadcrumb_trailing";s:1:"1";s:20:"zen_breadcrumb_title";s:1:"0";s:20:"zen_rebuild_registry";s:1:"1";s:14:"zen_wireframes";s:1:"0";}s:7:"scripts";a:1:{s:9:"script.js";s:35:"sites/all/themes/visikard/script.js";}s:3:"php";s:5:"4.3.5";s:6:"engine";s:11:"phptemplate";}');

-- --------------------------------------------------------

--
-- Table structure for table `term_data`
--

CREATE TABLE IF NOT EXISTS `term_data` (
  `tid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` longtext,
  `weight` tinyint(4) NOT NULL DEFAULT '0',
  `language` varchar(12) NOT NULL DEFAULT '',
  `trid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`),
  KEY `taxonomy_tree` (`vid`,`weight`,`name`),
  KEY `vid_name` (`vid`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `term_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `term_hierarchy`
--

CREATE TABLE IF NOT EXISTS `term_hierarchy` (
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  `parent` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`,`parent`),
  KEY `parent` (`parent`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `term_hierarchy`
--


-- --------------------------------------------------------

--
-- Table structure for table `term_node`
--

CREATE TABLE IF NOT EXISTS `term_node` (
  `nid` int(10) unsigned NOT NULL DEFAULT '0',
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`,`vid`),
  KEY `vid` (`vid`),
  KEY `nid` (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `term_node`
--


-- --------------------------------------------------------

--
-- Table structure for table `term_relation`
--

CREATE TABLE IF NOT EXISTS `term_relation` (
  `trid` int(11) NOT NULL AUTO_INCREMENT,
  `tid1` int(10) unsigned NOT NULL DEFAULT '0',
  `tid2` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`trid`),
  UNIQUE KEY `tid1_tid2` (`tid1`,`tid2`),
  KEY `tid2` (`tid2`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `term_relation`
--


-- --------------------------------------------------------

--
-- Table structure for table `term_synonym`
--

CREATE TABLE IF NOT EXISTS `term_synonym` (
  `tsid` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`tsid`),
  KEY `tid` (`tid`),
  KEY `name_tid` (`name`,`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `term_synonym`
--


-- --------------------------------------------------------

--
-- Table structure for table `url_alias`
--

CREATE TABLE IF NOT EXISTS `url_alias` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `src` varchar(128) NOT NULL DEFAULT '',
  `dst` varchar(128) NOT NULL DEFAULT '',
  `language` varchar(12) NOT NULL DEFAULT '',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `dst_language_pid` (`dst`,`language`,`pid`),
  KEY `src_language_pid` (`src`,`language`,`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `url_alias`
--

INSERT INTO `url_alias` (`pid`, `src`, `dst`, `language`) VALUES
(1, 'node/2', 'content/gioi-thieu', 'en'),
(2, 'node/3', 'content/san-pham', 'en'),
(4, 'node/5', 'content/liên-hệ', 'en'),
(6, 'node/7', 'content/với-hơn-5-năm-hoạt-động-trong-lĩnh-vực-dinh-dưỡng-chúng-tôi-đã-đạt-được-những-thành-tựu-sau', ''),
(7, 'node/8', 'content/với-hơn-10-dòng-sản-phẩm-chính-đáp-ứng-nhu-cầu-dinh-dưỡng-hàng-ngày-cho-mọi-lứa-tuổi', ''),
(8, 'node/9', 'content/ht-phân-phối', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL DEFAULT '',
  `pass` varchar(32) NOT NULL DEFAULT '',
  `mail` varchar(64) DEFAULT '',
  `mode` tinyint(4) NOT NULL DEFAULT '0',
  `sort` tinyint(4) DEFAULT '0',
  `threshold` tinyint(4) DEFAULT '0',
  `theme` varchar(255) NOT NULL DEFAULT '',
  `signature` varchar(255) NOT NULL DEFAULT '',
  `signature_format` smallint(6) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '0',
  `login` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `timezone` varchar(8) DEFAULT NULL,
  `language` varchar(12) NOT NULL DEFAULT '',
  `picture` varchar(255) NOT NULL DEFAULT '',
  `init` varchar(64) DEFAULT '',
  `data` longtext,
  `timezone_name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `name` (`name`),
  KEY `access` (`access`),
  KEY `created` (`created`),
  KEY `mail` (`mail`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `name`, `pass`, `mail`, `mode`, `sort`, `threshold`, `theme`, `signature`, `signature_format`, `created`, `access`, `login`, `status`, `timezone`, `language`, `picture`, `init`, `data`, `timezone_name`) VALUES
(0, '', '', '', 0, 0, 0, '', '', 0, 0, 0, 0, 0, NULL, '', '', '', NULL, ''),
(1, 'root', 'f379eaf3c831b04de153469d1bec345e', 'admin@goodmilk.com', 0, 0, 0, '', '', 0, 1420944341, 1421309608, 1421127607, 1, NULL, '', '', 'admin@goodmilk.com', 'a:0:{}', '');

-- --------------------------------------------------------

--
-- Table structure for table `users_roles`
--

CREATE TABLE IF NOT EXISTS `users_roles` (
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `rid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`,`rid`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_roles`
--


-- --------------------------------------------------------

--
-- Table structure for table `variable`
--

CREATE TABLE IF NOT EXISTS `variable` (
  `name` varchar(128) NOT NULL DEFAULT '',
  `value` longtext NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `variable`
--

INSERT INTO `variable` (`name`, `value`) VALUES
('theme_default', 's:9:"bootstrap";'),
('filter_html_1', 'i:1;'),
('node_options_forum', 'a:1:{i:0;s:6:"status";}'),
('drupal_private_key', 's:64:"5419303d98b86ff5ebc4228a3703ebbbaff7542c589d47602e579cca0435a114";'),
('menu_masks', 'a:22:{i:0;i:127;i:1;i:125;i:2;i:63;i:3;i:62;i:4;i:61;i:5;i:59;i:6;i:58;i:7;i:56;i:8;i:31;i:9;i:30;i:10;i:29;i:11;i:24;i:12;i:21;i:13;i:15;i:14;i:14;i:15;i:11;i:16;i:7;i:17;i:6;i:18;i:5;i:19;i:3;i:20;i:2;i:21;i:1;}'),
('install_task', 's:4:"done";'),
('menu_expanded', 'a:0:{}'),
('site_name', 's:9:"localhost";'),
('site_mail', 's:18:"admin@goodmilk.com";'),
('date_default_timezone', 's:5:"25200";'),
('user_email_verification', 'b:1;'),
('clean_url', 's:1:"1";'),
('install_time', 'i:1420944412;'),
('node_options_page', 'a:1:{i:0;s:6:"status";}'),
('comment_page', 'i:0;'),
('theme_settings', 'a:1:{s:21:"toggle_node_info_page";b:0;}'),
('drupal_http_request_fails', 'b:0;'),
('css_js_query_string', 's:20:"kos9NifgLAH1w7500000";'),
('install_profile', 's:7:"default";'),
('update_last_check', 'i:1421052403;'),
('file_directory_temp', 's:11:"D:/wamp/tmp";'),
('javascript_parsed', 'a:32:{i:0;s:14:"misc/jquery.js";i:1;s:14:"misc/drupal.js";i:2;s:42:"sites/all/modules/admin_menu/admin_menu.js";i:3;s:42:"sites/all/modules/lightbox2/js/lightbox.js";i:4;s:54:"sites/all/modules/nice_menus/superfish/js/superfish.js";i:5;s:64:"sites/all/modules/nice_menus/superfish/js/jquery.bgiframe.min.js";i:6;s:72:"sites/all/modules/nice_menus/superfish/js/jquery.hoverIntent.minified.js";i:7;s:42:"sites/all/modules/nice_menus/nice_menus.js";s:10:"refresh:vi";s:7:"waiting";i:8;s:39:"sites/all/themes/bootstrap/js/jquery.js";i:9;s:39:"sites/all/themes/bootstrap/js/script.js";i:10;s:42:"sites/all/themes/bootstrap/js/bootstrap.js";i:11;s:16:"misc/textarea.js";i:12;s:17:"misc/tabledrag.js";i:13;s:19:"misc/tableheader.js";i:14;s:41:"sites/all/modules/wysiwyg/wysiwyg.init.js";i:15;s:38:"sites/all/modules/pathauto/pathauto.js";i:16;s:40:"sites/all/libraries/ckeditor/ckeditor.js";i:17;s:52:"sites/all/modules/wysiwyg/editors/js/ckeditor-3.0.js";i:18;s:44:"sites/all/modules/wysiwyg/editors/js/none.js";i:19;s:33:"sites/all/modules/imce/js/imce.js";i:20;s:41:"sites/all/modules/imce/js/imce_set_app.js";i:21;s:49:"sites/all/modules/imce_wysiwyg/js/imce_wysiwyg.js";i:22;s:20:"misc/autocomplete.js";i:23;s:16:"misc/collapse.js";i:24;s:36:"sites/all/modules/wysiwyg/wysiwyg.js";i:25;s:38:"sites/all/themes/bootstrap/js/slick.js";i:26;s:32:"sites/all/modules/cck/content.js";i:27;s:12:"misc/form.js";i:28;s:19:"misc/tableselect.js";i:29;s:40:"sites/all/modules/imce/js/jquery.form.js";i:30;s:40:"sites/all/modules/imce/js/imce_extras.js";}'),
('cache', 's:1:"0";'),
('cache_lifetime', 's:1:"0";'),
('page_compression', 's:1:"1";'),
('block_cache', 's:1:"0";'),
('preprocess_css', 's:1:"0";'),
('preprocess_js', 's:1:"0";'),
('clear', 's:17:"Clear cached data";'),
('comment_anonymous_home', 'i:0;'),
('node_options_intro', 'a:2:{i:0;s:6:"status";i:1;s:7:"promote";}'),
('language_content_type_intro', 's:1:"0";'),
('form_build_id_intro', 's:37:"form-ad81dd1c5ef6fc43ee3410af805610fe";'),
('admin_theme', 's:7:"garland";'),
('node_admin_theme', 'i:1;'),
('content_schema_version', 'i:6009;'),
('fieldgroup_schema_version', 'i:6000;'),
('date_api_version', 's:3:"5.2";'),
('imce_profiles', 'a:2:{i:1;a:10:{s:4:"name";s:6:"User-1";s:7:"usertab";i:1;s:8:"filesize";i:0;s:5:"quota";i:0;s:7:"tuquota";i:0;s:10:"extensions";s:1:"*";s:10:"dimensions";s:9:"1200x1200";s:7:"filenum";i:0;s:11:"directories";a:1:{i:0;a:7:{s:4:"name";s:1:".";s:6:"subnav";i:1;s:6:"browse";i:1;s:6:"upload";i:1;s:5:"thumb";i:1;s:6:"delete";i:1;s:6:"resize";i:1;}}s:10:"thumbnails";a:3:{i:0;a:4:{s:4:"name";s:5:"Small";s:10:"dimensions";s:5:"90x90";s:6:"prefix";s:6:"small_";s:6:"suffix";s:0:"";}i:1;a:4:{s:4:"name";s:6:"Medium";s:10:"dimensions";s:7:"120x120";s:6:"prefix";s:7:"medium_";s:6:"suffix";s:0:"";}i:2;a:4:{s:4:"name";s:5:"Large";s:10:"dimensions";s:7:"180x180";s:6:"prefix";s:6:"large_";s:6:"suffix";s:0:"";}}}i:2;a:10:{s:4:"name";s:14:"Sample profile";s:7:"usertab";i:1;s:8:"filesize";i:1;s:5:"quota";i:2;s:7:"tuquota";i:0;s:10:"extensions";s:16:"gif png jpg jpeg";s:10:"dimensions";s:7:"800x600";s:7:"filenum";i:1;s:11:"directories";a:1:{i:0;a:7:{s:4:"name";s:5:"u%uid";s:6:"subnav";i:0;s:6:"browse";i:1;s:6:"upload";i:1;s:5:"thumb";i:1;s:6:"delete";i:0;s:6:"resize";i:0;}}s:10:"thumbnails";a:1:{i:0;a:4:{s:4:"name";s:5:"Thumb";s:10:"dimensions";s:5:"90x90";s:6:"prefix";s:6:"thumb_";s:6:"suffix";s:0:"";}}}}'),
('imce_roles_profiles', 'a:0:{}'),
('pathauto_modulelist', 'a:3:{i:0;s:4:"node";i:1;s:4:"user";i:2;s:8:"taxonomy";}'),
('pathauto_taxonomy_supportsfeeds', 's:6:"0/feed";'),
('pathauto_taxonomy_pattern', 's:34:"category/[vocab-raw]/[catpath-raw]";'),
('pathauto_taxonomy_bulkupdate', 'b:0;'),
('pathauto_taxonomy_applytofeeds', 'b:0;'),
('pathauto_taxonomy_2_pattern', 's:0:"";'),
('pathauto_taxonomy_1_pattern', 's:0:"";'),
('pathauto_ignore_words', 's:108:"a,an,as,at,before,but,by,for,from,is,in,into,like,of,off,on,onto,per,since,than,the,this,that,to,up,via,with";'),
('pathauto_indexaliases', 'b:0;'),
('pathauto_indexaliases_bulkupdate', 'b:0;'),
('pathauto_max_component_length', 's:3:"100";'),
('pathauto_max_length', 's:3:"100";'),
('pathauto_node_bulkupdate', 'b:0;'),
('pathauto_node_forum_pattern', 's:0:"";'),
('pathauto_node_image_pattern', 's:0:"";'),
('pathauto_node_page_pattern', 's:0:"";'),
('pathauto_node_pattern', 's:19:"content/[title-raw]";'),
('pathauto_node_story_pattern', 's:0:"";'),
('pathauto_punctuation_quotes', 'i:0;'),
('pathauto_separator', 's:1:"-";'),
('pathauto_update_action', 's:1:"2";'),
('pathauto_user_bulkupdate', 'b:0;'),
('pathauto_user_pattern', 's:16:"users/[user-raw]";'),
('pathauto_user_supportsfeeds', 'N;'),
('pathauto_verbose', 'b:0;'),
('pathauto_node_applytofeeds', 's:0:"";'),
('pathauto_punctuation_hyphen', 'i:1;'),
('theme_zen_settings', 'a:9:{s:17:"zen_block_editing";s:1:"1";s:14:"zen_breadcrumb";s:3:"yes";s:24:"zen_breadcrumb_separator";s:5:" › ";s:19:"zen_breadcrumb_home";s:1:"1";s:23:"zen_breadcrumb_trailing";s:1:"1";s:20:"zen_breadcrumb_title";s:1:"0";s:10:"zen_layout";s:18:"zen-columns-liquid";s:20:"zen_rebuild_registry";s:1:"0";s:14:"zen_wireframes";s:1:"0";}'),
('theme_bootstrap_settings', 'a:12:{s:17:"zen_block_editing";s:1:"1";s:14:"zen_breadcrumb";s:3:"yes";s:24:"zen_breadcrumb_separator";s:5:" › ";s:19:"zen_breadcrumb_home";s:1:"1";s:23:"zen_breadcrumb_trailing";s:1:"1";s:20:"zen_breadcrumb_title";s:1:"0";s:20:"zen_rebuild_registry";s:1:"1";s:14:"zen_wireframes";s:1:"0";s:26:"bootstrap_block_edit_links";s:1:"1";s:26:"bootstrap_rebuild_registry";s:1:"0";s:18:"bootstrap_showgrid";s:1:"0";s:25:"bootstrap_animated_submit";s:1:"1";}'),
('site_mission', 's:0:"";'),
('site_footer', 's:0:"";'),
('anonymous', 's:9:"Anonymous";'),
('site_frontpage', 's:4:"home";'),
('node_options_home', 'a:2:{i:0;s:6:"status";i:1;s:7:"promote";}'),
('language_content_type_home', 's:1:"0";'),
('form_build_id_home', 's:37:"form-7a55f6eb79b0d0716561f51690c4df57";'),
('comment_home', 's:1:"0";'),
('node_options_contact', 'a:2:{i:0;s:6:"status";i:1;s:7:"promote";}'),
('site_pagehit', 'i:55;'),
('contact_form_information', 's:0:"";'),
('contact_hourly_threshold', 's:1:"3";'),
('contact_default_status', 'i:1;'),
('language_count', 'i:2;'),
('i18n_translation_switch', 'i:0;'),
('site_slogan', 's:0:"";'),
('language_default', 'O:8:"stdClass":11:{s:8:"language";s:2:"en";s:4:"name";s:7:"English";s:6:"native";s:7:"English";s:9:"direction";s:1:"0";s:7:"enabled";i:1;s:7:"plurals";s:1:"0";s:7:"formula";s:0:"";s:6:"domain";s:0:"";s:6:"prefix";s:2:"en";s:6:"weight";s:1:"0";s:10:"javascript";s:0:"";}'),
('language_negotiation', 's:1:"0";'),
('language_content_type_contact', 's:1:"0";'),
('form_build_id_contact', 's:37:"form-60ddfd841b03c72d95804e454da88980";'),
('comment_contact', 's:1:"0";'),
('comment_default_mode_contact', 's:1:"4";'),
('comment_default_order_contact', 's:1:"1";'),
('comment_default_per_page_contact', 's:2:"50";'),
('comment_controls_contact', 's:1:"3";'),
('comment_anonymous_contact', 'i:0;'),
('comment_subject_field_contact', 's:1:"1";'),
('comment_preview_contact', 's:1:"1";'),
('comment_form_location_contact', 's:1:"0";'),
('comment_default_mode_home', 's:1:"4";'),
('content_extra_weights_contact', 'a:7:{s:5:"title";s:2:"-5";s:20:"revision_information";s:1:"4";s:6:"author";s:1:"3";s:7:"options";s:1:"5";s:16:"comment_settings";s:1:"7";s:4:"menu";s:1:"2";s:4:"path";s:1:"6";}'),
('comment_default_order_home', 's:1:"1";'),
('comment_default_per_page_home', 's:2:"50";'),
('comment_controls_home', 's:1:"3";'),
('i18n_selection_mode', 's:6:"simple";'),
('i18n_hide_translation_links', 'i:0;'),
('comment_intro', 's:1:"0";'),
('comment_default_mode_intro', 's:1:"4";'),
('comment_default_order_intro', 's:1:"1";'),
('comment_default_per_page_intro', 's:2:"50";'),
('comment_controls_intro', 's:1:"3";'),
('comment_anonymous_intro', 'i:0;'),
('comment_subject_field_intro', 's:1:"1";'),
('comment_preview_intro', 's:1:"1";'),
('comment_form_location_intro', 's:1:"0";'),
('i18n_newnode_current_intro', 'i:0;'),
('i18n_required_node_intro', 'i:0;'),
('i18n_lock_node_intro', 'i:0;'),
('i18n_node_intro', 'i:1;'),
('i18nsync_nodeapi_intro', 'a:0:{}'),
('comment_subject_field_home', 's:1:"1";'),
('content_extra_weights_intro', 'a:7:{s:5:"title";s:2:"-5";s:20:"revision_information";s:2:"-1";s:6:"author";s:1:"0";s:7:"options";s:1:"1";s:16:"comment_settings";s:1:"3";s:4:"menu";s:2:"-2";s:4:"path";s:1:"2";}'),
('comment_preview_home', 's:1:"1";'),
('comment_form_location_home', 's:1:"0";'),
('i18n_newnode_current_home', 'i:0;'),
('i18n_required_node_home', 'i:0;'),
('i18n_lock_node_home', 'i:0;'),
('i18n_node_home', 'i:1;'),
('i18nsync_nodeapi_home', 'a:0:{}'),
('content_extra_weights_home', 'a:7:{s:5:"title";s:2:"-5";s:20:"revision_information";s:1:"0";s:6:"author";s:1:"1";s:7:"options";s:1:"2";s:16:"comment_settings";s:1:"4";s:4:"menu";s:2:"-1";s:4:"path";s:1:"3";}'),
('node_options_distribution', 'a:2:{i:0;s:6:"status";i:1;s:7:"promote";}'),
('language_content_type_distribution', 's:1:"0";'),
('form_build_id_distribution', 's:37:"form-85a55917196eae30fa14221e4b19b39d";'),
('comment_distribution', 's:1:"0";'),
('comment_default_mode_distribution', 's:1:"4";'),
('comment_default_order_distribution', 's:1:"1";'),
('comment_default_per_page_distribution', 's:2:"50";'),
('comment_controls_distribution', 's:1:"3";'),
('comment_anonymous_distribution', 'i:0;'),
('comment_subject_field_distribution', 's:1:"1";'),
('comment_preview_distribution', 's:1:"1";'),
('comment_form_location_distribution', 's:1:"0";'),
('i18n_newnode_current_distribution', 'i:0;'),
('i18n_required_node_distribution', 'i:0;'),
('i18n_lock_node_distribution', 'i:0;'),
('i18n_node_distribution', 'i:1;'),
('i18nsync_nodeapi_distribution', 'a:0:{}'),
('content_extra_weights_distribution', 'a:7:{s:5:"title";s:2:"-5";s:20:"revision_information";s:2:"-2";s:6:"author";s:2:"-1";s:7:"options";s:1:"0";s:16:"comment_settings";s:1:"1";s:4:"menu";s:2:"-3";s:4:"path";s:1:"2";}');

-- --------------------------------------------------------

--
-- Table structure for table `views_display`
--

CREATE TABLE IF NOT EXISTS `views_display` (
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `id` varchar(64) NOT NULL DEFAULT '',
  `display_title` varchar(64) NOT NULL DEFAULT '',
  `display_plugin` varchar(64) NOT NULL DEFAULT '',
  `position` int(11) DEFAULT '0',
  `display_options` longtext,
  PRIMARY KEY (`vid`,`id`),
  KEY `vid` (`vid`,`position`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `views_display`
--


-- --------------------------------------------------------

--
-- Table structure for table `views_object_cache`
--

CREATE TABLE IF NOT EXISTS `views_object_cache` (
  `sid` varchar(64) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `obj` varchar(32) DEFAULT NULL,
  `updated` int(10) unsigned NOT NULL DEFAULT '0',
  `data` longtext,
  KEY `sid_obj_name` (`sid`,`obj`,`name`),
  KEY `updated` (`updated`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `views_object_cache`
--

INSERT INTO `views_object_cache` (`sid`, `name`, `obj`, `updated`, `data`) VALUES
('rhfddet3kf47atohr1blgv17r6', 'test', 'view', 1421135933, 'O:4:"view":25:{s:8:"db_table";s:10:"views_view";s:10:"base_table";s:4:"node";s:5:"built";b:0;s:8:"executed";b:0;s:4:"args";a:0:{}s:10:"build_info";a:0:{}s:8:"use_ajax";b:0;s:6:"result";a:0:{}s:5:"pager";a:5:{s:9:"use_pager";b:0;s:14:"items_per_page";i:10;s:7:"element";i:0;s:6:"offset";i:0;s:12:"current_page";i:0;}s:17:"attachment_before";s:0:"";s:16:"attachment_after";s:0:"";s:12:"exposed_data";a:0:{}s:13:"exposed_input";a:0:{}s:8:"old_view";a:0:{}s:3:"vid";s:3:"new";s:4:"name";s:4:"test";s:11:"description";s:0:"";s:3:"tag";s:0:"";s:8:"view_php";s:0:"";s:12:"is_cacheable";i:0;s:7:"display";a:1:{s:7:"default";O:13:"views_display":7:{s:8:"db_table";s:13:"views_display";s:3:"vid";i:0;s:2:"id";s:7:"default";s:13:"display_title";s:8:"Defaults";s:14:"display_plugin";s:7:"default";s:8:"position";i:0;s:15:"display_options";a:2:{s:7:"filters";a:1:{s:4:"type";a:9:{s:8:"operator";s:2:"in";s:5:"value";a:1:{s:7:"contact";s:7:"contact";}s:5:"group";s:1:"0";s:7:"exposed";b:0;s:6:"expose";a:2:{s:8:"operator";b:0;s:5:"label";s:0:"";}s:2:"id";s:4:"type";s:5:"table";s:4:"node";s:5:"field";s:4:"type";s:12:"relationship";s:4:"none";}}s:6:"fields";a:7:{s:5:"title";a:11:{s:5:"label";s:5:"Title";s:5:"alter";a:16:{s:10:"alter_text";i:0;s:4:"text";s:0:"";s:9:"make_link";i:0;s:4:"path";s:0:"";s:10:"link_class";s:0:"";s:3:"alt";s:0:"";s:6:"prefix";s:0:"";s:6:"suffix";s:0:"";s:6:"target";s:0:"";s:4:"help";s:0:"";s:4:"trim";i:0;s:10:"max_length";s:0:"";s:13:"word_boundary";i:1;s:8:"ellipsis";i:1;s:4:"html";i:0;s:10:"strip_tags";i:0;}s:5:"empty";s:0:"";s:10:"hide_empty";i:0;s:10:"empty_zero";i:0;s:12:"link_to_node";i:0;s:7:"exclude";i:0;s:2:"id";s:5:"title";s:5:"table";s:4:"node";s:5:"field";s:5:"title";s:12:"relationship";s:4:"none";}s:27:"field_contact_address_value";a:14:{s:5:"label";s:7:"Address";s:5:"alter";a:16:{s:10:"alter_text";i:0;s:4:"text";s:0:"";s:9:"make_link";i:0;s:4:"path";s:0:"";s:10:"link_class";s:0:"";s:3:"alt";s:0:"";s:6:"prefix";s:0:"";s:6:"suffix";s:0:"";s:6:"target";s:0:"";s:4:"help";s:0:"";s:4:"trim";i:0;s:10:"max_length";s:0:"";s:13:"word_boundary";i:1;s:8:"ellipsis";i:1;s:4:"html";i:0;s:10:"strip_tags";i:0;}s:5:"empty";s:0:"";s:10:"hide_empty";i:0;s:10:"empty_zero";i:0;s:12:"link_to_node";i:0;s:10:"label_type";s:6:"widget";s:6:"format";s:7:"default";s:8:"multiple";a:4:{s:5:"group";b:1;s:15:"multiple_number";s:0:"";s:13:"multiple_from";s:0:"";s:17:"multiple_reversed";b:0;}s:7:"exclude";i:0;s:2:"id";s:27:"field_contact_address_value";s:5:"table";s:31:"node_data_field_contact_address";s:5:"field";s:27:"field_contact_address_value";s:12:"relationship";s:4:"none";}s:25:"field_contact_email_value";a:14:{s:5:"label";s:5:"Email";s:5:"alter";a:16:{s:10:"alter_text";i:0;s:4:"text";s:0:"";s:9:"make_link";i:0;s:4:"path";s:0:"";s:10:"link_class";s:0:"";s:3:"alt";s:0:"";s:6:"prefix";s:0:"";s:6:"suffix";s:0:"";s:6:"target";s:0:"";s:4:"help";s:0:"";s:4:"trim";i:0;s:10:"max_length";s:0:"";s:13:"word_boundary";i:1;s:8:"ellipsis";i:1;s:4:"html";i:0;s:10:"strip_tags";i:0;}s:5:"empty";s:0:"";s:10:"hide_empty";i:0;s:10:"empty_zero";i:0;s:12:"link_to_node";i:0;s:10:"label_type";s:6:"widget";s:6:"format";s:7:"default";s:8:"multiple";a:4:{s:5:"group";b:1;s:15:"multiple_number";s:0:"";s:13:"multiple_from";s:0:"";s:17:"multiple_reversed";b:0;}s:7:"exclude";i:0;s:2:"id";s:25:"field_contact_email_value";s:5:"table";s:29:"node_data_field_contact_email";s:5:"field";s:25:"field_contact_email_value";s:12:"relationship";s:4:"none";}s:23:"field_contact_fax_value";a:14:{s:5:"label";s:3:"Fax";s:5:"alter";a:16:{s:10:"alter_text";i:0;s:4:"text";s:0:"";s:9:"make_link";i:0;s:4:"path";s:0:"";s:10:"link_class";s:0:"";s:3:"alt";s:0:"";s:6:"prefix";s:0:"";s:6:"suffix";s:0:"";s:6:"target";s:0:"";s:4:"help";s:0:"";s:4:"trim";i:0;s:10:"max_length";s:0:"";s:13:"word_boundary";i:1;s:8:"ellipsis";i:1;s:4:"html";i:0;s:10:"strip_tags";i:0;}s:5:"empty";s:0:"";s:10:"hide_empty";i:0;s:10:"empty_zero";i:0;s:12:"link_to_node";i:0;s:10:"label_type";s:6:"widget";s:6:"format";s:7:"default";s:8:"multiple";a:4:{s:5:"group";b:1;s:15:"multiple_number";s:0:"";s:13:"multiple_from";s:0:"";s:17:"multiple_reversed";b:0;}s:7:"exclude";i:0;s:2:"id";s:23:"field_contact_fax_value";s:5:"table";s:27:"node_data_field_contact_fax";s:5:"field";s:23:"field_contact_fax_value";s:12:"relationship";s:4:"none";}s:26:"field_contact_mobile_value";a:14:{s:5:"label";s:6:"Mobile";s:5:"alter";a:16:{s:10:"alter_text";i:0;s:4:"text";s:0:"";s:9:"make_link";i:0;s:4:"path";s:0:"";s:10:"link_class";s:0:"";s:3:"alt";s:0:"";s:6:"prefix";s:0:"";s:6:"suffix";s:0:"";s:6:"target";s:0:"";s:4:"help";s:0:"";s:4:"trim";i:0;s:10:"max_length";s:0:"";s:13:"word_boundary";i:1;s:8:"ellipsis";i:1;s:4:"html";i:0;s:10:"strip_tags";i:0;}s:5:"empty";s:0:"";s:10:"hide_empty";i:0;s:10:"empty_zero";i:0;s:12:"link_to_node";i:0;s:10:"label_type";s:6:"widget";s:6:"format";s:7:"default";s:8:"multiple";a:4:{s:5:"group";b:1;s:15:"multiple_number";s:0:"";s:13:"multiple_from";s:0:"";s:17:"multiple_reversed";b:0;}s:7:"exclude";i:0;s:2:"id";s:26:"field_contact_mobile_value";s:5:"table";s:30:"node_data_field_contact_mobile";s:5:"field";s:26:"field_contact_mobile_value";s:12:"relationship";s:4:"none";}s:25:"field_contact_phone_value";a:14:{s:5:"label";s:5:"Phone";s:5:"alter";a:16:{s:10:"alter_text";i:0;s:4:"text";s:0:"";s:9:"make_link";i:0;s:4:"path";s:0:"";s:10:"link_class";s:0:"";s:3:"alt";s:0:"";s:6:"prefix";s:0:"";s:6:"suffix";s:0:"";s:6:"target";s:0:"";s:4:"help";s:0:"";s:4:"trim";i:0;s:10:"max_length";s:0:"";s:13:"word_boundary";i:1;s:8:"ellipsis";i:1;s:4:"html";i:0;s:10:"strip_tags";i:0;}s:5:"empty";s:0:"";s:10:"hide_empty";i:0;s:10:"empty_zero";i:0;s:12:"link_to_node";i:0;s:10:"label_type";s:6:"widget";s:6:"format";s:7:"default";s:8:"multiple";a:4:{s:5:"group";b:1;s:15:"multiple_number";s:0:"";s:13:"multiple_from";s:0:"";s:17:"multiple_reversed";b:0;}s:7:"exclude";i:0;s:2:"id";s:25:"field_contact_phone_value";s:5:"table";s:29:"node_data_field_contact_phone";s:5:"field";s:25:"field_contact_phone_value";s:12:"relationship";s:4:"none";}s:27:"field_contact_website_value";a:14:{s:5:"label";s:7:"Website";s:5:"alter";a:16:{s:10:"alter_text";i:0;s:4:"text";s:0:"";s:9:"make_link";i:0;s:4:"path";s:0:"";s:10:"link_class";s:0:"";s:3:"alt";s:0:"";s:6:"prefix";s:0:"";s:6:"suffix";s:0:"";s:6:"target";s:0:"";s:4:"help";s:0:"";s:4:"trim";i:0;s:10:"max_length";s:0:"";s:13:"word_boundary";i:1;s:8:"ellipsis";i:1;s:4:"html";i:0;s:10:"strip_tags";i:0;}s:5:"empty";s:0:"";s:10:"hide_empty";i:0;s:10:"empty_zero";i:0;s:12:"link_to_node";i:0;s:10:"label_type";s:6:"widget";s:6:"format";s:7:"default";s:8:"multiple";a:4:{s:5:"group";b:1;s:15:"multiple_number";s:0:"";s:13:"multiple_from";s:0:"";s:17:"multiple_reversed";b:0;}s:7:"exclude";i:0;s:2:"id";s:27:"field_contact_website_value";s:5:"table";s:31:"node_data_field_contact_website";s:5:"field";s:27:"field_contact_website_value";s:12:"relationship";s:4:"none";}}}}}s:5:"query";O:8:"stdClass":0:{}s:7:"changed";b:1;s:16:"changed_sections";a:9:{s:15:"defaultadd-item";b:1;s:19:"default-filter-type";b:1;s:19:"default-field-title";b:1;s:41:"default-field-field_contact_address_value";b:1;s:39:"default-field-field_contact_email_value";b:1;s:37:"default-field-field_contact_fax_value";b:1;s:40:"default-field-field_contact_mobile_value";b:1;s:39:"default-field-field_contact_phone_value";b:1;s:41:"default-field-field_contact_website_value";b:1;}s:5:"stack";a:0:{}}');

-- --------------------------------------------------------

--
-- Table structure for table `views_view`
--

CREATE TABLE IF NOT EXISTS `views_view` (
  `vid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `tag` varchar(255) DEFAULT '',
  `view_php` blob,
  `base_table` varchar(64) NOT NULL DEFAULT '',
  `is_cacheable` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `views_view`
--


-- --------------------------------------------------------

--
-- Table structure for table `vocabulary`
--

CREATE TABLE IF NOT EXISTS `vocabulary` (
  `vid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` longtext,
  `help` varchar(255) NOT NULL DEFAULT '',
  `relations` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hierarchy` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `multiple` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `required` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `tags` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `module` varchar(255) NOT NULL DEFAULT '',
  `weight` tinyint(4) NOT NULL DEFAULT '0',
  `language` varchar(12) NOT NULL DEFAULT '',
  PRIMARY KEY (`vid`),
  KEY `list` (`weight`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `vocabulary`
--


-- --------------------------------------------------------

--
-- Table structure for table `vocabulary_node_types`
--

CREATE TABLE IF NOT EXISTS `vocabulary_node_types` (
  `vid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`type`,`vid`),
  KEY `vid` (`vid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vocabulary_node_types`
--


-- --------------------------------------------------------

--
-- Table structure for table `watchdog`
--

CREATE TABLE IF NOT EXISTS `watchdog` (
  `wid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(16) NOT NULL DEFAULT '',
  `message` longtext NOT NULL,
  `variables` longtext NOT NULL,
  `severity` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `link` varchar(255) NOT NULL DEFAULT '',
  `location` text NOT NULL,
  `referer` text,
  `hostname` varchar(128) NOT NULL DEFAULT '',
  `timestamp` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`wid`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=253 ;

--
-- Dumping data for table `watchdog`
--

INSERT INTO `watchdog` (`wid`, `uid`, `type`, `message`, `variables`, `severity`, `link`, `location`, `referer`, `hostname`, `timestamp`) VALUES
(1, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:208:"mail() [<a href=''function.mail''>function.mail</a>]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set()";s:5:"%file";s:38:"D:\\wamp\\www\\goodmilk\\includes\\mail.inc";s:5:"%line";i:192;}', 3, '', 'http://localhost/goodmilk/install.php?locale=en&profile=default', 'http://localhost/goodmilk/install.php?locale=en&profile=default', '127.0.0.1', 1420944412),
(2, 0, 'mail', 'Error sending e-mail (from %from to %to).', 'a:2:{s:5:"%from";s:18:"admin@goodmilk.com";s:3:"%to";s:18:"admin@goodmilk.com";}', 3, '', 'http://localhost/goodmilk/install.php?locale=en&profile=default', 'http://localhost/goodmilk/install.php?locale=en&profile=default', '127.0.0.1', 1420944412),
(3, 1, 'user', 'Session opened for %name.', 'a:1:{s:5:"%name";s:4:"root";}', 5, '', 'http://localhost/goodmilk/install.php?locale=en&profile=default', 'http://localhost/goodmilk/install.php?locale=en&profile=default', '127.0.0.1', 1420944412),
(4, 1, 'actions', 'Action ''%action'' added.', 'a:1:{s:7:"%action";s:15:"Publish comment";}', 5, '', 'http://localhost/goodmilk/install.php?locale=en&profile=default', 'http://localhost/goodmilk/install.php?locale=en&profile=default', '127.0.0.1', 1420944414),
(5, 1, 'actions', 'Action ''%action'' added.', 'a:1:{s:7:"%action";s:17:"Unpublish comment";}', 5, '', 'http://localhost/goodmilk/install.php?locale=en&profile=default', 'http://localhost/goodmilk/install.php?locale=en&profile=default', '127.0.0.1', 1420944414),
(6, 1, 'actions', 'Action ''%action'' added.', 'a:1:{s:7:"%action";s:12:"Publish post";}', 5, '', 'http://localhost/goodmilk/install.php?locale=en&profile=default', 'http://localhost/goodmilk/install.php?locale=en&profile=default', '127.0.0.1', 1420944414),
(7, 1, 'actions', 'Action ''%action'' added.', 'a:1:{s:7:"%action";s:14:"Unpublish post";}', 5, '', 'http://localhost/goodmilk/install.php?locale=en&profile=default', 'http://localhost/goodmilk/install.php?locale=en&profile=default', '127.0.0.1', 1420944414),
(8, 1, 'actions', 'Action ''%action'' added.', 'a:1:{s:7:"%action";s:16:"Make post sticky";}', 5, '', 'http://localhost/goodmilk/install.php?locale=en&profile=default', 'http://localhost/goodmilk/install.php?locale=en&profile=default', '127.0.0.1', 1420944414),
(9, 1, 'actions', 'Action ''%action'' added.', 'a:1:{s:7:"%action";s:18:"Make post unsticky";}', 5, '', 'http://localhost/goodmilk/install.php?locale=en&profile=default', 'http://localhost/goodmilk/install.php?locale=en&profile=default', '127.0.0.1', 1420944414),
(10, 1, 'actions', 'Action ''%action'' added.', 'a:1:{s:7:"%action";s:26:"Promote post to front page";}', 5, '', 'http://localhost/goodmilk/install.php?locale=en&profile=default', 'http://localhost/goodmilk/install.php?locale=en&profile=default', '127.0.0.1', 1420944414),
(11, 1, 'actions', 'Action ''%action'' added.', 'a:1:{s:7:"%action";s:27:"Remove post from front page";}', 5, '', 'http://localhost/goodmilk/install.php?locale=en&profile=default', 'http://localhost/goodmilk/install.php?locale=en&profile=default', '127.0.0.1', 1420944414),
(12, 1, 'actions', 'Action ''%action'' added.', 'a:1:{s:7:"%action";s:9:"Save post";}', 5, '', 'http://localhost/goodmilk/install.php?locale=en&profile=default', 'http://localhost/goodmilk/install.php?locale=en&profile=default', '127.0.0.1', 1420944414),
(13, 1, 'actions', 'Action ''%action'' added.', 'a:1:{s:7:"%action";s:18:"Block current user";}', 5, '', 'http://localhost/goodmilk/install.php?locale=en&profile=default', 'http://localhost/goodmilk/install.php?locale=en&profile=default', '127.0.0.1', 1420944414),
(14, 1, 'actions', 'Action ''%action'' added.', 'a:1:{s:7:"%action";s:30:"Ban IP address of current user";}', 5, '', 'http://localhost/goodmilk/install.php?locale=en&profile=default', 'http://localhost/goodmilk/install.php?locale=en&profile=default', '127.0.0.1', 1420944414),
(15, 1, 'update', 'Attempted to fetch information about all available new releases and updates.', 'a:0:{}', 5, '<a href="/goodmilk/admin/reports/updates">view</a>', 'http://localhost/goodmilk/admin', 'http://localhost/goodmilk/', '127.0.0.1', 1420944653),
(16, 1, 'content', '@type: added %title.', 'a:2:{s:5:"@type";s:4:"page";s:6:"%title";s:4:"test";}', 5, '<a href="/goodmilk/node/1">view</a>', 'http://localhost/goodmilk/node/add/page', 'http://localhost/goodmilk/node/add/page', '127.0.0.1', 1420945884),
(17, 1, 'content', 'Updating field type %type with module %module.', 'a:2:{s:5:"%type";s:9:"filefield";s:7:"%module";s:9:"filefield";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(18, 1, 'content', 'Updating widget type %type with module %module.', 'a:2:{s:5:"%type";s:16:"filefield_widget";s:7:"%module";s:9:"filefield";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(19, 1, 'content', 'Updating widget type %type with module %module.', 'a:2:{s:5:"%type";s:17:"imagefield_widget";s:7:"%module";s:10:"imagefield";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(20, 1, 'content', 'Updating field type %type with module %module.', 'a:2:{s:5:"%type";s:14:"number_integer";s:7:"%module";s:6:"number";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(21, 1, 'content', 'Updating field type %type with module %module.', 'a:2:{s:5:"%type";s:14:"number_decimal";s:7:"%module";s:6:"number";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(22, 1, 'content', 'Updating field type %type with module %module.', 'a:2:{s:5:"%type";s:12:"number_float";s:7:"%module";s:6:"number";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(23, 1, 'content', 'Updating widget type %type with module %module.', 'a:2:{s:5:"%type";s:6:"number";s:7:"%module";s:6:"number";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(24, 1, 'content', 'Updating widget type %type with module %module.', 'a:2:{s:5:"%type";s:20:"optionwidgets_select";s:7:"%module";s:13:"optionwidgets";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(25, 1, 'content', 'Updating widget type %type with module %module.', 'a:2:{s:5:"%type";s:21:"optionwidgets_buttons";s:7:"%module";s:13:"optionwidgets";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(26, 1, 'content', 'Updating widget type %type with module %module.', 'a:2:{s:5:"%type";s:19:"optionwidgets_onoff";s:7:"%module";s:13:"optionwidgets";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(27, 1, 'content', 'Updating field type %type with module %module.', 'a:2:{s:5:"%type";s:4:"text";s:7:"%module";s:4:"text";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(28, 1, 'content', 'Updating widget type %type with module %module.', 'a:2:{s:5:"%type";s:14:"text_textfield";s:7:"%module";s:4:"text";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(29, 1, 'content', 'Updating widget type %type with module %module.', 'a:2:{s:5:"%type";s:13:"text_textarea";s:7:"%module";s:4:"text";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(30, 1, 'content', 'Updating field type %type with module %module.', 'a:2:{s:5:"%type";s:13:"userreference";s:7:"%module";s:13:"userreference";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(31, 1, 'content', 'Updating widget type %type with module %module.', 'a:2:{s:5:"%type";s:20:"userreference_select";s:7:"%module";s:13:"userreference";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(32, 1, 'content', 'Updating widget type %type with module %module.', 'a:2:{s:5:"%type";s:21:"userreference_buttons";s:7:"%module";s:13:"userreference";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(33, 1, 'content', 'Updating widget type %type with module %module.', 'a:2:{s:5:"%type";s:26:"userreference_autocomplete";s:7:"%module";s:13:"userreference";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(34, 1, 'content', 'Updating field type %type with module %module.', 'a:2:{s:5:"%type";s:13:"nodereference";s:7:"%module";s:13:"nodereference";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(35, 1, 'content', 'Updating widget type %type with module %module.', 'a:2:{s:5:"%type";s:20:"nodereference_select";s:7:"%module";s:13:"nodereference";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(36, 1, 'content', 'Updating widget type %type with module %module.', 'a:2:{s:5:"%type";s:21:"nodereference_buttons";s:7:"%module";s:13:"nodereference";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(37, 1, 'content', 'Updating widget type %type with module %module.', 'a:2:{s:5:"%type";s:26:"nodereference_autocomplete";s:7:"%module";s:13:"nodereference";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946274),
(38, 1, 'actions', 'Action ''%action'' added.', 'a:1:{s:7:"%action";s:62:"ImageCache: Flush ALL presets for this node''s filefield images";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1420946336),
(39, 1, 'actions', 'Action ''%action'' added.', 'a:1:{s:7:"%action";s:65:"ImageCache: Generate ALL presets for this node''s filefield images";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1420946336),
(40, 1, 'content', 'Updating field type %type with module %module.', 'a:2:{s:5:"%type";s:4:"date";s:7:"%module";s:4:"date";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946558),
(41, 1, 'content', 'Updating field type %type with module %module.', 'a:2:{s:5:"%type";s:9:"datestamp";s:7:"%module";s:4:"date";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946558),
(42, 1, 'content', 'Updating field type %type with module %module.', 'a:2:{s:5:"%type";s:8:"datetime";s:7:"%module";s:4:"date";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946558),
(43, 1, 'content', 'Updating widget type %type with module %module.', 'a:2:{s:5:"%type";s:11:"date_select";s:7:"%module";s:4:"date";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946558),
(44, 1, 'content', 'Updating widget type %type with module %module.', 'a:2:{s:5:"%type";s:9:"date_text";s:7:"%module";s:4:"date";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules', '127.0.0.1', 1420946558),
(45, 0, 'page not found', 'logo.png', 'N;', 4, '', 'http://localhost/goodmilk//logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1420949114),
(46, 0, 'page not found', 'logo.png', 'N;', 4, '', 'http://localhost/goodmilk//logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1420949151),
(47, 1, 'update', 'Attempted to fetch information about all available new releases and updates.', 'a:0:{}', 5, '<a href="/goodmilk/admin/reports/updates">view</a>', 'http://localhost/goodmilk/admin/build/themes', 'http://localhost/goodmilk/admin/build/themes', '127.0.0.1', 1420949804),
(48, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949824),
(49, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949824),
(50, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949824),
(51, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949824),
(52, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949824),
(53, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949824),
(54, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949824),
(55, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949824),
(56, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949824),
(57, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949824),
(58, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949824),
(59, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949824),
(60, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:127:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_breadcrumb'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949824),
(61, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:133:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_menu_local_tasks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949824),
(62, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:160:"include(./sites/all/themes/bootstrap/templates/page.tpl.php) [<a href=''function.include''>function.include</a>]: failed to open stream: No such file or directory";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:1078;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949824),
(63, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:174:"include() [<a href=''function.include''>function.include</a>]: Failed opening ''./sites/all/themes/bootstrap/templates/page.tpl.php'' for inclusion (include_path=''.;C:\\php\\pear'')";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:1078;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949824),
(64, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949828),
(65, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949828),
(66, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949828),
(67, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949828),
(68, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949828),
(69, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949828),
(70, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949828),
(71, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949828),
(72, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949828),
(73, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949828),
(74, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949828),
(75, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:123:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_blocks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949828),
(76, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:127:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_breadcrumb'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949828),
(77, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:133:"call_user_func_array() expects parameter 1 to be a valid callback, function ''zen_menu_local_tasks'' not found or invalid function name";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:668;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949828),
(78, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:160:"include(./sites/all/themes/bootstrap/templates/page.tpl.php) [<a href=''function.include''>function.include</a>]: failed to open stream: No such file or directory";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:1078;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949828),
(79, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:174:"include() [<a href=''function.include''>function.include</a>]: Failed opening ''./sites/all/themes/bootstrap/templates/page.tpl.php'' for inclusion (include_path=''.;C:\\php\\pear'')";s:5:"%file";s:39:"D:\\wamp\\www\\goodmilk\\includes\\theme.inc";s:5:"%line";i:1078;}', 3, '', 'http://localhost/goodmilk/', '', '127.0.0.1', 1420949828),
(80, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421049359),
(81, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421050548),
(82, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421050572),
(83, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/user/login', '127.0.0.1', 1421050585),
(84, 1, 'user', 'Session opened for %name.', 'a:1:{s:5:"%name";s:4:"root";}', 5, '', 'http://localhost/goodmilk/user/login', 'http://localhost/goodmilk/user/login', '127.0.0.1', 1421050596),
(85, 1, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/user/1', '127.0.0.1', 1421050598),
(86, 1, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/user/1', '127.0.0.1', 1421050617),
(87, 1, 'user', 'Session closed for %name.', 'a:1:{s:5:"%name";s:4:"root";}', 5, '', 'http://localhost/goodmilk/logout', 'http://localhost/goodmilk/user/1', '127.0.0.1', 1421050634),
(88, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421050635),
(89, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421051149),
(90, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421051198),
(91, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421051341),
(92, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421051510),
(93, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421051848),
(94, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421051954),
(95, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421051978),
(96, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421052032),
(97, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421052218),
(98, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/user/login', '127.0.0.1', 1421052262),
(99, 1, 'user', 'Session opened for %name.', 'a:1:{s:5:"%name";s:4:"root";}', 5, '', 'http://localhost/goodmilk/user/login', 'http://localhost/goodmilk/user/login', '127.0.0.1', 1421052271),
(100, 1, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/user/1', '127.0.0.1', 1421052273),
(101, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421052395),
(102, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421052403),
(103, 1, 'update', 'Attempted to fetch information about all available new releases and updates.', 'a:0:{}', 5, '<a href="/goodmilk/admin/reports/updates">view</a>', 'http://localhost/goodmilk/admin/build/themes', '', '127.0.0.1', 1421052403),
(104, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421052462),
(105, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421052471),
(106, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421052532),
(107, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421052654),
(108, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421052670),
(109, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421052697),
(110, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421052956),
(111, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421053041),
(112, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421053083),
(113, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421053101),
(114, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421053368),
(115, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421053439),
(116, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421053539),
(117, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421054252),
(118, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421054307),
(119, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421054330),
(120, 0, 'page not found', 'node/sites/all/themes/bootstrap/images/slide-01.jpg', 'N;', 4, '', 'http://localhost/goodmilk/node/sites/all/themes/bootstrap/images/slide-01.jpg', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054402),
(121, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054402),
(122, 0, 'page not found', 'node/sites/all/themes/bootstrap/images/slide-03.jpg', 'N;', 4, '', 'http://localhost/goodmilk/node/sites/all/themes/bootstrap/images/slide-03.jpg', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054402),
(123, 0, 'page not found', 'node/sites/all/themes/bootstrap/images/slide-02.jpg', 'N;', 4, '', 'http://localhost/goodmilk/node/sites/all/themes/bootstrap/images/slide-02.jpg', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054402),
(124, 0, 'page not found', 'node/sites/all/themes/bootstrap/images/slide-03.jpg', 'N;', 4, '', 'http://localhost/goodmilk/node/sites/all/themes/bootstrap/images/slide-03.jpg', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054411),
(125, 0, 'page not found', 'node/sites/all/themes/bootstrap/images/slide-01.jpg', 'N;', 4, '', 'http://localhost/goodmilk/node/sites/all/themes/bootstrap/images/slide-01.jpg', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054411),
(126, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054411),
(127, 0, 'page not found', 'node/sites/all/themes/bootstrap/images/slide-02.jpg', 'N;', 4, '', 'http://localhost/goodmilk/node/sites/all/themes/bootstrap/images/slide-02.jpg', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054411),
(128, 0, 'page not found', 'node/sites/all/themes/bootstrap/images/slide-01.jpg', 'N;', 4, '', 'http://localhost/goodmilk/node/sites/all/themes/bootstrap/images/slide-01.jpg', '', '127.0.0.1', 1421054427),
(129, 0, 'page not found', 'node/sites/all/themes/bootstrap/images/slide-02.jpg', 'N;', 4, '', 'http://localhost/goodmilk/node/sites/all/themes/bootstrap/images/slide-02.jpg', '', '127.0.0.1', 1421054438),
(130, 0, 'page not found', 'node/sites/all/themes/bootstrap/images/slide-01.jpg', 'N;', 4, '', 'http://localhost/goodmilk/node/sites/all/themes/bootstrap/images/slide-01.jpg', '', '127.0.0.1', 1421054438),
(131, 0, 'page not found', 'node/sites/all/themes/bootstrap/images/slide-02.jpg', 'N;', 4, '', 'http://localhost/goodmilk/node/sites/all/themes/bootstrap/images/slide-02.jpg', '', '127.0.0.1', 1421054440),
(132, 0, 'page not found', 'node/sites/all/themes/bootstrap/images/slide-03.jpg', 'N;', 4, '', 'http://localhost/goodmilk/node/sites/all/themes/bootstrap/images/slide-03.jpg', '', '127.0.0.1', 1421054448),
(133, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054561),
(134, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054599),
(135, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054610),
(136, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054617),
(137, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054671),
(138, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054681),
(139, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054708),
(140, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054711),
(141, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054722),
(142, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421054724),
(143, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421055839),
(144, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421056111),
(145, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/', '127.0.0.1', 1421056206),
(146, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421056248),
(147, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421056327),
(148, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421056939),
(149, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421057016),
(150, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421057145),
(151, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421057911),
(152, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421058088),
(153, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421058226),
(154, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421058256),
(155, 0, 'page not found', 'goodmilk/node/1', 'N;', 4, '', 'http://localhost/goodmilk//goodmilk/node/1', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421058267),
(156, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk//goodmilk/node/1', '127.0.0.1', 1421058268),
(157, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421058271),
(158, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421058297),
(159, 1, 'content', '@type: added %title.', 'a:2:{s:5:"@type";s:4:"page";s:6:"%title";s:10:"Gioi Thieu";}', 5, '<a href="/goodmilk/content/gioi-thieu">view</a>', 'http://localhost/goodmilk/node/add/page', 'http://localhost/goodmilk/node/add/page', '127.0.0.1', 1421058350),
(160, 1, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/content/gioi-thieu', '127.0.0.1', 1421058351),
(161, 1, 'content', '@type: added %title.', 'a:2:{s:5:"@type";s:4:"page";s:6:"%title";s:8:"San Pham";}', 5, '<a href="/goodmilk/content/san-pham">view</a>', 'http://localhost/goodmilk/node/add/page', 'http://localhost/goodmilk/node/add/page', '127.0.0.1', 1421058378),
(162, 1, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/content/san-pham', '127.0.0.1', 1421058379),
(163, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421058411),
(164, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421058489),
(165, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421058518),
(166, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421058609),
(167, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421059071),
(168, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421059134),
(169, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421059172),
(170, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421059255),
(171, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421059453),
(172, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421059530),
(173, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421059639),
(174, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421059656),
(175, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421059911),
(176, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421059935),
(177, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421060017),
(178, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421060042),
(179, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421060191),
(180, 0, 'page not found', 'sites/all/themes/bootstrap/logo.png', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/logo.png', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421060280),
(181, 1, 'user', 'Session closed for %name.', 'a:1:{s:5:"%name";s:4:"root";}', 5, '', 'http://localhost/goodmilk/logout', 'http://localhost/goodmilk/', '127.0.0.1', 1421115388),
(182, 1, 'user', 'Session opened for %name.', 'a:1:{s:5:"%name";s:4:"root";}', 5, '', 'http://localhost/goodmilk/user/login', 'http://localhost/goodmilk/user/login', '127.0.0.1', 1421116737),
(183, 1, 'timezone', 'Detected time zone: %timezone; client date: %date; abbreviation: %abbreviation; offset: %offset; daylight saving time: %is_daylight_saving_time.', 'a:5:{s:9:"%timezone";s:16:"Asia/Krasnoyarsk";s:5:"%date";s:57:"Tue Jan 13 2015 10:09:16 GMT+0700 (SE Asia Standard Time)";s:13:"%abbreviation";s:0:"";s:7:"%offset";s:5:"25200";s:24:"%is_daylight_saving_time";N;}', 5, '', 'http://localhost/goodmilk/?q=user%2Ftimezone%2F0%2F25200%2F&date=Tue+Jan+13+2015+10%3A09%3A16+GMT%2B0700+(SE+Asia+Standard+Time)', 'http://localhost/goodmilk/user/1/edit', '127.0.0.1', 1421118556),
(184, 0, 'access denied', 'admin/build/views', 'N;', 4, '', 'http://localhost/goodmilk/admin/build/views', 'http://localhost/goodmilk/admin/settings/file-system', '127.0.0.1', 1421127580),
(185, 1, 'user', 'Session opened for %name.', 'a:1:{s:5:"%name";s:4:"root";}', 5, '', 'http://localhost/goodmilk/user/login', 'http://localhost/goodmilk/user/login', '127.0.0.1', 1421127606),
(186, 1, 'mail', 'Contact form: category %category added.', 'a:1:{s:9:"%category";s:7:"contact";}', 5, '<a href="/goodmilk/admin/build/contact">view</a>', 'http://localhost/goodmilk/admin/build/contact/add', 'http://localhost/goodmilk/admin/build/contact/add', '127.0.0.1', 1421127713),
(187, 1, 'page not found', 'contact-us', 'N;', 4, '', 'http://localhost/goodmilk/contact-us', '', '127.0.0.1', 1421127881),
(188, 1, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:102:"max() [<a href=''function.max''>function.max</a>]: When only one parameter is given, it must be an array";s:5:"%file";s:73:"D:\\wamp\\www\\goodmilk\\sites\\all\\modules\\contact_field\\contact_field.module";s:5:"%line";i:104;}', 3, '', 'http://localhost/goodmilk/contact', '', '127.0.0.1', 1421127889),
(189, 1, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:102:"max() [<a href=''function.max''>function.max</a>]: When only one parameter is given, it must be an array";s:5:"%file";s:73:"D:\\wamp\\www\\goodmilk\\sites\\all\\modules\\contact_field\\contact_field.module";s:5:"%line";i:105;}', 3, '', 'http://localhost/goodmilk/contact', '', '127.0.0.1', 1421127889),
(190, 1, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:102:"min() [<a href=''function.min''>function.min</a>]: When only one parameter is given, it must be an array";s:5:"%file";s:73:"D:\\wamp\\www\\goodmilk\\sites\\all\\modules\\contact_field\\contact_field.module";s:5:"%line";i:106;}', 3, '', 'http://localhost/goodmilk/contact', '', '127.0.0.1', 1421127889),
(191, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:102:"max() [<a href=''function.max''>function.max</a>]: When only one parameter is given, it must be an array";s:5:"%file";s:73:"D:\\wamp\\www\\goodmilk\\sites\\all\\modules\\contact_field\\contact_field.module";s:5:"%line";i:104;}', 3, '', 'http://localhost/goodmilk/contact', '', '127.0.0.1', 1421127913);
INSERT INTO `watchdog` (`wid`, `uid`, `type`, `message`, `variables`, `severity`, `link`, `location`, `referer`, `hostname`, `timestamp`) VALUES
(192, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:102:"max() [<a href=''function.max''>function.max</a>]: When only one parameter is given, it must be an array";s:5:"%file";s:73:"D:\\wamp\\www\\goodmilk\\sites\\all\\modules\\contact_field\\contact_field.module";s:5:"%line";i:105;}', 3, '', 'http://localhost/goodmilk/contact', '', '127.0.0.1', 1421127913),
(193, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:102:"min() [<a href=''function.min''>function.min</a>]: When only one parameter is given, it must be an array";s:5:"%file";s:73:"D:\\wamp\\www\\goodmilk\\sites\\all\\modules\\contact_field\\contact_field.module";s:5:"%line";i:106;}', 3, '', 'http://localhost/goodmilk/contact', '', '127.0.0.1', 1421127913),
(194, 1, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:102:"max() [<a href=''function.max''>function.max</a>]: When only one parameter is given, it must be an array";s:5:"%file";s:73:"D:\\wamp\\www\\goodmilk\\sites\\all\\modules\\contact_field\\contact_field.module";s:5:"%line";i:104;}', 3, '', 'http://localhost/goodmilk/contact', '', '127.0.0.1', 1421127930),
(195, 1, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:102:"max() [<a href=''function.max''>function.max</a>]: When only one parameter is given, it must be an array";s:5:"%file";s:73:"D:\\wamp\\www\\goodmilk\\sites\\all\\modules\\contact_field\\contact_field.module";s:5:"%line";i:105;}', 3, '', 'http://localhost/goodmilk/contact', '', '127.0.0.1', 1421127930),
(196, 1, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:102:"min() [<a href=''function.min''>function.min</a>]: When only one parameter is given, it must be an array";s:5:"%file";s:73:"D:\\wamp\\www\\goodmilk\\sites\\all\\modules\\contact_field\\contact_field.module";s:5:"%line";i:106;}', 3, '', 'http://localhost/goodmilk/contact', '', '127.0.0.1', 1421127930),
(197, 1, 'locale', 'The %language language (%code) has been created.', 'a:2:{s:9:"%language";s:10:"Vietnamese";s:5:"%code";s:2:"vi";}', 5, '', 'http://localhost/goodmilk/admin/settings/language/add', 'http://localhost/goodmilk/admin/settings/language/add', '127.0.0.1', 1421132071),
(198, 1, 'node', 'Added content type %name.', 'a:1:{s:5:"%name";s:7:"Contact";}', 5, '<a href="/goodmilk/admin/content/types">view</a>', 'http://localhost/goodmilk/admin/content/types/add', 'http://localhost/goodmilk/admin/content/types/add', '127.0.0.1', 1421134911),
(199, 1, 'content', '@type: added %title.', 'a:2:{s:5:"@type";s:7:"contact";s:6:"%title";s:82:"Số 413/7/6 Lê Văn Quới, KP.5 P. Bình Trị Đông A, Q. Bình Tân, TP. HCM";}', 5, '<a href="/goodmilk/content/s%E1%BB%91-41376-l%C3%AA-v%C4%83n-qu%E1%BB%9Bi-kp5-p-b%C3%ACnh-tr%E1%BB%8B-%C4%91%C3%B4ng-q-b%C3%ACnh-t%C3%A2n-tp-hcm">view</a>', 'http://localhost/goodmilk/node/add/contact', 'http://localhost/goodmilk/node/add/contact', '127.0.0.1', 1421135320),
(200, 1, 'content', '@type: deleted %title.', 'a:2:{s:5:"@type";s:7:"contact";s:6:"%title";s:82:"Số 413/7/6 Lê Văn Quới, KP.5 P. Bình Trị Đông A, Q. Bình Tân, TP. HCM";}', 5, '', 'http://localhost/goodmilk/admin/content/node', 'http://localhost/goodmilk/admin/content/node', '127.0.0.1', 1421135398),
(201, 1, 'content', '@type: added %title.', 'a:2:{s:5:"@type";s:7:"contact";s:6:"%title";s:10:"Liên hệ";}', 5, '<a href="/goodmilk/content/li%C3%AAn-h%E1%BB%87">view</a>', 'http://localhost/goodmilk/node/add/contact', 'http://localhost/goodmilk/node/add/contact', '127.0.0.1', 1421135793),
(202, 1, 'content', '@type: added %title.', 'a:2:{s:5:"@type";s:7:"contact";s:6:"%title";s:2:"12";}', 5, '<a href="/goodmilk/content/12">view</a>', 'http://localhost/goodmilk/node/add/contact', 'http://localhost/goodmilk/node/add/contact', '127.0.0.1', 1421136351),
(203, 1, 'content', '@type: deleted %title.', 'a:2:{s:5:"@type";s:7:"contact";s:6:"%title";s:2:"12";}', 5, '', 'http://localhost/goodmilk/admin/content/node', 'http://localhost/goodmilk/admin/content/node', '127.0.0.1', 1421138026),
(204, 1, 'content', '@type: updated %title.', 'a:2:{s:5:"@type";s:7:"contact";s:6:"%title";s:10:"Liên hệ";}', 5, '<a href="/goodmilk/content/li%C3%AAn-h%E1%BB%87">view</a>', 'http://localhost/goodmilk/node/5/edit?destination=admin%2Fcontent%2Fnode', 'http://localhost/goodmilk/node/5/edit?destination=admin%2Fcontent%2Fnode', '127.0.0.1', 1421138039),
(205, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:48:"field:contact-field_contact_address:widget_label";s:10:"%textgroup";s:3:"cck";s:7:"%string";s:7:"Address";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(206, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:46:"field:contact-field_contact_email:widget_label";s:10:"%textgroup";s:3:"cck";s:7:"%string";s:5:"Email";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(207, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:44:"field:contact-field_contact_fax:widget_label";s:10:"%textgroup";s:3:"cck";s:7:"%string";s:3:"Fax";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(208, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:47:"field:contact-field_contact_mobile:widget_label";s:10:"%textgroup";s:3:"cck";s:7:"%string";s:6:"Mobile";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(209, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:46:"field:contact-field_contact_phone:widget_label";s:10:"%textgroup";s:3:"cck";s:7:"%string";s:5:"Phone";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(210, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:48:"field:contact-field_contact_website:widget_label";s:10:"%textgroup";s:3:"cck";s:7:"%string";s:7:"Website";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(211, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:14:"type:poll:name";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:4:"Poll";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(212, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:15:"type:poll:title";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:8:"Question";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(213, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:21:"type:poll:description";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:191:"A <em>poll</em> is a question with a set of possible responses. A <em>poll</em>, once created, automatically provides a simple running count of the number of votes received for each response.";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(214, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:17:"type:contact:name";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:7:"Contact";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(215, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:18:"type:contact:title";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:5:"Title";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(216, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:14:"type:page:name";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:4:"Page";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(217, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:15:"type:page:title";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:5:"Title";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(218, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:14:"type:page:body";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:4:"Body";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(219, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:21:"type:page:description";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:296:"A <em>page</em>, similar in form to a <em>story</em>, is a simple method for creating and displaying information that rarely changes, such as an "About us" section of a website. By default, a <em>page</em> entry does not allow visitor comments and is not featured on the site''s initial home page.";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(220, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:15:"type:story:name";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:5:"Story";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(221, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:16:"type:story:title";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:5:"Title";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(222, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:15:"type:story:body";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:4:"Body";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(223, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:22:"type:story:description";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:392:"A <em>story</em>, similar in form to a <em>page</em>, is ideal for creating and displaying content that informs or engages website visitors. Press releases, site announcements, and informal blog-like entries may all be created with a <em>story</em> entry. By default, a <em>story</em> entry is automatically featured on the site''s initial home page, and provides the ability to post comments.";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139507),
(224, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:14:"item:225:title";s:10:"%textgroup";s:4:"menu";s:7:"%string";s:9:"Trang Chu";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139508),
(225, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:14:"item:430:title";s:10:"%textgroup";s:4:"menu";s:7:"%string";s:10:"Gioi Thieu";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139508),
(226, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:14:"item:443:title";s:10:"%textgroup";s:4:"menu";s:7:"%string";s:8:"San Pham";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139508),
(227, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:14:"item:444:title";s:10:"%textgroup";s:4:"menu";s:7:"%string";s:11:"Liện hệ";}', 5, '', 'http://localhost/goodmilk/admin/build/modules/list/confirm', 'http://localhost/goodmilk/admin/build/modules/list/confirm', '127.0.0.1', 1421139508),
(228, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:14:"item:557:title";s:10:"%textgroup";s:4:"menu";s:7:"%string";s:10:"Gioi Thieu";}', 5, '', 'http://localhost/goodmilk/admin/build/menu-customize/primary-links/add', 'http://localhost/goodmilk/admin/build/menu-customize/primary-links/add', '127.0.0.1', 1421141711),
(229, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:121:"call_user_func_array() expects parameter 1 to be a valid callback, function ''vsk_home'' not found or invalid function name";s:5:"%file";s:38:"D:\\wamp\\www\\goodmilk\\includes\\menu.inc";s:5:"%line";i:349;}', 3, '', 'http://localhost/goodmilk/intro', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421141743),
(230, 0, 'php', '%message in %file on line %line.', 'a:4:{s:6:"%error";s:7:"warning";s:8:"%message";s:121:"call_user_func_array() expects parameter 1 to be a valid callback, function ''vsk_home'' not found or invalid function name";s:5:"%file";s:38:"D:\\wamp\\www\\goodmilk\\includes\\menu.inc";s:5:"%line";i:349;}', 3, '', 'http://localhost/goodmilk/intro', 'http://localhost/goodmilk/node/1', '127.0.0.1', 1421141746),
(231, 1, 'menu', 'Deleted menu item %title.', 'a:1:{s:6:"%title";s:10:"Gioi Thieu";}', 5, '', 'http://localhost/goodmilk/admin/build/menu/item/430/delete', 'http://localhost/goodmilk/admin/build/menu/item/430/delete', '127.0.0.1', 1421142079),
(232, 1, 'menu', 'Deleted menu item %title.', 'a:1:{s:6:"%title";s:8:"San Pham";}', 5, '', 'http://localhost/goodmilk/admin/build/menu/item/443/delete', 'http://localhost/goodmilk/admin/build/menu/item/443/delete', '127.0.0.1', 1421142112),
(233, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:15:"type:intro:name";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:5:"Intro";}', 5, '', 'http://localhost/goodmilk/admin/content/types/add', 'http://localhost/goodmilk/admin/content/types/add', '127.0.0.1', 1421142972),
(234, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:16:"type:intro:title";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:5:"Title";}', 5, '', 'http://localhost/goodmilk/admin/content/types/add', 'http://localhost/goodmilk/admin/content/types/add', '127.0.0.1', 1421142972),
(235, 1, 'node', 'Added content type %name.', 'a:1:{s:5:"%name";s:5:"Intro";}', 5, '<a href="/goodmilk/admin/content/types">view</a>', 'http://localhost/goodmilk/admin/content/types/add', 'http://localhost/goodmilk/admin/content/types/add', '127.0.0.1', 1421142972),
(236, 0, 'page not found', 'www.youtube.com/embed/pTbzXl4rMK0', 'N;', 4, '', 'http://localhost/goodmilk/www.youtube.com/embed/pTbzXl4rMK0', 'http://localhost/goodmilk/intro', '127.0.0.1', 1421143616),
(237, 1, 'content', '@type: added %title.', 'a:2:{s:5:"@type";s:5:"intro";s:6:"%title";s:122:"Với hơn 5 năm hoạt động trong lĩnh vực dinh dưỡng chúng tôi đã đạt được những thành tựu sau";}', 5, '<a href="/goodmilk/content/v%E1%BB%9Bi-h%C6%A1n-5-n%C4%83m-ho%E1%BA%A1t-%C4%91%E1%BB%99ng-trong-l%C4%A9nh-v%E1%BB%B1c-dinh-d%C6%B0%E1%BB%A1ng-ch%C3%BAng-t%C3%B4i-%C4%91%C3%A3-%C4%91%E1%BA%A1t-%C4%91%C6%B0%E1%BB%A3c-nh%E1%BB%AFng-th%C3%A0nh-t%E1%BB%B1u-sau', 'http://localhost/goodmilk/node/add/intro', 'http://localhost/goodmilk/node/add/intro', '127.0.0.1', 1421144431),
(238, 1, 'access denied', 'user/login', 'N;', 4, '', 'http://localhost/goodmilk/user/login', '', '127.0.0.1', 1421146342),
(239, 1, 'access denied', 'user/login', 'N;', 4, '', 'http://localhost/goodmilk/user/login', '', '127.0.0.1', 1421289376),
(240, 0, 'page not found', 'images/bg-sp.png', 'N;', 4, '', 'http://localhost/goodmilk/images/bg-sp.png', 'http://localhost/goodmilk/home', '127.0.0.1', 1421297882),
(241, 0, 'page not found', 'sites/all/themes/bootstrap/css/ajax-loader.gif', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/css/ajax-loader.gif', 'http://localhost/goodmilk/sites/all/themes/bootstrap/css/bootstrap-custom.css?k', '127.0.0.1', 1421297882),
(242, 0, 'page not found', 'images/bg-sp.png', 'N;', 4, '', 'http://localhost/goodmilk/images/bg-sp.png', '', '127.0.0.1', 1421297928),
(243, 0, 'page not found', 'sites/all/themes/bootstrap/css/ajax-loader.gif', 'N;', 4, '', 'http://localhost/goodmilk/sites/all/themes/bootstrap/css/ajax-loader.gif', 'http://localhost/goodmilk/sites/all/themes/bootstrap/css/bootstrap-custom.css?k', '127.0.0.1', 1421298017),
(244, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:14:"type:home:name";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:4:"Home";}', 5, '', 'http://localhost/goodmilk/admin/content/types/add', 'http://localhost/goodmilk/admin/content/types/add', '127.0.0.1', 1421304113),
(245, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:15:"type:home:title";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:5:"Title";}', 5, '', 'http://localhost/goodmilk/admin/content/types/add', 'http://localhost/goodmilk/admin/content/types/add', '127.0.0.1', 1421304113),
(246, 1, 'node', 'Added content type %name.', 'a:1:{s:5:"%name";s:4:"Home";}', 5, '<a href="/goodmilk/admin/content/types">view</a>', 'http://localhost/goodmilk/admin/content/types/add', 'http://localhost/goodmilk/admin/content/types/add', '127.0.0.1', 1421304114),
(247, 1, 'content', '@type: added %title.', 'a:2:{s:5:"@type";s:4:"home";s:6:"%title";s:111:"Với hơn 10 dòng sản phẩm chính, đáp ứng nhu cầu dinh dưỡng hàng ngày cho mọi lứa tuổi";}', 5, '<a href="/goodmilk/content/v%E1%BB%9Bi-h%C6%A1n-10-d%C3%B2ng-s%E1%BA%A3n-ph%E1%BA%A9m-ch%C3%ADnh-%C4%91%C3%A1p-%E1%BB%A9ng-nhu-c%E1%BA%A7u-dinh-d%C6%B0%E1%BB%A1ng-h%C3%A0ng-ng%C3%A0y-cho-m%E1%BB%8Di-l%E1%BB%A9a-tu%E1%BB%95i">view</a>', 'http://localhost/goodmilk/node/add/home', 'http://localhost/goodmilk/node/add/home', '127.0.0.1', 1421304674),
(248, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:14:"item:610:title";s:10:"%textgroup";s:4:"menu";s:7:"%string";s:15:"HT Phân Phối";}', 5, '', 'http://localhost/goodmilk/admin/build/menu-customize/primary-links/add', 'http://localhost/goodmilk/admin/build/menu-customize/primary-links/add', '127.0.0.1', 1421309404),
(249, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:22:"type:distribution:name";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:12:"Distribution";}', 5, '', 'http://localhost/goodmilk/admin/content/types/add', 'http://localhost/goodmilk/admin/content/types/add', '127.0.0.1', 1421309574),
(250, 1, 'i18nstrings', 'Created string %location for text group %textgroup: %string', 'a:3:{s:9:"%location";s:23:"type:distribution:title";s:10:"%textgroup";s:8:"nodetype";s:7:"%string";s:5:"Title";}', 5, '', 'http://localhost/goodmilk/admin/content/types/add', 'http://localhost/goodmilk/admin/content/types/add', '127.0.0.1', 1421309574),
(251, 1, 'node', 'Added content type %name.', 'a:1:{s:5:"%name";s:12:"Distribution";}', 5, '<a href="/goodmilk/admin/content/types">view</a>', 'http://localhost/goodmilk/admin/content/types/add', 'http://localhost/goodmilk/admin/content/types/add', '127.0.0.1', 1421309575),
(252, 1, 'content', '@type: added %title.', 'a:2:{s:5:"@type";s:12:"distribution";s:6:"%title";s:15:"HT Phân Phối";}', 5, '<a href="/goodmilk/content/ht-ph%C3%A2n-ph%E1%BB%91i">view</a>', 'http://localhost/goodmilk/node/add/distribution', 'http://localhost/goodmilk/node/add/distribution', '127.0.0.1', 1421309676);

-- --------------------------------------------------------

--
-- Table structure for table `wysiwyg`
--

CREATE TABLE IF NOT EXISTS `wysiwyg` (
  `format` int(11) NOT NULL DEFAULT '0',
  `editor` varchar(128) NOT NULL DEFAULT '',
  `settings` text,
  PRIMARY KEY (`format`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wysiwyg`
--

INSERT INTO `wysiwyg` (`format`, `editor`, `settings`) VALUES
(1, '', NULL),
(2, 'ckeditor', 'a:20:{s:7:"default";i:1;s:11:"user_choose";i:0;s:11:"show_toggle";i:1;s:5:"theme";s:8:"advanced";s:8:"language";s:2:"en";s:7:"buttons";a:2:{s:7:"default";a:34:{s:4:"Bold";i:1;s:6:"Italic";i:1;s:9:"Underline";i:1;s:6:"Strike";i:1;s:11:"JustifyLeft";i:1;s:13:"JustifyCenter";i:1;s:12:"JustifyRight";i:1;s:12:"JustifyBlock";i:1;s:12:"BulletedList";i:1;s:12:"NumberedList";i:1;s:7:"Outdent";i:1;s:6:"Indent";i:1;s:4:"Redo";i:1;s:4:"Link";i:1;s:6:"Anchor";i:1;s:5:"Image";i:1;s:7:"BGColor";i:1;s:10:"Blockquote";i:1;s:6:"Source";i:1;s:3:"Cut";i:1;s:4:"Copy";i:1;s:5:"Paste";i:1;s:9:"PasteText";i:1;s:13:"PasteFromWord";i:1;s:12:"RemoveFormat";i:1;s:6:"Format";i:1;s:4:"Font";i:1;s:8:"FontSize";i:1;s:6:"Styles";i:1;s:5:"Table";i:1;s:9:"SelectAll";i:1;s:7:"Replace";i:1;s:9:"CreateDiv";i:1;s:12:"SpellChecker";i:1;}s:4:"imce";a:1:{s:4:"imce";i:1;}}s:11:"toolbar_loc";s:3:"top";s:13:"toolbar_align";s:4:"left";s:8:"path_loc";s:6:"bottom";s:8:"resizing";i:1;s:11:"verify_html";i:1;s:12:"preformatted";i:0;s:22:"convert_fonts_to_spans";i:1;s:17:"remove_linebreaks";i:1;s:23:"apply_source_formatting";i:0;s:27:"paste_auto_cleanup_on_paste";i:0;s:13:"block_formats";s:32:"p,address,pre,h2,h3,h4,h5,h6,div";s:11:"css_setting";s:5:"theme";s:8:"css_path";s:0:"";s:11:"css_classes";s:0:"";}'),
(3, '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wysiwyg_user`
--

CREATE TABLE IF NOT EXISTS `wysiwyg_user` (
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `format` int(11) DEFAULT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0',
  KEY `uid` (`uid`),
  KEY `format` (`format`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wysiwyg_user`
--

